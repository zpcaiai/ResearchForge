# Paper fixtures — provenance

`arxiv_1706.03762_abs.html` is a small deterministic HTML fixture derived from the metadata and
abstract displayed at `https://arxiv.org/abs/1706.03762` for *Attention Is All You Need*. It is not
a byte-for-byte capture of arXiv's landing page. It deliberately contains only abstract-page
content: the pipeline tests that ResearchForge detects the incomplete input instead of treating it
as full-text evidence.

The real-PDF ingestion tests use three optional local fixtures. They skip, rather than pass, when
those files are absent from a source distribution:

- `icml2024_pinn_loss_landscape.pdf`
- `ieee_unimoe_audio.pdf`
- `qwenlong_l1_5.pdf`

Those PDFs are not redistributed here because the source repositories do not establish a clear
redistribution grant for the papers themselves. See `docs/PDF_INGEST_QUALITY.md` for the measured
results and source repository revisions.
