---
name: sandbox-provisioner
description: Use before any generated or untrusted code executes, and whenever an evaluator must stay invisible to the agent being evaluated. Trigger at run setup, not at first execution.
version: 0.3.0
stage: 00-runtime
artifact_kind: workflow-skill
implementation_status: specification-ready
consolidates: [sandbox-provisioner]
---

# sandbox-provisioner

## Objective

Provide a pinned, least-privilege execution environment, and keep the grader context out of the agent's reach.

**Unchanged from v0.2.0** (`sandbox-provisioner`).

Kept whole. It is provisioned in phase 0 — reproduction needs it long before any experiment spec exists — which is precisely why v0.2.0's edge from experiment specs into the sandbox was a genuine design error.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: sandbox security profile`
- `external: sandbox image reference (local-only; default python:3.11-slim)`
- `external: literal strict-Docker NVIDIA GPU requirement for this invocation`
- `external: literal trusted-host authorization for this invocation`

## Outputs

- `environment_lock`
- `sandbox_container_config`
- `sandbox_manifest`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Validate an absolute Docker launch entry, its resolved client target and target hash, a local
   Unix-socket context/endpoint, and a stable Linux daemon identity; remote SSH/TCP contexts fail
   closed. Keep the launch entry separate from the resolved target: symlinked/multicall clients
   dispatch on `argv[0]`, so probes and runs use the validated launch entry while identity is bound
   to the resolved target bytes. Resolve an already-local image to its immutable image ID.
   A `docker` executable on `PATH` is not validation, and provisioning does not pull implicitly.
   `sandbox_image` may name an operator-prepared dependency image; it is validated as a safe image
   reference and still resolved locally and executed by immutable ID with `--pull=never`.
2. Smoke-run the immutable image as uid 65534 with an explicit Python entrypoint, no network,
   read-only root, dropped capabilities and no-new-privileges. Do not enable execution if this fails.
3. Capture `python -m pip freeze --all` inside that exact restricted image. The strict environment
   lock names the image and daemon; it never substitutes the host package set. Trusted-host mode
   measures the explicitly selected host Python instead.
4. Mount only required project/data paths and provide least-privilege secrets.
5. When `sandbox_gpu_required=true`, run a second restrictive smoke container with Docker's
   `--gpus all` allocation and a fixed `torch.cuda` probe. Record the typed device names/count,
   capabilities, PyTorch/CUDA versions and immutable image/daemon identity; otherwise fail closed.
6. Apply CPU/GPU/memory/time/process/network limits.
7. When evaluation could be gamed, put evaluator in a separate grader context invisible to the agent.

## Hard gates

- Untrusted generated code cannot run on the host by default.
- `untrusted_code_execution_allowed=true` requires a reachable Docker daemon, a local immutable
  image ID, and a container contract that disables networking, uses a read-only root filesystem,
  and does not mount the hidden evaluator. The runner re-checks that complete contract.
- `trusted-host-code` requires both the exact profile and literal `trusted_host_authorized=true` on
  the current provisioner invocation. The resulting manifest and config bind that authorization to
  the provisioner run ID. A later resumed runner must independently receive the literal authorization
  and the two stored records must still agree; a pre-existing project artifact alone is never
  authorization. It leaves
  `untrusted_code_execution_allowed=false`, records `isolation=none`, and records that host network
  access is unrestricted. It must never be presented as a sandbox or as no-network execution.
- Private evaluator and hidden tests are never mounted into the agent context.
- A strict environment lock is measured in the immutable execution image under the same restrictive
  flags. Failure to measure it blocks provisioning; a host `pip freeze` is not container provenance.
- GPU exposure is opt-in and strict-Docker-only. A literal `sandbox_gpu_required=true` requires an
  NVIDIA-capable local engine, a compatible PyTorch/CUDA image and a successful restrictive
  in-container probe. A host `nvidia-smi` result or CUDA-capable image label alone never enables or
  certifies GPU execution. The live acceptance run remains external evidence until performed on
  such a host, but device allocation itself is implemented and persisted.

## Verification / tests

- A legacy manifest that merely says `isolation=container` cannot start any process.
- A validated Docker fixture emits a `docker run --network none --read-only` invocation using the
  immutable image ID and mounting only generated code; tests mock Docker and require no daemon.
- If the validated Docker backend disappears, runs are `NOT_RUN` and no host fallback occurs.
- Remote/changed Docker engines and images that cannot run restricted non-root Python fail closed.
  A symlinked/multicall Docker fixture proves that context, image and smoke commands retain the
  validated launch entry while the resolved target and its hash remain independently recorded.
- GPU-required fixtures must emit the exact `--gpus all` request and typed probe evidence; malformed,
  unavailable or host-only GPUs leave the backend disabled and the acceptance harness untouched.
- Agent cannot read hidden evaluator fixture.

## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured failure record rather than degrading the honesty of the report.

## Upstream inspiration (conceptual, not vendored text)

See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their text.
