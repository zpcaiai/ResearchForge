#!/usr/bin/env bash
# Worked example. Usage: ./run.sh [new-project-dir]
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
if [ "$#" -gt 1 ]; then
  echo "usage: $0 [new-project-dir]" >&2
  exit 64
fi
if [ "$#" -eq 1 ]; then
  PROJ="$1"
  case "$PROJ" in
    ""|/|"$HOME"|"$ROOT"|"$HERE")
      echo "refusing unsafe project directory: $PROJ" >&2
      exit 64
      ;;
  esac
  if [ -e "$PROJ" ] || [ -L "$PROJ" ]; then
    echo "project directory must be a new path; refusing to overwrite: $PROJ" >&2
    exit 73
  fi
else
  PROJ="$(mktemp -d /tmp/rf-example.XXXXXX)"
fi
CLI="node $ROOT/packages/cli/dist/cli.js"
PAPER="$ROOT/fixtures/papers/arxiv_1706.03762_abs.html"
RF_PYTHON="${RESEARCHFORGE_PYTHON:-python3}"
if ! "$RF_PYTHON" -c 'from researchforge.runner import main' >/dev/null 2>&1; then
  echo "ResearchForge Python runtime is unavailable via $RF_PYTHON." >&2
  echo "Install pip install -e 'python[dev]' or set RESEARCHFORGE_PYTHON to that environment." >&2
  exit 69
fi
export RESEARCHFORGE_PYTHON="$RF_PYTHON"

# The experiment, manuscript, deck and release stages are paid features. This is a
# demo of the machinery, so it overrides the gate — which is recorded in the run's
# provenance and surfaces in the release manifest, exactly as it should be.
export RESEARCHFORGE_ALLOW_UNLICENSED=1

COMMON=(--project "$PROJ" --offline
  --set 'security_profile=trusted-host-code'
  --set 'trusted_host_authorized=true'
  --set 'hypothesis=Attention entropy drifts toward uniform as sequence length exceeds the trained regime'
  --set 'candidate_method=numpy probe of scaled dot-product attention entropy across sequence lengths'
  --set 'resource_envelope={"gpu_hours":0,"usd":0,"wallclock_hours":4,"seeds":7}'
  --set 'research_objective=characterize length-generalization failure modes of attention'
  --set 'submission_schema={"mechanism_activation":"float","failure_mode_incidence":"float"}')

echo "── phase 1: to the human gate ──"
set +e
$CLI run "$PAPER" "${COMMON[@]}"
phase1_rc=$?
set -e
if [ "$phase1_rc" -ne 10 ]; then
  echo "phase 1 expected the human-selection gate (exit 10), got $phase1_rc" >&2
  [ "$phase1_rc" -eq 0 ] && exit 1
  exit "$phase1_rc"
fi

echo; echo "── phase 2: select a direction, compile and scaffold ──"
set +e
$CLI run "$PAPER" "${COMMON[@]}" --select I-001 --redo sandbox-provisioner
phase2_rc=$?
set -e
if [ "$phase2_rc" -ne 11 ]; then
  echo "phase 2 expected a named missing-implementation stop (exit 11), got $phase2_rc" >&2
  [ "$phase2_rc" -eq 0 ] && exit 1
  exit "$phase2_rc"
fi
LEDGER="$PROJ/experiment_ledger.jsonl"
if [ ! -s "$LEDGER" ] || ! grep -Eq '"failure_class"[[:space:]]*:[[:space:]]*"METHOD_NOT_IMPLEMENTED"' "$LEDGER"; then
  echo "phase 2 did not record METHOD_NOT_IMPLEMENTED in experiment_ledger.jsonl" >&2
  exit 1
fi

echo; echo "── phase 3: supply the method under test, then re-run the experiments ──"
for f in "$HERE"/impl/*.py; do
  id="$(basename "$f" .py)"                      # E-001 -> code/e_001/impl.py
  dir="$PROJ/code/$(echo "$id" | tr 'A-Z-' 'a-z_')"
  [ -d "$dir" ] && cp "$f" "$dir/impl.py" && echo "  $id -> $dir/impl.py"
done
$CLI run "$PAPER" "${COMMON[@]}" --select I-001 \
  --redo experiment-runner

echo; echo "── result ──"
$CLI status --project "$PROJ"
