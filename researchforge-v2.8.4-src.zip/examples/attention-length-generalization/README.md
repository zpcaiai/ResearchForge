# Worked example — attention entropy vs sequence length

A machinery example, from an abstract-page fixture to a submission-refused assisted-draft path,
on a machine with no GPU and no model key. It uses the explicit `trusted-host-code` profile for the
three bundled implementations; that profile has no filesystem or network isolation and must not be
used for generated or third-party code.

It reaches RL0 (the fixture is an abstract page, so there is no code to reproduce), which puts the
project in `CM_NONE`: no comparative performance claim is admissible, and only diagnostic and
evaluation-methodology directions remain open. The experiments below are exactly that kind of work,
which is why the run gets anywhere at all.

## Why you have to write `impl/`

`codebase-scaffolder` generates the experiment harness — CLI, seeding, invalid-condition checks,
result emission — and deliberately does **not** generate the method under test. A generator that
writes the algorithm it also measures produces evidence about itself. The generated
`experiment.py` loads a sibling `impl.py` and raises `MethodNotImplemented` if it is absent.

The three files here are that missing piece, written the way a researcher would write them. They
are real numpy computations, not stand-ins: scaled dot-product attention over random inputs at
increasing sequence lengths, a metric-validity probe, and a matched-compute ablation.

## Run it

```bash
./run.sh /tmp/example-project
```

Three phases, because there is a human in the middle and a researcher in the middle:

1. drive to the human selection gate, choose a direction
2. compile the blueprint and scaffold the code — then drop `impl/*.py` into place
3. `--redo experiment-runner` and continue to the release gate

## Verified v2.8.4 output

The example was rerun end-to-end on 2026-08-20 after the sandbox/resume changes:

- 42 completed rows (3 experiments × 7 seeds × baseline/candidate) with measured NumPy metrics
- an integrity audit that recomputes every reported statistic from the raw ledger
- 56 editable SVG candidate figures
- a 20-slide `.pptx` with 55 native shapes and 0 pictures
- a blocked release manifest with no packaged deliverables because the draft and review are synthetic

The refusal is the point. The prose comes from `--offline`, so the draft is synthetic and cannot be
released as evidence. A live model run is a different path and still does not make the result
submission-ready without the remaining human and acceptance gates.
