import test from "node:test";
import assert from "node:assert/strict";
import { ArgumentError, parseArgs } from "./args.js";

test("argument parser preserves equals signs in values", () => {
  const got = parseArgs(["run", "paper.pdf", "--intent=a=b"]);
  assert.equal(got.flags.intent, "a=b");
});

test("argument parser refuses duplicate and unknown control flags", () => {
  assert.throws(() => parseArgs(["run", "p", "--project", "a", "--project", "b"]),
                ArgumentError);
  assert.throws(() => parseArgs(["run", "p", "--redo", "x", "--project", "safe",
                                 "--project", "other"]), ArgumentError);
  assert.throws(() => parseArgs(["run", "p", "--offine"]), /unknown flag/);
});

test("sets are explicit, unique, and scoped to run", () => {
  assert.deepEqual(parseArgs(["run", "p", "--set", "seeds=3"]).sets, { seeds: 3 });
  assert.throws(() => parseArgs(["run", "p", "--set", "seeds=3", "--set", "seeds=4"]),
                /supplied twice/);
  assert.throws(() => parseArgs(["run", "p", "--set", "missing"]), /key=value/);
  assert.throws(() => parseArgs(["status", "--set", "x=1"]), /only for run/);
  assert.throws(() => parseArgs(["run", "p", "--set", "__proto__={}"]), /reserved/);
});

test("boolean flags cannot smuggle string values", () => {
  assert.throws(() => parseArgs(["run", "p", "--offline=false"]), /takes no value/);
  const got = parseArgs(["run", "p", "--offline"]);
  assert.equal(got.flags.offline, true);
});
