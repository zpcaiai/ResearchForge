import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { MAX_BRIDGE_OUTPUT_BYTES, PythonBridge, validateRunResponse } from "./bridge.js";

function executable(t: test.TestContext, body: string): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "rf-bridge-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const script = path.join(dir, "fake-python");
  fs.writeFileSync(script, `#!/usr/bin/env node\n${body}\n`, { mode: 0o700 });
  return script;
}

const request = {
  skill: "paper-ingest" as const,
  project: "/tmp/project",
  runId: "run-test",
  mode: "guided" as const,
  model: "offline",
  offline: true,
};

const success = {
  ok: true, skill: "paper-ingest", produced: [], warnings: [], synthetic: false,
  needs_human: null, next_state: null, detail: {}, quota: [],
};

test("subprocess JSON must match one of the response contracts", () => {
  assert.equal(validateRunResponse(null), null);
  assert.equal(validateRunResponse({ ok: true }), null);
  assert.equal(validateRunResponse({ ok: false, error: { kind: "x" } }), null);
  assert.deepEqual(validateRunResponse({ ok: false, error: { kind: "x", message: "bad" } }),
                   { ok: false, error: { kind: "x", message: "bad" } });
});

test("bridge turns shape-invalid JSON into a bounded failure", async (t) => {
  const bridge = new PythonBridge(os.tmpdir(), executable(t, "console.log('null')"));
  const result = await bridge.run(request, 5_000);
  assert.equal(result.ok, false);
  if (!result.ok && !("needs_human" in result)) assert.equal(result.error.kind, "bad_output");
});

test("bridge preserves UTF-8 JSON split across byte-sized writes", async (t) => {
  const payload = JSON.stringify({ ...success, warnings: ["证据已绑定"] });
  const python = executable(t, `
    const bytes = Buffer.from(${JSON.stringify(payload)});
    let offset = 0;
    function writeByte() {
      if (offset === bytes.length) return;
      process.stdout.write(bytes.subarray(offset, ++offset));
      setImmediate(writeByte);
    }
    writeByte();`);
  const result = await new PythonBridge(os.tmpdir(), python).run(request, 5_000);
  assert.equal(result.ok, true);
  if (result.ok) assert.deepEqual(result.warnings, ["证据已绑定"]);
});

test("bridge rejects success for another skill or an undeclared artifact", async (t) => {
  const wrongSkill = executable(t,
    `console.log(JSON.stringify(${JSON.stringify({ ...success, skill: "paper-model-builder" })}))`);
  const wrongArtifact = executable(t,
    `console.log(JSON.stringify(${JSON.stringify({ ...success, produced: ["experiment_ledger"] })}))`);
  for (const python of [wrongSkill, wrongArtifact]) {
    const result = await new PythonBridge(os.tmpdir(), python).run(request, 5_000);
    assert.equal(result.ok, false);
    if (!result.ok && !("needs_human" in result)) assert.equal(result.error.kind, "bad_output");
  }
});

test("bridge rejects success JSON from a nonzero process", async (t) => {
  const python = executable(t,
    `console.log(JSON.stringify(${JSON.stringify(success)})); process.exitCode = 7`);
  const result = await new PythonBridge(os.tmpdir(), python).run(request, 5_000);
  assert.equal(result.ok, false);
  if (!result.ok && !("needs_human" in result)) assert.match(result.error.message, /status 7/);
});

test("bridge kills a child whose captured output exceeds the limit", async (t) => {
  const marker = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "rf-bridge-pid-")), "pid");
  t.after(() => fs.rmSync(path.dirname(marker), { recursive: true, force: true }));
  const script = executable(t,
    `require('node:fs').writeFileSync(${JSON.stringify(marker)}, String(process.pid));
     process.stdout.write('x'.repeat(${MAX_BRIDGE_OUTPUT_BYTES} + 1)); setInterval(() => {}, 1000)`);
  const bridge = new PythonBridge(os.tmpdir(), script);
  const result = await bridge.run(request, 5_000);
  assert.equal(result.ok, false);
  if (!result.ok && !("needs_human" in result)) assert.equal(result.error.kind, "output_limit");
  const pid = Number(fs.readFileSync(marker, "utf8"));
  assert.throws(() => process.kill(pid, 0), (error: unknown) =>
    (error as NodeJS.ErrnoException).code === "ESRCH");
});

test("bridge refuses invalid timeout values before spawning", async (t) => {
  const bridge = new PythonBridge(os.tmpdir(), executable(t, "process.exit(99)"));
  await assert.rejects(() => bridge.run(request, Number.POSITIVE_INFINITY), /bridge timeout/);
  await assert.rejects(() => bridge.run(request, 2_147_483_648), /bridge timeout/);
});

test("contract probe rejects a shape-invalid digest", async (t) => {
  const bridge = new PythonBridge(os.tmpdir(), executable(t, "console.log(JSON.stringify({digest: 'short'}))"));
  await assert.rejects(() => bridge.contractDigest(), /invalid digest response/);
});

test("license probe cannot omit a requested paid gate", async (t) => {
  const payload = JSON.stringify({ ok: true, edition: "site", reason: "verified", checks: [] });
  const bridge = new PythonBridge(os.tmpdir(), executable(t, `console.log(${JSON.stringify(payload)})`));
  await assert.rejects(() => bridge.licenseAccess(["experiment-runner"]), /omitted/);
});

test("license probe requires a unique nonempty set of paid skills", async (t) => {
  const bridge = new PythonBridge(os.tmpdir(), executable(t, "process.exit(99)"));
  await assert.rejects(() => bridge.licenseAccess([]), /at least one/);
  await assert.rejects(() => bridge.licenseAccess(["experiment-runner", "experiment-runner"]),
                       /duplicates/);
  await assert.rejects(() => bridge.licenseAccess(["paper-ingest"]), /unknown paid skill/);
});
