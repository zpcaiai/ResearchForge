/** The language boundary.
 *
 * One subprocess per skill invocation. Built-in skills can hang, exhaust memory,
 * or die; process isolation turns "the skill crashed" into a normal observable
 * outcome rather than a corrupted shared runtime. Generated experiment code has
 * a separate Docker boundary. The request is not persisted here, so process
 * isolation by itself is not a replay guarantee.
 */
import { spawn } from "node:child_process";
import path from "node:path";
import { StringDecoder } from "node:string_decoder";
import { SKILLS, type SkillName } from "@researchforge/contracts";
import { licensePublicKey } from "./pubkey.js";

/** Every Python skill guarded by a paid feature, used by read-only release preflight. */
export const PAID_PIPELINE_SKILLS = [
  "codebase-scaffolder", "experiment-runner", "evaluator-builder",
  "manuscript-builder", "claim-citation-auditor", "review-simulator",
  "figure-factory", "deck-factory", "release-gate",
] as const;

export interface RunRequest {
  skill: SkillName;
  project: string;
  runId: string;
  mode: "guided" | "auto" | "analysis-only";
  model: string;
  offline: boolean;
  config?: Record<string, unknown>;
  quota?: Record<string, { max_calls?: number; max_usd?: number }>;
  fixtures?: string;
}

export type RunResponse =
  | { ok: true; skill: string; produced: string[]; warnings: string[]; synthetic: boolean;
      needs_human: unknown; next_state: string | null; detail: Record<string, unknown>;
      quota: unknown[] }
  | { ok: false; needs_human: true; prompt: string; options_artifact: string }
  | { ok: false; error: { kind: string; message: string; [k: string]: unknown } };

export const MAX_BRIDGE_OUTPUT_BYTES = 1024 * 1024;

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Runtime validation for the untyped subprocess boundary. */
export function validateRunResponse(value: unknown): RunResponse | null {
  if (!record(value) || typeof value.ok !== "boolean") return null;
  if (value.ok === true) {
    if (typeof value.skill !== "string" || !Array.isArray(value.produced) ||
        !value.produced.every((item) => typeof item === "string") ||
        !Array.isArray(value.warnings) || !value.warnings.every((item) => typeof item === "string") ||
        typeof value.synthetic !== "boolean" || !record(value.detail) ||
        !Array.isArray(value.quota) ||
        !(value.next_state === null || typeof value.next_state === "string")) return null;
    return value as unknown as RunResponse;
  }
  if (value.needs_human === true) {
    if (typeof value.prompt !== "string" || typeof value.options_artifact !== "string") return null;
    return value as unknown as RunResponse;
  }
  if (!record(value.error) || typeof value.error.kind !== "string" ||
      typeof value.error.message !== "string") return null;
  return value as unknown as RunResponse;
}

/** Environment for the Python side of the boundary.
 *
 * The release key is compiled into the TypeScript build. `release-build.mjs`
 * restores the source sentinel after compiling, so Python cannot rediscover the
 * key by reading `pubkey.ts`; it has to cross this boundary explicitly. A user
 * supplied value is deleted in a source/community build and overwritten in a
 * release build, so the normal CLI cannot be pointed at an attacker's key.
 */
export function pythonEnvironment(
  repoRoot: string,
  base: NodeJS.ProcessEnv = process.env,
  publicKeyPem: string | null = licensePublicKey(),
): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...base,
    PYTHONPATH: path.join(repoRoot, "python"),
  };
  if (publicKeyPem) env.RESEARCHFORGE_LICENSE_PUBKEY_PEM = publicKeyPem;
  else delete env.RESEARCHFORGE_LICENSE_PUBKEY_PEM;
  return env;
}

export class PythonBridge {
  constructor(
    private readonly repoRoot: string,
    private readonly python = process.env.RESEARCHFORGE_PYTHON ?? "python3",
  ) {}

  async run(req: RunRequest, timeoutMs = 4 * 3600 * 1000): Promise<RunResponse> {
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 2_147_483_647) {
      throw new RangeError("bridge timeout must be between 1 and 2147483647 milliseconds");
    }
    const args = [
      "-m", "researchforge.runner", "run",
      "--skill", req.skill,
      "--project", req.project,
      "--run-id", req.runId,
      "--mode", req.mode,
      "--model", req.model,
      "--schemas", path.join(this.repoRoot, "schemas"),
    ];
    if (req.offline) args.push("--offline");
    if (req.fixtures) args.push("--fixtures", req.fixtures);

    return await new Promise<RunResponse>((resolve) => {
      const child = spawn(this.python, args, {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
        stdio: ["pipe", "pipe", "pipe"],
      });
      let out = "", err = "", outBytes = 0, errBytes = 0, settled = false;
      let pendingKill: RunResponse | null = null;
      let killFallback: NodeJS.Timeout | undefined;
      const outDecoder = new StringDecoder("utf8");
      const errDecoder = new StringDecoder("utf8");
      const finish = (response: RunResponse) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (killFallback) clearTimeout(killFallback);
        resolve(response);
      };
      const killAndFinish = (response: RunResponse) => {
        if (settled || pendingKill) return;
        pendingKill = response;
        clearTimeout(timer);
        child.kill("SIGKILL");
        // Resolve on `close`, after stdio is closed and the direct child has
        // reaped. The fallback prevents a platform-level child_process defect
        // from hanging the caller forever after kill was requested.
        killFallback = setTimeout(() => finish(response), 5_000);
      };
      const append = (stream: "stdout" | "stderr", data: Buffer | string) => {
        if (settled || pendingKill) return;
        const chunk = Buffer.isBuffer(data) ? data : Buffer.from(data);
        if (stream === "stdout") outBytes += chunk.length;
        else errBytes += chunk.length;
        if (outBytes > MAX_BRIDGE_OUTPUT_BYTES || errBytes > MAX_BRIDGE_OUTPUT_BYTES) {
          killAndFinish({ ok: false, error: { kind: "output_limit",
            message: `skill '${req.skill}' exceeded the ${MAX_BRIDGE_OUTPUT_BYTES}-byte ` +
                     `${stream} capture limit and was killed` } });
          return;
        }
        if (stream === "stdout") out += outDecoder.write(chunk);
        else err += errDecoder.write(chunk);
      };
      const timer = setTimeout(() => {
        killAndFinish({ ok: false, error: { kind: "timeout",
          message: `skill '${req.skill}' exceeded ${Math.round(timeoutMs / 1000)}s and was killed. ` +
                   `The time box is enforced by the runtime, not by the skill's own judgment.` } });
      }, timeoutMs);

      child.stdout.on("data", (d) => append("stdout", d));
      child.stderr.on("data", (d) => append("stderr", d));
      child.on("error", (e) => {
        finish({ ok: false, error: { kind: "spawn_failed", message: String(e) } });
      });
      child.on("close", (code) => {
        if (settled) return;
        if (pendingKill) { finish(pendingKill); return; }
        out += outDecoder.end();
        err += errDecoder.end();
        const line = out.trim().split("\n").filter(Boolean).pop();
        if (!line) {
          finish({ ok: false, error: { kind: "no_output",
            message: `skill '${req.skill}' produced no JSON on stdout`, stderr: err.slice(-2000) } });
          return;
        }
        try {
          const response = validateRunResponse(JSON.parse(line));
          if (!response) {
            finish({ ok: false, error: { kind: "bad_output",
            message: `skill '${req.skill}' returned JSON with an invalid response shape`,
            raw: line.slice(0, 1000), stderr: err.slice(-2000) } });
          } else if (response.ok && code !== 0) {
            finish({ ok: false, error: { kind: "bad_output",
              message: `skill '${req.skill}' returned success JSON but exited with status ${code}`,
              stderr: err.slice(-2000) } });
          } else if (response.ok && response.skill !== req.skill) {
            finish({ ok: false, error: { kind: "bad_output",
              message: `skill '${req.skill}' returned a result for '${response.skill}'` } });
          } else if (response.ok) {
            const declared = new Set<string>(SKILLS[req.skill].produces);
            if (new Set(response.produced).size !== response.produced.length ||
                response.produced.some((artifact) => !declared.has(artifact))) {
              finish({ ok: false, error: { kind: "bad_output",
                message: `skill '${req.skill}' returned duplicate or undeclared artifacts` } });
            } else finish(response);
          } else finish(response);
        } catch {
          finish({ ok: false, error: { kind: "bad_output",
            message: `skill '${req.skill}' returned unparseable output`,
            raw: line.slice(0, 1000), stderr: err.slice(-2000) } });
        }
      });
      child.stdin.on("error", () => { /* child may reject/exit before consuming the request */ });
      child.stdin.end(JSON.stringify({
        project: req.project, config: req.config ?? {}, quota: req.quota ?? {},
      }));
    });
  }

  async contractDigest(): Promise<string> {
    const r = await new Promise<{ out: string; err: string; code: number | null }>((resolve, reject) => {
      const c = spawn(this.python, ["-m", "researchforge.runner", "contract"], {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
        stdio: ["ignore", "pipe", "pipe"],
      });
      let o = "", err = "", outBytes = 0, errBytes = 0, settled = false;
      const outDecoder = new StringDecoder("utf8");
      const errDecoder = new StringDecoder("utf8");
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        c.kill("SIGKILL");
        reject(new Error("Python contract probe timed out"));
      }, 30_000);
      const fail = (error: unknown) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(error instanceof Error ? error : new Error(String(error)));
      };
      c.stdout.on("data", (data) => {
        const chunk = Buffer.isBuffer(data) ? data : Buffer.from(data);
        outBytes += chunk.length;
        if (outBytes > MAX_BRIDGE_OUTPUT_BYTES) {
          c.kill("SIGKILL");
          fail(new Error("Python contract probe exceeded the output limit"));
        } else o += outDecoder.write(chunk);
      });
      c.stderr.on("data", (data) => {
        const chunk = Buffer.isBuffer(data) ? data : Buffer.from(data);
        errBytes += chunk.length;
        if (errBytes > MAX_BRIDGE_OUTPUT_BYTES) {
          c.kill("SIGKILL");
          fail(new Error("Python contract probe exceeded the error-output limit"));
        } else err += errDecoder.write(chunk);
      });
      c.on("error", fail);
      c.on("close", (code) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        o += outDecoder.end();
        err += errDecoder.end();
        resolve({ out: o, err, code });
      });
    });
    if (r.code !== 0) {
      throw new Error(`Python contract probe exited with status ${r.code}: ${r.err.slice(-500)}`);
    }
    const parsed: unknown = JSON.parse(r.out.trim());
    if (!record(parsed) || typeof parsed.digest !== "string" ||
        !/^[0-9a-f]{64}$/.test(parsed.digest)) {
      throw new Error("Python contract probe returned an invalid digest response");
    }
    return parsed.digest;
  }

  /** Ask the Python choke point about paid-skill access without creating a project. */
  async licenseAccess(skills: readonly string[]): Promise<{
    ok: boolean;
    edition: string;
    reason: string;
    checks: { skill: string; allowed: boolean; overridden: boolean; feature?: string }[];
  }> {
    if (skills.length === 0) throw new Error("Python licence probe requires at least one paid skill");
    if (new Set(skills).size !== skills.length) {
      throw new Error("Python licence probe skill request must not contain duplicates");
    }
    const paid = new Set<string>(PAID_PIPELINE_SKILLS);
    const unknown = skills.filter((skill) => !paid.has(skill));
    if (unknown.length > 0) {
      throw new Error(`Python licence probe received unknown paid skill(s): ${unknown.join(", ")}`);
    }
    const args = ["-m", "researchforge.runner", "license"];
    for (const skill of skills) args.push("--license-skill", skill);
    const result = await new Promise<{ out: string; err: string; code: number | null }>((resolve) => {
      const child = spawn(this.python, args, {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
        stdio: ["ignore", "pipe", "pipe"],
      });
      let out = "", err = "", outBytes = 0, errBytes = 0, settled = false;
      const outDecoder = new StringDecoder("utf8");
      const errDecoder = new StringDecoder("utf8");
      const finish = (value: { out: string; err: string; code: number | null }) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      };
      const timer = setTimeout(() => {
        child.kill("SIGKILL");
        finish({ out, err: "Python licence probe timed out", code: null });
      }, 30_000);
      const append = (stream: "out" | "err", data: Buffer | string) => {
        const chunk = Buffer.isBuffer(data) ? data : Buffer.from(data);
        if (stream === "out") outBytes += chunk.length;
        else errBytes += chunk.length;
        if (outBytes > MAX_BRIDGE_OUTPUT_BYTES || errBytes > MAX_BRIDGE_OUTPUT_BYTES) {
          child.kill("SIGKILL");
          finish({ out: "", err: "Python licence probe exceeded the output limit", code: null });
          return;
        }
        if (stream === "out") out += outDecoder.write(chunk);
        else err += errDecoder.write(chunk);
      };
      child.stdout.on("data", (data) => append("out", data));
      child.stderr.on("data", (data) => append("err", data));
      child.on("error", (error) => finish({ out, err: String(error), code: null }));
      child.on("close", (code) => {
        out += outDecoder.end();
        err += errDecoder.end();
        finish({ out, err, code });
      });
    });
    const line = result.out.trim().split("\n").filter(Boolean).pop();
    if (!line) throw new Error(`Python licence probe produced no JSON: ${result.err.slice(-500)}`);
    const parsed: unknown = JSON.parse(line);
    if (!record(parsed) || typeof parsed.ok !== "boolean" ||
        typeof parsed.edition !== "string" || typeof parsed.reason !== "string" ||
        !Array.isArray(parsed.checks) || !parsed.checks.every((item) =>
          record(item) && typeof item.skill === "string" &&
          typeof item.allowed === "boolean" && typeof item.overridden === "boolean" &&
          (item.feature === null || item.feature === undefined || typeof item.feature === "string"))) {
      throw new Error("Python licence probe returned an invalid response shape");
    }
    const checks = parsed.checks as {
      skill: string; allowed: boolean; overridden: boolean; feature?: string
    }[];
    const returned = checks.map((item) => item.skill);
    if (returned.length !== skills.length || new Set(returned).size !== returned.length ||
        skills.some((skill) => !returned.includes(skill))) {
      throw new Error("Python licence probe omitted, repeated, or substituted a requested skill");
    }
    const resultParsed = parsed as unknown as {
      ok: boolean;
      edition: string;
      reason: string;
      checks: { skill: string; allowed: boolean; overridden: boolean; feature?: string }[];
    };
    if (result.code !== 0 || !resultParsed.ok) return { ...resultParsed, ok: false };
    return resultParsed;
  }
}
