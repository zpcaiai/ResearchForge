/** The language boundary.
 *
 * One subprocess per skill invocation. Built-in skills can hang, exhaust memory,
 * or die; process isolation turns "the skill crashed" into a normal observable
 * outcome rather than a corrupted shared runtime. Generated experiment code has
 * a separate Docker boundary. The request is not persisted here, so process
 * isolation by itself is not a replay guarantee.
 */
import { spawn } from "node:child_process";
import path from "node:path";
import type { SkillName } from "@researchforge/contracts";
import { licensePublicKey } from "./pubkey.js";

/** Every Python skill guarded by a paid feature, used by read-only release preflight. */
export const PAID_PIPELINE_SKILLS = [
  "codebase-scaffolder", "experiment-runner", "evaluator-builder",
  "manuscript-builder", "claim-citation-auditor", "review-simulator",
  "figure-factory", "deck-factory", "release-gate",
] as const;

export interface RunRequest {
  skill: SkillName;
  project: string;
  runId: string;
  mode: "guided" | "auto" | "analysis-only";
  model: string;
  offline: boolean;
  config?: Record<string, unknown>;
  quota?: Record<string, { max_calls?: number; max_usd?: number }>;
  fixtures?: string;
}

export type RunResponse =
  | { ok: true; skill: string; produced: string[]; warnings: string[]; synthetic: boolean;
      needs_human: unknown; next_state: string | null; detail: Record<string, unknown>;
      quota: unknown[] }
  | { ok: false; needs_human: true; prompt: string; options_artifact: string }
  | { ok: false; error: { kind: string; message: string; [k: string]: unknown } };

/** Environment for the Python side of the boundary.
 *
 * The release key is compiled into the TypeScript build. `release-build.mjs`
 * restores the source sentinel after compiling, so Python cannot rediscover the
 * key by reading `pubkey.ts`; it has to cross this boundary explicitly. A user
 * supplied value is deleted in a source/community build and overwritten in a
 * release build, so the normal CLI cannot be pointed at an attacker's key.
 */
export function pythonEnvironment(
  repoRoot: string,
  base: NodeJS.ProcessEnv = process.env,
  publicKeyPem: string | null = licensePublicKey(),
): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...base,
    PYTHONPATH: path.join(repoRoot, "python"),
  };
  if (publicKeyPem) env.RESEARCHFORGE_LICENSE_PUBKEY_PEM = publicKeyPem;
  else delete env.RESEARCHFORGE_LICENSE_PUBKEY_PEM;
  return env;
}

export class PythonBridge {
  constructor(
    private readonly repoRoot: string,
    private readonly python = process.env.RESEARCHFORGE_PYTHON ?? "python3",
  ) {}

  async run(req: RunRequest, timeoutMs = 4 * 3600 * 1000): Promise<RunResponse> {
    const args = [
      "-m", "researchforge.runner", "run",
      "--skill", req.skill,
      "--project", req.project,
      "--run-id", req.runId,
      "--mode", req.mode,
      "--model", req.model,
      "--schemas", path.join(this.repoRoot, "schemas"),
    ];
    if (req.offline) args.push("--offline");
    if (req.fixtures) args.push("--fixtures", req.fixtures);

    return await new Promise<RunResponse>((resolve) => {
      const child = spawn(this.python, args, {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
        stdio: ["pipe", "pipe", "pipe"],
      });
      let out = "", err = "";
      const timer = setTimeout(() => {
        child.kill("SIGKILL");
        resolve({ ok: false, error: { kind: "timeout",
          message: `skill '${req.skill}' exceeded ${Math.round(timeoutMs / 1000)}s and was killed. ` +
                   `The time box is enforced by the runtime, not by the skill's own judgment.` } });
      }, timeoutMs);

      child.stdout.on("data", (d) => (out += d));
      child.stderr.on("data", (d) => (err += d));
      child.on("error", (e) => {
        clearTimeout(timer);
        resolve({ ok: false, error: { kind: "spawn_failed", message: String(e) } });
      });
      child.on("close", () => {
        clearTimeout(timer);
        const line = out.trim().split("\n").filter(Boolean).pop();
        if (!line) {
          resolve({ ok: false, error: { kind: "no_output",
            message: `skill '${req.skill}' produced no JSON on stdout`, stderr: err.slice(-2000) } });
          return;
        }
        try {
          resolve(JSON.parse(line) as RunResponse);
        } catch {
          resolve({ ok: false, error: { kind: "bad_output",
            message: `skill '${req.skill}' returned unparseable output`,
            raw: line.slice(0, 1000), stderr: err.slice(-2000) } });
        }
      });
      child.stdin.end(JSON.stringify({
        project: req.project, config: req.config ?? {}, quota: req.quota ?? {},
      }));
    });
  }

  async contractDigest(): Promise<string> {
    const r = await new Promise<string>((resolve) => {
      const c = spawn(this.python, ["-m", "researchforge.runner", "contract"], {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
      });
      let o = ""; c.stdout.on("data", (d) => (o += d)); c.on("close", () => resolve(o));
    });
    return (JSON.parse(r.trim()) as { digest: string }).digest;
  }

  /** Ask the Python choke point about paid-skill access without creating a project. */
  async licenseAccess(skills: readonly string[]): Promise<{
    ok: boolean;
    edition: string;
    reason: string;
    checks: { skill: string; allowed: boolean; overridden: boolean; feature?: string }[];
  }> {
    const args = ["-m", "researchforge.runner", "license"];
    for (const skill of skills) args.push("--license-skill", skill);
    const result = await new Promise<{ out: string; err: string; code: number | null }>((resolve) => {
      const child = spawn(this.python, args, {
        cwd: this.repoRoot,
        env: pythonEnvironment(this.repoRoot),
        stdio: ["ignore", "pipe", "pipe"],
      });
      let out = "", err = "";
      child.stdout.on("data", (data) => (out += data));
      child.stderr.on("data", (data) => (err += data));
      child.on("error", (error) => resolve({ out, err: String(error), code: null }));
      child.on("close", (code) => resolve({ out, err, code }));
    });
    const line = result.out.trim().split("\n").filter(Boolean).pop();
    if (!line) throw new Error(`Python licence probe produced no JSON: ${result.err.slice(-500)}`);
    const parsed = JSON.parse(line) as {
      ok: boolean;
      edition: string;
      reason: string;
      checks: { skill: string; allowed: boolean; overridden: boolean; feature?: string }[];
    };
    if (result.code !== 0 || !parsed.ok) return { ...parsed, ok: false };
    return parsed;
  }
}
