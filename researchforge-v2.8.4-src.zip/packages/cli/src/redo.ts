import fs from "node:fs";
import path from "node:path";
import {
  ARTIFACTS,
  BUILD_ORDER,
  SKILLS,
  type ArtifactId,
  type SkillName,
} from "@researchforge/contracts";

export class RedoError extends Error {}

export interface RedoPlan {
  /** Skills named explicitly by the operator, after trimming and de-duplication. */
  readonly requested: readonly SkillName[];
  /** Requested skills plus every transitive dependent, in contract build order. */
  readonly skills: readonly SkillName[];
  /** The complete, de-duplicated set of declared outputs owned by those skills. */
  readonly artifacts: readonly ArtifactId[];
}

export interface RedoResult extends RedoPlan {
  /** Declared artifact paths that actually existed and were removed. */
  readonly removed: readonly ArtifactId[];
}

/** Plan a dependency-aware redo without touching the project.
 *
 * `dependsOn` is the generated, acyclic build graph. Contract `feedback` reads
 * deliberately do not participate: they describe runtime loops, so treating
 * them as build dependencies would invalidate upstream and downstream skills as
 * one cycle. Skills that are stores over feedback are already marked `rerun` in
 * the state machine at the stage where the feedback becomes available.
 */
export function planRedo(names: readonly string[]): RedoPlan {
  const requested: SkillName[] = [];
  const seenRequested = new Set<string>();

  // Validate the whole request before returning a plan. In particular, a typo
  // after a valid name must not permit a caller to perform a partial deletion.
  for (const raw of names) {
    const name = raw.trim();
    if (!name || !Object.prototype.hasOwnProperty.call(SKILLS, name)) {
      throw new RedoError(`unknown skill '${name}'`);
    }
    if (!seenRequested.has(name)) {
      seenRequested.add(name);
      requested.push(name as SkillName);
    }
  }

  if (requested.length === 0) throw new RedoError("no skills were supplied");

  const affected = new Set<SkillName>(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const dependency = queue.shift()!;
    for (const skill of BUILD_ORDER) {
      if (affected.has(skill)) continue;
      if (SKILLS[skill].dependsOn.includes(dependency)) {
        affected.add(skill);
        queue.push(skill);
      }
    }
  }

  const skills = BUILD_ORDER.filter((skill) => affected.has(skill));
  const artifacts = skills.flatMap((skill) => SKILLS[skill].produces);
  return { requested, skills, artifacts };
}

/** Remove the declared outputs in a redo plan, and nothing else. */
export function clearRedoOutputs(project: string, names: readonly string[]): RedoResult {
  const plan = planRedo(names);
  const suppliedRoot = path.resolve(project);
  if (!fs.existsSync(suppliedRoot) || !fs.statSync(suppliedRoot).isDirectory()) {
    throw new RedoError(`project directory does not exist: ${suppliedRoot}`);
  }
  const root = fs.realpathSync(suppliedRoot);
  const targets: { artifact: ArtifactId; target: string }[] = [];

  for (const artifact of plan.artifacts) {
    // ArtifactStore and the resumable orchestrator both use the first path in a
    // `|` declaration as the canonical on-disk path. Match that convention so a
    // redo changes exactly the same existence predicate that resume consults.
    const relative = ARTIFACTS[artifact].path.split("|")[0]!;
    const target = path.resolve(root, relative);
    const insideProject = target !== root && target.startsWith(root + path.sep);
    if (!insideProject) {
      throw new RedoError(
        `artifact '${artifact}' resolves outside the project (${relative}); refusing to delete`,
      );
    }
    // A lexical prefix check is not enough when an operator project contains a
    // symlinked artifact directory (for example analysis -> /shared/results).
    // rm on analysis/report.json would follow that parent and delete outside the
    // project. Validate every existing component before *any* deletion.
    let cursor = root;
    for (const component of path.relative(root, target).split(path.sep)) {
      cursor = path.join(cursor, component);
      if (fs.existsSync(cursor) && fs.lstatSync(cursor).isSymbolicLink()) {
        throw new RedoError(
          `artifact '${artifact}' crosses symbolic link '${cursor}'; refusing to delete`,
        );
      }
    }
    targets.push({ artifact, target });
  }

  // Validate and snapshot every path before deleting any of them. Some declared
  // artifacts nest inside directory-valued outputs (for example the release
  // manifest lives inside release_bundle), so remove the deepest paths first and
  // report everything that existed at the start of the operation.
  const existed = new Set(
    targets.filter(({ target }) => fs.existsSync(target)).map(({ artifact }) => artifact),
  );
  for (const { target } of [...targets].sort((a, b) => b.target.length - a.target.length)) {
    if (fs.existsSync(target)) fs.rmSync(target, { recursive: true, force: true });
  }
  const removed = plan.artifacts.filter((artifact) => existed.has(artifact));

  return { ...plan, removed };
}
