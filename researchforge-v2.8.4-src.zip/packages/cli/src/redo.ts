import fs from "node:fs";
import path from "node:path";
import {
  ARTIFACTS,
  BUILD_ORDER,
  INTERNAL_ARTIFACTS,
  SKILLS,
  type ArtifactId,
  type SkillName,
} from "@researchforge/contracts";
import { redoArtifactPaths, redoDeclaredPaths } from "./artifact-paths.js";

export class RedoError extends Error {}

function lexicalExists(target: string): boolean {
  try { fs.lstatSync(target); return true; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

export interface RedoPlan {
  /** Skills named explicitly by the operator, after trimming and de-duplication. */
  readonly requested: readonly SkillName[];
  /** Requested skills plus every transitive dependent, in contract build order. */
  readonly skills: readonly SkillName[];
  /** The complete, de-duplicated set of declared outputs owned by those skills. */
  readonly artifacts: readonly ArtifactId[];
  /** Skill-private outputs that must be cleared with their owner. */
  readonly internalArtifacts: readonly {
    skill: SkillName; artifact: string; path: string;
  }[];
}

export interface RedoResult extends RedoPlan {
  /** Declared artifact paths that actually existed and were removed. */
  readonly removed: readonly ArtifactId[];
  readonly removedInternal: readonly string[];
}

/** Plan a dependency-aware redo without touching the project.
 *
 * `dependsOn` is the generated, acyclic build graph. Contract `feedback` reads
 * deliberately do not participate: they describe runtime loops, so treating
 * them as build dependencies would invalidate upstream and downstream skills as
 * one cycle. Skills that are stores over feedback are already marked `rerun` in
 * the state machine at the stage where the feedback becomes available.
 */
export function planRedo(names: readonly string[]): RedoPlan {
  const requested: SkillName[] = [];
  const seenRequested = new Set<string>();

  // Validate the whole request before returning a plan. In particular, a typo
  // after a valid name must not permit a caller to perform a partial deletion.
  for (const raw of names) {
    const name = raw.trim();
    if (!name || !Object.prototype.hasOwnProperty.call(SKILLS, name)) {
      throw new RedoError(`unknown skill '${name}'`);
    }
    if (!seenRequested.has(name)) {
      seenRequested.add(name);
      requested.push(name as SkillName);
    }
  }

  if (requested.length === 0) throw new RedoError("no skills were supplied");

  const affected = new Set<SkillName>(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const dependency = queue.shift()!;
    for (const skill of BUILD_ORDER) {
      if (affected.has(skill)) continue;
      if (SKILLS[skill].dependsOn.includes(dependency)) {
        affected.add(skill);
        queue.push(skill);
      }
    }
  }

  const skills = BUILD_ORDER.filter((skill) => affected.has(skill));
  const artifacts = skills.flatMap((skill) => SKILLS[skill].produces);
  const internalArtifacts = skills.flatMap((skill) =>
    Object.entries(INTERNAL_ARTIFACTS[skill] ?? {}).map(([artifact, spec]) =>
      ({ skill, artifact, path: spec.path })));
  return { requested, skills, artifacts, internalArtifacts };
}

/** Remove the declared outputs in a redo plan, and nothing else. */
export function clearRedoOutputs(project: string, names: readonly string[]): RedoResult {
  const plan = planRedo(names);
  const suppliedRoot = path.resolve(project);
  if (!fs.existsSync(suppliedRoot) || !fs.statSync(suppliedRoot).isDirectory()) {
    throw new RedoError(`project directory does not exist: ${suppliedRoot}`);
  }
  const root = fs.realpathSync(suppliedRoot);
  if (root === path.parse(root).root) {
    throw new RedoError(`refusing to use filesystem root as a project: ${root}`);
  }
  const targets: { artifact?: ArtifactId; internal?: string; target: string }[] = [];

  const addTarget = (label: string, target: string,
                     artifact?: ArtifactId, internal?: string) => {
    const relative = path.relative(root, target);
    const insideProject = target !== root && target.startsWith(root + path.sep);
    if (!insideProject) {
      throw new RedoError(
        `artifact '${label}' resolves outside the project (${relative}); refusing to delete`,
      );
    }
    let cursor = root;
    for (const component of relative.split(path.sep)) {
      cursor = path.join(cursor, component);
      if (lexicalExists(cursor) && fs.lstatSync(cursor).isSymbolicLink()) {
        throw new RedoError(
          `artifact '${label}' crosses symbolic link '${cursor}'; refusing to delete`,
        );
      }
    }
    targets.push({ artifact, internal, target });
  };

  for (const artifact of plan.artifacts) {
    // Expand the same alternatives/globs that the resumable orchestrator uses.
    // Clearing only a literal `experiments/*.yaml` path leaves stale specs on
    // disk and can mix an old design with a freshly compiled blueprint.
    const artifactTargets = redoArtifactPaths(root, artifact);
    for (const target of artifactTargets) {
      addTarget(artifact, target, artifact);
    }
  }
  for (const item of plan.internalArtifacts) {
    const label = `${item.skill}:${item.artifact}`;
    for (const target of redoDeclaredPaths(root, item.path)) addTarget(label, target, undefined, label);
  }

  // Validate and snapshot every path before deleting any of them. Some declared
  // artifacts nest inside directory-valued outputs (for example the release
  // manifest lives inside release_bundle), so remove the deepest paths first and
  // report everything that existed at the start of the operation.
  const existed = new Set(
    targets.filter(({ target }) => lexicalExists(target)).map(({ artifact }) => artifact),
  );
  const existedInternal = new Set(
    targets.filter(({ target }) => lexicalExists(target)).map(({ internal }) => internal),
  );
  for (const { target } of [...targets].sort((a, b) => b.target.length - a.target.length)) {
    if (lexicalExists(target)) fs.rmSync(target, { recursive: true, force: true });
  }
  const removed = plan.artifacts.filter((artifact) => existed.has(artifact));
  const removedInternal = plan.internalArtifacts.map((item) => `${item.skill}:${item.artifact}`)
    .filter((label) => existedInternal.has(label));

  return { ...plan, removed, removedInternal };
}
