#!/usr/bin/env node
/** researchforge — self-hosted research runtime. */
import fs from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import readline from "node:readline/promises";
import { ARTIFACTS, SKILLS, STATES, type RunState } from "@researchforge/contracts";
import { PAID_PIPELINE_SKILLS, PythonBridge } from "./bridge.js";
import { run, type RunEvent } from "./orchestrator.js";
import { PIPELINE } from "./state.js";
import { describeRestriction, verify } from "./license.js";
import { licensePublicKey, licensePublicKeyFingerprint } from "./pubkey.js";
import { clearRedoOutputs, RedoError } from "./redo.js";
import { artifactExists, existingArtifactPaths } from "./artifact-paths.js";
import { ArgumentError, parseArgs, type ParsedArgs } from "./args.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, "../../..");

const C = {
  dim: (s: string) => `\x1b[2m${s}\x1b[0m`, b: (s: string) => `\x1b[1m${s}\x1b[0m`,
  g: (s: string) => `\x1b[32m${s}\x1b[0m`, y: (s: string) => `\x1b[33m${s}\x1b[0m`,
  r: (s: string) => `\x1b[31m${s}\x1b[0m`, c: (s: string) => `\x1b[36m${s}\x1b[0m`,
};

function printEvent(e: RunEvent) {
  switch (e.kind) {
    case "stage": console.log(`\n${C.b("▸ " + e.state)}`); break;
    case "skill": process.stdout.write(C.dim(`    ${e.skill} … `)); break;
    case "skill-ok":
      console.log(C.g("ok") + C.dim(` (${e.produced.length} artifacts)`) +
                  (e.synthetic ? " " + C.y("[SYNTHETIC]") : ""));
      for (const w of e.warnings) console.log(C.y(`      ! ${w}`));
      break;
    case "skill-stub":
      console.log(C.y("not implemented"));
      console.log(C.y(`      would be built in: ${e.batch}`));
      console.log(C.y(`      requires: ${e.missing}`));
      break;
    case "skill-fail":
      console.log(C.r(`failed (${e.kind2})`));
      console.log(C.r(`      ${e.message.split("\n").join("\n      ")}`));
      break;
    case "gate": console.log(C.r(`  ✖ ${e.message}`)); break;
    case "human": console.log(`\n${C.c("⏸  " + e.prompt)}`); break;
  }
}

async function cmdRun(pos: string[], flags: Record<string, string | boolean>,
                      sets: Record<string, unknown>) {
  const locator = pos[0];
  if (!locator) { console.error("usage: researchforge run <paper-url-or-file> [--project DIR]"); return 2; }
  if (pos.length !== 1) { console.error("run accepts exactly one paper locator"); return 2; }
  const project = path.resolve(String(flags.project ?? "./research-project"));
  const modeValue = String(flags.mode ?? "guided");
  if (modeValue !== "guided" && modeValue !== "auto" && modeValue !== "analysis-only") {
    console.error("--mode must be guided, auto, or analysis-only"); return 2;
  }
  const mode = modeValue;
  const offline = flags.offline === true;
  const model = String(flags.model ?? (offline ? "offline" : "anthropic"));
  const until = flags.until ? String(flags.until) : undefined;
  if (until && !STATES.includes(until as RunState)) {
    console.error(`--until must be one of ${STATES.join(", ")}`); return 2;
  }
  const reproTimebox = Number(flags["repro-timebox"] ?? 4 * 3600);
  if (!Number.isFinite(reproTimebox) || reproTimebox <= 0) {
    console.error("--repro-timebox must be a positive finite number of seconds"); return 2;
  }

  // No license file at all still means community edition — verify() answers that
  // before it ever looks at the key, so an unlicensed user is never blocked and
  // never sees a key-configuration error that is ours, not theirs.
  const lic = verify(licensePublicKey());
  if (!lic.valid) { console.error(C.r(`license: ${lic.reason}`)); return 3; }
  console.log(C.dim(`license: ${lic.license?.edition ?? "unknown"} edition`));
  if (lic.restricted.length)
    console.log(C.dim(`  not included: ${lic.restricted.map(describeRestriction).join("; ")}`));
  if (offline)
    console.log(C.y("offline: model calls return clearly-marked synthetic output. " +
                    "Nothing produced in this mode is research."));

  // --redo <skills>: invalidate the requested skills and every transitive
  // downstream dependent. Clearing only the named skill can combine a fresh
  // ledger with stale analysis, manuscript, review and release artifacts.
  if (flags.redo) {
    try {
      const result = clearRedoOutputs(project, String(flags.redo).split(","));
      const downstream = result.skills.length - result.requested.length;
      console.log(C.dim(
        `redo: invalidated ${result.artifacts.length + result.internalArtifacts.length} declared outputs from ` +
        `${result.requested.join(", ")} and ${downstream} downstream skill(s); ` +
        `removed ${result.removed.length + result.removedInternal.length} existing path(s)`,
      ));
    } catch (error) {
      if (!(error instanceof RedoError)) throw error;
      console.error(C.r(`--redo: ${error.message}`));
      return 2;
    }
  }

  fs.mkdirSync(project, { recursive: true });
  const runId = `run-${Date.now().toString(36)}-${crypto.randomUUID()}`;
  console.log(C.dim(`project: ${project}\nrun: ${runId}  mode: ${mode}  model: ${model}`));

  const outcome = await run({
    project, repoRoot: REPO_ROOT, runId, mode, model, offline,
    until: until as RunState | undefined,
    config: {
      paper_locator: locator,
      project_intent: String(flags.intent ?? "paper-to-innovation run"),
      search_objective: flags["search-objective"] ? String(flags["search-objective"]) : undefined,
      reference_strings: [],
      repro_timebox_seconds: reproTimebox,
      user_feedback: flags.select ? { selected: String(flags.select).split(",") } : undefined,
      ...sets,
    },
    onEvent: printEvent,
  });

  console.log("\n" + "─".repeat(64));
  console.log(`${C.b("state")}      ${outcome.finalState}`);
  console.log(`${C.b("artifacts")}  ${outcome.produced.length}/${Object.keys(ARTIFACTS).length}`);
  if (outcome.synthetic) console.log(C.y("output includes SYNTHETIC artifacts — not research"));
  if (outcome.reachedHumanGate) {
    console.log(C.c(`\n${outcome.humanPrompt}`));
    console.log(C.dim(`\n  researchforge select --project ${project} --ids I-001[,I-002]`));
    return 10;
  }
  if (outcome.blockedBy) {
    console.log(C.y(`\nstopped at ${outcome.blockedBy.skill} (${outcome.blockedBy.kind})`));
    return 11;
  }
  return 0;
}

async function cmdSelect(flags: Record<string, string | boolean>) {
  const project = path.resolve(String(flags.project ?? "./research-project"));
  const declaredRanked = path.join(project, ARTIFACTS["ranked_ideas"]!.path);
  if (!fs.existsSync(declaredRanked)) { console.error("no ranked_ideas yet; run first"); return 2; }
  const safeRanked = existingArtifactPaths(project, "ranked_ideas");
  if (safeRanked.length !== 1) {
    console.error("ranked_ideas crosses a symbolic link or is not a regular file"); return 2;
  }
  const ranked = safeRanked[0]!;
  const root = fs.realpathSync(project);
  const realRanked = fs.realpathSync(ranked);
  if (fs.lstatSync(ranked).isSymbolicLink() ||
      (realRanked !== root && !realRanked.startsWith(root + path.sep))) {
    console.error("ranked_ideas crosses a symbolic link or leaves the project"); return 2;
  }
  let parsed: unknown;
  try { parsed = JSON.parse(fs.readFileSync(realRanked, "utf8")); }
  catch { console.error("ranked_ideas is not valid JSON"); return 2; }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed) ||
      !Array.isArray((parsed as { ranking?: unknown }).ranking) ||
      !(parsed as { ranking: unknown[] }).ranking.every((row) =>
        typeof row === "object" && row !== null && !Array.isArray(row) &&
        typeof (row as { idea_id?: unknown }).idea_id === "string" &&
        typeof (row as { title?: unknown }).title === "string" &&
        typeof (row as { rank?: unknown }).rank === "number" &&
        Number.isFinite((row as { rank: number }).rank) &&
        typeof (row as { composite?: unknown }).composite === "number" &&
        Number.isFinite((row as { composite: number }).composite) &&
        typeof (row as { why_not_higher?: unknown }).why_not_higher === "string" &&
        ((row as { mode?: unknown }).mode === undefined ||
         typeof (row as { mode?: unknown }).mode === "string"))) {
    console.error("ranked_ideas has an invalid ranking shape"); return 2;
  }
  const data = parsed as
    { ranking: { rank: number; idea_id: string; title: string; mode?: string;
                 composite: number; why_not_higher: string }[] };
  console.log(C.b("\nranked directions\n"));
  for (const r of data.ranking) {
    console.log(`  ${C.c(r.idea_id)}  ${r.title}`);
    console.log(C.dim(`      mode=${r.mode ?? "?"}  composite=${r.composite}  ${r.why_not_higher}`));
  }
  let rawSelection = flags.ids ? String(flags.ids) : "";
  if (!rawSelection) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rawSelection = await rl.question("\nselect (comma-separated ids, or 'reject'): ");
    rl.close();
  }
  const rejectAll = rawSelection.trim().toLowerCase() === "reject";
  const ids = rejectAll ? [] : rawSelection.split(",").map((s) => s.trim()).filter(Boolean);
  if (!rejectAll && ids.length === 0) { console.error("selection is empty; enter ids or 'reject'"); return 2; }
  if (new Set(ids).size !== ids.length) { console.error("selection repeats an idea id"); return 2; }
  const known = new Set(data.ranking.map((row) => row.idea_id));
  const unknown = ids.filter((id) => !known.has(id));
  if (unknown.length) { console.error(`unknown idea id(s): ${unknown.join(", ")}`); return 2; }
  const bridge = new PythonBridge(REPO_ROOT);
  const res = await bridge.run({
    skill: "user-feedback-gate", project,
    runId: `sel-${Date.now().toString(36)}-${crypto.randomUUID()}`,
    mode: "guided", model: "offline", offline: true,
    config: { user_feedback: { selected: ids, note: "cli selection" } },
  });
  if ("ok" in res && res.ok) {
    console.log(C.g(ids.length ? `\nselected: ${ids.join(", ")}` : "\nrejected all directions"));
    console.log(C.dim("rejected candidates are retained, not deleted"));
    return 0;
  }
  console.error(C.r(JSON.stringify(res, null, 2)));
  return 1;
}

async function cmdStatus(flags: Record<string, string | boolean>) {
  const project = path.resolve(String(flags.project ?? "./research-project"));
  const have = new Set(Object.entries(ARTIFACTS)
    .filter(([id]) => artifactExists(project, id as keyof typeof ARTIFACTS))
    .map(([id]) => id));
  console.log(C.b(`\n${project}\n`));
  for (const stage of PIPELINE) {
    const missing = stage.requires.filter((a) => !have.has(a));
    const mark = stage.requires.length === 0 ? C.dim("·")
      : missing.length === 0 ? C.g("✔") : missing.length === stage.requires.length ? C.dim("·") : C.y("◐");
    console.log(`  ${mark} ${stage.state}${missing.length && missing.length < stage.requires.length
      ? C.dim(`   missing: ${missing.join(", ")}`) : ""}`);
  }
  console.log(C.dim(`\n${have.size}/${Object.keys(ARTIFACTS).length} artifacts on disk`));
  return 0;
}

async function cmdDoctor() {
  const bridge = new PythonBridge(REPO_ROOT);
  console.log(C.b("\nresearchforge doctor\n"));
  const digest = await bridge.contractDigest().catch(() => null);
  console.log(`  python bridge     ${digest ? C.g("ok") : C.r("FAILED")}`);
  console.log(`  contract digest   ${digest ?? "-"}`);
  console.log(`  skills            ${Object.keys(SKILLS).length}`);
  console.log(`  artifacts         ${Object.keys(ARTIFACTS).length}`);
  console.log(`  states            ${STATES.length}`);
  const lic = verify(licensePublicKey());
  console.log(`  license           ${lic.valid ? C.g(lic.license?.edition ?? "?") : C.r(lic.reason ?? "invalid")}`);
  // Printed so a support conversation can distinguish "your license is forged"
  // from "this build shipped the wrong verification key".
  console.log(`  license key       ${licensePublicKeyFingerprint() ?? C.dim("none compiled in (community only)")}`);
  for (const k of ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "SEMANTIC_SCHOLAR_API_KEY",
                   "RESEARCHFORGE_CONTACT_EMAIL"]) {
    console.log(`  ${k.padEnd(30)} ${process.env[k] ? C.g("set") : C.dim("unset (BYOK)")}`);
  }
  return digest ? 0 : 1;
}

async function cmdLicenseCheck(flags: Record<string, string | boolean>) {
  const requested = String(flags.skills ?? PAID_PIPELINE_SKILLS.join(","))
    .split(",").map((skill) => skill.trim()).filter(Boolean);
  const status = verify(licensePublicKey());
  if (!status.valid) {
    console.log(JSON.stringify({ ok: false, edition: status.license?.edition ?? "invalid",
      reason: status.reason ?? "TypeScript licence verification failed", checks: [] }));
    return 14;
  }
  const bridge = new PythonBridge(REPO_ROOT);
  try {
    const result = await bridge.licenseAccess(requested);
    console.log(JSON.stringify(result));
    return result.ok ? 0 : 14;
  } catch (error) {
    console.error(C.r(`license-check: ${String(error)}`));
    return 1;
  }
}

const HELP = `
researchforge — self-hosted research runtime

  run <paper>        ingest a paper and drive the pipeline to the human gate
      --project DIR  --mode guided|auto  --offline  --until STATE  --select IDS
      --set key=value   supply a declared external input (repeatable)
      --redo SKILLS     clear those skills and transitive downstream outputs
  select             review ranked directions and choose
  status             what exists on disk, by stage
  doctor             environment, contract digest, license, keys
  license-check      read-only proof that Python paid-skill gates permit this build/licence
      --skills IDS   comma-separated skill names (defaults to every paid pipeline skill)

Reproduction runs BEFORE ideation. If the source paper cannot be reproduced the
run does not stop — the comparison mode narrows and the admissible innovation
modes narrow with it.
`;

let parsed: ParsedArgs;
try {
  parsed = parseArgs(process.argv.slice(2));
} catch (error) {
  console.error(C.r(error instanceof ArgumentError ? error.message : String(error)));
  process.exit(2);
}
const { cmd, pos, flags, sets } = parsed;
const code = await (async () => {
  switch (cmd) {
    case "run": return cmdRun(pos, flags, sets);
    case "select": return cmdSelect(flags);
    case "status": return cmdStatus(flags);
    case "doctor": return cmdDoctor();
    case "license-check": return cmdLicenseCheck(flags);
    case "help": case "--help": case "-h": console.log(HELP); return 0;
    default: console.log(HELP); return cmd ? 2 : 0;
  }
})();
process.exit(code);
