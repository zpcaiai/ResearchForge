export class ArgumentError extends Error {}

export interface ParsedArgs {
  cmd: string | undefined;
  pos: string[];
  flags: Record<string, string | boolean>;
  sets: Record<string, unknown>;
}

const FLAGS: Record<string, { values: Set<string>; booleans: Set<string> }> = {
  run: {
    values: new Set(["project", "mode", "model", "until", "select", "redo", "intent",
                     "search-objective", "repro-timebox"]),
    booleans: new Set(["offline"]),
  },
  select: { values: new Set(["project", "ids"]), booleans: new Set() },
  status: { values: new Set(["project"]), booleans: new Set() },
  doctor: { values: new Set(), booleans: new Set() },
  "license-check": { values: new Set(["skills"]), booleans: new Set() },
};

export function parseArgs(argv: string[]): ParsedArgs {
  const [cmd, ...rest] = argv;
  const flags: Record<string, string | boolean> = {};
  const sets: Record<string, unknown> = {};
  const pos: string[] = [];
  const spec = cmd ? FLAGS[cmd] : undefined;
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i]!;
    if (arg === "--set") {
      if (cmd !== "run") throw new ArgumentError("--set is valid only for run");
      const kv = rest[++i];
      if (!kv || kv.startsWith("--")) throw new ArgumentError("--set requires key=value");
      const eq = kv.indexOf("=");
      if (eq < 1) throw new ArgumentError("--set requires key=value with a non-empty key");
      const key = kv.slice(0, eq).trim();
      if (key === "__proto__" || key === "prototype" || key === "constructor") {
        throw new ArgumentError(`--set key '${key}' is reserved`);
      }
      if (!key || Object.prototype.hasOwnProperty.call(sets, key)) {
        throw new ArgumentError(!key ? "--set key must not be empty" : `--set '${key}' was supplied twice`);
      }
      const raw = kv.slice(eq + 1);
      try { sets[key] = JSON.parse(raw); } catch { sets[key] = raw; }
      continue;
    }
    if (!arg.startsWith("--")) { pos.push(arg); continue; }
    if (arg === "--") throw new ArgumentError("bare -- passthrough is not supported");
    const eq = arg.indexOf("=");
    const key = arg.slice(2, eq < 0 ? undefined : eq);
    if (!key) throw new ArgumentError("empty flag name");
    if (!spec || (!spec.values.has(key) && !spec.booleans.has(key))) {
      throw new ArgumentError(`unknown flag --${key} for ${cmd ?? "this command"}`);
    }
    if (Object.prototype.hasOwnProperty.call(flags, key)) {
      throw new ArgumentError(`--${key} was supplied twice`);
    }
    if (spec.booleans.has(key)) {
      if (eq >= 0) throw new ArgumentError(`--${key} is boolean and takes no value`);
      flags[key] = true;
      continue;
    }
    const value = eq >= 0 ? arg.slice(eq + 1) : rest[++i];
    if (value === undefined || value === "" || value.startsWith("--")) {
      throw new ArgumentError(`--${key} requires a value`);
    }
    flags[key] = value;
  }
  if (spec && cmd !== "run" && pos.length > 0) {
    throw new ArgumentError(`${cmd} does not accept positional arguments`);
  }
  return { cmd, pos, flags, sets };
}
