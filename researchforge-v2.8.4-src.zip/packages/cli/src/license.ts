/** Self-hosted licensing.
 *
 * The commercial model is self-hosted with an offline-verified licence key.
 * Licence verification and telemetry do not send customer data anywhere. Live
 * research is a separate egress surface: selected model/scholarly providers,
 * remote paper retrieval and repository clones can use the network.
 *
 * The key is verified offline against a public key. There is no phone-home, both
 * because it would be a data-egress question in exactly the environments this is
 * meant for, and because a research run that dies at hour six because a license
 * server was unreachable is worse than one that was never licensed.
 */
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

export interface License {
  licensee: string;
  edition: "community" | "team" | "site";
  expires: string | null;   // ISO date; null = perpetual
  features: string[];
  issued: string;
}

export interface LicenseStatus {
  valid: boolean;
  reason?: string;
  license?: License;
  /** Features unavailable under this license, with what each gates. */
  restricted: string[];
}

const COMMUNITY: License = {
  licensee: "community", edition: "community", expires: null,
  features: ["ingest", "literature", "reproduction", "innovation", "human-gate"],
  issued: "1970-01-01",
};

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const FEATURE_RE = /^[a-z0-9][a-z0-9-]*$/;
export const MAX_LICENSE_BYTES = 64 * 1024;

function plainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function realIsoDay(value: string): boolean {
  if (!DAY_RE.test(value)) return false;
  const time = Date.parse(`${value}T00:00:00Z`);
  return Number.isFinite(time) && new Date(time).toISOString().slice(0, 10) === value;
}

function lexicalExists(target: string): boolean {
  try { fs.lstatSync(target); return true; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

function readLicenseFile(target: string): string | null {
  let fd: number | undefined;
  try {
    // Reject pipes/devices before opening so an operator-controlled licence path
    // cannot hang the CLI. O_NONBLOCK closes the residual stat/open race.
    const before = fs.statSync(target);
    if (!before.isFile() || before.size > MAX_LICENSE_BYTES) return null;
    fd = fs.openSync(target, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.size > MAX_LICENSE_BYTES) return null;
    const buffer = Buffer.alloc(MAX_LICENSE_BYTES + 1);
    let offset = 0;
    while (offset < buffer.length) {
      const count = fs.readSync(fd, buffer, offset, buffer.length - offset, null);
      if (count === 0) break;
      offset += count;
    }
    if (offset > MAX_LICENSE_BYTES) return null;
    return buffer.subarray(0, offset).toString("utf8");
  } catch {
    return null;
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
  }
}

function validateBlob(value: unknown): { license: License; signature: string } | string {
  if (!plainObject(value)) return "top level must be an object";
  if (Object.keys(value).sort().join(",") !== "license,signature") {
    return "top level must contain exactly license and signature";
  }
  const lic = value.license;
  if (!plainObject(lic)) return "license must be an object";
  const expected = ["edition", "expires", "features", "issued", "licensee"];
  if (Object.keys(lic).sort().join(",") !== expected.join(",")) {
    return "license has missing or unknown fields";
  }
  if (typeof lic.licensee !== "string" || !lic.licensee.trim() || lic.licensee.length > 200) {
    return "licensee must be a non-empty string of at most 200 characters";
  }
  if (lic.edition !== "community" && lic.edition !== "team" && lic.edition !== "site") {
    return "edition must be community, team, or site";
  }
  if (lic.expires !== null && (typeof lic.expires !== "string" || !realIsoDay(lic.expires))) {
    return "expires must be null or a real YYYY-MM-DD date";
  }
  if (typeof lic.issued !== "string" || !realIsoDay(lic.issued)) {
    return "issued must be a real YYYY-MM-DD date";
  }
  if (!Array.isArray(lic.features) || !lic.features.every((feature) =>
    typeof feature === "string" && FEATURE_RE.test(feature))) {
    return "features must be an array of non-empty feature ids";
  }
  if (new Set(lic.features).size !== lic.features.length) return "features must not repeat";
  if (typeof value.signature !== "string" || value.signature.length === 0 ||
      value.signature.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(value.signature)) {
    return "signature must be canonical base64";
  }
  const decoded = Buffer.from(value.signature, "base64");
  if (decoded.length !== 64 || decoded.toString("base64") !== value.signature) {
    return "signature must be one canonical Ed25519 signature";
  }
  return { license: lic as unknown as License, signature: value.signature };
}

/** Features the community edition does not include. */
const PAID_FEATURES: Record<string, string> = {
  "experiment-engine": "multi-branch experiment execution with strict Docker isolation for untrusted code and an explicitly non-isolated trusted-host option",
  "manuscript": "evidence-bound manuscript drafting and citation audit",
  "deck": "native editable defense deck generation",
  "release-gate": "release packaging with full provenance verification",
};

export function licensePath(): string {
  return process.env.RESEARCHFORGE_LICENSE ??
         path.join(os.homedir(), ".researchforge", "license.json");
}

export function verify(publicKeyPem: string | null, p = licensePath()): LicenseStatus {
  if (!lexicalExists(p)) {
    return { valid: true, license: COMMUNITY, reason: "no license file; community edition",
             restricted: Object.keys(PAID_FEATURES) };
  }
  let parsed: unknown;
  const text = readLicenseFile(p);
  if (text === null) {
    return { valid: false,
             reason: `license file at ${p} is not a bounded regular file (maximum ${MAX_LICENSE_BYTES} bytes)`,
             restricted: Object.keys(PAID_FEATURES) };
  }
  try {
    parsed = JSON.parse(text);
  } catch {
    return { valid: false, reason: `license file at ${p} is not valid JSON`,
             restricted: Object.keys(PAID_FEATURES) };
  }
  const checked = validateBlob(parsed);
  if (typeof checked === "string") {
    return { valid: false, reason: `license file shape is invalid: ${checked}`,
             restricted: Object.keys(PAID_FEATURES) };
  }
  const blob = checked;
  if (!publicKeyPem) {
    return { valid: false, reason: "no public key compiled in; cannot verify a license offline",
             restricted: Object.keys(PAID_FEATURES) };
  }
  // The signed message is the re-serialisation of the parsed license, so the
  // issuer must emit fields in this interface's declared order (tools/license/issue.mjs
  // pins that and self-checks it before writing).
  //
  // The digest argument is `null` because Ed25519 is PureEdDSA: it hashes the
  // message internally as part of the scheme, and OpenSSL rejects an externally
  // named digest outright rather than ignoring it.
  //
  // Wrapped because verify() throws — it does not return false — on a malformed
  // compiled-in key or an unparseable one. A build that shipped a corrupt key
  // constant would otherwise crash every command with a stack trace instead of
  // saying that the license could not be verified.
  let ok = false;
  try {
    ok = crypto.verify(
      null, Buffer.from(JSON.stringify(blob.license), "utf8"),
      publicKeyPem, Buffer.from(blob.signature ?? "", "base64"),
    );
  } catch {
    return { valid: false, reason: "license signature could not be checked (bad key or signature encoding)",
             restricted: Object.keys(PAID_FEATURES) };
  }
  if (!ok) {
    return { valid: false, reason: "license signature does not verify",
             restricted: Object.keys(PAID_FEATURES) };
  }
  if (blob.license.expires &&
      Date.parse(`${blob.license.expires}T00:00:00Z`) < Date.now()) {
    return { valid: false, reason: `license expired ${blob.license.expires}`, license: blob.license,
             restricted: Object.keys(PAID_FEATURES) };
  }
  const restricted = Object.keys(PAID_FEATURES).filter((f) => !blob.license.features.includes(f));
  return { valid: true, license: blob.license, restricted };
}

export function describeRestriction(feature: string): string {
  return PAID_FEATURES[feature] ?? feature;
}
