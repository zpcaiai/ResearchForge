import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { ARTIFACTS, SKILLS } from "@researchforge/contracts";
import { clearRedoOutputs, planRedo, RedoError } from "./redo.js";

function project(t: test.TestContext): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "researchforge-redo-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  return root;
}

function artifactPath(root: string, artifact: keyof typeof ARTIFACTS): string {
  return path.join(root, ARTIFACTS[artifact].path.split("|")[0]!);
}

function write(root: string, relative: string, contents = "old"): string {
  const target = path.join(root, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, contents);
  return target;
}

test("redo plan follows all transitive downstream dependencies", () => {
  const plan = planRedo(["experiment-runner"]);

  assert.equal(plan.skills[0], "experiment-runner");
  assert.ok(plan.skills.includes("data-analyst"));
  assert.ok(plan.skills.includes("integrity-auditor"));
  assert.ok(plan.skills.includes("manuscript-builder"));
  assert.ok(plan.skills.includes("figure-factory"), "transitive dependent must be included");
  assert.ok(plan.skills.includes("review-simulator"));
  assert.ok(plan.skills.includes("release-gate"));
  assert.ok(plan.artifacts.includes("experiment_ledger"));
  assert.ok(plan.artifacts.includes("analysis_results"));
  assert.ok(plan.artifacts.includes("release_manifest"));
  assert.ok(plan.internalArtifacts.some((item) => item.artifact === "run_index"));

  assert.ok(!plan.skills.includes("codebase-scaffolder"), "upstream skill must be preserved");
  assert.ok(!plan.skills.includes("evaluator-builder"), "upstream skill must be preserved");
  assert.ok(!plan.skills.includes("retrospective-benchmark-builder"),
    "unrelated branch must be preserved");
});

test("every affected non-root skill is connected through a declared dependency", () => {
  const plan = planRedo(["experiment-runner"]);
  const reached = new Set(plan.requested);
  for (const skill of plan.skills) {
    if (reached.has(skill)) continue;
    assert.ok(SKILLS[skill].dependsOn.some((dependency) => reached.has(dependency)),
      `${skill} has no affected declared dependency`);
    reached.add(skill);
  }
});

test("redo removes affected declared outputs and preserves upstream and undeclared files", (t) => {
  const root = project(t);
  const ledger = write(root, ARTIFACTS.experiment_ledger.path, "ledger");
  const analysis = write(root, ARTIFACTS.analysis_results.path, "analysis");
  const release = write(root, ARTIFACTS.release_manifest.path, "release");
  const upstream = write(root, ARTIFACTS.evaluator_code.path, "evaluator");
  const unrelated = write(root, "analysis/operator-notes.txt", "keep");

  const result = clearRedoOutputs(root, ["experiment-runner"]);

  assert.ok(!fs.existsSync(ledger));
  assert.ok(!fs.existsSync(analysis));
  assert.ok(!fs.existsSync(release));
  assert.ok(fs.existsSync(upstream));
  assert.ok(fs.existsSync(unrelated));
  assert.ok(result.removed.includes("experiment_ledger"));
  assert.ok(result.removed.includes("analysis_results"));
  assert.ok(result.removed.includes("release_manifest"));
  assert.ok(!result.removed.includes("evaluator_code"));
});

test("all names are validated before any output is deleted", (t) => {
  const root = project(t);
  const ledger = write(root, ARTIFACTS.experiment_ledger.path, "ledger");

  assert.throws(
    () => clearRedoOutputs(root, ["experiment-runner", "typo-skill"]),
    (error: unknown) => error instanceof RedoError && /unknown skill 'typo-skill'/.test(error.message),
  );
  assert.ok(fs.existsSync(ledger), "a later invalid name must not cause partial invalidation");
});

test("multiple requested skills are de-duplicated before taking the dependency union", () => {
  const plan = planRedo([" data-analyst ", "experiment-runner", "data-analyst"]);
  assert.deepEqual(plan.requested, ["data-analyst", "experiment-runner"]);
  assert.equal(new Set(plan.skills).size, plan.skills.length);
  assert.equal(new Set(plan.artifacts).size, plan.artifacts.length);
});

test("artifact helper follows the same canonical path convention as invalidation", (t) => {
  const root = project(t);
  assert.equal(artifactPath(root, "analysis_code"), path.join(root, "analysis/analysis.py"));
});

test("redo refuses a symlinked artifact parent before deleting anything", (t) => {
  const root = project(t);
  const outside = project(t);
  const ledger = write(root, ARTIFACTS.experiment_ledger.path, "ledger");
  const victim = write(outside, "analysis_results.json", "keep me");
  fs.symlinkSync(outside, path.join(root, "analysis"), "dir");

  assert.throws(
    () => clearRedoOutputs(root, ["experiment-runner"]),
    (error: unknown) => error instanceof RedoError && /symbolic link/.test(error.message),
  );
  assert.ok(fs.existsSync(ledger), "validation must precede every deletion");
  assert.equal(fs.readFileSync(victim, "utf8"), "keep me");
});

test("redo expands experiment spec globs without deleting sibling artifacts", (t) => {
  const root = project(t);
  const spec1 = write(root, "experiments/E-001.yaml", "one");
  const spec2 = write(root, "experiments/E-002.yaml", "two");
  const container = write(root, "experiments/container.yaml", "sandbox");
  const ablation = write(root, "experiments/ablation_plan.yaml", "plan");

  const result = clearRedoOutputs(root, ["research-blueprint-compiler"]);
  assert.ok(result.removed.includes("experiment_specs"));
  assert.equal(fs.existsSync(spec1), false);
  assert.equal(fs.existsSync(spec2), false);
  assert.equal(fs.existsSync(ablation), false, "the compiler owns the ablation plan too");
  assert.equal(fs.readFileSync(container, "utf8"), "sandbox");
  assert.ok(result.removedInternal.includes("research-blueprint-compiler:ablation_plan"));
});

test("redo refuses a dangling symlink matched by an artifact glob", (t) => {
  const root = project(t);
  const ledger = write(root, ARTIFACTS.experiment_ledger.path, "keep until validation succeeds");
  fs.mkdirSync(path.join(root, "experiments"), { recursive: true });
  const link = path.join(root, "experiments/E-001.yaml");
  fs.symlinkSync(path.join(root, "missing-target.yaml"), link);

  assert.throws(() => clearRedoOutputs(root, ["research-blueprint-compiler"]),
                (error: unknown) => error instanceof RedoError && /symbolic link/.test(error.message));
  assert.equal(fs.lstatSync(link).isSymbolicLink(), true);
  assert.equal(fs.readFileSync(ledger, "utf8"), "keep until validation succeeds");
});

test("redo refuses filesystem root as a project", () => {
  assert.throws(() => clearRedoOutputs(path.parse(process.cwd()).root, ["paper-ingest"]),
                (error: unknown) => error instanceof RedoError && /filesystem root/.test(error.message));
});
