import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describeRestriction, MAX_LICENSE_BYTES, verify } from "./license.js";
import { PAID_PIPELINE_SKILLS, pythonEnvironment } from "./bridge.js";

test("no license file falls back to community, not to a failure", () => {
  const p = path.join(os.tmpdir(), "rf-nonexistent-license.json");
  const s = verify(null, p);
  assert.equal(s.valid, true);
  assert.equal(s.license?.edition, "community");
  assert.ok(s.restricted.includes("experiment-engine"));
});

test("a malformed license file is invalid and says why", () => {
  const p = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "rf-")), "license.json");
  fs.writeFileSync(p, "{not json");
  const s = verify(null, p);
  assert.equal(s.valid, false);
  assert.match(s.reason!, /not valid JSON/);
});

test("non-regular, dangling, and oversized license paths fail closed", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "rf-lic-shape-"));
  const directory = path.join(root, "directory");
  fs.mkdirSync(directory);
  const dangling = path.join(root, "dangling.json");
  fs.symlinkSync(path.join(root, "missing.json"), dangling);
  const oversized = path.join(root, "oversized.json");
  fs.writeFileSync(oversized, "x".repeat(MAX_LICENSE_BYTES + 1));
  for (const candidate of [directory, dangling, oversized]) {
    const status = verify(null, candidate);
    assert.equal(status.valid, false);
    assert.match(status.reason!, /bounded regular file/);
    assert.ok(status.restricted.includes("release-gate"));
  }
});

test("a well-formed license cannot be accepted without a verification key", () => {
  const p = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "rf-")), "license.json");
  fs.writeFileSync(p, JSON.stringify({
    license: { licensee: "acme", edition: "site", expires: null,
               features: ["experiment-engine"], issued: "2026-01-01" },
    signature: "not-a-real-signature",
  }));
  const s = verify(null, p);
  assert.equal(s.valid, false, "an unsigned-but-plausible license must not unlock features");
});

test("malformed license shapes fail closed before key handling", () => {
  for (const value of [
    null,
    { license: null, signature: "x" },
    { license: { licensee: "x", edition: "site", expires: null,
                 features: "release-gate", issued: "2026-01-01" }, signature: "x" },
    { license: { licensee: "x", edition: "site", expires: "2026-02-31",
                 features: ["release-gate"], issued: "2026-01-01" }, signature: "x" },
  ]) {
    const p = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "rf-")), "license.json");
    fs.writeFileSync(p, JSON.stringify(value));
    const s = verify("not-even-a-key", p);
    assert.equal(s.valid, false);
    assert.match(s.reason!, /shape is invalid/);
    assert.ok(s.restricted.includes("release-gate"));
  }
});

test("restrictions are described in terms of what they gate", () => {
  assert.match(describeRestriction("experiment-engine"), /experiment/i);
});

test("the compiled release key crosses into Python and an ambient key cannot replace it", () => {
  const compiled = "-----BEGIN PUBLIC KEY-----\nrelease-key\n-----END PUBLIC KEY-----\n";
  const env = pythonEnvironment("/opt/researchforge",
    { RESEARCHFORGE_LICENSE_PUBKEY_PEM: "attacker-key", PATH: "/bin" }, compiled);
  assert.equal(env.RESEARCHFORGE_LICENSE_PUBKEY_PEM, compiled);
  assert.equal(env.PYTHONPATH, path.join("/opt/researchforge", "python"));

  const source = pythonEnvironment("/opt/researchforge",
    { RESEARCHFORGE_LICENSE_PUBKEY_PEM: "attacker-key" }, null);
  assert.equal(source.RESEARCHFORGE_LICENSE_PUBKEY_PEM, undefined);
});

test("paid-gate preflight covers every paid Python pipeline skill", () => {
  assert.deepEqual(new Set(PAID_PIPELINE_SKILLS), new Set([
    "codebase-scaffolder", "experiment-runner", "evaluator-builder",
    "manuscript-builder", "claim-citation-auditor", "review-simulator",
    "figure-factory", "deck-factory", "release-gate",
  ]));
});
