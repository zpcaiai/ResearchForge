import fs from "node:fs";
import path from "node:path";
import { ARTIFACTS, INTERNAL_ARTIFACTS, type ArtifactId } from "@researchforge/contracts";

function lexicalExists(target: string): boolean {
  try { fs.lstatSync(target); return true; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

/** Expand the compact `a.ext|alternative` path syntax used by the contract. */
export function artifactAlternatives(declaration: string): string[] {
  const [first, ...rest] = declaration.split("|");
  if (!first) return [];
  const out = [first];
  const dir = path.posix.dirname(first);
  const extension = path.posix.extname(first);
  const stem = extension ? first.slice(0, -extension.length) : first;
  for (const alternative of rest) {
    if (!alternative) continue;
    if (alternative.includes("/")) out.push(alternative);
    else if (alternative.startsWith(".")) out.push(stem + alternative);
    else if (alternative.includes(".")) out.push(path.posix.join(dir, alternative));
    else out.push(stem + "." + alternative);
  }
  return [...new Set(out)];
}

function safeLeaf(root: string, relative: string): string | null {
  const target = path.resolve(root, relative);
  if (target === root || !target.startsWith(root + path.sep)) return null;
  let cursor = root;
  for (const component of path.relative(root, target).split(path.sep)) {
    cursor = path.join(cursor, component);
    if (!lexicalExists(cursor)) break;
    if (fs.lstatSync(cursor).isSymbolicLink()) return null;
  }
  return target;
}

function exactContractPaths(): Set<string> {
  const exact = new Set<string>();
  for (const spec of Object.values(ARTIFACTS)) {
    if (spec.path.includes("*")) continue;
    for (const candidate of artifactAlternatives(spec.path)) exact.add(candidate.replace(/\/$/, ""));
  }
  for (const owned of Object.values(INTERNAL_ARTIFACTS)) {
    for (const spec of Object.values(owned ?? {})) {
      if (spec.path.includes("*")) continue;
      for (const candidate of artifactAlternatives(spec.path)) exact.add(candidate.replace(/\/$/, ""));
    }
  }
  return exact;
}

const EXACT_CONTRACT_PATHS = exactContractPaths();

function globPaths(root: string, declaration: string, includeNonFiles = false): string[] {
  const dirRel = path.posix.dirname(declaration);
  const base = path.posix.basename(declaration);
  // Contract paths currently use a single-segment `*`. Refuse to guess if a
  // future contract introduces recursive or character-class glob semantics.
  if ((base.match(/\*/g) ?? []).length !== 1 || /[?\[\]]/.test(base)) return [];
  const dir = safeLeaf(root, dirRel);
  if (!dir || !fs.existsSync(dir) || !fs.lstatSync(dir).isDirectory()) return [];
  const pattern = new RegExp("^" + base.split("*").map((part) =>
    part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$");
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => pattern.test(entry.name) &&
      (includeNonFiles || (entry.isFile() && !entry.isSymbolicLink())))
    .map((entry) => path.posix.join(dirRel, entry.name))
    // A glob-valued artifact must not claim another artifact's exact output.
    // In particular, container.yaml and ablation_plan.yaml are not experiments.
    .filter((relative) => !EXACT_CONTRACT_PATHS.has(relative));
}

/** Existing safe paths represented by an artifact declaration.
 *
 * Directory artifacts exist only when their store manifest exists. This keeps
 * an empty or pre-seeded directory from causing its producer to be skipped.
 */
export function existingArtifactPaths(project: string, artifactId: ArtifactId): string[] {
  const root = path.resolve(project);
  const declaration = ARTIFACTS[artifactId].path;
  if (declaration.includes("*")) {
    return globPaths(root, declaration).map((relative) => path.resolve(root, relative));
  }
  const found: string[] = [];
  for (const relative of artifactAlternatives(declaration)) {
    const target = safeLeaf(root, relative.replace(/\/$/, ""));
    if (!target || !fs.existsSync(target)) continue;
    const stat = fs.lstatSync(target);
    if (declaration.endsWith("/")) {
      if (!stat.isDirectory()) continue;
      const marker = safeLeaf(root, path.posix.join(relative, "_manifest.json"));
      if (marker && fs.existsSync(marker) && fs.lstatSync(marker).isFile()) found.push(target);
    } else if (stat.isFile()) {
      found.push(target);
    }
  }
  return found;
}

export function artifactExists(project: string, artifactId: ArtifactId): boolean {
  return existingArtifactPaths(project, artifactId).length > 0;
}

/** Lexical targets to remove for redo, including all currently matched glob rows. */
export function redoArtifactPaths(project: string, artifactId: ArtifactId): string[] {
  const root = path.resolve(project);
  const declaration = ARTIFACTS[artifactId].path;
  if (declaration.includes("*")) {
    return globPaths(root, declaration, true).map((relative) => path.resolve(root, relative));
  }
  return artifactAlternatives(declaration)
    .map((relative) => path.resolve(root, relative.replace(/\/$/, "")));
}

export function redoDeclaredPaths(project: string, declaration: string): string[] {
  const root = path.resolve(project);
  if (declaration.includes("*")) {
    return globPaths(root, declaration, true).map((relative) => path.resolve(root, relative));
  }
  return artifactAlternatives(declaration)
    .map((relative) => path.resolve(root, relative.replace(/\/$/, "")));
}
