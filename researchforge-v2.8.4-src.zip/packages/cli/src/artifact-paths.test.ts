import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { artifactAlternatives, artifactExists, existingArtifactPaths } from "./artifact-paths.js";

function project(t: test.TestContext): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "rf-paths-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  return root;
}

function write(root: string, relative: string, body = "x"): string {
  const target = path.join(root, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, body);
  return target;
}

test("compact alternative declarations resolve to their real sibling paths", () => {
  assert.deepEqual(artifactAlternatives("analysis/analysis.py|ipynb"),
                   ["analysis/analysis.py", "analysis/analysis.ipynb"]);
  assert.deepEqual(artifactAlternatives("paper/main.tex|main.md"),
                   ["paper/main.tex", "paper/main.md"]);
  assert.deepEqual(artifactAlternatives("source/paper.pdf|.html"),
                   ["source/paper.pdf", "source/paper.html"]);
});

test("experiment glob excludes other exact contract artifacts", (t) => {
  const root = project(t);
  write(root, "experiments/container.yaml");
  write(root, "experiments/ablation_plan.yaml");
  assert.equal(artifactExists(root, "experiment_specs"), false);
  const spec = write(root, "experiments/E-001.yaml");
  assert.equal(artifactExists(root, "experiment_specs"), true);
  assert.deepEqual(existingArtifactPaths(root, "experiment_specs"), [spec]);
});

test("directory artifacts require the store marker, not an empty directory", (t) => {
  const root = project(t);
  fs.mkdirSync(path.join(root, "analysis/plots"), { recursive: true });
  assert.equal(artifactExists(root, "analysis_plots"), false);
  write(root, "analysis/plots/_manifest.json", "{}");
  assert.equal(artifactExists(root, "analysis_plots"), true);
});

test("symlinked artifacts and parents never satisfy resume", (t) => {
  const root = project(t);
  const outside = project(t);
  const target = write(outside, "ranked.json", "{}");
  fs.mkdirSync(path.join(root, "ideas"), { recursive: true });
  fs.symlinkSync(target, path.join(root, "ideas/ranked_ideas.json"));
  assert.equal(artifactExists(root, "ranked_ideas"), false);
  fs.rmSync(path.join(root, "ideas"), { recursive: true, force: true });
  fs.symlinkSync(outside, path.join(root, "ideas"));
  assert.equal(artifactExists(root, "ranked_ideas"), false);
});

test("a dangling symlink parent never satisfies resume", (t) => {
  const root = project(t);
  fs.symlinkSync(path.join(root, "missing-outside"), path.join(root, "ideas"));
  assert.equal(artifactExists(root, "ranked_ideas"), false);
});
