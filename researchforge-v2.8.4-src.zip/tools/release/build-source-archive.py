#!/usr/bin/env python3
"""Build the rootless ResearchForge source archive from an explicit allowlist.

This is deliberately not ``zip -r``.  Source releases must not inherit caches,
editable-install metadata, virtual environments, build output, prior archives,
credentials, or macOS resource forks merely because they happen to be in the
working tree.  ZIP entries use fixed metadata and no compression, so identical
source bytes produce identical archive bytes across zlib versions.
"""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import secrets
import stat
import zipfile


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE_TIME = (2026, 8, 13, 0, 0, 0)

ROOT_FILES = (
    ".gitignore",
    "CHANGELOG_v2.md",
    "README.md",
    "package.json",
    "package-lock.json",
    "tsconfig.base.json",
)
TREE_SUFFIXES = {
    "acceptance": {".md", ".py", ".sh"},
    "benchmarks/retro-v1": {".json", ".jsonl", ".md", ".txt"},
    "docs": {".json", ".jsonl", ".md", ".py", ".txt", ".xlsx"},
    "examples/attention-length-generalization": {".md", ".py", ".sh"},
}
EXACT_FILES = (
    "fixtures/papers/SOURCES.md",
    "fixtures/papers/arxiv_1706.03762_abs.html",
    "python/pyproject.toml",
    "tools/codegen/generate.py",
    "tools/license/issue.mjs",
    "tools/license/keygen.mjs",
    "tools/license/release-build.mjs",
    "tools/license/server.mjs",
    "tools/license/demo/DEMO-THROWAWAY-do-not-use.private.pem",
    "tools/license/demo/DEMO-THROWAWAY-do-not-use.public.pem",
    "tools/license/demo/demo-license.json",
    "tools/release/build-source-archive.py",
)
EXECUTABLES = {
    "acceptance/grade.py",
    "acceptance/run_acceptance.sh",
    "examples/attention-length-generalization/run.sh",
    "tools/license/issue.mjs",
    "tools/license/keygen.mjs",
    "tools/license/release-build.mjs",
    "tools/license/server.mjs",
    "tools/release/build-source-archive.py",
}
FORBIDDEN_PARTS = {
    ".git",
    ".pytest_cache",
    ".venv",
    "__MACOSX",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "research-project",
}
FORBIDDEN_SUFFIXES = {
    ".db", ".log", ".p12", ".pfx", ".pyc", ".pyo", ".sqlite", ".sqlite3",
    ".tsbuildinfo", ".whl", ".zip",
}
DEMO_PRIVATE_KEY = PurePosixPath(
    "tools/license/demo/DEMO-THROWAWAY-do-not-use.private.pem"
)


class CollectedSources(tuple):
    """A tuple of paths bound to the file identities seen during collection."""

    def __new__(cls, paths, identities):
        instance = super().__new__(cls, paths)
        instance.identities = dict(identities)
        return instance


def _open_flags(*names: str) -> int:
    flags = 0
    for name in names:
        flags |= getattr(os, name, 0)
    return flags


def _safe_parts(relative: PurePosixPath) -> tuple[str, ...]:
    if relative.is_absolute() or not relative.parts or any(
        part in {"", ".", ".."} for part in relative.parts
    ):
        raise ValueError(f"unsafe archive path: {relative}")
    return relative.parts


def _source_identity(metadata: os.stat_result) -> tuple[int, ...]:
    """Return the fields that must remain stable between validation and read."""
    return (
        metadata.st_dev,
        metadata.st_ino,
        metadata.st_mode,
        metadata.st_nlink,
        metadata.st_size,
        metadata.st_mtime_ns,
        metadata.st_ctime_ns,
    )


def _validate_source_metadata(relative: PurePosixPath,
                              metadata: os.stat_result) -> tuple[int, ...]:
    if not stat.S_ISREG(metadata.st_mode):
        raise ValueError(f"source is not a regular file: {relative}")
    # A hard-linked release input has another mutable pathname referring to the
    # same inode, so its bytes cannot be bound to this allowlisted name alone.
    if metadata.st_nlink != 1:
        raise ValueError(f"source has multiple hard links: {relative}")
    return _source_identity(metadata)


def _open_source_fd(relative: PurePosixPath) -> int:
    """Open a source through no-follow directory fds and return its bound fd."""
    parts = _safe_parts(relative)
    root = ROOT.resolve(strict=True)
    directory_flags = _open_flags("O_RDONLY", "O_DIRECTORY", "O_CLOEXEC", "O_NOFOLLOW")
    file_flags = _open_flags("O_RDONLY", "O_CLOEXEC", "O_NOFOLLOW")
    directory_fd = os.open(root, directory_flags)
    try:
        for part in parts[:-1]:
            next_fd = os.open(part, directory_flags, dir_fd=directory_fd)
            os.close(directory_fd)
            directory_fd = next_fd
        file_fd = os.open(parts[-1], file_flags, dir_fd=directory_fd)
    except OSError as exc:
        raise ValueError(f"source could not be opened without following links: {relative}") from exc
    finally:
        os.close(directory_fd)
    try:
        _validate_source_metadata(relative, os.fstat(file_fd))
    except Exception:
        os.close(file_fd)
        raise
    return file_fd


def _validated_source_identity(relative: PurePosixPath) -> tuple[int, ...]:
    file_fd = _open_source_fd(relative)
    try:
        return _validate_source_metadata(relative, os.fstat(file_fd))
    finally:
        os.close(file_fd)


def _read_validated_source(relative: PurePosixPath,
                           expected: tuple[int, ...] | None) -> bytes:
    """Validate and read one inode, then ensure its allowlisted path stayed bound."""
    file_fd = _open_source_fd(relative)
    try:
        before = _validate_source_metadata(relative, os.fstat(file_fd))
        if expected is not None and before != expected:
            raise ValueError(f"source changed after allowlist collection: {relative}")
        chunks: list[bytes] = []
        while True:
            chunk = os.read(file_fd, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        after = _validate_source_metadata(relative, os.fstat(file_fd))
        if after != before:
            raise ValueError(f"source changed while it was being read: {relative}")
        data = b"".join(chunks)
        if len(data) != before[4]:
            raise ValueError(f"source size changed while it was being read: {relative}")
    finally:
        os.close(file_fd)

    # Reopen through the no-follow path after reading.  Reading from the bound
    # descriptor is safe even if the name is swapped; this second check makes
    # such a swap fail closed instead of silently packaging the old inode.
    current = _validated_source_identity(relative)
    if current != before:
        raise ValueError(f"source path changed while it was being read: {relative}")
    return data


def _relative_file(path: Path) -> PurePosixPath:
    """Return a validated root-relative archive path for a real regular file."""
    try:
        relative = path.relative_to(ROOT)
    except ValueError as exc:
        raise ValueError(f"source escaped repository root: {path}") from exc
    posix = PurePosixPath(relative.as_posix())
    _safe_parts(posix)
    _validated_source_identity(posix)
    return posix


def _allowed(path: PurePosixPath) -> bool:
    if any(part in FORBIDDEN_PARTS or part.endswith(".egg-info") or
           part.endswith(".dist-info") for part in path.parts):
        return False
    if path.name.startswith("._") or path.name in {".DS_Store", ".env"}:
        return False
    if path.name.startswith(".env.") and path.name != ".env.example":
        return False
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        return False
    if path.suffix.lower() == ".pdf":
        return False
    if (path.suffix.lower() in {".key", ".pem"} and
            path != DEMO_PRIVATE_KEY and not path.name.endswith(".public.pem")):
        return False
    return True


def collect_source_files() -> tuple[PurePosixPath, ...]:
    """Resolve the complete release allowlist, failing on drift or unsafe entries."""
    paths: set[PurePosixPath] = set()
    identities: dict[PurePosixPath, tuple[int, ...]] = {}

    def add(path: Path) -> None:
        relative = _relative_file(path)
        if not _allowed(relative):
            raise ValueError(f"allowlist selected a forbidden path: {relative}")
        paths.add(relative)
        identity = _validated_source_identity(relative)
        previous = identities.setdefault(relative, identity)
        if previous != identity:
            raise ValueError(f"source changed during allowlist collection: {relative}")

    for relative in ROOT_FILES + EXACT_FILES:
        candidate = ROOT / relative
        if not candidate.exists():
            raise FileNotFoundError(f"required source file is missing: {relative}")
        add(candidate)

    for base, suffixes in TREE_SUFFIXES.items():
        directory = ROOT / base
        if not directory.is_dir() or directory.is_symlink():
            raise FileNotFoundError(f"required source directory is missing: {base}")
        for candidate in directory.rglob("*"):
            if candidate.is_file() and candidate.suffix.lower() in suffixes:
                relative = PurePosixPath(candidate.relative_to(ROOT).as_posix())
                if _allowed(relative):
                    add(candidate)

    for candidate in sorted((ROOT / "manifests").glob("*.json")):
        add(candidate)
    for candidate in sorted((ROOT / "schemas").glob("*.json")):
        add(candidate)
    for candidate in sorted((ROOT / "skills").glob("*/SKILL.md")):
        add(candidate)
    for candidate in sorted((ROOT / "tools/benchmark").glob("*.py")):
        add(candidate)
    for package in ("cli", "contracts"):
        for relative in (f"packages/{package}/package.json", f"packages/{package}/tsconfig.json"):
            add(ROOT / relative)
        for candidate in sorted((ROOT / f"packages/{package}/src").rglob("*.ts")):
            add(candidate)
    for candidate in sorted((ROOT / "python/researchforge").rglob("*.py")):
        add(candidate)
    for candidate in sorted((ROOT / "python/tests").rglob("*.py")):
        add(candidate)

    expected = {
        PurePosixPath("packages/contracts/src/generated.ts"),
        PurePosixPath("python/researchforge/generated.py"),
        PurePosixPath("fixtures/papers/SOURCES.md"),
        PurePosixPath("fixtures/papers/arxiv_1706.03762_abs.html"),
    }
    missing = expected - paths
    if missing:
        raise ValueError(f"release would omit required generated/fixture files: {sorted(missing)}")
    ordered = tuple(sorted(paths, key=str))
    return CollectedSources(ordered, identities)


def _output_location(output: Path) -> tuple[Path, str, int]:
    """Bind an absent lexical output name to an opened canonical parent fd."""
    requested = Path(os.path.abspath(os.fspath(output)))
    if requested.name in {"", ".", ".."}:
        raise ValueError(f"output must name a file: {output}")

    # This check intentionally precedes all resolve operations.  In particular,
    # a dangling caller-supplied symlink must never become a request to create
    # its target.
    try:
        os.lstat(requested)
    except FileNotFoundError:
        pass
    else:
        raise FileExistsError(f"refusing to overwrite existing output: {requested}")

    requested.parent.mkdir(parents=True, exist_ok=True)
    canonical_parent = requested.parent.resolve(strict=True)
    directory_flags = _open_flags("O_RDONLY", "O_DIRECTORY", "O_CLOEXEC", "O_NOFOLLOW")
    directory_fd = os.open(canonical_parent, directory_flags)
    try:
        os.stat(requested.name, dir_fd=directory_fd, follow_symlinks=False)
    except FileNotFoundError:
        return canonical_parent, requested.name, directory_fd
    except Exception:
        os.close(directory_fd)
        raise
    else:
        os.close(directory_fd)
        raise FileExistsError(f"refusing to overwrite existing output: {requested}")


def _new_temporary_fd(directory_fd: int, output_name: str) -> tuple[str, int]:
    flags = _open_flags("O_RDWR", "O_CREAT", "O_EXCL", "O_CLOEXEC", "O_NOFOLLOW")
    for _ in range(128):
        name = f".{output_name}.{secrets.token_hex(16)}.tmp"
        try:
            return name, os.open(name, flags, 0o600, dir_fd=directory_fd)
        except FileExistsError:
            continue
    raise FileExistsError("could not allocate a unique archive temporary file")


def _digest_stream(stream) -> str:
    digest = hashlib.sha256()
    stream.seek(0)
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            return digest.hexdigest()
        digest.update(chunk)


def build_archive(output: Path, sources: tuple[PurePosixPath, ...]) -> str:
    _canonical_parent, output_name, directory_fd = _output_location(output)
    temporary_name = ""
    temporary_fd = -1
    try:
        temporary_name, temporary_fd = _new_temporary_fd(directory_fd, output_name)
        expected_identities = getattr(sources, "identities", {})
        with os.fdopen(temporary_fd, "w+b", closefd=False) as stream:
            with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_STORED,
                                 strict_timestamps=True) as archive:
                for relative in sources:
                    data = _read_validated_source(relative, expected_identities.get(relative))
                    info = zipfile.ZipInfo(relative.as_posix(), ARCHIVE_TIME)
                    info.create_system = 3
                    info.compress_type = zipfile.ZIP_STORED
                    mode = 0o755 if relative.as_posix() in EXECUTABLES else 0o644
                    info.external_attr = (stat.S_IFREG | mode) << 16
                    info.flag_bits |= 0x800
                    archive.writestr(info, data)
            stream.flush()
            os.fsync(temporary_fd)
            stream.seek(0)
            with zipfile.ZipFile(stream) as archive:
                names = archive.namelist()
                if names != [str(path) for path in sources] or archive.testzip() is not None:
                    raise ValueError("archive verification failed: entries drifted or data is corrupt")
            digest = _digest_stream(stream)

        os.fchmod(temporary_fd, 0o644)
        os.fsync(temporary_fd)

        temporary_stat = os.fstat(temporary_fd)
        named_temporary_stat = os.stat(
            temporary_name, dir_fd=directory_fd, follow_symlinks=False
        )
        if (_source_identity(temporary_stat) != _source_identity(named_temporary_stat)
                or not stat.S_ISREG(temporary_stat.st_mode)
                or temporary_stat.st_nlink != 1):
            raise ValueError("archive temporary file changed before publication")

        # link(2) creates the destination only when it is absent.  Unlike
        # os.replace(), a destination introduced by another process wins and is
        # preserved.  The random, mode-0600 temporary and bound directory fd are
        # the safest portable no-clobber publication primitive on macOS/Python.
        os.link(
            temporary_name,
            output_name,
            src_dir_fd=directory_fd,
            dst_dir_fd=directory_fd,
            follow_symlinks=False,
        )
        published = os.stat(output_name, dir_fd=directory_fd, follow_symlinks=False)
        if (published.st_dev, published.st_ino) != (temporary_stat.st_dev, temporary_stat.st_ino):
            raise ValueError("published archive does not match the validated temporary")
        try:
            os.fsync(directory_fd)
        except OSError as exc:
            if exc.errno not in {errno.EINVAL, errno.ENOTSUP, errno.EROFS}:
                raise
        return digest
    finally:
        if temporary_fd >= 0:
            os.close(temporary_fd)
        if temporary_name:
            try:
                os.unlink(temporary_name, dir_fd=directory_fd)
            except FileNotFoundError:
                pass
        os.close(directory_fd)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="new .zip path (existing paths are refused)")
    parser.add_argument("--list", action="store_true", help="print the resolved allowlist")
    args = parser.parse_args()
    sources = collect_source_files()
    if args.list:
        print("\n".join(map(str, sources)))
    if args.output:
        digest = build_archive(args.output, sources)
        metadata = {"output": os.path.abspath(os.fspath(args.output)), "files": len(sources),
                    "sha256": digest}
        print(json.dumps(metadata, sort_keys=True))
    if not args.list and not args.output:
        parser.error("one of --list or --output is required")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
