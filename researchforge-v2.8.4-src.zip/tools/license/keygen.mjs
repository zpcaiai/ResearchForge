#!/usr/bin/env node
/** researchforge — license signing keypair generator (ISSUING SIDE ONLY).
 *
 * Run this once, on a machine the customer never touches, to produce the keypair
 * that signs every ResearchForge license. The private key is the entire security
 * boundary of the commercial model: anyone holding it can mint a perpetual site
 * license for themselves, and because verification is offline there is no
 * revocation channel to undo it. Treat a leak as "rotate the key and re-issue
 * every outstanding license", not as "revoke one license".
 *
 * Ed25519 rather than RSA: a 64-byte signature and a 44-character public key fit
 * in a hand-pasted license file and in a source constant, key generation has no
 * parameter choices to get wrong (no key size, no exponent, no padding mode —
 * RSA's PKCS#1 v1.5 vs PSS confusion is a whole class of verifier bugs we simply
 * do not have), and signing is deterministic, so there is no per-signature
 * nonce whose reuse or bias would leak the private key the way ECDSA's does.
 *
 * Usage:
 *   node tools/license/keygen.mjs --out /secure/path/researchforge-signing.key
 *                                 [--pub /path/to/public.pem] [--force]
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

function lexicalExists(target) {
  try { fs.lstatSync(target); return true; }
  catch (error) { if (error && error.code === "ENOENT") return false; throw error; }
}

function publishFile(target, text, { force, mode }) {
  const parent = path.dirname(target);
  fs.mkdirSync(parent, { recursive: true, mode: 0o700 });
  const temporary = path.join(
    parent, `.${path.basename(target)}.${process.pid}.${crypto.randomBytes(8).toString("hex")}.tmp`);
  let fd;
  try {
    fd = fs.openSync(temporary, "wx", mode);
    fs.writeFileSync(fd, text);
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = undefined;
    if (force) fs.renameSync(temporary, target);
    else {
      fs.linkSync(temporary, target);
      fs.unlinkSync(temporary);
    }
  } catch (error) {
    if (fd !== undefined) fs.closeSync(fd);
    try { fs.unlinkSync(temporary); } catch { /* absent or already published */ }
    throw error;
  }
}

function parseArgs(argv) {
  const values = new Set(["out", "pub"]);
  const booleans = new Set(["force"]);
  const flags = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--") || a === "--") throw new Error(`unexpected argument '${a}'`);
    const eq = a.indexOf("=");
    const name = a.slice(2, eq < 0 ? undefined : eq);
    if (!values.has(name) && !booleans.has(name)) throw new Error(`unknown option --${name}`);
    if (Object.hasOwn(flags, name)) throw new Error(`--${name} was supplied twice`);
    if (booleans.has(name)) {
      if (eq >= 0) throw new Error(`--${name} is boolean and takes no value`);
      flags[name] = true;
      continue;
    }
    const value = eq >= 0 ? a.slice(eq + 1) : argv[++i];
    if (value === undefined || value === "" || value.startsWith("--")) {
      throw new Error(`--${name} requires a value`);
    }
    flags[name] = value;
  }
  return flags;
}

function physicalTarget(target) {
  let cursor = path.resolve(target);
  const suffix = [];
  for (;;) {
    try { return path.join(fs.realpathSync.native(cursor), ...suffix.reverse()); }
    catch (error) {
      if (!error || error.code !== "ENOENT") throw error;
      const parent = path.dirname(cursor);
      if (parent === cursor) throw error;
      suffix.push(path.basename(cursor));
      cursor = parent;
    }
  }
}

/** Short, stable identifier for a public key.
 *
 * Printed here, by issue.mjs, and by the server's /health so an operator can
 * confirm the CLI shipped with the same key that signs licenses. A key mismatch
 * otherwise surfaces only as "signature does not verify" on a customer's
 * machine, which is indistinguishable from a forged license.
 */
export function publicKeyFingerprint(publicKeyPem) {
  const der = crypto.createPublicKey(publicKeyPem).export({ type: "spki", format: "der" });
  return crypto.createHash("sha256").update(der).digest("hex").slice(0, 16);
}

function main(argv) {
  let flags;
  try { flags = parseArgs(argv); }
  catch (error) { console.error(error.message); return 2; }
  const out = flags.out;
  if (!out || out === true) {
    console.error("usage: keygen.mjs --out <private-key-path> [--pub <path>] [--force]");
    return 2;
  }
  const outPath = path.resolve(String(out));
  const pubPath = flags.pub && flags.pub !== true ? path.resolve(String(flags.pub)) : null;
  if (pubPath && physicalTarget(pubPath) === physicalTarget(outPath)) {
    console.error("private and public key paths must be different");
    return 3;
  }

  // Refuse to clobber without --force. Overwriting a signing key silently
  // orphans every license already in customers' hands, and the failure only
  // shows up later, on their machines, as an invalid license.
  const occupied = [outPath, ...(pubPath ? [pubPath] : [])].filter(lexicalExists);
  if (occupied.length && !flags.force) {
    console.error(`refusing to overwrite existing key path: ${occupied.join(", ")}`);
    console.error("if you truly mean to replace it, re-run with --force — every license");
    console.error("signed by the old key will stop verifying once the CLI ships the new one.");
    return 3;
  }

  const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
  const privPem = privateKey.export({ type: "pkcs8", format: "pem" });
  const pubPem = publicKey.export({ type: "spki", format: "pem" });

  const fp = publicKeyFingerprint(pubPem);
  try {
    // Publish the non-secret half first. If the private publish then loses a
    // no-clobber race, the only partial output is a useless public key rather
    // than an unpaired signing secret. Temp+rename/link never follows an
    // existing symlink or truncates an outside hardlink.
    if (pubPath) publishFile(pubPath, pubPem, { force: Boolean(flags.force), mode: 0o644 });
    publishFile(outPath, privPem, { force: Boolean(flags.force), mode: 0o600 });
  } catch (error) {
    console.error(`cannot publish keypair: ${error.code ?? error.message ?? "error"}`);
    return 4;
  }
  if (pubPath) console.error(`public key written to ${pubPath}`);

  console.error("");
  console.error("  ############################################################");
  console.error("  #  PRIVATE SIGNING KEY WRITTEN — THIS FILE IS THE PRODUCT  #");
  console.error("  ############################################################");
  console.error("");
  console.error(`  path        ${outPath}   (mode 0600)`);
  console.error(`  fingerprint ${fp}`);
  console.error("");
  console.error("  Anyone with this file can issue themselves a perpetual site license.");
  console.error("  Verification is offline, so there is no way to revoke one after the fact.");
  console.error("  Keep it off developer laptops, out of the repo, and out of CI logs.");
  console.error("");
  console.error("  Compile the public key below into the CLI: paste it into");
  console.error("  packages/cli/src/pubkey.ts (or have your build substitute it).");
  console.error("");

  // Public key to stdout so it can be piped; everything else went to stderr.
  process.stdout.write(pubPem);
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main(process.argv.slice(2)));
}
