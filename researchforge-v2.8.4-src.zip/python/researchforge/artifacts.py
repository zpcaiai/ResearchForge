"""The artifact store — where the contract stops being a document.

v0.1.0's central defect was that its 62 skills communicated through prose: one
skill produced `idea_portfolio.json`, another consumed "idea portfolio", and
nothing could tell they were the same thing or notice when they weren't. The fix
is not better documentation. Calls through :class:`ArtifactStore` cannot write
an artifact the caller does not own or read one it did not declare. Built-in
skills still have ordinary host filesystem access, so this is an API/contract
boundary rather than an operating-system capability boundary.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import stat
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from jsonschema import Draft202012Validator
from jsonschema import ValidationError as _JSValidationError

from .errors import ContractViolation, SchemaViolation
from .generated import ARTIFACTS, INTERNAL_ARTIFACT_SPECS, INTERNAL_ARTIFACTS, SKILLS
from .provenance import Event, ProvenanceLog


class ArtifactStore:
    #: set by the runner so internal artifacts resolve for the executing skill only
    current_skill: str | None = None

    def __init__(self, project: Path, schemas_dir: Path, run_id: str,
                 provenance: ProvenanceLog | None = None) -> None:
        self.project = Path(project)
        self.schemas_dir = Path(schemas_dir)
        self.run_id = run_id
        self.prov = provenance or ProvenanceLog(self.project)
        self._validators: dict[str, Draft202012Validator] = {}

    # ---------- contract ----------
    def _spec(self, artifact_id: str, skill: str | None = None):
        spec = ARTIFACTS.get(artifact_id)
        if spec is None:
            owner = skill or self.current_skill
            if owner:
                spec = INTERNAL_ARTIFACT_SPECS.get(owner, {}).get(artifact_id)
            if spec is None:
                for m in INTERNAL_ARTIFACT_SPECS.values():
                    if artifact_id in m:
                        spec = m[artifact_id]
                        break
        if spec is None:
            raise ContractViolation(
                f"unknown artifact '{artifact_id}'. It is not in the contract. "
                f"Add it to manifests/artifact-graph.json and re-run codegen; do not "
                f"write undeclared artifacts."
            )
        return spec

    def _may_write(self, skill: str, artifact_id: str) -> None:
        if artifact_id in INTERNAL_ARTIFACTS.get(skill, ()):
            return
        spec = self._spec(artifact_id, skill)
        if spec.producer != skill:
            raise ContractViolation(
                f"skill '{skill}' tried to write '{artifact_id}', which is produced by "
                f"'{spec.producer}'. Every artifact has exactly one producer; two writers "
                f"means no one owns whether it is correct."
            )

    def _may_read(self, skill: str, artifact_id: str) -> None:
        c = SKILLS.get(skill)
        if c is None:
            raise ContractViolation(f"unknown skill '{skill}'")
        if artifact_id in c.consumes or artifact_id in c.feedback:
            return
        if artifact_id in INTERNAL_ARTIFACTS.get(skill, ()):
            return
        spec = ARTIFACTS.get(artifact_id)
        if spec is not None and spec.producer == skill:
            return
        raise ContractViolation(
            f"skill '{skill}' tried to read '{artifact_id}', which is not in its declared "
            f"inputs. Declared: {sorted(c.consumes)}. If this read is legitimate, it is a "
            f"change to the contract, not to the code."
        )

    # ---------- schema ----------
    def _validator(self, schema_name: str) -> Draft202012Validator:
        if schema_name not in self._validators:
            p = self.schemas_dir / f"{schema_name}.schema.json"
            if not p.exists():
                raise SchemaViolation(f"schema '{schema_name}' declared but {p} is missing")
            self._validators[schema_name] = Draft202012Validator(json.loads(p.read_text()))
        return self._validators[schema_name]

    def _validate(self, artifact_id: str, payload: Any, skill: str | None = None) -> None:
        spec = self._spec(artifact_id, skill)
        if not spec.schema:
            return
        v = self._validator(spec.schema)
        items = payload if isinstance(payload, list) else [payload]
        for i, item in enumerate(items):
            try:
                v.validate(item)
            except _JSValidationError as e:
                where = f"[{i}]" if isinstance(payload, list) else ""
                raise SchemaViolation(
                    f"'{artifact_id}'{where} does not validate against {spec.schema}: "
                    f"{e.message} (at {'/'.join(str(x) for x in e.absolute_path) or '<root>'})"
                ) from e

    # ---------- paths ----------
    def path_for(self, artifact_id: str) -> Path:
        spec = self._spec(artifact_id)
        rel = spec.path.split("|")[0]
        return self.project / rel

    @contextmanager
    def _safe_parent(self, path: Path, *,
                     create: bool = True) -> Iterator[tuple[int, str]]:
        """Open an artifact parent without following filesystem indirections.

        Artifact paths come from the generated contract, but their on-disk
        components may have been pre-created by an untrusted checkout.  Walking
        with directory file descriptors keeps every lookup anchored below the
        project and makes a symlink in any parent fail closed.
        """
        try:
            rel = path.relative_to(self.project)
        except ValueError as exc:
            raise ContractViolation(
                f"artifact path {path!s} is outside project {self.project!s}"
            ) from exc
        if not rel.parts or any(part in ("", ".", "..") for part in rel.parts):
            raise ContractViolation(f"artifact path {rel!s} is not a safe relative path")

        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        directory_flags |= getattr(os, "O_NOFOLLOW", 0)
        try:
            current = os.open(self.project, directory_flags)
        except OSError as exc:
            raise ContractViolation(
                f"project root {self.project!s} is not a safe directory: {exc.strerror}"
            ) from exc
        try:
            for component in rel.parts[:-1]:
                try:
                    child = os.open(component, directory_flags, dir_fd=current)
                except FileNotFoundError:
                    if not create:
                        raise
                    try:
                        os.mkdir(component, mode=0o755, dir_fd=current)
                    except FileExistsError:
                        pass
                    try:
                        child = os.open(component, directory_flags, dir_fd=current)
                    except OSError as exc:
                        raise ContractViolation(
                            f"artifact parent component {component!r} is not a safe directory"
                        ) from exc
                except OSError as exc:
                    raise ContractViolation(
                        f"artifact parent component {component!r} is not a safe directory"
                    ) from exc
                os.close(current)
                current = child
            yield current, rel.parts[-1]
        finally:
            os.close(current)

    @staticmethod
    def _checked_regular_file(fd: int, path: Path) -> None:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ContractViolation(f"artifact target {path!s} is not a regular file")
        if info.st_nlink != 1:
            raise ContractViolation(
                f"artifact target {path!s} has {info.st_nlink} hard links; refusing to "
                "overwrite a peer path"
            )

    @staticmethod
    def _write_all(fd: int, payload: bytes) -> None:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("artifact write made no progress")
            view = view[written:]

    @staticmethod
    def _read_all(fd: int) -> bytes:
        os.lseek(fd, 0, os.SEEK_SET)
        chunks = []
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                return b"".join(chunks)
            chunks.append(chunk)

    def _write_bytes(self, path: Path, payload: bytes) -> str:
        """Atomically replace a regular single-link artifact and return its digest."""
        nofollow = getattr(os, "O_NOFOLLOW", 0)
        cloexec = getattr(os, "O_CLOEXEC", 0)
        with self._safe_parent(path) as (parent, name):
            mode = 0o666
            try:
                existing = os.stat(name, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                existing = None
            except OSError as exc:
                raise ContractViolation(
                    f"artifact target {path!s} is not a safe regular file"
                ) from exc
            if existing is not None:
                if not stat.S_ISREG(existing.st_mode):
                    raise ContractViolation(
                        f"artifact target {path!s} is not a safe regular file"
                    )
                if existing.st_nlink != 1:
                    raise ContractViolation(
                        f"artifact target {path!s} has {existing.st_nlink} hard links; "
                        "refusing to overwrite a peer path"
                    )
                mode = stat.S_IMODE(existing.st_mode)

            temporary = f".{name}.rf-{secrets.token_hex(16)}.tmp"
            flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | nofollow | cloexec
            fd = -1
            try:
                fd = os.open(temporary, flags, mode, dir_fd=parent)
                self._checked_regular_file(fd, path)
                self._write_all(fd, payload)
                os.fsync(fd)
                self._checked_regular_file(fd, path)
                digest = hashlib.sha256(self._read_all(fd)).hexdigest()
                os.close(fd)
                fd = -1
                os.replace(temporary, name, src_dir_fd=parent, dst_dir_fd=parent)
            finally:
                if fd >= 0:
                    os.close(fd)
                try:
                    os.unlink(temporary, dir_fd=parent)
                except FileNotFoundError:
                    pass
        return digest

    def _append_bytes(self, path: Path, payload: bytes) -> str:
        flags = os.O_RDWR | os.O_APPEND | os.O_CREAT | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        with self._safe_parent(path) as (parent, name):
            try:
                fd = os.open(name, flags, 0o666, dir_fd=parent)
            except OSError as exc:
                raise ContractViolation(
                    f"artifact target {path!s} is not a safe regular file"
                ) from exc
            try:
                self._checked_regular_file(fd, path)
                self._write_all(fd, payload)
                os.fsync(fd)
                self._checked_regular_file(fd, path)
                digest = hashlib.sha256(self._read_all(fd)).hexdigest()
            finally:
                os.close(fd)
        return digest

    def _read_bytes(self, path: Path) -> bytes:
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        with self._safe_parent(path, create=False) as (parent, name):
            try:
                fd = os.open(name, flags, dir_fd=parent)
            except FileNotFoundError:
                raise
            except OSError as exc:
                raise ContractViolation(
                    f"artifact target {path!s} is not a safe regular file"
                ) from exc
            try:
                self._checked_regular_file(fd, path)
                return self._read_all(fd)
            finally:
                os.close(fd)

    def _exists_safe(self, path: Path) -> bool:
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        try:
            with self._safe_parent(path, create=False) as (parent, name):
                try:
                    fd = os.open(name, flags, dir_fd=parent)
                except FileNotFoundError:
                    return False
                except OSError as exc:
                    raise ContractViolation(
                        f"artifact target {path!s} is not a safe regular file"
                    ) from exc
                try:
                    self._checked_regular_file(fd, path)
                    return True
                finally:
                    os.close(fd)
        except FileNotFoundError:
            return False

    def exists(self, artifact_id: str) -> bool:
        p = self.path_for(artifact_id)
        if self._spec(artifact_id).path.endswith("/"):
            p = p / "_manifest.json"
        return self._exists_safe(p)

    # ---------- io ----------
    def write(self, skill: str, artifact_id: str, payload: Any, *,
              detail: dict[str, Any] | None = None) -> Path:
        self._may_write(skill, artifact_id)
        self._validate(artifact_id, payload, skill)
        self.current_skill = skill
        p = self.path_for(artifact_id)
        if self._spec(artifact_id).path.endswith("/"):
            # directory-valued artifact: the manifest inside it is what carries provenance
            p = p / "_manifest.json"
        if p.suffix == ".jsonl":
            if not isinstance(payload, list):
                raise ContractViolation(f"'{artifact_id}' is .jsonl; payload must be a list")
            encoded = "".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n"
                              for r in payload).encode("utf-8")
        elif p.suffix in (".json",):
            encoded = json.dumps(payload, ensure_ascii=False, indent=1,
                                 sort_keys=True).encode("utf-8")
        elif isinstance(payload, (str, bytes)):
            encoded = payload.encode() if isinstance(payload, str) else payload
        else:
            encoded = json.dumps(payload, ensure_ascii=False, indent=1).encode("utf-8")
        digest = self._write_bytes(p, encoded)
        self.prov.append(Event(self.prov.now(), self.run_id, skill, "artifact_write",
                               artifact_id, str(p.relative_to(self.project)),
                               digest, detail or {}))
        return p

    def write_member(self, skill: str, artifact_id: str, member: str | Path,
                     payload: str | bytes, *,
                     detail: dict[str, Any] | None = None) -> Path:
        """Safely write one file inside a declared directory-valued artifact.

        Directory artifacts used to call :meth:`path_for` and then write through
        ordinary ``Path`` APIs, bypassing the store's parent and target link
        checks.  Keep the public artifact API while applying the same atomic,
        fd-bound write used for scalar artifacts to each member.
        """
        self._may_write(skill, artifact_id)
        spec = self._spec(artifact_id, skill)
        if not spec.path.endswith("/"):
            raise ContractViolation(
                f"'{artifact_id}' is not a directory-valued artifact"
            )
        relative = Path(member)
        if (relative.is_absolute() or not relative.parts
                or any(part in ("", ".", "..") for part in relative.parts)):
            raise ContractViolation(
                f"directory artifact member {str(member)!r} is not a safe relative path"
            )
        if not isinstance(payload, (str, bytes)):
            raise ContractViolation(
                "directory artifact member payload must be text or bytes"
            )
        self.current_skill = skill
        path = self.path_for(artifact_id).joinpath(*relative.parts)
        encoded = payload.encode("utf-8") if isinstance(payload, str) else payload
        digest = self._write_bytes(path, encoded)
        event_detail = dict(detail or {})
        event_detail["member"] = relative.as_posix()
        self.prov.append(Event(self.prov.now(), self.run_id, skill, "artifact_write",
                               artifact_id, str(path.relative_to(self.project)),
                               digest, event_detail))
        return path

    def read_member(self, skill: str, artifact_id: str, member: str | Path, *,
                    default: Any = None) -> bytes | Any:
        """Safely read one file inside a declared directory-valued artifact."""
        self._may_read(skill, artifact_id)
        spec = self._spec(artifact_id, skill)
        if not spec.path.endswith("/"):
            raise ContractViolation(
                f"'{artifact_id}' is not a directory-valued artifact"
            )
        relative = Path(member)
        if (relative.is_absolute() or not relative.parts
                or any(part in ("", ".", "..") for part in relative.parts)):
            raise ContractViolation(
                f"directory artifact member {str(member)!r} is not a safe relative path"
            )
        path = self.path_for(artifact_id).joinpath(*relative.parts)
        try:
            encoded = self._read_bytes(path)
        except FileNotFoundError:
            if default is not None:
                return default
            raise ContractViolation(
                f"skill '{skill}' requires member {relative.as_posix()!r} of "
                f"'{artifact_id}', but it has not been produced"
            )
        self.prov.append(Event(self.prov.now(), self.run_id, skill, "artifact_read",
                               artifact_id, str(path.relative_to(self.project)), None,
                               {"member": relative.as_posix()}))
        return encoded

    def append_jsonl(self, skill: str, artifact_id: str, records: list[Any]) -> Path:
        """Append to a ledger without rewriting it. Ledgers are append-only by design."""
        self._may_write(skill, artifact_id)
        self._validate(artifact_id, records, skill)
        self.current_skill = skill
        p = self.path_for(artifact_id)
        encoded = "".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n"
                          for r in records).encode("utf-8")
        digest = self._append_bytes(p, encoded)
        self.prov.append(Event(self.prov.now(), self.run_id, skill, "artifact_write",
                               artifact_id, str(p.relative_to(self.project)),
                               digest, {"appended": len(records)}))
        return p

    def read(self, skill: str, artifact_id: str, *, default: Any = None) -> Any:
        self._may_read(skill, artifact_id)
        p = self.path_for(artifact_id)
        try:
            encoded = self._read_bytes(p)
        except FileNotFoundError:
            if default is not None:
                return default
            raise ContractViolation(
                f"skill '{skill}' requires '{artifact_id}' but it has not been produced. "
                f"Its producer is '{self._spec(artifact_id).producer}', which has not run."
            )
        self.prov.append(Event(self.prov.now(), self.run_id, skill, "artifact_read",
                               artifact_id, str(p.relative_to(self.project)), None, {}))
        if p.suffix == ".jsonl":
            return [json.loads(l) for l in encoded.decode("utf-8").splitlines() if l.strip()]
        if p.suffix == ".json":
            return json.loads(encoded.decode("utf-8"))
        return encoded.decode("utf-8", errors="replace")
