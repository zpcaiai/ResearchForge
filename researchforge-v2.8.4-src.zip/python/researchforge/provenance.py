"""Append-only provenance. Nothing that isn't in here happened."""
from __future__ import annotations

import hashlib
import json
import os
import stat
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .errors import ContractViolation


def sha256_file(p: Path) -> str:
    """Hash one stable, exclusively owned regular file without following links."""
    absolute = Path(os.path.abspath(os.fspath(p)))
    parts = absolute.parts
    if not parts or not absolute.is_absolute():
        raise ContractViolation(f"digest path {p!s} is not absolute")
    directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) \
        | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    file_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) \
        | getattr(os, "O_CLOEXEC", 0)
    directory = os.open(parts[0], directory_flags)
    fd = -1
    try:
        for component in parts[1:-1]:
            child = os.open(component, directory_flags, dir_fd=directory)
            os.close(directory)
            directory = child
        fd = os.open(parts[-1], file_flags, dir_fd=directory)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise ContractViolation(
                f"digest path {p!s} is not an exclusively owned regular file"
            )
        named_before = os.stat(parts[-1], dir_fd=directory, follow_symlinks=False)
        if (named_before.st_dev, named_before.st_ino) != (before.st_dev, before.st_ino):
            raise ContractViolation(f"digest path {p!s} changed before it was read")
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            h.update(chunk)
        after = os.fstat(fd)
        named_after = os.stat(parts[-1], dir_fd=directory, follow_symlinks=False)
        identity = lambda info: (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
                                 info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        if identity(after) != identity(before) or identity(named_after) != identity(before):
            raise ContractViolation(f"digest path {p!s} changed while it was read")
        return h.hexdigest()
    except ContractViolation:
        raise
    except OSError as exc:
        raise ContractViolation(
            f"digest path {p!s} could not be opened without following links"
        ) from exc
    finally:
        if fd >= 0:
            os.close(fd)
        os.close(directory)


@dataclass
class Event:
    ts: float
    run_id: str
    skill: str
    kind: str                       # artifact_write | artifact_read | skill_start | skill_end | gate | decision | provider_call
    artifact_id: str | None = None
    path: str | None = None
    digest: str | None = None
    detail: dict[str, Any] = field(default_factory=dict)


class ProvenanceLog:
    """One file, opened append-only, fsynced on write.

    Fsync matters here: a run killed mid-experiment must not lose the record of
    what it had already done, or resume will re-run work whose results already
    exist and quietly produce two ledger entries for one experiment.
    """

    def __init__(self, project: Path) -> None:
        self.path = project / "provenance.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _open(self, flags: int, *, create: bool = False) -> int:
        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        directory_flags |= getattr(os, "O_NOFOLLOW", 0)
        try:
            parent = os.open(self.path.parent, directory_flags)
        except OSError as exc:
            raise ContractViolation(
                f"provenance parent {self.path.parent!s} is not a safe directory"
            ) from exc
        try:
            file_flags = flags | getattr(os, "O_NOFOLLOW", 0) \
                | getattr(os, "O_CLOEXEC", 0)
            if create:
                file_flags |= os.O_CREAT
            try:
                fd = os.open(self.path.name, file_flags, 0o666, dir_fd=parent)
            except FileNotFoundError:
                raise
            except OSError as exc:
                raise ContractViolation(
                    f"provenance path {self.path!s} is not a safe regular file"
                ) from exc
        finally:
            os.close(parent)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            os.close(fd)
            detail = "not a regular file" if not stat.S_ISREG(info.st_mode) \
                else f"has {info.st_nlink} hard links"
            raise ContractViolation(f"provenance path {self.path!s} {detail}")
        return fd

    def append(self, ev: Event) -> None:
        line = (json.dumps(asdict(ev), ensure_ascii=False, sort_keys=True) + "\n").encode()
        fd = self._open(os.O_WRONLY | os.O_APPEND, create=True)
        try:
            view = memoryview(line)
            while view:
                written = os.write(fd, view)
                if written <= 0:
                    raise OSError("provenance write made no progress")
                view = view[written:]
            os.fsync(fd)
        finally:
            os.close(fd)

    def read(self) -> list[Event]:
        try:
            fd = self._open(os.O_RDONLY)
        except FileNotFoundError:
            return []
        try:
            chunks = []
            while True:
                chunk = os.read(fd, 1 << 20)
                if not chunk:
                    break
                chunks.append(chunk)
        finally:
            os.close(fd)
        out = []
        for line in b"".join(chunks).decode("utf-8").splitlines():
            if line.strip():
                out.append(Event(**json.loads(line)))
        return out

    def events_for(self, artifact_id: str) -> list[Event]:
        return [e for e in self.read() if e.artifact_id == artifact_id]

    def now(self) -> float:
        return time.time()
