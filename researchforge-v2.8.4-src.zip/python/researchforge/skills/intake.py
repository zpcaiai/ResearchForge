"""Intake: repository, sandbox, ingestion, paper model."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from .. import __version__
from ..errors import GateBlocked
from ..skill import Context, Skill, SkillResult, register

ARXIV_RE = re.compile(r"(?:arxiv\.org/(?:abs|pdf)/|arXiv:)\s*(\d{4}\.\d{4,5})(v\d+)?", re.I)
DOI_RE = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Z0-9]+\b", re.I)

STRICT_SANDBOX_PROFILE = "no-network-untrusted-code"
TRUSTED_HOST_PROFILE = "trusted-host-code"
DEFAULT_SANDBOX_IMAGE = "python:3.11-slim"
_IMAGE_ID_RE = re.compile(r"sha256:[0-9a-f]{64}\Z")
_CONTAINER_ID_RE = re.compile(r"[0-9a-f]{64}\Z")
_SAFE_IMAGE_REF_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/:@-]{0,254}\Z")
_GPU_SMOKE_PREFIX = "RF_GPU_SMOKE "


def _sandbox_image_reference(value: Any) -> str:
    """Return a Docker image reference safe to pass as one CLI argument.

    The daemon remains the authority on Docker's full reference grammar.  This
    boundary rejects empty values, options, whitespace/control characters and
    shell punctuation before any daemon call, then the provisioner resolves the
    accepted reference to an immutable local image ID.
    """
    image = value if isinstance(value, str) else ""
    if not _SAFE_IMAGE_REF_RE.fullmatch(image):
        raise GateBlocked(
            "sandbox_image",
            "sandbox_image must be a nonempty Docker image reference of at most 255 "
            "characters using only letters, digits, '.', '_', '/', ':', '@' and '-'; "
            "it may not begin with an option or contain whitespace/control characters.",
            f"pass a local image reference such as {DEFAULT_SANDBOX_IMAGE!r}",
        )
    return image


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _docker_command(command: list[str], *, timeout: float = 10) -> subprocess.CompletedProcess:
    """Run a small, trusted Docker metadata probe with loss-tolerant decoding."""
    return subprocess.run(command, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout)


def _local_docker_identity(docker: str) -> tuple[dict[str, Any], str | None]:
    """Resolve the exact local Docker client, endpoint and daemon being trusted.

    Docker contexts can transparently target SSH/TCP engines.  Such an engine
    cannot safely consume a host bind path, and calling it would make a
    "local-only" validation perform network I/O.  Context metadata is therefore
    checked before the first daemon command and only an absolute Unix socket is
    accepted.
    """
    identity: dict[str, Any] = {}
    try:
        real = Path(docker).resolve(strict=True)
        if not real.is_file() or not os.access(real, os.X_OK):
            return identity, "docker executable is not a regular executable file"
        identity.update(docker_realpath=str(real), docker_sha256=_file_sha256(real))
    except (OSError, ValueError) as exc:
        return identity, f"docker executable identity failed: {type(exc).__name__}"

    # Docker gives DOCKER_CONTEXT precedence over DOCKER_HOST. Mirror that
    # order exactly so a local DOCKER_HOST cannot mask a remote effective
    # context during this supposedly local-only validation.
    context_override = os.environ.get("DOCKER_CONTEXT")
    host_override = os.environ.get("DOCKER_HOST")
    try:
        if context_override:
            context = context_override.strip()
            if not context or any(ord(char) < 32 for char in context):
                return identity, "DOCKER_CONTEXT is not a safe context name"
            inspected = _docker_command(
                [str(real), "context", "inspect", context, "--format",
                 "{{json .Endpoints.docker.Host}}"])
            if inspected.returncode != 0:
                return identity, f"docker context {context!r} could not be inspected"
            try:
                endpoint = json.loads(inspected.stdout.strip())
            except json.JSONDecodeError:
                endpoint = inspected.stdout.strip().strip('"')
        elif host_override:
            context = "DOCKER_HOST"
            endpoint = host_override.strip()
        else:
            shown = _docker_command([str(real), "context", "show"])
            context = shown.stdout.strip()
            if shown.returncode != 0 or not context or "\n" in context:
                return identity, "docker context could not be determined"
            inspected = _docker_command(
                [str(real), "context", "inspect", context, "--format",
                 "{{json .Endpoints.docker.Host}}"])
            if inspected.returncode != 0:
                return identity, f"docker context {context!r} could not be inspected"
            try:
                endpoint = json.loads(inspected.stdout.strip())
            except json.JSONDecodeError:
                endpoint = inspected.stdout.strip().strip('"')
        if not isinstance(endpoint, str) or not endpoint.startswith("unix://"):
            return identity, (
                f"docker endpoint {endpoint!r} is not a local Unix socket; "
                "ssh/tcp/npipe/fd contexts are refused")
        socket_path = endpoint[len("unix://"):]
        if not socket_path.startswith("/") or "\x00" in socket_path:
            return identity, f"docker Unix endpoint {endpoint!r} is not an absolute safe path"
        identity.update(context=context, endpoint=endpoint)

        info = _docker_command(
            [str(real), "info", "--format", "{{.ID}}\t{{.ServerVersion}}\t{{.OSType}}"])
    except (OSError, subprocess.TimeoutExpired) as exc:
        return identity, f"docker daemon probe failed: {type(exc).__name__}"
    if info.returncode != 0:
        detail = (info.stderr or info.stdout).strip().splitlines()
        return identity, "docker daemon is not reachable" + (
            f": {detail[-1][:240]}" if detail else "")
    fields = info.stdout.strip().split("\t")
    if len(fields) != 3 or not fields[0] or fields[2] != "linux":
        return identity, "docker daemon did not report a stable ID and Linux container mode"
    identity.update(daemon_id=fields[0], server_version=fields[1] or "unknown",
                    daemon_os=fields[2])
    return identity, None


def _cid_from(path: Path) -> str | None:
    try:
        value = path.read_text(encoding="ascii").strip()
    except (OSError, UnicodeError):
        return None
    return value if _CONTAINER_ID_RE.fullmatch(value) else None


def _remove_exact_container(docker: str, cidfile: Path) -> None:
    """Best-effort cleanup, but only after validating Docker's exact full ID."""
    cid = _cid_from(cidfile)
    if not cid:
        return
    try:
        subprocess.run([docker, "rm", "-f", cid], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        pass


def _smoke_validate_image(docker: str, image_id: str) -> tuple[dict[str, Any], str | None]:
    """Prove the immutable image can run Python as non-root under run-time flags."""
    smoke: dict[str, Any] = {"validated": False, "python_entrypoint": False,
                             "nonroot_uid": None}
    with tempfile.TemporaryDirectory(prefix="rf-sandbox-smoke-") as tmp:
        cidfile = Path(tmp) / "container.cid"
        command = [
            docker, "run", "--rm", "--cidfile", str(cidfile), "--pull=never",
            "--network", "none", "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--pids-limit", "32",
            "--memory", str(128 << 20), "--cpus", "0.25", "--user", "65534:65534",
            "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,mode=1777,size=16m",
            "--env", "HOME=/tmp", "--env", "TMPDIR=/tmp", "--entrypoint", "python",
            image_id, "-c", "import os; print('RF_SANDBOX_SMOKE', os.geteuid())",
        ]
        try:
            run = subprocess.run(command, capture_output=True, timeout=20)
        except subprocess.TimeoutExpired:
            _remove_exact_container(docker, cidfile)
            return smoke, "sandbox image smoke test timed out and its container was removed"
        except OSError as exc:
            _remove_exact_container(docker, cidfile)
            return smoke, f"sandbox image smoke test failed: {type(exc).__name__}"
        if run.returncode != 0:
            _remove_exact_container(docker, cidfile)
            detail = run.stderr.decode("utf-8", errors="replace").strip().splitlines()
            return smoke, "sandbox image cannot run the restrictive Python smoke test" + (
                f": {detail[-1][:240]}" if detail else "")
        output = run.stdout.decode("utf-8", errors="replace").strip()
        if output != "RF_SANDBOX_SMOKE 65534":
            _remove_exact_container(docker, cidfile)
            return smoke, "sandbox image smoke test did not prove Python ran as uid 65534"
        smoke.update(validated=True, python_entrypoint=True, nonroot_uid=65534,
                     command_contract="no-network/read-only/nonroot/no-new-privileges")
        return smoke, None


def _smoke_validate_gpu(docker: str, image_id: str) -> tuple[dict[str, Any], str | None]:
    """Prove NVIDIA allocation and CUDA usability inside the exact execution image.

    Host discovery is not container evidence.  Acceptance therefore requires a
    second restrictive smoke run with Docker's NVIDIA device request and a
    fixed in-container ``torch.cuda`` probe.  An image without a compatible
    PyTorch/CUDA stack is not acceptance-ready, even when the host has a GPU.
    """
    evidence: dict[str, Any] = {
        "requested": True, "validated": False, "runtime": "nvidia",
        "selector": "all", "device_count": 0, "devices": [],
    }
    probe = (
        "import json,torch; "
        "assert torch.cuda.is_available(), 'torch.cuda.is_available() is false'; "
        "n=torch.cuda.device_count(); assert n>0, 'no CUDA devices'; "
        "d=[{'index':i,'name':torch.cuda.get_device_name(i),"
        "'capability':'.'.join(map(str,torch.cuda.get_device_capability(i)))} "
        "for i in range(n)]; "
        f"print({_GPU_SMOKE_PREFIX!r}+json.dumps({{'device_count':n,'devices':d,"
        "'torch_version':torch.__version__,'cuda_runtime':torch.version.cuda}},"
        "separators=(',',':'),sort_keys=True))"
    )
    with tempfile.TemporaryDirectory(prefix="rf-gpu-smoke-") as tmp:
        cidfile = Path(tmp) / "container.cid"
        command = [
            docker, "run", "--rm", "--cidfile", str(cidfile), "--pull=never",
            "--network", "none", "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--pids-limit", "64",
            "--memory", str(1 << 30), "--cpus", "1", "--user", "65534:65534",
            "--gpus", "all",
            "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,mode=1777,size=32m",
            "--env", "HOME=/tmp", "--env", "TMPDIR=/tmp", "--entrypoint", "python",
            image_id, "-c", probe,
        ]
        try:
            run = subprocess.run(command, capture_output=True, timeout=60)
        except subprocess.TimeoutExpired:
            _remove_exact_container(docker, cidfile)
            return evidence, "GPU smoke test timed out and its exact container was removed"
        except OSError as exc:
            _remove_exact_container(docker, cidfile)
            return evidence, f"GPU smoke test failed: {type(exc).__name__}"
        if run.returncode != 0:
            _remove_exact_container(docker, cidfile)
            detail = run.stderr.decode("utf-8", errors="replace").strip().splitlines()
            return evidence, (
                "the immutable image could not use an allocated NVIDIA GPU with torch.cuda" +
                (f": {detail[-1][:240]}" if detail else ""))
        if len(run.stdout) > (1 << 20):
            _remove_exact_container(docker, cidfile)
            return evidence, "GPU smoke evidence exceeded the 1 MiB capture limit"
        output = run.stdout.decode("utf-8", errors="replace").strip()
        if not output.startswith(_GPU_SMOKE_PREFIX):
            return evidence, "GPU smoke test emitted no recognised evidence record"
        try:
            payload = json.loads(output[len(_GPU_SMOKE_PREFIX):])
        except json.JSONDecodeError:
            return evidence, "GPU smoke test emitted malformed JSON evidence"
        devices = payload.get("devices") if isinstance(payload, dict) else None
        count = payload.get("device_count") if isinstance(payload, dict) else None
        valid_devices = (
            isinstance(count, int) and not isinstance(count, bool) and count > 0
            and isinstance(devices, list) and len(devices) == count
            and all(isinstance(row, dict)
                    and isinstance(row.get("index"), int)
                    and isinstance(row.get("name"), str) and row.get("name")
                    and isinstance(row.get("capability"), str) and row.get("capability")
                    for row in devices)
        )
        if not valid_devices:
            return evidence, "GPU smoke evidence did not describe every allocated CUDA device"
        torch_version = payload.get("torch_version")
        cuda_runtime = payload.get("cuda_runtime")
        if not isinstance(torch_version, str) or not torch_version or not isinstance(cuda_runtime, str) \
                or not cuda_runtime:
            return evidence, "GPU smoke evidence did not name PyTorch and CUDA runtime versions"
        evidence.update(validated=True, device_count=count, devices=devices,
                        torch_version=torch_version, cuda_runtime=cuda_runtime,
                        command_contract="docker --gpus all/torch.cuda/restrictive-runtime")
        return evidence, None


def _capture_container_environment(docker: str, image_id: str,
                                   daemon_id: str) -> tuple[str | None, dict[str, Any], str | None]:
    """Measure installed distributions inside the exact execution image."""
    measurement: dict[str, Any] = {
        "source_backend": "docker", "container_image_id": image_id,
        "daemon_id": daemon_id, "measured": False,
    }
    with tempfile.TemporaryDirectory(prefix="rf-environment-lock-") as tmp:
        cidfile = Path(tmp) / "container.cid"
        command = [
            docker, "run", "--rm", "--cidfile", str(cidfile), "--pull=never",
            "--network", "none", "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--pids-limit", "32",
            "--memory", str(256 << 20), "--cpus", "0.5", "--user", "65534:65534",
            "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,mode=1777,size=16m",
            "--env", "HOME=/tmp", "--env", "TMPDIR=/tmp", "--entrypoint", "python",
            image_id, "-m", "pip", "freeze", "--all",
        ]
        try:
            run = subprocess.run(command, capture_output=True, timeout=30)
        except subprocess.TimeoutExpired:
            _remove_exact_container(docker, cidfile)
            return None, measurement, (
                "container environment measurement timed out and its exact container was removed")
        except OSError as exc:
            _remove_exact_container(docker, cidfile)
            return None, measurement, (
                f"container environment measurement failed: {type(exc).__name__}")
        if run.returncode != 0:
            _remove_exact_container(docker, cidfile)
            detail = run.stderr.decode("utf-8", errors="replace").strip().splitlines()
            return None, measurement, "container Python could not produce pip freeze --all" + (
                f": {detail[-1][:240]}" if detail else "")
        if len(run.stdout) > (1 << 20):
            _remove_exact_container(docker, cidfile)
            return None, measurement, "container environment lock exceeded the 1 MiB capture limit"
        packages = run.stdout.decode("utf-8", errors="replace")
        lock = (
            "# measured_by=container-python-pip-freeze\n"
            f"# execution_backend=docker\n# container_image_id={image_id}\n"
            f"# docker_daemon_id={daemon_id}\n" + packages
        )
        measurement.update(measured=True, command="python -m pip freeze --all",
                           sha256=hashlib.sha256(lock.encode("utf-8")).hexdigest())
        return lock, measurement, None


def _validate_local_docker_image(image: str, *, gpu_required: bool = False) -> dict[str, Any]:
    """Validate a usable, already-local Docker backend without using the network.

    A binary on ``PATH`` is not a sandbox: Docker Desktop may be stopped, the
    caller may not be allowed to reach the daemon, or the configured image may be
    absent.  The runner consumes the immutable image id returned here and uses
    ``--pull=never``; provisioning therefore never turns a missing image into an
    implicit network operation.
    """
    docker = shutil.which("docker")
    result: dict[str, Any] = {
        "validated": False,
        "docker_path": docker,
        "daemon_reachable": False,
        "image_present": False,
        "image": image,
        "image_id": None,
        "gpu": {"requested": gpu_required, "validated": False,
                "runtime": "nvidia" if gpu_required else "none",
                "selector": "all" if gpu_required else "none",
                "device_count": 0, "devices": []},
    }
    if not docker:
        result["reason"] = "docker executable not found"
        return result
    identity, reason = _local_docker_identity(docker)
    result.update(identity)
    if reason:
        result["reason"] = reason
        return result
    result["daemon_reachable"] = True
    docker_real = str(identity["docker_realpath"])
    try:
        inspect = _docker_command(
            [docker_real, "image", "inspect", "--format", "{{.Id}}", image])
    except (OSError, subprocess.TimeoutExpired) as exc:
        result["reason"] = f"docker image probe failed: {type(exc).__name__}"
        return result
    image_id = inspect.stdout.strip()
    if inspect.returncode != 0 or not _IMAGE_ID_RE.fullmatch(image_id):
        result["reason"] = (
            f"local image {image!r} is unavailable or did not resolve to an immutable sha256 id; "
            "no pull was attempted")
        return result
    result.update(image_present=True, image_id=image_id)
    smoke, reason = _smoke_validate_image(docker_real, image_id)
    result["smoke"] = smoke
    if reason:
        result["reason"] = reason
        return result
    if gpu_required:
        gpu, reason = _smoke_validate_gpu(docker_real, image_id)
        result["gpu"] = gpu
        if reason:
            result["reason"] = reason
            return result
    result.update(validated=True, validated_at=time.time())
    return result


@register
class ProjectRepoManager(Skill):
    name = "project-repo-manager"

    def execute(self, ctx: Context) -> SkillResult:
        locator = ctx.external("paper_locator", required=True)
        intent = ctx.external("project_intent", "unspecified")
        root = ctx.project
        git = (root / ".git").exists()
        if not git:
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "runtime@researchforge.local"],
                           cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "ResearchForge"], cwd=root, check=True)
            (root / ".gitignore").write_text(
                # data and secrets must never be committable by accident
                "*.env\n.env\n**/secrets*\nsource/assets/\nanalysis/prepared/\n"
                "*.ckpt\n*.pt\n*.safetensors\n__pycache__/\n", encoding="utf-8")
        for d in ("source", "literature", "reproduction", "baseline", "ideas", "experiments",
                  "analysis", "evidence", "paper", "figures", "slides", "review", "release",
                  ".researchforge"):
            (root / d).mkdir(exist_ok=True)
        ctx.store.write(self.name, "quest_repo",
                        {"root": str(root), "initialized_git": not git,
                         "paper_locator": locator, "project_intent": intent,
                         "created_at": time.time()})
        ctx.store.write(self.name, "branch_map",
                        {"main": "main", "ideas": {}, "experiments": {},
                         "policy": "failed branches are retained until their findings are distilled"})
        ctx.store.write(self.name, "checkpoint_metadata", [
            {"ts": time.time(), "state": "INGESTED", "note": "project initialized",
             "run_id": ctx.run_id}])
        return SkillResult(self.name, produced=list(ctx.store and
                           ["quest_repo", "branch_map", "checkpoint_metadata"]),
                           next_state="INGESTED")


@register
class SandboxProvisioner(Skill):
    name = "sandbox-provisioner"

    def execute(self, ctx: Context) -> SkillResult:
        profile = str(ctx.external("security_profile", STRICT_SANDBOX_PROFILE))
        if profile not in (STRICT_SANDBOX_PROFILE, TRUSTED_HOST_PROFILE):
            raise GateBlocked(
                "security_profile",
                f"unknown security_profile {profile!r}; an unknown label cannot define an "
                "execution boundary",
                f"use {STRICT_SANDBOX_PROFILE!r}, or explicitly authorize "
                f"{TRUSTED_HOST_PROFILE!r} for operator-trusted code",
            )
        image = _sandbox_image_reference(
            ctx.external("sandbox_image", DEFAULT_SANDBOX_IMAGE))
        raw_gpu_required = ctx.external("sandbox_gpu_required", False)
        if not isinstance(raw_gpu_required, bool):
            raise GateBlocked(
                "sandbox_gpu_required",
                "sandbox_gpu_required must be the literal JSON boolean true or false; strings "
                "and numeric values cannot authorize device exposure",
                "pass --set sandbox_gpu_required=true only for a GPU-backed strict Docker run",
            )
        gpu_required = raw_gpu_required
        warn: list[str] = []
        limits = {"cpus": 4, "memory": "8g", "network": "none", "pids": 512,
                  "timeout_seconds": 14400}

        if profile == TRUSTED_HOST_PROFILE:
            if gpu_required:
                raise GateBlocked(
                    "sandbox_gpu_required",
                    "GPU allocation is implemented only for the strict Docker backend; trusted "
                    "host execution cannot produce acceptance GPU evidence",
                    f"use security_profile={STRICT_SANDBOX_PROFILE!r} with a local NVIDIA-ready "
                    "image and engine",
                )
            authorized = ctx.external("trusted_host_authorized", False) is True
            if not authorized:
                raise GateBlocked(
                    "trusted_host_authorization",
                    "trusted-host-code was requested without literal "
                    "trusted_host_authorized=true on this sandbox-provisioner invocation. "
                    "A stored project artifact is not operator authorization.",
                    "pass both --set security_profile=trusted-host-code and "
                    "--set trusted_host_authorized=true only for code you have reviewed and trust",
                )
            # This is deliberately not an escape hatch for untrusted code.  It is
            # an explicit assertion by the operator that the code is trusted, and
            # both artifacts say that the host network and filesystem are not an
            # isolation boundary.
            validation = {"validated": False, "reason": "container validation not requested"}
            container_config = {
                "engine": "host",
                "execution_backend": "trusted-host",
                "code_trust": "user-asserted",
                "operator_authorization": {"literal": True, "run_id": ctx.run_id},
                "limits": {**limits, "network": "host-unrestricted"},
                "mounts": {"project": "host-access", "hidden_evaluator": "not-isolated"},
                "validation": validation,
            }
            warn.append(
                "trusted-host-code was explicitly selected. Only operator-trusted code may run: "
                "execution has host filesystem and network access, provides no container "
                "isolation, and must not be described as no-network execution.")
            manifest = {
                "profile": profile,
                "isolation": "none",
                "execution_backend": "trusted-host",
                "untrusted_code_execution_allowed": False,
                "trusted_host_execution_allowed": True,
                "operator_authorization_run_id": ctx.run_id,
                "network_isolation_enforced": False,
                "host": {"platform": platform.platform(), "python": sys.version.split()[0]},
                "warnings": warn,
            }
            freeze = subprocess.run(
                [sys.executable, "-m", "pip", "freeze", "--all"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
            if freeze.returncode != 0:
                raise GateBlocked(
                    "environment_lock",
                    "trusted-host-code could not measure the host Python environment with pip freeze",
                    "repair the selected Python environment before authorizing trusted host execution",
                )
            environment_lock = (
                "# measured_by=trusted-host-python-pip-freeze\n"
                "# execution_backend=trusted-host\n"
                f"# python_executable={Path(sys.executable).resolve()}\n" + freeze.stdout
            )
            container_config["environment_lock_measurement"] = {
                "source_backend": "trusted-host", "measured": True,
                "python_executable": str(Path(sys.executable).resolve()),
                "sha256": hashlib.sha256(environment_lock.encode("utf-8")).hexdigest(),
            }
        else:
            validation = _validate_local_docker_image(image, gpu_required=gpu_required)
            if gpu_required and isinstance(validation.get("gpu"), dict) \
                    and validation["gpu"].get("validated") is True:
                # A mutable project file is not device-exposure authorization.
                # Bind the successful probe to the provisioner invocation so a
                # resumed runner must receive the same literal request again.
                validation["gpu"] = {**validation["gpu"], "request_run_id": ctx.run_id}
            validated = bool(validation.get("validated"))
            container_config = {
                "engine": "docker",
                "execution_backend": "docker" if validated else "disabled",
                "image": image,
                "image_id": validation.get("image_id"),
                "pull_policy": "never",
                "read_only_rootfs": True,
                "limits": limits,
                # Mount only generated code. Mounting the project root would also
                # expose evaluation/hidden_tests, contradicting the artifact contract.
                "mounts": {"code": "ro", "run_tmp": "tmpfs",
                           "hidden_evaluator": "not_mounted"},
                "validation": validation,
                "gpu_allocation": validation.get("gpu"),
            }
            if validated:
                environment_lock, measurement, lock_error = _capture_container_environment(
                    str(validation["docker_realpath"]), str(validation["image_id"]),
                    str(validation["daemon_id"]))
                container_config["environment_lock_measurement"] = measurement
                if lock_error or environment_lock is None:
                    raise GateBlocked(
                        "environment_lock",
                        "the validated container could not produce an environment lock: "
                        f"{lock_error or 'unknown measurement failure'}. The host package set "
                        "will not be recorded for a container run.",
                        "prepare a local image whose non-root Python can run `python -m pip "
                        "freeze --all`, then re-run sandbox-provisioner",
                    )
            else:
                environment_lock = (
                    "# NOT_MEASURED\n# execution_backend=disabled\n"
                    f"# reason={validation.get('reason', 'container validation failed')}\n"
                )
                container_config["environment_lock_measurement"] = {
                    "source_backend": "none", "measured": False,
                    "reason": validation.get("reason", "container validation failed"),
                }
            if not validated:
                warn.append(
                    f"container sandbox unavailable: {validation.get('reason', 'validation failed')}. "
                    "Untrusted-code execution stays disabled; the runner will record planned "
                    "runs as NOT_RUN and will not fall back to this host.")
            manifest = {
                "profile": profile,
                "isolation": "container" if validated else "none",
                "execution_backend": "docker" if validated else "disabled",
                "untrusted_code_execution_allowed": validated,
                "trusted_host_execution_allowed": False,
                "network_isolation_enforced": validated,
                "container_image_id": validation.get("image_id"),
                "container_image_reference": image,
                "gpu_allocation": validation.get("gpu"),
                "host": {"platform": platform.platform(), "python": sys.version.split()[0]},
                "warnings": warn,
            }

        ctx.store.write(self.name, "environment_lock", environment_lock)
        ctx.store.write(self.name, "sandbox_container_config", container_config)
        ctx.store.write(self.name, "sandbox_manifest", manifest)
        return SkillResult(self.name,
                           produced=["environment_lock", "sandbox_container_config", "sandbox_manifest"],
                           warnings=warn,
                           detail={"execution_backend": manifest["execution_backend"],
                                   "untrusted_code_execution_allowed":
                                       manifest["untrusted_code_execution_allowed"]})


@register
class PaperIngest(Skill):
    name = "paper-ingest"
    # visual fallback only fires when text extraction is unreliable
    optional_outputs = ("visual_notes", "paper_assets")

    def execute(self, ctx: Context) -> SkillResult:
        locator = str(ctx.external("paper_locator", required=True))
        raw, origin, media = self._fetch(locator, ctx)
        text, warnings, assets, extraction = self._extract(raw, media)

        if len(text.split()) < 300:
            warnings.append(
                f"only {len(text.split())} words extracted. Below 300 words this is an abstract "
                f"page, not a paper: claims cannot be anchored and every downstream novelty and "
                f"feasibility judgment would rest on the abstract alone.")

        ctx.store.write(self.name, "paper_source_file", raw if isinstance(raw, (str, bytes)) else str(raw))
        ctx.store.write(self.name, "normalized_text", text)
        locmap, paragraphs = self._locators(text)
        ctx.store.write(self.name, "locator_map", locmap)
        ctx.store.write(self.name, "source_manifest", {
            "locator": locator, "origin": origin, "media_type": media,
            "retrieved_at": time.time(),
            "sha256": hashlib.sha256(text.encode()).hexdigest(),
            "words": len(text.split()), "paragraphs": paragraphs,
            "arxiv_id": (ARXIV_RE.search(locator) or [None])[0] if ARXIV_RE.search(locator) else None,
            "doi": (DOI_RE.search(text).group(0) if DOI_RE.search(text) else None),
            "title_hint": extraction.get("title_hint"),
            "page_count": extraction.get("page_count"),
        })
        # This artifact used to print "none: ... anchored, ordered content" whenever
        # the warning list happened to be empty — an affirmative all-clear for checks
        # that were never run. In a system whose entire pitch is refusing to report
        # work it did not do, that was the worst defect in the codebase. It now
        # reports what was checked and what was not, and can no longer say "none".
        checked = [
            f"word count: {len(text.split())}",
            f"text-block anchors: {paragraphs}",
            f"media type: {media}",
        ]
        not_checked = [
            "column order was NOT verified against the rendered page",
            "float/footnote splicing into body sentences was NOT detected",
            "section headings are matched by regex; unconventional layouts are missed silently",
            "figure and table captions are matched by regex; unnumbered captions are missed",
        ]
        body = ["# Layout and extraction", "", "## Checked", ""]
        body += [f"- {c}" for c in checked]
        body += ["", "## Warnings", ""]
        body += ([f"- {w}" for w in warnings] if warnings
                 else ["- no warning was raised by the checks that ran"])
        body += ["", "## NOT checked", "",
                 "These are not clean bills of health. Nothing below was tested, and a "
                 "downstream skill must not read their absence as evidence.", ""]
        body += [f"- {c}" for c in not_checked]
        ctx.store.write(self.name, "layout_warnings", "\n".join(body))
        if assets:
            ctx.store.write(self.name, "paper_assets", json.dumps(assets, indent=1))
        produced = ["paper_source_file", "normalized_text", "locator_map",
                    "source_manifest", "layout_warnings"] + (["paper_assets"] if assets else [])
        return SkillResult(self.name, produced=produced, warnings=warnings, next_state="INGESTED")

    # -- helpers -------------------------------------------------------
    def _fetch(self, locator: str, ctx: Context):
        p = Path(locator.replace("file://", ""))
        if p.exists():
            media = {".pdf": "application/pdf", ".html": "text/html", ".htm": "text/html",
                     ".txt": "text/plain", ".md": "text/markdown"}.get(p.suffix.lower(), "text/plain")
            return (p.read_bytes() if media == "application/pdf" else p.read_text(encoding="utf-8", errors="replace")), f"file:{p}", media
        if locator.startswith(("http://", "https://")):
            if ctx.offline:
                raise GateBlocked("network", f"offline mode cannot fetch {locator}",
                                  "pass a local file, or run without --offline")
            import httpx
            r = httpx.get(locator, follow_redirects=True, timeout=60.0,
                          headers={"User-Agent":
                                   f"ResearchForge/{__version__} (+researchforge.local)"})
            if r.status_code != 200:
                raise GateBlocked("ingest", f"HTTP {r.status_code} for {locator}", "check the URL")
            return ((r.content if "pdf" in r.headers.get("content-type", "") else r.text),
                    locator, r.headers.get("content-type", "text/html").split(";")[0])
        raise GateBlocked("ingest", f"cannot resolve locator {locator!r}",
                          "supply a local path, file:// URL, or http(s) URL")

    def _extract(self, raw, media: str):
        warnings: list[str] = []
        assets: list[dict[str, Any]] = []
        if media == "application/pdf":
            from pypdf import PdfReader
            import io
            rd = PdfReader(io.BytesIO(raw if isinstance(raw, bytes) else raw.encode()))
            pages = [(pg.extract_text() or "") for pg in rd.pages]
            metadata = rd.metadata or {}
            title_hint = metadata.get("/Title") if hasattr(metadata, "get") else None
            if not isinstance(title_hint, str) or not title_hint.strip():
                title_hint = None
            # pypdf hands back lone surrogates for math-italic glyphs (U+D835 range).
            # Left alone they crash the artifact store on `.encode()`, and a real
            # paper then looks like a runtime bug rather than an extraction problem.
            # Measured on 18 real PDFs: 1 in 18 was un-ingestable for this reason.
            fixed = 0
            for i, t in enumerate(pages):
                try:
                    t.encode("utf-8")
                except UnicodeEncodeError:
                    pages[i] = t.encode("utf-8", "replace").decode("utf-8")
                    fixed += 1
            if fixed:
                warnings.append(
                    f"{fixed} page(s) contained unpaired surrogates — almost always math "
                    f"glyphs — and were transcoded lossily. Formulae on those pages are "
                    f"unreliable and any claim anchored there should be re-read by hand.")

            # Exact lines repeated on at least three pages are page furniture,
            # not paper prose. Remove them before sentence/claim mining so a
            # journal header cannot become a quoted research claim or title.
            line_pages: dict[str, int] = {}
            for page in pages:
                page_keys: set[str] = set()
                for raw_line in page.splitlines():
                    line = raw_line.strip()
                    if 8 <= len(line) <= 180:
                        # Printed page numbers make an otherwise identical running
                        # header unique on every page. Normalise only a final
                        # integer; the original bytes remain available as source.
                        page_keys.add(re.sub(r"\s+\d+\s*$", "", line))
                for key in page_keys:
                    line_pages[key] = line_pages.get(key, 0) + 1
            repeated = {key for key, count in line_pages.items() if count >= 3}
            if repeated:
                pages = ["\n".join(
                    line for line in page.splitlines()
                    if re.sub(r"\s+\d+\s*$", "", line.strip()) not in repeated)
                         for page in pages]
                warnings.append(
                    f"removed {len(repeated)} exact running header/footer line(s) repeated on "
                    "at least three pages before claim extraction")

            # Join words split only for PDF line wrapping. The count is evidence:
            # downstream search otherwise silently misses every repaired token.
            dehyphenated = 0
            normalised_pages: list[str] = []
            for page in pages:
                page, count = re.subn(r"(?<=[a-z])-\n(?=[a-z])", "", page)
                dehyphenated += count
                normalised_pages.append(page)
            pages = normalised_pages
            if dehyphenated:
                warnings.append(
                    f"de-hyphenated {dehyphenated} lowercase word(s) split across PDF line breaks")
            empty = sum(1 for t in pages if len(t.strip()) < 40)
            if empty > len(pages) * 0.3:
                warnings.append(
                    f"{empty}/{len(pages)} pages yielded almost no text. This PDF is likely scanned "
                    f"or vector-only; the visual fallback path is required before these sections "
                    f"can be trusted.")
            return ("\n\n".join(pages), warnings, assets,
                    {"title_hint": title_hint.strip() if title_hint else None,
                     "page_count": len(pages)})
        if media in ("text/html", "application/xhtml+xml"):
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(raw, "lxml")
            for t in soup(["script", "style", "nav", "footer"]):
                t.decompose()
            for i, img in enumerate(soup.find_all("img")):
                assets.append({"kind": "image", "index": i, "src": img.get("src"),
                               "alt": img.get("alt")})
            if soup.find_all("table"):
                warnings.append(f"{len(soup.find_all('table'))} HTML tables flattened to text; "
                                f"numeric cells may lose their row/column identity")
            return (re.sub(r"\n{3,}", "\n\n", soup.get_text("\n")), warnings, assets,
                    {"title_hint": None, "page_count": None})
        return str(raw), warnings, assets, {"title_hint": None, "page_count": None}

    def _locators(self, text: str):
        paras = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
        return ({"granularity": "text_block",
                 "anchors": [{"anchor": f"p{i}", "offset": text.find(p), "chars": len(p),
                              "preview": p.strip()[:80]} for i, p in enumerate(paras)]},
                len(paras))


# The number separator must allow "1." and "1.1." with no space and roman numerals:
# ICML/PMLR style writes "1. Introduction", which the whitespace-only version missed
# entirely. Measured cost of that miss: 7 of 18 real papers detected exactly two
# sections, so every body claim was filed under "Abstract".
HEAD_RE = re.compile(
    r"^\s*(?:((?:\d+(?:\.\d+)*|[IVXLC]+)[.)]?)[\s.]*)?(abstract|introduction|related work|background|method(?:s|ology)?|"
    r"approach|model|architecture|experiments?|experimental setup|results?|discussion|analysis|"
    r"ablation[a-z ]*|limitations?|conclusions?|future work|references|appendix)\s*$",
    re.I | re.M)
CLAIM_CUE = re.compile(
    r"\b(we (?:propose|introduce|present|show|demonstrate|prove|find|observe|achieve|improve|outperform)|"
    r"our (?:method|model|approach|system) (?:achieves|outperforms|improves|reduces|yields)|"
    r"results? (?:show|indicate|demonstrate)|achieves? (?:a )?(?:new )?state[- ]of[- ]the[- ]art)\b", re.I)
NUM_RE = re.compile(r"\b\d+(?:\.\d+)?\s*(?:%|BLEU|F1|AUC|mAP|accuracy|points?|x\b)", re.I)


@register
class PaperModelBuilder(Skill):
    name = "paper-model-builder"

    def execute(self, ctx: Context) -> SkillResult:
        text = ctx.store.read(self.name, "normalized_text")
        locmap = ctx.store.read(self.name, "locator_map")
        source_manifest = ctx.store.read(self.name, "source_manifest")
        sections = self._sections(text)
        claims, claim_warnings = self._claims(text, sections)
        warnings: list[str] = list(claim_warnings)
        if len(sections) < 3:
            warnings.append(
                f"only {len(sections)} sections detected. Heading detection is regex-based and "
                f"fails on unconventional layouts; claim anchors below are therefore weak.")
        if not claims:
            warnings.append("no claims matched the cue patterns; the paper model is structural only")

        figures = self._captions(text, "figure")
        tables = self._captions(text, "table")
        if not figures and re.search(r"\b(?:figure|fig\.)\s+[0-9ivxl]+", text, re.I):
            warnings.append(
                "figure-like labels were present but no captions were indexed; inspect the PDF")
        if not tables and re.search(r"\b(?:table|tab\.)\s+[0-9ivxl]+", text, re.I):
            warnings.append(
                "table-like labels were present but no captions were indexed; inspect the PDF")

        ctx.store.write(self.name, "section_map",
                        {"sections": sections, "detector": "regex/heading-v1",
                         "anchor_granularity": locmap.get("granularity")})
        ctx.store.write(self.name, "figure_table_index",
                        {"figures": figures, "tables": tables})
        model = {
            "paper_id": ctx.store.read(self.name, "normalized_text") and
                        hashlib.sha256(text.encode()).hexdigest()[:16],
            "title": self._title(text, source_manifest.get("title_hint")),
            "sections": [{"id": s["id"], "title": s["title"], "start": s["start"]} for s in sections],
            "claims": [{"claim_id": c["claim_id"], "text": c["text"], "locator": c["locator"],
                        "quantitative": c["quantitative"]} for c in claims],
            "methods": self._terms(text, ("architecture", "algorithm", "loss", "objective", "encoder", "decoder")),
            "datasets": self._terms(text, ("dataset", "corpus", "benchmark", "WMT", "ImageNet", "GLUE")),
            "metrics": self._metrics(text),
            "limitations": [s["title"] for s in sections if "limitation" in s["title"].lower()],
            "locators": {"granularity": locmap.get("granularity"),
                         "anchor_count": len(locmap.get("anchors", []))},
        }
        ctx.store.write(self.name, "paper_model", model)
        atoms = self._atoms(claims)
        ctx.store.write(self.name, "contribution_atoms", {"atoms": atoms, "source": "claim-cue-v1"})
        ctx.store.write(self.name, "method_dependency_graph", {
            "nodes": [{"id": a["atom_id"], "label": a["summary"][:70]} for a in atoms],
            "edges": [{"from": atoms[i]["atom_id"], "to": atoms[i + 1]["atom_id"],
                       "kind": "textual_order", "confidence": "low",
                       "note": "ordering only; not a verified causal dependency"}
                      for i in range(len(atoms) - 1)],
        })
        return SkillResult(self.name,
                           produced=["section_map", "figure_table_index", "paper_model",
                                     "contribution_atoms", "method_dependency_graph"],
                           warnings=warnings, next_state="MODELED",
                           detail={"sections": len(sections), "claims": len(claims),
                                   "atoms": len(atoms)})

    # -- helpers -------------------------------------------------------
    def _title(self, text: str, title_hint: Any = None) -> str:
        if isinstance(title_hint, str):
            hint = " ".join(title_hint.split())
            if 5 < len(hint) < 300 and hint.lower() not in {"untitled", "unknown"}:
                return hint
        for line in text.splitlines():
            s = line.strip()
            if 15 < len(s) < 200 and not s.lower().startswith(("arxiv", "abstract", "http")):
                return s
        return "(title not detected)"

    def _sections(self, text: str):
        out = []
        offset = 0
        for line in text.splitlines(keepends=True):
            raw = line.rstrip("\r\n")
            # IEEE small caps often arrive as ``I NTRODUCTION``. Joining one
            # isolated capital to the following capital run is conservative and
            # lets the ordinary heading grammar see the actual word.
            normalised = re.sub(r"\b([A-Z])\s+([A-Z]{2,})\b", r"\1\2", raw)
            m = HEAD_RE.fullmatch(normalised)
            if m:
                out.append({"id": f"s{len(out)}", "number": m.group(1),
                            "title": m.group(2).strip(), "start": offset})
            offset += len(line)
        return out

    def _captions(self, text: str, kind: str):
        label = r"(?:figure|fig\.)" if kind == "figure" else r"(?:table|tab\.)"
        number = r"(?:\d+(?:\.\d+)?|[IVXLCDM]+)"
        pat = re.compile(
            rf"(?<!\w){label}\s+({number})\s*[:.]\s*([^\n]{{0,200}})", re.I)
        found: dict[str, dict[str, Any]] = {}
        for m in pat.finditer(text):
            num = m.group(1).upper()
            ident = f"{kind[0]}{num.lower()}"
            if ident not in found:
                found[ident] = {"id": ident, "number": num,
                                "caption": m.group(2).strip(), "offset": m.start()}
        return list(found.values())

    def _claims(self, text: str, sections):
        def sect_of(off):
            cur = None
            for s in sections:
                if s["start"] <= off:
                    cur = s
            return cur["id"] if cur else "s?"
        references = [s["start"] for s in sections if s["title"].lower() == "references"]
        claim_text = text[:min(references)] if references else text
        protected = claim_text
        replacements = {
            "Fig.": "Fig<prd>", "Tab.": "Tab<prd>", "Sec.": "Sec<prd>",
            "Eq.": "Eq<prd>", "eq.": "eq<prd>", "et al.": "et al<prd>",
            "e.g.": "e<prd>g<prd>", "i.e.": "i<prd>e<prd>",
        }
        for before, after in replacements.items():
            protected = protected.replace(before, after)
        out = []
        discarded = 0
        for sent in re.split(r"(?<=[.!?])\s+", protected):
            sent = sent.replace("<prd>", ".")
            s = sent.strip()
            if len(s) < 25 or len(s) > 600 or not CLAIM_CUE.search(s):
                continue
            off = text.find(s)
            out.append({"claim_id": f"C-{len(out)+1:03d}", "text": s,
                        "locator": {"section": sect_of(off), "offset": off},
                        "quantitative": bool(re.search(r"\d", s))})
            if len(out) >= 60:
                discarded += 1
                break
        warnings: list[str] = []
        if references and CLAIM_CUE.search(text[min(references):]):
            warnings.append(
                "claim-like sentences after the References heading were excluded from the paper's "
                "contribution claims; appendices require separate operator review")
        if discarded:
            warnings.append("claim extraction reached its 60-claim cap; later cue hits were excluded")
        return out, warnings

    def _terms(self, text: str, cues):
        found: list[str] = []
        explicit = [cue for cue in cues if any(char.isupper() for char in cue)]
        for cue in explicit:
            if re.search(rf"\b{re.escape(cue)}\b", text, re.I):
                found.append(cue)
        generic = [cue for cue in cues if cue not in explicit]
        if generic:
            cue_alt = "|".join(re.escape(cue) for cue in generic)
            pattern = re.compile(
                rf"\b([A-Z][A-Za-z0-9._-]{{2,}}(?:\s+[A-Z][A-Za-z0-9._-]{{2,}}){{0,2}})"
                rf"\s+(?:{cue_alt})s?\b")
            for match in pattern.finditer(text):
                term = match.group(1).strip()
                if term.lower() not in {item.lower() for item in found}:
                    found.append(term)
                if len(found) >= 20:
                    break
        return found

    def _metrics(self, text: str) -> list[str]:
        """Return named metrics, never numeric values or plot-axis fragments."""
        pattern = re.compile(
            r"\b(?:BLEU|F1|AUC|mAP|accuracy|perplexity|WER|L\d[A-Z]{2,})\b", re.I)
        found: list[str] = []
        for match in pattern.finditer(text):
            value = match.group(0)
            if value.lower() not in {item.lower() for item in found}:
                found.append(value)
        return found[:40]

    def _atoms(self, claims):
        atoms = []
        for c in claims:
            if not c["quantitative"] and len(atoms) >= 12:
                continue
            atoms.append({
                "atom_id": f"A-{len(atoms)+1:03d}",
                "summary": c["text"][:220],
                "claim_ids": [c["claim_id"]],
                "kind": "empirical" if c["quantitative"] else "conceptual",
                "attackable_as": ["assumption", "evaluation_scope", "generality"],
                "locator": c["locator"],
            })
            if len(atoms) >= 20:
                break
        return atoms
