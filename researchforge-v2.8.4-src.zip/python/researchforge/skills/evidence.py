"""Evidence plane: provider management, coverage, search, citations, claim graph."""
from __future__ import annotations

import hashlib
import os
import re
import time
from typing import Any

from ..errors import GateBlocked, ProviderUnavailable
from ..invalid_conditions import drop_void
from ..providers import DEFAULT_PROVIDERS
from ..skill import Context, Skill, SkillResult, register


def _in_family(hit: dict[str, Any], family: str) -> bool:
    """Was this hit retrieved by `family`?

    Reads the merged list first and falls back to the single tag, because a
    literature_candidates artifact written by an earlier version has only the
    tag — and reading it as "not in the family" would silently re-open the bug
    the list exists to close.
    """
    fams = hit.get("_query_families")
    if isinstance(fams, list) and fams:
        return family in fams
    return hit.get("_query_family") in (None, family)



@register
class LiteratureProviderManager(Skill):
    name = "literature-provider-manager"

    def execute(self, ctx: Context) -> SkillResult:
        raw_budget = ctx.external("quota_budget", {})
        if raw_budget is None:
            budget: dict[str, Any] = {}
        elif isinstance(raw_budget, dict):
            budget = raw_budget
        else:
            raise GateBlocked(
                "quota_budget",
                "quota_budget must be a JSON object keyed by scholarly provider; an invalid "
                "budget cannot be treated as unlimited",
                "pass quota_budget as {provider: {max_calls: int, max_usd: number}}",
            )
        scope = ctx.external("domain_scope", "unspecified")
        registry, warnings = [], []
        for p in ctx.scholarly:
            provider_budget = budget.get(p.name, {})
            if provider_budget is None:
                provider_budget = {}
            if not isinstance(provider_budget, dict):
                raise GateBlocked(
                    "quota_budget",
                    f"quota_budget[{p.name!r}] must be a JSON object, not "
                    f"{type(provider_budget).__name__}",
                    "supply max_calls and/or max_usd inside a provider object",
                )
            avail = p.available()
            reason = ""
            if (p.capabilities.requires_key and p.api_key_env
                    and not os.environ.get(p.api_key_env)):
                reason = f"{p.api_key_env} not set (BYOK)"
            elif p.api_key_env and not os.environ.get(p.api_key_env):
                warnings.append(
                    f"{p.name}: optional {p.api_key_env} unset — public shared-pool access "
                    "may be throttled; a key is recommended for repeatable live runs")
            if p.mailto_env and not os.environ.get(p.mailto_env):
                warnings.append(f"{p.name}: {p.mailto_env} unset — polite-pool rate limits will "
                                f"not apply and throttling is likely")
            registry.append({
                "name": p.name, "base_url": p.base_url, "available": avail,
                "unavailable_reason": reason,
                "capabilities": {k: v for k, v in vars(p.capabilities).items()},
                "budget": provider_budget,
            })
            ctx.quota.budget(p.name, max_calls=provider_budget.get("max_calls"),
                             max_usd=provider_budget.get("max_usd"))
        ctx.store.write(self.name, "provider_registry",
                        {"scope": scope, "providers": registry, "generated_at": time.time()})

        active = [r for r in registry if r["available"]]
        blind = []
        for cap, label in (("full_text", "no full-text search"),
                           ("citations", "no citation graph"),
                           ("code_search", "no code/artifact search"),
                           ("non_english", "no non-English coverage"),
                           ("preprints", "no preprint coverage"),
                           ("last_90_days", "no coverage of the last 90 days")):
            if not any(r["capabilities"].get(cap) for r in active):
                blind.append(label)
        # coverage is measured, never assumed; with no measurement yet it is UNKNOWN
        report = {
            "status": "UNKNOWN_COVERAGE",
            "measured": False,
            "method": "seeded-recall + saturation + cross-provider agreement",
            "score": None,
            "active_providers": [r["name"] for r in active],
            "named_blind_spots": blind,
            "note": ("No search has run yet, so coverage is unmeasured. This artifact starts at "
                     "UNKNOWN_COVERAGE by construction: a novelty claim is an absence claim, and "
                     "an unmeasured search cannot support one."),
        }
        if not active:
            warnings.append("no scholarly provider is available; every novelty judgment this run "
                            "will be UNKNOWN_COVERAGE")
        if "no full-text search" in blind:
            warnings.append("no full-text provider: mechanism-level near-duplicate search is "
                            "degraded, which is the search novelty verification most depends on")
        ctx.store.write(self.name, "coverage_report", report)
        ctx.store.append_jsonl(self.name, "quota_ledger",
                               [{"ts": time.time(), "event": "budget_set", "budget": budget}])
        return SkillResult(self.name, produced=["provider_registry", "coverage_report", "quota_ledger"],
                           warnings=warnings,
                           detail={"active": [r["name"] for r in active], "blind_spots": blind})


@register
class LiteratureSearch(Skill):
    name = "literature-search"
    optional_outputs = ("library_hits", "library_note_links")

    def execute(self, ctx: Context) -> SkillResult:
        model = ctx.store.read(self.name, "paper_model")
        registry = ctx.store.read(self.name, "provider_registry")
        coverage = ctx.store.read(self.name, "coverage_report")
        objective = ctx.external("search_objective",
                                 f"related work and competing methods for: {model.get('title')}")
        active = [p for p in ctx.scholarly if p.name in
                  {r["name"] for r in registry["providers"] if r["available"]}]

        queries = self._queries(model, objective)
        plan = {"objective": objective, "queries": queries,
                "providers": [p.name for p in active],
                "seeded_recall_probe": [c["claim_id"] for c in model.get("claims", [])[:5]]}
        ctx.store.write(self.name, "literature_search_plan", plan)

        hits: list[dict[str, Any]] = []
        log: list[dict[str, Any]] = []
        warnings: list[str] = []
        for spec in queries:
            q, fam = spec["query"], spec["family"]
            for p in active:
                try:
                    ctx.quota.check(p.name)
                except ProviderUnavailable as e:
                    log.append({"ts": time.time(), "provider": p.name, "query": q,
                                "query_family": fam, "returned": 0, "error": str(e)[:300]})
                    warnings.append(f"{p.name}: {str(e).splitlines()[0][:140]}")
                    continue
                try:
                    raw_rows = p.search(q, limit=25)
                    if not isinstance(raw_rows, list) \
                            or any(not isinstance(row, dict) for row in raw_rows):
                        raise ProviderUnavailable(
                            f"provider '{p.name}' search must return a list of objects")
                    rows = [dict(row) for row in raw_rows]
                    for index, row in enumerate(rows):
                        for field in ("id", "doi", "title"):
                            value = row.get(field)
                            if value is not None and not isinstance(value, str):
                                raise ProviderUnavailable(
                                    f"provider '{p.name}' returned malformed result "
                                    f"{index}: {field} must be a string or null")
                except ProviderUnavailable as e:
                    # This was a real provider/fixture attempt. Count failures as
                    # calls too; otherwise a provider returning 429 forever never
                    # consumes max_calls and the quota is an unbounded retry loop.
                    ctx.quota.record(p.name, endpoint="search", error=str(e)[:300])
                    log.append({"ts": time.time(), "provider": p.name, "query": q,
                                "query_family": fam, "returned": 0, "error": str(e)[:300]})
                    warnings.append(f"{p.name}: {str(e).splitlines()[0][:140]}")
                    continue
                ctx.quota.record(p.name, endpoint="search")
                for row in rows:
                    row.setdefault("_provider", p.name)
                    row.setdefault("_query", q)
                    row.setdefault("_query_family", fam)
                hits.extend(rows)
                log.append({"ts": time.time(), "provider": p.name, "query": q,
                            "query_family": fam, "returned": len(rows), "error": None})

        # Dedup MERGES the query families rather than keeping the first one. The
        # related-work family runs first and includes one query per dataset — the
        # query most likely to co-return the frontier paper — so first-wins
        # tagging recorded "which family saw it first", and the two consumers that
        # filter on the tag then threw the frontier paper away and reported that
        # the field has no state of the art. A hit belongs to every family that
        # retrieved it.
        seen: dict[str, dict[str, Any]] = {}
        dedup: list[dict[str, Any]] = []
        for h in hits:
            k = (h.get("doi") or h.get("id") or h.get("title", "")).strip().lower()
            fam = h.get("_query_family")
            kept = seen.get(k) if k else None
            if kept is not None:
                fams = kept.setdefault("_query_families", [kept.get("_query_family")])
                if fam and fam not in fams:
                    fams.append(fam)
                    kept.setdefault("_also_found_by", []).append(h.get("_query"))
                continue
            h["_query_families"] = [fam] if fam else []
            if k:
                seen[k] = h
            dedup.append(h)

        ctx.store.write(self.name, "literature_candidates", dedup)
        ctx.store.write(self.name, "literature_retrieval_log", log)

        returned = sum(l["returned"] for l in log)
        errors = [l for l in log if l["error"]]
        if returned == 0:
            warnings.append(
                "search returned zero works. This is NOT evidence that the field is empty. "
                "Coverage stays UNKNOWN_COVERAGE and no NOVEL_ENOUGH verdict may be issued.")
        ctx.store.write(self.name, "landscape_report", self._landscape(model, dedup, coverage, log))
        ctx.store.write(self.name, "system_matrix",
                        self._csv(["system", "provider", "year", "venue"],
                                  [[h.get("title", "")[:80], h.get("_provider", ""),
                                    str(h.get("year", "")), str(h.get("venue", ""))] for h in dedup[:50]]))
        bench_rows, bench_notes = self._benchmark_rows(model, dedup)
        ctx.store.write(self.name, "benchmark_matrix",
                        self._csv(["benchmark", "reported_by", "value", "source"], bench_rows))
        warnings += bench_notes
        warnings = list(dict.fromkeys(warnings))   # one line per provider, not per query
        produced = ["literature_search_plan", "literature_candidates", "literature_retrieval_log",
                    "landscape_report", "system_matrix", "benchmark_matrix"]
        return SkillResult(self.name, produced=produced, warnings=warnings,
                           detail={"queries": len(queries), "returned": returned,
                                   "unique": len(dedup), "provider_errors": len(errors)})

    def _queries(self, model, objective):
        """Query families, each tagged with what it is for.

        The related-work family finds neighbours. It does not find the strongest
        method on this paper's own benchmark, and a keyword filter over its results
        does not either: a title containing "state-of-the-art" is evidence that
        somebody wrote those words, not that the work is on this task. The SOTA
        family asks the question directly, against the named task and dataset, so a
        candidate can later be required to share one of them.
        """
        title = model.get("title", "")
        task = str(model.get("task") or model.get("problem") or "").strip()
        datasets = [str(d) for d in (model.get("datasets") or []) if str(d).strip()][:8]
        fams: list[tuple[str, str]] = [("related_work", title), ("related_work", objective)]
        fams += [("related_work", f"{title} {m}") for m in model.get("methods", [])[:3]]
        fams += [("related_work", d) for d in datasets[:3]]
        # One SOTA query per (task, dataset) the paper actually names. Asking
        # "state of the art" with no benchmark attached retrieves the phrase, not
        # the frontier.
        #
        # Emitted in ROUNDS, not per dataset: the first round asks the direct
        # question of every benchmark, and only then do the extra phrasings of the
        # first benchmark compete for budget. Nesting it the other way meant a
        # paper reporting on four benchmarks searched two of them and named all
        # four in `searched_for` — the artifact claimed coverage the search never
        # had, and the manuscript gate quotes that artifact back to the author.
        rounds = [lambda d: f"state of the art {d}",
                  lambda d: f"best performing method {d} benchmark results"]
        if task:
            rounds.append(lambda d: f"{task} {d} outperforms previous state of the art")
        for build in rounds:
            for d in datasets:
                fams.append(("sota", build(d)))
        if task and not datasets:
            fams.append(("sota", f"state of the art {task}"))
        out, seen = [], set()
        for fam, q in fams:
            q = re.sub(r"\s+", " ", str(q)).strip()
            # Short benchmark names — GLUE, CoLA, C4, MNLI — are real names, and
            # the old `4 < len(q)` floor dropped them from the related-work family
            # entirely. The floor exists to reject empty and one-word junk, so it
            # applies to the free-text families and not to a query built around a
            # name the paper itself declared.
            floor = 1 if fam == "sota" else 4
            if floor < len(q) < 300 and q.lower() not in seen:
                seen.add(q.lower())
                out.append({"family": fam, "query": q})
        # The SOTA family is never squeezed out by a long method list: it is the
        # only family that can answer the question the ablations depend on. Its
        # budget is at least one query per named benchmark, because a cap below
        # that silently decides which of the paper's own benchmarks do not matter.
        related = [q for q in out if q["family"] == "related_work"][:6]
        sota_all = [q for q in out if q["family"] == "sota"]
        sota = sota_all[:max(6, len(datasets))]
        return related + sota

    #: A number in an abstract, next to a dataset name. Deliberately narrow: a
    #: percentage or a two-to-three digit score within a short window of the
    #: benchmark's name. Anything looser scrapes years, table numbers and
    #: hyperparameters and files them as results.
    _RESULT_NEAR = re.compile(r"(?<![\w.])(\d{1,3}(?:\.\d{1,2})?)\s?%?(?![\w.])")

    def _benchmark_rows(self, model, hits) -> tuple[list[list[str]], list[str]]:
        """Benchmarks x reported results — with somebody else's results in it.

        This artifact used to contain one row per metric of the source paper, every
        value the literal string "see paper". It was named "Benchmarks x reported
        results" and carried no reported result from anybody, which is why
        `result-reproducer` reading it for state-of-the-art candidates found
        nothing and reported that as "no SOTA exists".

        Rows extracted from an abstract are labelled as such and keep the sentence
        they came from, because a number lifted out of prose is a claim about what
        someone wrote, not a measurement — and the reader has to be able to check
        it in one click.
        """
        rows = [[m, "source paper", "see paper", str(model.get("title", ""))[:60]]
                for m in (model.get("metrics") or [])[:20]]
        notes: list[str] = []
        datasets = [str(d) for d in (model.get("datasets") or []) if str(d).strip()]
        if not datasets:
            notes.append(
                "no dataset is named in the paper model, so no competing result could be "
                "attributed to a benchmark. benchmark_matrix carries the source paper's own "
                "metrics only, and any later state-of-the-art comparison has nothing to anchor "
                "to.")
            return rows, notes
        extracted = 0
        for h in hits:
            if not _in_family(h, "sota"):
                continue
            text = f"{h.get('title', '')} {h.get('abstract', '') or h.get('summary', '')}"
            for d in datasets:
                i = text.lower().find(d.lower())
                if i < 0:
                    continue
                # The search starts AFTER the dataset name, not at it. Starting at
                # it meant `WikiText-103` matched its own suffix — `_RESULT_NEAR`'s
                # lookbehind is satisfied by a hyphen — so the "competing result"
                # for the changelog's own worked example was 103, not the 10.2 in
                # the abstract. That number then became the candidate's
                # `reported_value`, which the direction-aware ranking sorts on, so
                # the top-5 selection was driven by digits in a benchmark's name.
                after = text[i + len(d):]
                before = text[max(0, i - 120): i]
                m = (self._RESULT_NEAR.search(after[:200]) or
                     self._RESULT_NEAR.search(before))
                if not m:
                    continue
                window = text[max(0, i - 120): i + len(d) + 200]
                rows.append([d, str(h.get("title", ""))[:80], m.group(1),
                             f"{h.get('_provider', '?')}: {re.sub(chr(34), chr(39), window.strip())[:180]}"])
                extracted += 1
                break
        if extracted:
            notes.append(
                f"{extracted} competing result(s) were extracted from abstracts retrieved by the "
                f"state-of-the-art query family. Each row keeps the sentence it came from: these "
                f"are numbers somebody reported, not numbers anybody measured here, and nothing "
                f"downstream may treat them as a baseline.")
        else:
            notes.append(
                "the state-of-the-art query family returned no abstract in which a named dataset "
                "and a number appear together, so benchmark_matrix carries no competing result. "
                "That is a statement about this retrieval, not about the field.")
        return rows, notes

    def _csv(self, header, rows):
        esc = lambda s: '"' + str(s).replace('"', '""') + '"'
        return "\n".join([",".join(header)] + [",".join(esc(c) for c in r) for r in rows])

    def _landscape(self, model, hits, coverage, log):
        lines = [f"# Landscape — {model.get('title','(untitled)')}", "",
                 f"Retrieved {len(hits)} unique works across {len({l['provider'] for l in log})} providers.", ""]
        if coverage.get("status") == "UNKNOWN_COVERAGE":
            lines += ["> **Coverage is UNKNOWN.** This landscape describes what the configured "
                      "providers returned, not what exists. Absence from this document is not "
                      "evidence of absence from the field.", ""]
        if coverage.get("named_blind_spots"):
            lines += ["## Named blind spots", ""] + \
                     [f"- {b}" for b in coverage["named_blind_spots"]] + [""]
        lines += ["## Works", ""]
        for h in hits[:40]:
            lines.append(f"- {h.get('title','(untitled)')} — {h.get('_provider','?')}"
                         + (f" ({h.get('year')})" if h.get("year") else ""))
        if not hits:
            lines.append("- none returned")
        return "\n".join(lines)


@register
class CitationResolver(Skill):
    name = "citation-resolver"
    optional_outputs = ("citation_graph", "citation_clusters", "citation_gap_candidates")

    def execute(self, ctx: Context) -> SkillResult:
        registry = ctx.store.read(self.name, "provider_registry")
        raw = ctx.external("reference_strings", []) or []
        seed = ctx.external("seed_paper_id", None)
        warnings: list[str] = []

        resolved = []
        for i, s in enumerate(raw):
            doi = re.search(r"\b10\.\d{4,9}/[-._;()/:A-Z0-9]+\b", str(s), re.I)
            arx = re.search(r"\b\d{4}\.\d{4,5}\b", str(s))
            resolved.append({
                "ref_id": f"R-{i+1:03d}", "raw": str(s)[:400],
                "doi": doi.group(0) if doi else None,
                "arxiv": arx.group(0) if arx else None,
                "status": "IDENTIFIED" if (doi or arx) else "UNRESOLVED",
                "resolved_via": "pattern" if (doi or arx) else None,
            })
        unresolved = [r for r in resolved if r["status"] == "UNRESOLVED"]
        if unresolved:
            warnings.append(f"{len(unresolved)}/{len(resolved)} references could not be resolved to "
                            f"an identifier. They may not be cited in the manuscript until they are.")
        if not raw:
            warnings.append("no reference strings supplied; the bibliography is empty. Any citation "
                            "in a later draft would have nothing to resolve against.")

        ctx.store.write(self.name, "resolved_references", resolved)
        ctx.store.write(self.name, "bibliography", self._bib(resolved))
        ctx.store.write(self.name, "citation_resolution_report", self._report(resolved, registry))

        graph_capable = any(r["capabilities"].get("citations") and r["available"]
                            for r in registry["providers"])
        produced = ["resolved_references", "bibliography", "citation_resolution_report"]
        if graph_capable and seed:
            ctx.store.write(self.name, "citation_graph",
                            {"seed": seed, "nodes": [], "edges": [],
                             "note": "expansion requires a live provider transport"})
            ctx.store.write(self.name, "citation_clusters", {"clusters": []})
            ctx.store.write(self.name, "citation_gap_candidates", [])
            produced += ["citation_graph", "citation_clusters", "citation_gap_candidates"]
        else:
            warnings.append("citation-graph expansion skipped: no available provider exposes a "
                            "citation graph, or no seed identifier was given. Gap mining that "
                            "depends on graph structure is therefore unavailable this run.")
        return SkillResult(self.name, produced=produced, warnings=warnings)

    def _bib(self, resolved):
        out = []
        for r in resolved:
            if r["status"] != "IDENTIFIED":
                continue
            key = (r["doi"] or r["arxiv"] or r["ref_id"]).replace("/", "_")
            out.append("@misc{%s,\n  note = {%s},\n%s}\n" % (
                key, r["raw"][:200].replace("{", "").replace("}", ""),
                (f"  doi = {{{r['doi']}}},\n" if r["doi"] else
                 f"  eprint = {{{r['arxiv']}}},\n  archivePrefix = {{arXiv}},\n")))
        return "\n".join(out) or "% no resolvable references\n"

    def _report(self, resolved, registry):
        ident = sum(1 for r in resolved if r["status"] == "IDENTIFIED")
        lines = ["# Citation resolution", "",
                 f"- supplied: {len(resolved)}", f"- identified: {ident}",
                 f"- unresolved: {len(resolved)-ident}", "",
                 "An identifier proves the work exists. It does not prove the work supports the "
                 "claim it is attached to — that check belongs to `claim-citation-auditor` and has "
                 "not run.", "", "## Providers", ""]
        lines += [f"- {p['name']}: {'available' if p['available'] else 'unavailable — ' + (p['unavailable_reason'] or 'probe failed')}"
                  for p in registry["providers"]]
        return "\n".join(lines)


@register
class ClaimEvidenceGraph(Skill):
    name = "claim-evidence-graph"

    def execute(self, ctx: Context) -> SkillResult:
        model = ctx.store.read(self.name, "paper_model")
        refs = ctx.store.read(self.name, "resolved_references", default=[])
        # Experiment evidence arrives long after the first pass over this skill.
        # The graph is a store, not a one-shot transform: it is re-entered every
        # time new evidence lands, which is the only way an own-work claim can ever
        # acquire a support edge. Read as a feedback edge — declared, not sneaked.
        ledger = ctx.store.read(self.name, "experiment_ledger", default=[])
        # Void experiments never become claims. This skill reads the ledger
        # directly rather than through analysis._require_ledger, so the void
        # filter has to be applied here too — without it, an experiment whose
        # invalid conditions all fired produced a SUPPORTED own-work claim, and
        # the manuscript could then cite it.
        tree = ctx.store.read(self.name, "experiment_tree", default={})
        ledger, void_ids = drop_void(ledger, tree)
        completed = [r for r in ledger if r.get("status") == "COMPLETED" and r.get("metrics")]
        claims = model.get("claims", [])
        registry, edges = [], []
        for c in claims:
            cid = c["claim_id"]
            registry.append({
                "claim_id": cid, "claim_text": c["text"],
                "claim_type": "empirical" if c.get("quantitative") else "conceptual",
                "origin": "source_paper", "locator": c.get("locator"),
                "status": "UNVERIFIED",
            })
            edges.append({
                "claim_id": cid, "claim_text": c["text"][:300],
                "claim_type": "empirical" if c.get("quantitative") else "conceptual",
                "support_edges": [],
                "conflicts": [],
                "status": "UNSUPPORTED",
            })
        # --- own-work claims, one per measured metric, each born with its support ---
        own = self._own_claims(completed)
        registry += [{"claim_id": o["claim_id"], "claim_text": o["claim_text"],
                      "claim_type": "empirical", "origin": "own_work",
                      "locator": None, "status": o["status"]} for o in own]
        edges += own

        ctx.store.write(self.name, "claim_registry",
                        {"claims": registry, "source": model.get("paper_id"),
                         "source_claims": len(claims), "own_work_claims": len(own)})
        ctx.store.write(self.name, "evidence_graph", edges)

        w = []
        if void_ids:
            w.append(f"{len(void_ids)} experiment(s) are void ({', '.join(sorted(void_ids))}); "
                     f"their runs produced no claim. A void run is not a weak result to be "
                     f"caveated — there is nothing in it to claim.")
        if not edges:
            w.append("no claims extracted; the evidence graph is empty and cannot gate anything")
        unsupported = [e for e in edges if not e["support_edges"]]
        if unsupported:
            w.append(f"{len(unsupported)}/{len(edges)} claims remain UNSUPPORTED. Source-paper "
                     f"claims stay unsupported until a citation is verified to support the "
                     f"proposition; they are not evidence for our own work.")
        if own:
            w.append(f"{len(own)} own-work claim(s) attached to {len(completed)} completed runs. "
                     f"Each names its run ids, so a number in the manuscript can be traced to the "
                     f"runs that produced it — or fail the citation audit.")
        elif completed:
            w.append("completed runs exist but produced no numeric metric to claim")
        return SkillResult(self.name, produced=["claim_registry", "evidence_graph"], warnings=w,
                           next_state="EVIDENCE_EXPANDED",
                           detail={"source_claims": len(claims), "own_claims": len(own),
                                   "completed_runs": len(completed), "references": len(refs)})

    def _own_claims(self, completed: list[dict]) -> list[dict]:
        """One claim per (experiment, arm, metric), supported by the runs that measured it.

        Deliberately mechanical. A claim generated here says only what the ledger
        says — the mean over seeds of ONE condition, and which run ids produced it.
        Anything more interesting is the manuscript's job, and it will have to
        justify itself against these edges rather than inventing its own.

        Per arm, not per experiment. Averaging a method together with the baseline
        it is being compared against produces a number that is arithmetically valid
        and describes no condition that was ever run — and because it is a real
        average of real runs, every downstream integrity check passes it.
        """
        import statistics
        by: dict[tuple, list] = {}
        for r in completed:
            arm = str((r.get("provenance") or {}).get("arm") or r.get("arm") or "candidate")
            for m, v in (r.get("metrics") or {}).items():
                if isinstance(v, (int, float)):
                    # attempt_id, not run_id: `_base_entry` sets run_id to the
                    # orchestration run for EVERY row, so a claim promising "a
                    # number can be traced to the runs that produced it" listed the
                    # same id three times and traced to nothing.
                    by.setdefault((r.get("experiment_id", "?"), arm, m), []).append(
                        (str(r.get("attempt_id") or r.get("run_id")), float(v)))
        out = []
        for i, ((exp, arm, metric), rows) in enumerate(sorted(by.items()), 1):
            vals = [v for _, v in rows]
            mean = statistics.fmean(vals)
            sd = statistics.stdev(vals) if len(vals) > 1 else 0.0
            out.append({
                "claim_id": f"OC-{i:03d}",
                "claim_text": (f"In {exp}, the {arm} arm's {metric} measured {mean:.4f} "
                               f"(sd {sd:.4f}, n={len(vals)} runs)."),
                "claim_type": "empirical",
                "support_edges": [{"kind": "experiment_result", "experiment_id": exp,
                                   "arm": arm, "branch": f"{exp}:{arm}",
                                   "metric": metric, "value": round(mean, 6),
                                   "sd": round(sd, 6), "n": len(vals),
                                   "run_ids": [rid for rid, _ in rows]}],
                "conflicts": [],
                "status": "SUPPORTED",
            })
        return out
