"""External providers: language models and scholarly APIs.

Two rules shape this module.

1. **BYOK.** The user brings their own keys. Nothing here ships a credential, and
   no credential is ever written to an artifact, a log or the quota ledger.

2. **An unavailable provider is a run condition, not an empty result.** The most
   dangerous failure in this system is a literature search that returns nothing
   because the quota ran out, and a novelty verifier that reads that emptiness as
   evidence of novelty. Every provider therefore reports *why* it returned what
   it returned, and exhaustion raises rather than returning `[]`.
"""
from __future__ import annotations

import json
import math
import os
import stat
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any, Callable, Protocol

from . import __version__
from .errors import ProviderUnavailable


# --------------------------------------------------------------------------
# quota
# --------------------------------------------------------------------------
@dataclass
class QuotaState:
    provider: str
    calls: int = 0
    max_calls: int | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    usd: float = 0.0
    max_usd: float | None = None
    throttled: bool = False
    last_error: str | None = None

    def exhausted(self) -> bool:
        return ((self.max_calls is not None and self.calls >= self.max_calls)
                or (self.max_usd is not None and self.usd >= self.max_usd))


class QuotaLedger:
    """Per-run record of what was spent where. Never contains credentials."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        absolute = self.path.absolute()
        # Anchor creation at the closest lexical ancestor that already exists.
        # That ancestor is itself opened O_NOFOLLOW below, and every missing
        # component is then created/opened relative to a bound directory fd.
        # In the normal project layout this makes ``project`` the anchor and
        # ``literature`` the first checked component.
        root = absolute.parent
        missing: list[str] = []
        while True:
            try:
                os.lstat(root)
                break
            except FileNotFoundError:
                if root == root.parent:
                    raise ProviderUnavailable(
                        f"quota ledger parent for {self.path!s} does not exist"
                    )
                missing.append(root.name)
                root = root.parent
        self._root = root
        self._relative = Path(*reversed(missing), absolute.name)
        self.state: dict[str, QuotaState] = {}

    def _append(self, payload: bytes) -> None:
        """Append one bound record without following a project-controlled link."""
        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        directory_flags |= getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        try:
            current = os.open(self._root, directory_flags)
        except OSError as exc:
            raise ProviderUnavailable(
                f"quota ledger parent {self._root!s} is not a safe directory"
            ) from exc
        try:
            for component in self._relative.parts[:-1]:
                try:
                    child = os.open(component, directory_flags, dir_fd=current)
                except FileNotFoundError:
                    try:
                        os.mkdir(component, mode=0o755, dir_fd=current)
                    except FileExistsError:
                        pass
                    try:
                        child = os.open(component, directory_flags, dir_fd=current)
                    except OSError as exc:
                        raise ProviderUnavailable(
                            f"quota ledger parent component {component!r} is not a safe "
                            "directory"
                        ) from exc
                except OSError as exc:
                    raise ProviderUnavailable(
                        f"quota ledger parent component {component!r} is not a safe directory"
                    ) from exc
                os.close(current)
                current = child

            flags = (os.O_WRONLY | os.O_APPEND | os.O_CREAT
                     | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0))
            try:
                fd = os.open(self._relative.parts[-1], flags, 0o666, dir_fd=current)
            except OSError as exc:
                raise ProviderUnavailable(
                    f"quota ledger path {self.path!s} is not a safe regular file"
                ) from exc
            try:
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode):
                    raise ProviderUnavailable(
                        f"quota ledger path {self.path!s} is not a regular file"
                    )
                if info.st_nlink != 1:
                    raise ProviderUnavailable(
                        f"quota ledger path {self.path!s} has {info.st_nlink} hard links"
                    )
                view = memoryview(payload)
                while view:
                    written = os.write(fd, view)
                    if written <= 0:
                        raise OSError("quota ledger write made no progress")
                    view = view[written:]
                os.fsync(fd)
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    raise ProviderUnavailable(
                        f"quota ledger path {self.path!s} stopped being a private regular file"
                    )
            finally:
                os.close(fd)
        finally:
            os.close(current)

    def budget(self, provider: str, *, max_calls: int | None = None,
               max_usd: float | None = None) -> None:
        if (max_calls is not None
                and (isinstance(max_calls, bool) or not isinstance(max_calls, int)
                     or max_calls < 0)):
            raise ProviderUnavailable(
                f"invalid quota budget for '{provider}': max_calls must be a "
                "non-negative integer or null")
        if max_usd is not None:
            if (isinstance(max_usd, bool) or not isinstance(max_usd, (int, float))
                    or not math.isfinite(float(max_usd)) or float(max_usd) < 0):
                raise ProviderUnavailable(
                    f"invalid quota budget for '{provider}': max_usd must be a finite "
                    "non-negative number or null")
            max_usd = float(max_usd)
        s = self.state.setdefault(provider, QuotaState(provider))
        s.max_calls, s.max_usd = max_calls, max_usd

    def record(self, provider: str, *, tokens_in: int = 0, tokens_out: int = 0,
               usd: float = 0.0, endpoint: str = "", error: str | None = None) -> None:
        encoded = (json.dumps({"ts": time.time(), "provider": provider,
                               "endpoint": endpoint, "tokens_in": tokens_in,
                               "tokens_out": tokens_out, "usd": usd, "error": error},
                              ensure_ascii=False) + "\n").encode("utf-8")
        # Only advance the in-memory view after the durable append succeeds. A
        # refused symlink/hardlink is not a provider call recorded by this ledger.
        self._append(encoded)
        s = self.state.setdefault(provider, QuotaState(provider))
        s.calls += 1
        s.tokens_in += tokens_in
        s.tokens_out += tokens_out
        s.usd += usd
        if error:
            s.last_error = error
            if "429" in error or "rate" in error.lower():
                s.throttled = True

    def check(self, provider: str) -> None:
        s = self.state.get(provider)
        if s and s.exhausted():
            raise ProviderUnavailable(
                f"quota exhausted for '{provider}' after {s.calls} calls / ${s.usd:.2f}. "
                f"This is a run condition, not an empty result set: any novelty judgment "
                f"made from here on must be marked UNKNOWN_COVERAGE."
            )

    def snapshot(self) -> list[dict[str, Any]]:
        return [dict(provider=s.provider, calls=s.calls, tokens_in=s.tokens_in,
                     tokens_out=s.tokens_out, usd=round(s.usd, 4),
                     throttled=s.throttled, exhausted=s.exhausted(),
                     last_error=s.last_error) for s in self.state.values()]


# --------------------------------------------------------------------------
# language models
# --------------------------------------------------------------------------
@dataclass
class ModelResponse:
    text: str
    model: str
    synthetic: bool = False          # true => output is not from a real model
    tokens_in: int = 0
    tokens_out: int = 0
    usd: float = 0.0


class ModelProvider(Protocol):
    name: str
    def complete(self, prompt: str, *, system: str = "", max_tokens: int = 4096,
                 json_mode: bool = False) -> ModelResponse: ...


class AnthropicProvider:
    name = "anthropic"

    def __init__(self, model: str = "claude-opus-4-6", api_key: str | None = None) -> None:
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ProviderUnavailable(
                "ANTHROPIC_API_KEY is not set. ResearchForge is BYOK: it never ships a key. "
                "Export one, or run with --offline to exercise the pipeline with clearly "
                "marked synthetic output."
            )

    def complete(self, prompt: str, *, system: str = "", max_tokens: int = 4096,
                 json_mode: bool = False) -> ModelResponse:
        import httpx
        body: dict[str, Any] = {"model": self.model, "max_tokens": max_tokens,
                                "messages": [{"role": "user", "content": prompt}]}
        if system:
            body["system"] = system
        r = httpx.post("https://api.anthropic.com/v1/messages",
                       headers={"x-api-key": self.api_key,
                                "anthropic-version": "2023-06-01",
                                "content-type": "application/json"},
                       json=body, timeout=180.0)
        if r.status_code != 200:
            raise ProviderUnavailable(f"anthropic {r.status_code}: {r.text[:300]}")
        d = r.json()
        u = d.get("usage", {})
        return ModelResponse("".join(b.get("text", "") for b in d.get("content", [])),
                             self.model, False,
                             u.get("input_tokens", 0), u.get("output_tokens", 0))


class OpenAIProvider:
    name = "openai"

    def __init__(self, model: str = "gpt-5", api_key: str | None = None) -> None:
        self.model = model
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise ProviderUnavailable("OPENAI_API_KEY is not set (BYOK).")

    def complete(self, prompt: str, *, system: str = "", max_tokens: int = 4096,
                 json_mode: bool = False) -> ModelResponse:
        import httpx
        msgs = ([{"role": "system", "content": system}] if system else []) + \
               [{"role": "user", "content": prompt}]
        body: dict[str, Any] = {"model": self.model, "messages": msgs,
                                "max_completion_tokens": max_tokens}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        r = httpx.post("https://api.openai.com/v1/chat/completions",
                       headers={"Authorization": f"Bearer {self.api_key}"},
                       json=body, timeout=180.0)
        if r.status_code != 200:
            raise ProviderUnavailable(f"openai {r.status_code}: {r.text[:300]}")
        d = r.json()
        u = d.get("usage", {})
        return ModelResponse(d["choices"][0]["message"]["content"], self.model, False,
                             u.get("prompt_tokens", 0), u.get("completion_tokens", 0))


class OfflineStubProvider:
    """Structurally valid output that is not research.

    This exists so the state machine, the artifact contract and the human gate can
    be exercised without a key. It is not a fallback and must never be reached by
    accident: it has to be turned on explicitly. Model responses are synthetic and
    model-derived artifacts/provenance carry that status, which the release gate
    treats as a blocker.

    The temptation this guards against is real. A stub that returned plausible
    prose would make a demo look like a working research system, which is exactly
    the claim this project exists to stop anyone from making.
    """

    name = "offline-stub"

    def __init__(self, fixtures: Path | None = None) -> None:
        self.fixtures = Path(fixtures) if fixtures else None

    def complete(self, prompt: str, *, system: str = "", max_tokens: int = 4096,
                 json_mode: bool = False) -> ModelResponse:
        return ModelResponse(
            json.dumps({"_synthetic": True,
                        "_warning": "OfflineStubProvider output. Not model-generated. "
                                    "Any artifact derived from this is not research.",
                        "_prompt_sha": __import__("hashlib").sha256(prompt.encode()).hexdigest()[:12]}),
            "offline-stub", synthetic=True)


def build_model_provider(spec: str, *, offline: bool = False) -> ModelProvider:
    if offline or spec == "offline":
        return OfflineStubProvider()
    if spec.startswith("anthropic"):
        return AnthropicProvider(*( [spec.split(":", 1)[1]] if ":" in spec else [] ))
    if spec.startswith("openai"):
        return OpenAIProvider(*( [spec.split(":", 1)[1]] if ":" in spec else [] ))
    raise ProviderUnavailable(f"unknown model provider '{spec}'")


# --------------------------------------------------------------------------
# scholarly providers
# --------------------------------------------------------------------------
@dataclass
class ScholarlyCapabilities:
    """What a provider can actually do — used to name coverage blind spots.

    These flags are the difference between a coverage report that means something
    and one that reports hit counts. A provider set with `full_text=False`
    everywhere cannot support a mechanism-level novelty search, and the run needs
    to say so rather than return a confident NOVEL_ENOUGH.
    """
    full_text: bool = False
    abstracts: bool = True
    citations: bool = False
    code_search: bool = False
    preprints: bool = False
    non_english: bool = False
    last_90_days: bool = True
    requires_key: bool = False
    documented_rate: str = "unknown"


@dataclass
class ScholarlyProvider:
    name: str
    base_url: str
    capabilities: ScholarlyCapabilities
    api_key_env: str | None = None
    mailto_env: str | None = None
    probe_ok: bool | None = None
    probe_detail: str = ""
    _transport: Any = field(default=None, repr=False)

    def available(self) -> bool:
        # ``api_key_env`` also names optional credentials for public endpoints.
        # Only providers whose selected capability really requires a key are
        # unavailable without one.  Treating every configured key as mandatory
        # silently removed Semantic Scholar's public paper search from live runs.
        if (self.capabilities.requires_key and self.api_key_env
                and not os.environ.get(self.api_key_env)):
            return False
        return self.probe_ok is not False

    def search(self, query: str, limit: int = 25) -> list[dict[str, Any]]:
        if self._transport is None:
            raise ProviderUnavailable(
                f"provider '{self.name}' has no transport configured. Live search requires "
                f"network access; tests and demos use FixtureTransport."
            )
        return self._transport.search(self, query, limit)


class FixtureTransport:
    """Deterministic replay from disk.

    Tests that hit the live network are not tests, and a demo whose result changes
    with the weather is not evidence. Fixtures are recorded once and replayed.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def search(self, provider: ScholarlyProvider, query: str, limit: int) -> list[dict[str, Any]]:
        import hashlib
        key = hashlib.sha256(f"{provider.name}|{query}".encode()).hexdigest()[:16]
        p = self.root / provider.name / f"{key}.json"
        if not p.exists():
            raise ProviderUnavailable(
                f"no fixture for provider '{provider.name}' query {query!r} (expected {p}). "
                f"Record it with `researchforge record`, or run live with credentials."
            )
        try:
            rows = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError, RecursionError) as exc:
            raise ProviderUnavailable(
                f"fixture for provider '{provider.name}' is unreadable or malformed: "
                f"{type(exc).__name__}: {exc}") from exc
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ProviderUnavailable(
                f"fixture for provider '{provider.name}' must contain a JSON array of objects")
        try:
            bounded = max(1, min(int(limit), 100))
        except (TypeError, ValueError, OverflowError) as exc:
            raise ProviderUnavailable(
                "scholarly search limit must be an integer between 1 and 100") from exc
        return [dict(row) for row in rows[:bounded]]


class LiveTransport:
    """HTTP transport for the four built-in scholarly providers.

    Provider endpoints do not share a result schema.  Normalisation happens at
    this boundary so every downstream search consumer sees the same honest,
    sparse record instead of depending on provider-specific response shapes.
    Network failures and malformed responses are conditions of the run and are
    therefore raised, never converted to an empty result set.
    """

    def __init__(self, *, client: Any = None, timeout: float = 45.0,
                 trust_env: bool = True, rate_limit_retries: int = 1,
                 max_retry_after: float = 30.0,
                 sleep: Callable[[float], None] | None = None) -> None:
        self.client = client
        self.timeout = timeout
        # Keep proxy use explicit.  Enterprise runners normally want the system
        # proxy, but a caller that has diagnosed a broken proxy can opt into a
        # direct request without changing global process state.
        self.trust_env = bool(trust_env)
        self.rate_limit_retries = max(0, int(rate_limit_retries))
        self.max_retry_after = max(0.0, float(max_retry_after))
        self._sleep = sleep or time.sleep

    @staticmethod
    def _mapping(value: Any, provider_name: str, field: str, *,
                 nullable: bool = False) -> dict[str, Any]:
        """Require an object at a provider JSON boundary.

        These checks deliberately live before normalization.  Letting a provider
        response reach a ``.get``/iteration TypeError turns a remote data-shape
        problem into an internal ResearchForge crash, bypassing the literature
        searcher's fail-loud ``ProviderUnavailable`` handling.
        """
        if value is None and nullable:
            return {}
        if not isinstance(value, dict):
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: {field} must be an object")
        return value

    @staticmethod
    def _sequence(value: Any, provider_name: str, field: str, *,
                  nullable: bool = False) -> list[Any]:
        if value is None and nullable:
            return []
        if not isinstance(value, list):
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: {field} must be an array")
        return value

    @classmethod
    def _object_rows(cls, value: Any, provider_name: str, field: str, *,
                     nullable: bool = False) -> list[dict[str, Any]]:
        rows = cls._sequence(value, provider_name, field, nullable=nullable)
        return [cls._mapping(row, provider_name, f"{field}[{index}]")
                for index, row in enumerate(rows)]

    @classmethod
    def _string_list(cls, value: Any, provider_name: str, field: str, *,
                     nullable: bool = False) -> list[str]:
        values = cls._sequence(value, provider_name, field, nullable=nullable)
        if any(not isinstance(item, str) for item in values):
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: "
                f"{field} must contain only strings")
        return values

    @staticmethod
    def _string(value: Any, provider_name: str, field: str, *,
                nullable: bool = True) -> str | None:
        if value is None and nullable:
            return None
        if not isinstance(value, str):
            suffix = " or null" if nullable else ""
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: "
                f"{field} must be a string{suffix}")
        return value

    @staticmethod
    def _integer(value: Any, provider_name: str, field: str, *,
                 nullable: bool = True, non_negative: bool = False) -> int | None:
        if value is None and nullable:
            return None
        if isinstance(value, bool) or not isinstance(value, int):
            suffix = " or null" if nullable else ""
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: "
                f"{field} must be an integer{suffix}")
        if non_negative and value < 0:
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: "
                f"{field} must be a non-negative integer")
        return value

    @classmethod
    def _abstract(cls, inv: Any, provider_name: str, field: str) -> str | None:
        if inv is None:
            return None
        index = cls._mapping(inv, provider_name, field)
        positioned: list[tuple[int, str]] = []
        for word, raw_places in index.items():
            places = cls._sequence(raw_places, provider_name, f"{field}.{word}")
            if any(isinstance(pos, bool) or not isinstance(pos, int) for pos in places):
                raise ProviderUnavailable(
                    f"provider '{provider_name}' returned malformed JSON: "
                    f"{field}.{word} must contain only integer positions")
            positioned.extend((pos, str(word)) for pos in places)
        return " ".join(word for _pos, word in sorted(positioned)) or None

    @classmethod
    def _doi(cls, value: Any, provider_name: str, field: str) -> str | None:
        raw = cls._string(value, provider_name, field)
        text = (raw or "").strip()
        for prefix in ("https://doi.org/", "http://doi.org/", "doi:"):
            if text.lower().startswith(prefix):
                text = text[len(prefix):]
        return text or None

    def _retry_delay(self, response: Any, attempt: int) -> float:
        """Return a bounded delay for a 429 response.

        ``Retry-After`` may be seconds or an HTTP date.  Some scholarly services
        omit it, in which case one small exponential delay is still kinder than
        an immediate retry storm.  The caller controls the retry count and cap.
        """
        headers = getattr(response, "headers", {}) or {}
        raw = str(headers.get("retry-after", "")).strip()
        delay: float | None = None
        if raw:
            try:
                delay = float(raw)
            except ValueError:
                try:
                    when = parsedate_to_datetime(raw)
                    delay = when.timestamp() - time.time()
                except (TypeError, ValueError, OverflowError):
                    delay = None
        if delay is None:
            delay = float(2 ** attempt)
        return min(max(delay, 0.0), self.max_retry_after)

    def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        import httpx
        request = self.client.request if self.client is not None else httpx.request
        request_kwargs = {"timeout": self.timeout, **kwargs}
        if self.client is None:
            request_kwargs["trust_env"] = self.trust_env
        for attempt in range(self.rate_limit_retries + 1):
            try:
                response = request(method, url, **request_kwargs)
            except Exception as e:  # injected clients expose different exception types
                raise ProviderUnavailable(f"scholarly request failed for {url}: {e}") from e
            if response.status_code == 200:
                return response
            if response.status_code == 429 and attempt < self.rate_limit_retries:
                self._sleep(self._retry_delay(response, attempt))
                continue
            body = str(getattr(response, "text", ""))[:300]
            raise ProviderUnavailable(
                f"scholarly provider returned HTTP {response.status_code} for {url}: {body}")
        raise AssertionError("unreachable scholarly retry loop")

    @staticmethod
    def _json(response: Any, provider_name: str) -> dict[str, Any]:
        try:
            value = response.json()
        except Exception as e:
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned malformed JSON: {e}") from e
        if not isinstance(value, dict):
            raise ProviderUnavailable(
                f"provider '{provider_name}' returned a non-object JSON response")
        return value

    def search(self, provider: ScholarlyProvider, query: str, limit: int) -> list[dict[str, Any]]:
        try:
            limit = max(1, min(int(limit), 100))
        except (TypeError, ValueError, OverflowError) as exc:
            raise ProviderUnavailable(
                "scholarly search limit must be an integer between 1 and 100") from exc
        contact = os.environ.get(provider.mailto_env or "") if provider.mailto_env else None
        headers = {
            "User-Agent": f"ResearchForge/{__version__} scholarly-search" +
                          (f" (mailto:{contact})" if contact else ""),
            "Accept": "application/json, application/atom+xml;q=0.9",
        }
        if provider.name == "openalex":
            params: dict[str, Any] = {"search": query, "per-page": limit}
            if contact:
                params["mailto"] = contact
            data = self._json(
                self._request("GET", f"{provider.base_url.rstrip('/')}/works",
                              params=params, headers=headers), provider.name)
            out = []
            rows = self._object_rows(data.get("results"), provider.name, "results")
            for index, w in enumerate(rows):
                loc = self._mapping(w.get("primary_location"), provider.name,
                                    f"results[{index}].primary_location", nullable=True)
                source = self._mapping(loc.get("source"), provider.name,
                                       f"results[{index}].primary_location.source", nullable=True)
                authorships = self._object_rows(
                    w.get("authorships"), provider.name,
                    f"results[{index}].authorships", nullable=True)
                authors = []
                for author_index, authorship in enumerate(authorships):
                    author = self._mapping(
                        authorship.get("author"), provider.name,
                        f"results[{index}].authorships[{author_index}].author", nullable=True)
                    name = author.get("display_name")
                    if name is not None and not isinstance(name, str):
                        raise ProviderUnavailable(
                            f"provider '{provider.name}' returned malformed JSON: "
                            f"results[{index}].authorships[{author_index}].author.display_name "
                            "must be a string or null")
                    if name:
                        authors.append(name)
                row_field = f"results[{index}]"
                display_name = self._string(
                    w.get("display_name"), provider.name, f"{row_field}.display_name")
                fallback_title = self._string(
                    w.get("title"), provider.name, f"{row_field}.title")
                out.append({"id": self._string(w.get("id"), provider.name,
                                                f"{row_field}.id"),
                            "doi": self._doi(w.get("doi"), provider.name,
                                             f"{row_field}.doi"),
                            "title": display_name or fallback_title,
                            "year": self._integer(w.get("publication_year"), provider.name,
                                                  f"{row_field}.publication_year"),
                            "venue": self._string(source.get("display_name"), provider.name,
                                                  f"{row_field}.primary_location.source."
                                                  "display_name"),
                            "abstract": self._abstract(
                                w.get("abstract_inverted_index"), provider.name,
                                f"{row_field}.abstract_inverted_index"),
                            "url": (self._string(loc.get("landing_page_url"), provider.name,
                                                 f"{row_field}.primary_location."
                                                 "landing_page_url")
                                    or self._string(w.get("id"), provider.name,
                                                    f"{row_field}.id")),
                            "authors": authors,
                            "cited_by_count": self._integer(
                                w.get("cited_by_count"), provider.name,
                                f"{row_field}.cited_by_count", non_negative=True)})
            return out

        if provider.name == "crossref":
            params = {"query": query, "rows": limit}
            if contact:
                params["mailto"] = contact
            data = self._json(
                self._request("GET", f"{provider.base_url.rstrip('/')}/works",
                              params=params, headers=headers), provider.name)
            message = self._mapping(data.get("message"), provider.name, "message")
            rows = self._object_rows(message.get("items"), provider.name, "message.items")
            out = []
            for index, w in enumerate(rows):
                title = self._string_list(w.get("title"), provider.name,
                                          f"message.items[{index}].title", nullable=True)
                container_title = self._string_list(
                    w.get("container-title"), provider.name,
                    f"message.items[{index}].container-title", nullable=True)
                date_record: dict[str, Any] = {}
                for date_field in ("published-print", "published-online", "issued"):
                    if date_field not in w or w[date_field] is None:
                        continue
                    candidate = self._mapping(
                        w[date_field], provider.name,
                        f"message.items[{index}].{date_field}")
                    if candidate:
                        date_record = candidate
                        break
                dates = self._sequence(
                    date_record.get("date-parts"), provider.name,
                    f"message.items[{index}].date-parts", nullable=True)
                for part_index, part in enumerate(dates):
                    parts = self._sequence(part, provider.name,
                                           f"message.items[{index}].date-parts[{part_index}]")
                    for value_index, value in enumerate(parts):
                        self._integer(
                            value, provider.name,
                            f"message.items[{index}].date-parts[{part_index}]"
                            f"[{value_index}]", nullable=False)
                author_rows = self._object_rows(
                    w.get("author"), provider.name,
                    f"message.items[{index}].author", nullable=True)
                authors = []
                for author_index, author in enumerate(author_rows):
                    names = []
                    for name_field in ("given", "family"):
                        value = author.get(name_field)
                        if value is not None and not isinstance(value, str):
                            raise ProviderUnavailable(
                                f"provider '{provider.name}' returned malformed JSON: "
                                f"message.items[{index}].author[{author_index}].{name_field} "
                                "must be a string or null")
                        if value:
                            names.append(value)
                    authors.append(" ".join(names))
                row_field = f"message.items[{index}]"
                doi_raw = self._string(w.get("DOI"), provider.name, f"{row_field}.DOI")
                url = self._string(w.get("URL"), provider.name, f"{row_field}.URL")
                out.append({"id": doi_raw or url,
                            "doi": self._doi(doi_raw, provider.name, f"{row_field}.DOI"),
                            "title": " ".join(title),
                            "year": dates[0][0] if dates and dates[0] else None,
                            "venue": " ".join(container_title),
                            "abstract": self._string(w.get("abstract"), provider.name,
                                                     f"{row_field}.abstract"),
                            "url": url,
                            "authors": authors,
                            "cited_by_count": self._integer(
                                w.get("is-referenced-by-count"), provider.name,
                                f"{row_field}.is-referenced-by-count", non_negative=True)})
            return out

        if provider.name == "semantic_scholar":
            params = {"query": query, "limit": limit,
                      "fields": "paperId,title,year,venue,abstract,url,authors,externalIds,citationCount"}
            api_key = os.environ.get(provider.api_key_env or "") if provider.api_key_env else None
            if api_key:
                headers["x-api-key"] = api_key
            data = self._json(
                self._request("GET", f"{provider.base_url.rstrip('/')}/paper/search",
                              params=params, headers=headers), provider.name)
            out = []
            rows = self._object_rows(data.get("data"), provider.name, "data")
            for index, w in enumerate(rows):
                external_ids = self._mapping(
                    w.get("externalIds"), provider.name,
                    f"data[{index}].externalIds", nullable=True)
                author_rows = self._object_rows(
                    w.get("authors"), provider.name,
                    f"data[{index}].authors", nullable=True)
                authors = []
                for author_index, author in enumerate(author_rows):
                    name = author.get("name")
                    if name is not None and not isinstance(name, str):
                        raise ProviderUnavailable(
                            f"provider '{provider.name}' returned malformed JSON: "
                            f"data[{index}].authors[{author_index}].name must be a string or null")
                    if name:
                        authors.append(name)
                row_field = f"data[{index}]"
                out.append({"id": self._string(w.get("paperId"), provider.name,
                                                f"{row_field}.paperId"),
                            "doi": self._doi(external_ids.get("DOI"), provider.name,
                                             f"{row_field}.externalIds.DOI"),
                            "arxiv": self._string(external_ids.get("ArXiv"), provider.name,
                                                  f"{row_field}.externalIds.ArXiv"),
                            "title": self._string(w.get("title"), provider.name,
                                                  f"{row_field}.title"),
                            "year": self._integer(w.get("year"), provider.name,
                                                  f"{row_field}.year"),
                            "venue": self._string(w.get("venue"), provider.name,
                                                  f"{row_field}.venue"),
                            "abstract": self._string(w.get("abstract"), provider.name,
                                                     f"{row_field}.abstract"),
                            "url": self._string(w.get("url"), provider.name,
                                                f"{row_field}.url"),
                            "authors": authors,
                            "cited_by_count": self._integer(
                                w.get("citationCount"), provider.name,
                                f"{row_field}.citationCount", non_negative=True)})
            return out

        if provider.name == "arxiv":
            response = self._request(
                "GET", f"{provider.base_url.rstrip('/')}/query",
                params={"search_query": f'all:"{query}"', "start": 0,
                        "max_results": limit}, headers=headers)
            try:
                root = ET.fromstring(response.text)
            except (ET.ParseError, TypeError, ValueError) as e:
                raise ProviderUnavailable(f"arxiv returned malformed Atom XML: {e}") from e
            atom = "{http://www.w3.org/2005/Atom}"
            if root.tag != f"{atom}feed":
                raise ProviderUnavailable(
                    "arxiv returned malformed Atom XML: root element is not an Atom feed")
            out = []
            for entry in root.findall(f"{atom}entry"):
                ident = (entry.findtext(f"{atom}id") or "").strip()
                published = (entry.findtext(f"{atom}published") or "").strip()
                out.append({"id": ident, "arxiv": ident.rsplit("/", 1)[-1] or None,
                            "doi": None,
                            "title": " ".join((entry.findtext(f"{atom}title") or "").split()),
                            "year": int(published[:4]) if published[:4].isdigit() else None,
                            "venue": "arXiv",
                            "abstract": " ".join((entry.findtext(f"{atom}summary") or "").split()),
                            "url": ident,
                            "authors": [(a.findtext(f"{atom}name") or "").strip()
                                        for a in entry.findall(f"{atom}author")]})
            return out

        raise ProviderUnavailable(f"no live transport adapter for provider '{provider.name}'")


DEFAULT_PROVIDERS = [
    ScholarlyProvider("openalex", "https://api.openalex.org",
                      ScholarlyCapabilities(abstracts=True, citations=True, preprints=True,
                                            non_english=True, documented_rate="100k/day polite pool"),
                      mailto_env="RESEARCHFORGE_CONTACT_EMAIL"),
    ScholarlyProvider("crossref", "https://api.crossref.org",
                      ScholarlyCapabilities(abstracts=False, citations=True,
                                            documented_rate="polite pool, UA with mailto"),
                      mailto_env="RESEARCHFORGE_CONTACT_EMAIL"),
    ScholarlyProvider("arxiv", "https://export.arxiv.org/api",
                      ScholarlyCapabilities(abstracts=True, preprints=True,
                                            documented_rate="~1 req/3s"),),
    ScholarlyProvider("semantic_scholar", "https://api.semanticscholar.org/graph/v1",
                      ScholarlyCapabilities(abstracts=True, citations=True, preprints=True,
                                            requires_key=False,
                                            documented_rate="shared unauthenticated pool; "
                                                            "authenticated introductory limit 1 RPS"),
                      api_key_env="SEMANTIC_SCHOLAR_API_KEY"),
]
