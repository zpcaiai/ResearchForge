"""The state-of-the-art arm, from the plan through to the manuscript gate.

A comparative experiment with two arms answers "is our method better than the
paper we started from". No reviewer asks that. The arm these tests guard is the
third one — the current strongest method — and the property under test is that it
is *binding*: declaring it must change the plan, running it must change the
ledger, and failing to run it must stop the sentence that claims the frontier.

The failure mode being designed against is specific and common. A project
reproduces a 2019 baseline, beats it, ablates its own method against itself, and
writes "state-of-the-art". Every number in that paper is real. The claim is still
false, and nothing in a two-arm pipeline can notice.
"""
import json
from pathlib import Path

import pytest

from researchforge import skills as _skills  # noqa: F401  registers implementations
from researchforge.artifacts import ArtifactStore
from researchforge.providers import OfflineStubProvider, QuotaLedger, build_model_provider
from researchforge.provenance import ProvenanceLog
from researchforge.skill import Context, get
from researchforge.skills.execution import _spec_arms
from researchforge.skills.planning import ResearchBlueprintCompiler

ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = ROOT / "schemas"

ENVELOPE = {"gpu_hours": 8, "wallclock_hours": 24, "usd": 40, "seeds": 5,
            "datasets": [{"name": "toy", "split": "test", "resolved": True}]}


def make_ctx(tmp_path, config=None, *, offline_model=True):
    prov = ProvenanceLog(tmp_path)
    store = ArtifactStore(tmp_path, SCHEMAS, run_id="test", provenance=prov)
    return Context(project=tmp_path, run_id="test", mode="auto", store=store, prov=prov,
                   quota=QuotaLedger(tmp_path / "quota.jsonl"),
                   model=(build_model_provider("offline", offline=True) if offline_model
                          else OfflineStubProvider()),
                   scholarly=[], config=config or {}, offline=True)


# ======================================================================
# planning: the arm exists, or its absence is stated
# ======================================================================
def seed_plan(store, *, mode="CM_MEASURED", level="RL3", sota=None, established=False):
    store.write("result-reproducer", "source_repro_report", {
        "target_paper_id": "p", "target_kind": "source_paper", "level": level,
        "assessed_at_run_id": "test", "claim_comparisons": [], "failure_codes": [],
        "environment_digest": "none", "timebox_seconds": 1.0, "timebox_exhausted": False})
    assets = {"repos": [{"url": "https://github.com/x/y"}], "checkpoints": [], "datasets": [],
              "pinned_revision": "abc123"}
    if sota is not None:
        assets["sota"] = {"candidates": sota, "established": established, "established_ids": [],
                          "relevant_metrics": ["accuracy"], "note": ""}
        assets["sota_established"] = established
    store.write("result-reproducer", "baseline_assets", assets)
    store.write("reproduction-fallback-planner", "comparison_mode", {
        "mode": mode, "derived_from_level": level,
        "admissible_idea_modes": ["explain_diagnose", "benchmark_evaluate"],
        "forbidden_claim_patterns": [],
        "disclosure_required": {"required": False, "text_template": "", "must_appear_in": []}})
    store.write("user-feedback-gate", "selected_direction", {
        "selected_idea_ids": ["I-001"], "comparison_mode": mode, "rejected_but_retained": []})


def compile_plan(tmp_path, **seed_kw):
    ctx = make_ctx(tmp_path, {
        "hypothesis": "adding a gate to the router reduces expert collapse",
        "candidate_method": "top-k router with a load-balancing gate",
        "resource_envelope": dict(ENVELOPE)})
    seed_plan(ctx.store, **seed_kw)
    res = get("research-blueprint-compiler")(ctx)
    specs = json.loads((tmp_path / "experiments" / "*.yaml").read_text())
    return ctx, res, specs


def primary_of(specs):
    return next(s for s in specs if s["claim_type"] == "comparative")


def ablations_of(specs):
    return [s for s in specs if s["claim_type"] == "ablation"]


def test_a_sota_candidate_adds_a_third_condition_to_the_primary_comparison(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2", "source": "declared_by_user"}])
    primary = primary_of(specs)
    assert primary["sota"]["required"] is True
    assert primary["resources"]["conditions"] == 3
    assert primary["resources"]["runs"] == 3 * len(primary["seeds"])
    assert "current strongest method" in primary["success_metric"]


def test_the_reported_arm_says_in_the_success_metric_that_it_is_reported(tmp_path):
    """The caveat travels with the criterion, not in a footnote nobody reads."""
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}], established=False)
    assert "was not measured here" in primary_of(specs)["success_metric"]


def test_absence_of_any_sota_candidate_is_reported_rather_than_passed_over(tmp_path):
    _, res, specs = compile_plan(tmp_path, sota=None)
    primary = primary_of(specs)
    assert primary["sota"]["required"] is False
    assert primary["resources"]["conditions"] == 2
    assert any("no state-of-the-art arm is planned" in w for w in res.warnings), \
        "silence here reads as 'there is no state of the art', which is a different claim"


def test_an_unmeasured_sota_arm_narrows_the_claim_and_does_not_void_the_runs(tmp_path):
    """The defect this replaced: declaring a SOTA candidate deleted every measurement.

    It was filed as an `invalid_condition`, whose check read an artifact flag no
    runtime path ever sets True — so three arms and six completed runs, including a
    measured state-of-the-art arm, came back VOID with `best_candidate` reporting
    "no run produced a measurement".
    """
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}])
    primary = primary_of(specs)
    assert not [c for c in primary["invalid_conditions"] if "SOTA" in c["code"]], \
        "a narrow comparison is not a void one"
    cond = next(c for c in primary["narrowing_conditions"]
                if c["code"] == "SOTA_ARM_NOT_MEASURED")
    assert cond["check"] == {"kind": "ledger_arm_completed", "arm": "sota", "value": 1}
    assert "measurement stands" in cond["narrows_to"]


def test_the_narrowing_condition_clears_once_the_sota_arm_actually_runs(tmp_path):
    """It has to be satisfiable by something the runtime can do."""
    from researchforge.invalid_conditions import evaluate_all
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}])
    primary = primary_of(specs)
    conds = primary["narrowing_conditions"]
    ledger = [{"experiment_id": "E-001", "status": "COMPLETED", "arm": "sota",
               "metrics": {"primary": 0.9}, "provenance": {"arm": "sota"}}]
    ev = evaluate_all({"experiment_id": "E-001", "invalid_conditions": conds}, ledger, {})
    assert ev["fired"] == [] and ev["void"] is False
    ev_empty = evaluate_all({"experiment_id": "E-001", "invalid_conditions": conds}, [], {})
    assert ev_empty["fired"] == ["SOTA_ARM_NOT_MEASURED"]


def test_the_condition_is_absent_when_there_is_no_sota_to_establish(tmp_path):
    """An unsatisfiable condition on every spec would make the mechanism noise."""
    _, _, specs = compile_plan(tmp_path, sota=None)
    assert not primary_of(specs).get("narrowing_conditions")


def test_seeds_too_few_names_the_arms_so_a_starved_arm_is_still_counted(tmp_path):
    """An arm with zero completed runs produced no group key and CLEARED."""
    from researchforge.invalid_conditions import evaluate
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}])
    cond = next(c for c in primary_of(specs)["invalid_conditions"]
                if c["code"] == "SEEDS_TOO_FEW")
    assert cond["check"]["conditions"] == ["baseline", "candidate", "sota"]
    ledger = [{"experiment_id": "E-001", "status": "COMPLETED", "arm": arm,
               "metrics": {"primary": 1.0}, "provenance": {"arm": arm}}
              for arm in ("baseline", "candidate") for _ in range(5)]
    v = evaluate(cond, experiment_id="E-001", ledger=ledger, artifacts={})
    assert v["status"] == "FIRED" and v["short"] == {"sota": 0}


def test_ablations_record_the_strength_of_what_they_are_anchored_to(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=None)
    abl = ablations_of(specs)
    assert abl, "the fixture must produce ablations for this test to mean anything"
    for s in abl:
        assert s["anchored_to"]["parent_has_sota_arm"] is False
        assert "internal contrast only" in s["anchored_to"]["strawman_risk"]


def test_a_declared_but_unmeasured_sota_arm_is_a_different_caveat(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}], established=False)
    for s in ablations_of(specs):
        assert s["anchored_to"]["parent_has_sota_arm"] is True
        assert s["anchored_to"]["parent_sota_established"] is False
        assert "never run here" in s["anchored_to"]["strawman_risk"]


def test_an_established_sota_anchor_carries_no_strawman_warning(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}], established=True)
    for s in ablations_of(specs):
        assert "strawman_risk" not in s["anchored_to"]
        assert s["anchored_to"]["parent_sota_established"] is True


# ======================================================================
# execution: an arm nobody invokes is not an arm
# ======================================================================
def test_spec_arms_follow_what_the_spec_declares(tmp_path):
    assert _spec_arms({"baseline": {}, "candidate": {}}) == ["baseline", "candidate"]
    assert _spec_arms({"baseline": {}, "candidate": {}, "sota": {}}) == \
        ["baseline", "candidate", "sota"]
    # never an empty arm list: an experiment with nothing to run must still produce
    # a ledger row saying so, rather than silently contributing zero rows
    assert _spec_arms({}) == ["candidate"]
    # a spec whose `sota` is a string, not an arm definition, declares no sota arm
    assert _spec_arms({"candidate": {}, "sota": "Mamba-2"}) == ["candidate"]


def test_the_planned_arms_are_the_ones_the_runner_would_invoke(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}])
    primary = primary_of(specs)
    assert _spec_arms(primary) == ["baseline", "candidate", "sota"]
    assert len(_spec_arms(primary)) == primary["resources"]["conditions"], \
        "the resource estimate and the arms the runner can invoke must be the same number"


# ======================================================================
# the manuscript gate
# ======================================================================
DISCLOSURE_OFF = {
    "mode": "CM_MEASURED", "derived_from_level": "RL3",
    "admissible_idea_modes": ["explain_diagnose", "benchmark_evaluate"],
    "forbidden_claim_patterns": [],
    "disclosure_required": {"required": False, "text_template": "", "must_appear_in": []},
    "substitute_baseline": None, "approved_by": None, "autonomous_decision_id": None,
}
REFERENCES = [{"ref_id": "R-001", "raw": "A real cited work", "doi": "10.1234/real",
               "arxiv": None, "status": "IDENTIFIED", "resolved_via": "pattern"}]
GRAPH = [{"claim_id": "C-1", "claim_text": "frontier claim", "claim_type": "empirical",
          "status": "SUPPORTED", "conflicts": [],
          "support_edges": [{"ref_id": "R-001", "relation": "supports"},
                            {"result_id": "E-001", "relation": "supports"}]}]


#: The minimum an ExperimentSpec must carry to validate. The auditor reads exactly
#: one field of it — `sota` — so the rest is scaffolding, and writing it through the
#: real store rather than stubbing the reader is deliberate: a check that only works
#: against hand-made dicts is a check that has never met a real spec.
SPEC_SKELETON = {
    "experiment_id": "E-001",
    "hypothesis": "the gate reduces expert collapse",
    "baseline": {"kind": "source_paper_repo"},
    "candidate": {"description": "top-k router with a load-balancing gate"},
    "datasets": [{"name": "toy"}],
    "metrics": [{"name": "accuracy", "role": "decision"}],
    "seeds": [0, 1, 2],
    "invalid_conditions": [{"code": "SEEDS_TOO_FEW", "condition": "fewer than 3 seeds"}],
}


def ledger_entry(arm, status="COMPLETED", metrics=None):
    return {"run_id": "run-1", "experiment_id": "E-001", "arm": arm, "status": status,
            "metrics": metrics if metrics is not None else {"accuracy": 0.83},
            "artifacts": [], "provenance": {"code_sha": "abc", "seed": 0, "arm": arm}}


def seed_audit(ctx, ledger, *, specs=None):
    s = ctx.store
    s.write("claim-evidence-graph", "evidence_graph", GRAPH)
    s.write("finding-memory", "findings", [{"finding_id": "F-1", "statement": "x",
                                            "result_ids": ["E-001"]}])
    s.write("integrity-auditor", "stats_audit", {"issues": []})
    s.write("reproduction-fallback-planner", "comparison_mode", DISCLOSURE_OFF)
    s.write("citation-resolver", "resolved_references", REFERENCES)
    s.write("experiment-runner", "experiment_ledger", ledger)
    s.write("experiment-runner", "experiment_tree",
            {"run_id": "test", "validity": {}, "void_experiments": []})
    s.write("result-reproducer", "source_repro_report",
            {"target_paper_id": "p-1", "target_kind": "source_paper", "level": "RL3",
             "assessed_at_run_id": "test", "claim_comparisons": [], "failure_codes": [],
             "environment_digest": "d", "timebox_seconds": 60.0, "timebox_exhausted": False,
             "human_reviewed": False})
    if specs is not None:
        s.write("research-blueprint-compiler", "experiment_specs",
                [dict(SPEC_SKELETON, **sp) for sp in specs])


def put_draft(ctx, sentence):
    body = "\n".join(["\\documentclass{article}", "\\begin{document}", "\\section{Results}",
                      "% claim: C-1", sentence, "\\end{document}"])
    ctx.store.write("manuscript-builder", "manuscript_draft", body)
    ctx.store.write("manuscript-builder", "draft_manifest", {
        "sections": ["Results"], "paragraphs": [], "claim_index": {},
        "disclosure": {"required": False, "text": "", "must_appear_in": [], "inserted_in": [],
                       "missing_sections": []},
        "every_paragraph_bound_to_a_claim": True, "_synthetic": False})
    ctx.store.write("manuscript-builder", "manuscript_spine",
                    {"thesis": "t", "claims": [{"claim_id": "C-1", "statement": "s",
                                                "section": "Results", "kind": "empirical",
                                                "evidence": {"ref_ids": ["R-001"],
                                                             "result_ids": ["E-001"]}}]})


def audit_kinds(ctx):
    get("claim-citation-auditor")(ctx)
    gate = json.loads((ctx.project / "review/integrity_gate.json").read_text())
    return gate, {b["kind"] for b in gate["blockers"]}


SOTA_BLOCKER = "sota_claim_without_measured_sota_arm"

FRONTIER_SENTENCE = ("Our method outperforms all prior approaches on the benchmark "
                     "\\cite{R-001}.")


def test_a_frontier_claim_without_any_sota_arm_blocks_submission(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate")], specs=[])
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER in kinds
    assert gate["submission_permitted"] is False
    detail = next(b["detail"] for b in gate["blockers"] if b["kind"] == SOTA_BLOCKER)
    assert "ever declared a state-of-the-art arm" in detail


def test_a_planned_but_never_executed_sota_arm_still_blocks(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": {"required": True, "candidates": [{"name": "M"}]}}]
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate")], specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    _, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER in kinds


def test_a_sota_arm_that_ran_but_produced_nothing_is_not_a_comparison(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": {"required": True, "candidates": [{"name": "M"}]}}]
    seed_audit(ctx, [ledger_entry("candidate"),
                     ledger_entry("sota", status="FAILED", metrics={})], specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER in kinds
    detail = next(b["detail"] for b in gate["blockers"] if b["kind"] == SOTA_BLOCKER)
    assert "did not run is not a comparison" in detail


def test_a_measured_sota_arm_clears_the_frontier_claim(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001",
              "sota": {"required": True, "topic_match_strength": "direct",
                       "candidates": [{"name": "M"}]}}]
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate"), ledger_entry("sota")],
               specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER not in kinds
    check = next(c for c in gate["checks"] if c["name"] == "sota_claims_have_a_measured_sota_arm")
    assert check["status"] == "PASS"


def test_describing_the_literature_is_not_a_claim_about_this_work(tmp_path):
    """The check has to be trustworthy in related work or it will be turned off."""
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("candidate")], specs=[])
    put_draft(ctx, "Recent state-of-the-art language models use rotary embeddings "
                   "\\cite{R-001}.")
    _, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER not in kinds


def test_beating_the_source_baseline_is_not_a_frontier_claim(tmp_path):
    """A narrow comparative claim stays admissible; only 'best' needs the best."""
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate")], specs=[])
    put_draft(ctx, "Our method improves over the baseline of \\cite{R-001} on this benchmark.")
    _, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER not in kinds


# ======================================================================
# the frontier gate: what it used to miss, and what it used to block
# ======================================================================
FRONTIER_MISSES = [
    ("a named system with no pronoun",
     "ForgeNet outperforms all prior methods on WMT14."),
    ("pronoun continuation across sentences",
     "Our approach is simple. It outperforms all prior methods."),
    ("the same claim in plainer words",
     "We report the highest accuracy ever recorded on this benchmark."),
    ("the control that always worked",
     "Our method outperforms all prior methods."),
]


@pytest.mark.parametrize("label,sentence", FRONTIER_MISSES, ids=[x[0] for x in FRONTIER_MISSES])
def test_a_frontier_claim_is_caught_however_it_is_phrased(tmp_path, label, sentence):
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate")], specs=[])
    put_draft(ctx, sentence + " \\cite{R-001}" if "cite" not in sentence else sentence)
    _, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER in kinds, f"{label}: {sentence!r} passed the gate"


FRONTIER_NON_CLAIMS = [
    ("a mention in a setup sentence",
     "We follow the setup of prior work, e.g. state-of-the-art transformers \\cite{R-001}."),
    ("a sentence about the literature",
     "Recent state-of-the-art language models use rotary embeddings \\cite{R-001}."),
    ("a narrow comparative claim",
     "Our method improves over the baseline of \\cite{R-001} on this benchmark."),
]


@pytest.mark.parametrize("label,sentence", FRONTIER_NON_CLAIMS,
                         ids=[x[0] for x in FRONTIER_NON_CLAIMS])
def test_correct_text_is_not_blocked(tmp_path, label, sentence):
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate")], specs=[])
    put_draft(ctx, sentence)
    _, kinds = audit_kinds(ctx)
    assert SOTA_BLOCKER not in kinds, f"{label}: {sentence!r} was blocked"


def test_a_sentence_beginning_with_a_digit_is_its_own_sentence(tmp_path):
    """The splitter's uppercase-only lookahead merged results prose constantly."""
    from researchforge.skills.writing import _sentences
    got = _sentences("Our method improves over the baseline. "
                     "12 recent systems report state-of-the-art numbers.")
    assert len(got) == 2, got
    assert _sentences("We ran it on e.g. 3 datasets.") == ["We ran it on e.g. 3 datasets."]


# ======================================================================
# the SOTA search: same field, same research topic
# ======================================================================
from researchforge.skills.reproduction import ResultReproducer  # noqa: E402

MODEL = {"title": "Gated routing for mixture-of-experts language models",
         "task": "language modelling with sparse expert routing",
         "datasets": ["WikiText-103", "C4"],
         "metrics": ["perplexity"]}


def sota_of(lit=None, bench="", declared=None, coverage=None):
    return ResultReproducer()._sota(MODEL, bench, lit or [], declared or [], coverage or {})


def hit(title, abstract="", family="sota", provider="openalex"):
    return {"title": title, "abstract": abstract, "_query_family": family,
            "_provider": provider, "_query": "state of the art WikiText-103"}


def test_a_candidate_naming_this_papers_benchmark_is_a_direct_match():
    s = sota_of([hit("ExpertLM sets a new state of the art on WikiText-103",
                     "We outperform all prior work on WikiText-103 perplexity.")])
    assert len(s["candidates"]) == 1
    m = s["candidates"][0]["topic_match"]
    assert m["kind"] == "shared_benchmark" and m["matched"] == "WikiText-103"
    assert m["strength"] == "direct"


def test_a_frontier_claim_from_another_field_is_rejected_with_a_reason():
    """The old filter was 'the title contains state-of-the-art', which any field satisfies."""
    s = sota_of([hit("State-of-the-art protein folding with diffusion priors",
                     "We outperform all prior methods on CASP15 structure prediction.")])
    assert s["candidates"] == []
    assert s["rejected_off_topic"][0]["why"].startswith("names none of this paper's benchmarks")


def test_task_term_overlap_qualifies_but_is_recorded_as_weak():
    s = sota_of([hit("Sparse expert routing achieves state-of-the-art language modelling",
                     "Our routing outperforms dense baselines.")])
    m = s["candidates"][0]["topic_match"]
    assert m["kind"] == "shared_task_terms" and m["strength"] == "weak"
    assert "may not be measured the same way" in m["why"]


def test_only_the_sota_query_family_is_mined_for_candidates():
    """Related-work hits are neighbours, not a frontier search."""
    s = sota_of([hit("A survey of state-of-the-art routing on WikiText-103",
                     family="related_work")])
    assert s["candidates"] == [] and s["rejected_off_topic"] == []


def test_a_hit_that_asserts_nothing_about_the_frontier_is_not_a_candidate():
    s = sota_of([hit("An analysis of routing collapse on WikiText-103",
                     "We characterise when experts collapse.")])
    assert s["candidates"] == []


def test_the_source_papers_own_benchmark_row_is_not_a_competing_method():
    bench = ('benchmark,reported_by,value,source\n'
             '"WikiText-103","source paper","see paper","this paper"\n'
             '"WikiText-103","ExpertLM","14.2","openalex: ..."\n')
    s = sota_of(bench=bench)
    assert [c["name"] for c in s["candidates"]] == ["ExpertLM"]


BENCH_TWO = ('benchmark,reported_by,value,source\n'
             '"WikiText-103","LowScore","30.0","x"\n'
             '"WikiText-103","HighScore","90.0","x"\n')


def test_candidates_are_ordered_strongest_evidence_first():
    """Shared benchmark before task overlap, whatever the numbers say."""
    s = sota_of([hit("Sparse expert routing state-of-the-art language modelling")],
                bench=BENCH_TWO)
    strengths = [c["topic_match"]["strength"] for c in s["candidates"]]
    assert strengths == sorted(strengths, key=["direct", "asserted", "weak"].index), strengths
    assert [c["name"] for c in s["candidates"]][2] == \
        "Sparse expert routing state-of-the-art language modelling"


def test_a_reported_number_ranks_candidates_only_when_a_direction_was_declared():
    """44.0 is not better than 8.9 until somebody says which way the metric runs.

    The old key was `-float(value)` with no direction at all, so on perplexity —
    or error rate, WER, FID, latency, loss — it put the WORST method first and
    the `[:5]` in the blueprint then dropped the best one.
    """
    r = ResultReproducer()
    maximised = dict(MODEL, metrics=[{"name": "accuracy", "direction": "maximize"}])
    minimised = dict(MODEL, metrics=[{"name": "perplexity", "direction": "minimize"}])

    hi = r._sota(maximised, BENCH_TWO, [], [], {})
    assert [c["name"] for c in hi["candidates"]] == ["HighScore", "LowScore"]
    assert "maximize" in hi["searched_for"]["ordering"]

    lo = r._sota(minimised, BENCH_TWO, [], [], {})
    assert [c["name"] for c in lo["candidates"]] == ["LowScore", "HighScore"]

    # undeclared: retrieval order, and the artifact says why rather than guessing
    none = r._sota(dict(MODEL, metrics=["perplexity"]), BENCH_TWO, [], [], {})
    assert [c["name"] for c in none["candidates"]] == ["LowScore", "HighScore"]
    assert "no metric direction was declared" in none["searched_for"]["ordering"]


def test_an_operator_declared_candidate_is_not_gated_but_is_labelled_asserted():
    s = sota_of(declared=[{"name": "Mamba-2"}])
    m = s["candidates"][0]["topic_match"]
    assert m["kind"] == "declared" and m["strength"] == "asserted"


def test_an_empty_result_under_unknown_coverage_is_not_evidence_of_no_sota():
    s = sota_of(coverage={"status": "UNKNOWN_COVERAGE"})
    assert s["candidates"] == []
    assert s["retrieval_coverage"] == "UNKNOWN_COVERAGE"
    assert "not about the field" in s["absence_means"]


def test_what_was_searched_for_is_recorded_so_the_gate_can_be_audited():
    s = sota_of()
    assert s["searched_for"]["datasets"] == ["WikiText-103", "C4"]
    assert "must name one of this paper's benchmarks" in s["searched_for"]["gate"]


def test_a_weak_topic_match_reaches_the_ablation_as_its_own_risk(tmp_path):
    """A wrong-measurement anchor must not read as the milder unmeasured-anchor caveat."""
    ctx = make_ctx(tmp_path, {
        "hypothesis": "adding a gate to the router reduces expert collapse",
        "candidate_method": "top-k router with a load-balancing gate",
        "resource_envelope": dict(ENVELOPE)})
    seed_plan(ctx.store, mode="CM_MEASURED", level="RL3",
              sota=[{"name": "Adjacent work", "topic_match": {"kind": "shared_task_terms",
                                                              "strength": "weak", "why": "x"}}])
    get("research-blueprint-compiler")(ctx)
    specs = json.loads((tmp_path / "experiments" / "*.yaml").read_text())
    primary = primary_of(specs)
    assert primary["sota"]["topic_match_strength"] == "weak"
    assert "may not be measured the same way" in primary["sota"]["topic_caveat"]
    for a in ablations_of(specs):
        assert "strongest at a different measurement" in a["anchored_to"]["topic_risk"]


# ======================================================================
# the topic anchor at the manuscript gate
# ======================================================================
#: A measured frontier arm answers "was the frontier run". It does not answer
#: "was it the frontier of this question" — and the second is what the word
#: "strongest" in a manuscript asserts. These two failures are kept apart
#: everywhere they surface: separate blocker kind, separate gate check.
TOPIC_BLOCKER = "sota_claim_on_weak_topic_anchor"


def weak_sota(**over):
    base = {"required": True, "kind": "current_strongest_reported",
            "candidates": [{"name": "HyperMoE", "reported_value": 0.91}],
            "established": False,
            "topic_match_strength": "weak",
            "searched_for": {"task": "mixture-of-experts routing",
                             "datasets": ["WMT14", "C4"], "query_family": "sota",
                             "gate": "names a benchmark, or overlaps the task"},
            "rejected_off_topic": 3,
            "retrieval_coverage": "UNKNOWN_COVERAGE"}
    base.update(over)
    return base


def test_a_measured_arm_on_a_weak_topic_match_still_blocks_the_word_strongest(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota()}]
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate"), ledger_entry("sota")],
               specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    # the arm did run, so the *other* blocker must stay silent — otherwise the
    # author is told to run something that already ran
    assert SOTA_BLOCKER not in kinds
    assert TOPIC_BLOCKER in kinds
    assert gate["submission_permitted"] is False
    b = next(b for b in gate["blockers"] if b["kind"] == TOPIC_BLOCKER)
    assert "shared task terms alone" in b["detail"]
    assert "HyperMoE" in b["detail"]
    assert "WMT14" in b["detail"]                      # what it failed to name
    assert "UNKNOWN_COVERAGE" in b["detail"]           # and how thin the search was
    assert "may be strongest at a different measurement" in b["detail"]
    assert "restate the claim" in b["remediation"]


def test_the_two_frontier_failures_are_reported_as_two_different_checks(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota()}]
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")], specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, _ = audit_kinds(ctx)
    ran = next(c for c in gate["checks"] if c["name"] == "sota_claims_have_a_measured_sota_arm")
    topic = next(c for c in gate["checks"] if c["name"] == "sota_claims_rest_on_a_same_topic_anchor")
    assert ran["status"] == "PASS", "the arm ran; that check has no business failing"
    assert topic["status"] == "FAIL"
    assert "weak" in topic["detail"]


def test_a_direct_topic_match_licenses_the_claim(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota(topic_match_strength="direct")}]
    seed_audit(ctx, [ledger_entry("baseline"), ledger_entry("candidate"), ledger_entry("sota")],
               specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER not in kinds
    assert SOTA_BLOCKER not in kinds
    topic = next(c for c in gate["checks"] if c["name"] == "sota_claims_rest_on_a_same_topic_anchor")
    assert topic["status"] == "PASS"


def test_one_on_topic_anchor_anywhere_is_enough(tmp_path):
    """The caveat on a weak anchor belongs in its spec, not on the whole paper."""
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota()},
             {"experiment_id": "E-002", "sota": weak_sota(topic_match_strength="direct")}]
    ledger = [ledger_entry("candidate"), ledger_entry("sota"),
              dict(ledger_entry("sota"), run_id="run-2", experiment_id="E-002")]
    seed_audit(ctx, ledger, specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    _, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER not in kinds


def test_an_asserted_frontier_is_a_topic_match_even_without_a_shared_benchmark(tmp_path):
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota(topic_match_strength="asserted")}]
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")], specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    _, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER not in kinds


def test_prose_that_makes_no_frontier_claim_is_never_touched_by_the_topic_gate(tmp_path):
    """A weak anchor is not itself a defect. Only 'strongest' makes it one."""
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota()}]
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")], specs=specs)
    put_draft(ctx, "Our method improves over the baseline of \\cite{R-001} on this benchmark.")
    gate, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER not in kinds
    assert gate["submission_permitted"] is not False or True


UNVERIFIABLE = "sota_claim_on_unverifiable_anchor"


def test_a_measured_arm_with_no_spec_to_judge_it_by_is_blocked_as_unverifiable(tmp_path):
    """Silence about the topic is not evidence of a good topic either.

    This used to return no blocker at all, which is a pass. Whether the
    comparison was on this paper's topic was then decided by whether a ledger row
    happened to carry an experiment_id somebody had compiled a spec for.
    """
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")], specs=[])
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER not in kinds          # not a weak anchor — an unreadable one
    assert UNVERIFIABLE in kinds
    assert gate["submission_permitted"] is False


@pytest.mark.parametrize("label,ledger,specs", [
    ("the sota row belongs to an experiment nobody compiled",
     [ledger_entry("candidate"), dict(ledger_entry("sota"), experiment_id="E-999")],
     [{"experiment_id": "E-001", "sota": weak_sota()}]),
    ("the sota row landed under a spec that declares no sota arm",
     [ledger_entry("candidate"), dict(ledger_entry("sota"), experiment_id="E-ABL-001")],
     [{"experiment_id": "E-001", "sota": weak_sota()},
      {"experiment_id": "E-ABL-001"}]),
    ("the spec declares the arm but never recorded how it was matched",
     [ledger_entry("candidate"), ledger_entry("sota")],
     [{"experiment_id": "E-001",
       "sota": {"required": True, "candidates": [{"name": "HyperMoE"}]}}]),
])
def test_an_anchor_that_cannot_be_read_does_not_license_the_claim(tmp_path, label, ledger, specs):
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, ledger, specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert UNVERIFIABLE in kinds, f"{label}: passed the gate"
    assert gate["submission_permitted"] is False
    topic = next(c for c in gate["checks"]
                 if c["name"] == "sota_claims_rest_on_a_same_topic_anchor")
    assert topic["status"] == "FAIL"
    # the detail line and the status must not contradict each other
    assert "could not be attributed" in topic["detail"]


def test_an_unreadable_spec_file_blocks_rather_than_disabling_the_gate(tmp_path):
    """A partial write used to switch the newest gate off silently."""
    ctx = make_ctx(tmp_path, offline_model=False)
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")],
               specs=[{"experiment_id": "E-001", "sota": weak_sota()}])
    put_draft(ctx, FRONTIER_SENTENCE)
    for f in sorted((ctx.project / "experiments").glob("*.yaml")):
        f.write_text(f.read_text()[:-40], encoding="utf-8")
    gate, kinds = audit_kinds(ctx)
    assert UNVERIFIABLE in kinds
    assert gate["submission_permitted"] is False


def test_a_candidate_recorded_as_a_bare_string_does_not_kill_the_auditor(tmp_path):
    """spec.sota has no schema, so this shape validates. It must not crash."""
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota(candidates=["HyperMoE", "Mamba-2"])}]
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")], specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER in kinds
    assert "HyperMoE" in next(b for b in gate["blockers"]
                              if b["kind"] == TOPIC_BLOCKER)["detail"]


# ======================================================================
# an arm nobody can run must not be planned, budgeted or required
# ======================================================================
def test_a_project_with_no_known_frontier_is_not_voided_by_its_own_sota_arm(tmp_path):
    """The worst false positive available: a sound two-arm run reported as nothing.

    `spec["sota"]` is written on every comparative spec even when the search
    found nobody, because `searched_for` / `absence_means` are the audit trail for
    *why* there is no frontier arm. That made it a dict, and three separate rules
    read "is a dict" as "is an arm": the runner's arm list, the resource estimate,
    and the seed-count void condition. A perfect ledger for baseline and candidate
    then fired SEEDS_TOO_FEW on an arm that had no candidate to implement, and
    every measurement in the experiment was discarded as void.
    """
    from researchforge.invalid_conditions import evaluate_all

    _, _, specs = compile_plan(tmp_path)                   # no sota candidates
    primary = primary_of(specs)
    assert primary["sota"]["required"] is False
    assert primary["sota"]["kind"] == "none_identified"
    assert primary["sota"]["note"], "the audit trail for why there is no arm must survive"

    assert _spec_arms(primary) == ["baseline", "candidate"]
    assert primary["resources"]["conditions"] == len(_spec_arms(primary))

    seeds = primary["seeds"]
    ledger = [{"run_id": f"r{i}-{arm}", "experiment_id": primary["experiment_id"], "arm": arm,
               "status": "COMPLETED", "metrics": {"primary": 0.8}, "artifacts": [],
               "provenance": {"seed": s, "arm": arm}}
              for i, s in enumerate(seeds) for arm in ("baseline", "candidate")]
    verdict = evaluate_all(primary, ledger, {})
    assert verdict["void"] is False, f"a complete run came back void: {verdict['fired']}"


def test_the_sota_arm_is_still_runnable_when_a_candidate_exists(tmp_path):
    _, _, specs = compile_plan(tmp_path, sota=[{"name": "Mamba-2"}])
    primary = primary_of(specs)
    assert _spec_arms(primary) == ["baseline", "candidate", "sota"]
    seeds_cond = next(c for c in primary["invalid_conditions"] if c["code"] == "SEEDS_TOO_FEW")
    assert seeds_cond["check"]["conditions"] == ["baseline", "candidate", "sota"]


# ======================================================================
# the search: what it retrieves, and what it may not silently drop
# ======================================================================
def test_a_hit_belongs_to_every_family_that_retrieved_it(tmp_path):
    """Dedup used to keep the family that saw it FIRST, and related_work runs first.

    The related-work family includes one query per dataset — the query most likely
    to co-return the frontier paper — so the frontier paper was retrieved, tagged
    `related_work`, and then discarded by both consumers, which reported that the
    field has no state of the art.
    """
    from researchforge.skills.evidence import _in_family

    hit_seen_twice = {"title": "HyperMoE sets a new state of the art on WikiText-103",
                      "_query_family": "related_work", "_query_families": ["related_work", "sota"]}
    assert _in_family(hit_seen_twice, "sota")
    # an artifact written before the list existed still reads correctly
    assert _in_family({"title": "x", "_query_family": "sota"}, "sota")
    assert not _in_family({"title": "x", "_query_family": "related_work"}, "sota")


def test_every_benchmark_the_paper_names_gets_a_frontier_query():
    """`searched_for` is quoted back to the author as evidence of what was searched."""
    from researchforge.skills.evidence import LiteratureSearch

    model = {"title": "Gated routing", "task": "language modelling",
             "datasets": ["WikiText-103", "C4", "The Pile", "LAMBADA"],
             "methods": ["a", "b", "c"]}
    qs = LiteratureSearch()._queries(model, "objective text here")
    sota = " ".join(q["query"] for q in qs if q["family"] == "sota").lower()
    for d in model["datasets"]:
        assert d.lower() in sota, f"{d} was named by the paper and never searched for"


def test_searched_for_reports_the_benchmarks_actually_queried():
    r = ResultReproducer()
    log = [{"query": "state of the art WikiText-103", "query_family": "sota"},
           {"query": "C4 corpus", "query_family": "related_work"}]
    s = r._sota(MODEL, "", [], [], {}, log)
    assert s["searched_for"]["datasets"] == ["WikiText-103"]
    assert s["searched_for"]["datasets_never_queried"] == ["C4"]
    assert s["searched_for"]["datasets_named_by_the_paper"] == ["WikiText-103", "C4"]
    # with no log at all, "unknown" is not reported as "all of them"
    s2 = r._sota(MODEL, "", [], [], {})
    assert s2["searched_for"]["datasets_never_queried"] is None


def test_a_benchmark_name_is_matched_as_a_name_not_as_a_substring():
    """`"pile" in "compiler"` graded a tensor-compiler paper as a direct match."""
    r = ResultReproducer()
    model = dict(MODEL, datasets=["Pile"])
    s = r._sota(model, "", [hit("A state-of-the-art compiler for tensor programs",
                                "We outperform prior compilers.")], [], {})
    assert s["candidates"] == []
    s2 = r._sota(model, "", [hit("MegaLM: state of the art on the Pile",
                                 "Best perplexity reported on the Pile.")], [], {})
    assert s2["candidates"][0]["topic_match"]["strength"] == "direct"


def test_a_scalar_sota_methods_value_is_not_iterated_character_by_character():
    """`--set sota_methods=Mamba-2` produced five one-character `asserted` candidates,
    and one `asserted` candidate anywhere switches the topic gate off."""
    s = sota_of(declared="Mamba-2")
    assert [c["name"] for c in s["candidates"]] == ["Mamba-2"]
    s2 = ResultReproducer()._sota(dict(MODEL, datasets="WikiText-103"), "", [], [], {})
    assert s2["searched_for"]["datasets_named_by_the_paper"] == ["WikiText-103"]


def test_a_comma_in_a_title_does_not_shift_every_column_of_benchmark_matrix():
    bench = ('benchmark,reported_by,value,source\n'
             '"WikiText-103","HyperMoE: sparse routing, revisited","12.1","arxiv:1234"\n'
             '"language modelling perplexity, windowed","source paper","see paper","p"\n')
    s = sota_of(bench=bench)
    names = [c["name"] for c in s["candidates"]]
    assert names == ["HyperMoE: sparse routing, revisited"], names
    c = s["candidates"][0]
    assert c["reported_value"] == "12.1" and c["citation"] == "arxiv:1234"
    assert "windowed" not in " ".join(names), "the paper was anchored to its own metric name"


def test_the_stronger_record_of_a_duplicate_candidate_survives():
    """Dedup ran in source order, so the operator's bare name displaced the same
    method's shared-benchmark evidence AND its reported number, invisibly."""
    bench = ('benchmark,reported_by,value,source\n'
             '"WikiText-103","Mamba-2","12.1","arxiv:9"\n')
    s = sota_of(bench=bench, declared=[{"name": "Mamba-2"}])
    assert len(s["candidates"]) == 1
    c = s["candidates"][0]
    assert c["topic_match"]["strength"] == "direct"
    assert c["reported_value"] == "12.1"
    assert "declared_by_user" in c.get("also_found_by", []) or c["source"] == "declared_by_user"


def test_the_weak_blocker_names_the_papers_benchmarks_and_what_was_searched(tmp_path):
    """v2.8.2 redefined `searched_for.datasets` to mean "actually queried".

    The blocker's "names none of this paper's benchmarks (…)" clause kept reading
    that field, so whenever the retrieval log was absent it printed an empty
    parenthesis and told the author to "compare against a method that reports on
    this paper's benchmark" — the exact "no idea what was already looked at"
    failure the blocker was written to fix.
    """
    ctx = make_ctx(tmp_path, offline_model=False)
    sota = weak_sota()
    sota["searched_for"] = {"task": "moe routing", "datasets": [],
                            "datasets_named_by_the_paper": ["WMT14", "C4"],
                            "datasets_never_queried": ["WMT14", "C4"]}
    seed_audit(ctx, [ledger_entry("candidate"), ledger_entry("sota")],
               specs=[{"experiment_id": "E-001", "sota": sota}])
    put_draft(ctx, FRONTIER_SENTENCE)
    gate, _ = audit_kinds(ctx)
    b = next(b for b in gate["blockers"] if b["kind"] == TOPIC_BLOCKER)
    assert "(WMT14, C4)" in b["detail"]
    assert "no benchmark-specific frontier query at all" in b["detail"]
    assert "reports on WMT14" in b["remediation"]


def test_a_weak_anchor_and_an_unreadable_one_are_both_reported(tmp_path):
    """Told only about the weak one, the author fixes the wrong experiment."""
    ctx = make_ctx(tmp_path, offline_model=False)
    specs = [{"experiment_id": "E-001", "sota": weak_sota()},
             {"experiment_id": "E-002",
              "sota": {"required": True, "candidates": [{"name": "X"}]}}]
    ledger = [ledger_entry("candidate"), ledger_entry("sota"),
              dict(ledger_entry("sota"), run_id="run-2", experiment_id="E-002")]
    seed_audit(ctx, ledger, specs=specs)
    put_draft(ctx, FRONTIER_SENTENCE)
    _, kinds = audit_kinds(ctx)
    assert TOPIC_BLOCKER in kinds and UNVERIFIABLE in kinds
