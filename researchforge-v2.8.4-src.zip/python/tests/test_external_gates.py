"""Coherence checks for the v2.8.4 external-evidence snapshot.

These tests validate the evidence document, not the real-world gates.  In
particular, a passing test must never promote a missing GPU, human study,
production signature, or external adjudication to PASSED.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SNAPSHOT = ROOT / "docs/external-gates-v2.8.4.json"
PDF_REPORT = ROOT / "docs/pdf18-report.json"


def _snapshot() -> dict:
    value = json.loads(SNAPSHOT.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def test_external_gate_snapshot_is_referentially_complete_and_redacted():
    snapshot = _snapshot()
    assert snapshot["schema_version"] == "1.0"
    assert snapshot["release"] == "2.8.4"
    assert snapshot["observed_environment"]["values_redacted"] is True
    assert set(snapshot["observed_environment"]["variables"].values()) == {"UNSET"}

    runs = snapshot["evidence_runs"]
    run_ids = [run["id"] for run in runs]
    assert len(run_ids) == len(set(run_ids))
    assert all(run.get("result", {}).get("status")
               in {"PASSED", "PARTIAL", "MEASURED", "FAILED"}
               for run in runs)

    gates = snapshot["gates"]
    gate_ids = [gate["id"] for gate in gates]
    assert len(gate_ids) == len(set(gate_ids)) == 6
    vocabulary = set(snapshot["status_vocabulary"])
    assert all(gate["overall_status"] in vocabulary for gate in gates)
    for gate in gates:
        assert gate["blocking_evidence"]
        assert gate["pass_requires"]
        for subgate in gate["passed_subgates"]:
            assert subgate["status"] in {"PASSED", "PARTIAL"}
            assert subgate["evidence_run_id"] in run_ids

    summary = snapshot["summary"]
    assert summary["overall_external_gates_total"] == len(gates)
    assert summary["overall_external_gates_passed"] == sum(
        gate["overall_status"] == "PASSED" for gate in gates
    )


def test_external_gate_snapshot_preserves_the_six_named_evidence_boundaries():
    gates = {gate["id"]: gate["overall_status"] for gate in _snapshot()["gates"]}
    assert gates == {
        "live_gpu_acceptance": "BLOCKED_NOT_RUN",
        "human_b_arm": "NOT_RUN",
        "pdf_quality_remeasurement": "PARTIAL_NOT_ADJUDICATED",
        "innovation_quality": "NOT_MEASURED",
        "live_service_compatibility": "NOT_VERIFIED",
        "production_key_signing_release": "NOT_CERTIFIED",
    }
    report = json.loads(PDF_REPORT.read_text(encoding="utf-8"))
    assert report["summary"]["automated_protocol_status"] == "PASSED"
    assert report["summary"]["overall_status"] == "PARTIAL_NOT_ADJUDICATED"
    assert report["summary"]["complete_quality_status"] == "NOT_ADJUDICATED"

    spec = importlib.util.spec_from_file_location(
        "pdf18_runner_status_test", ROOT / "docs/pdf18-runner.py"
    )
    assert spec and spec.loader
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    summary = runner._aggregate(
        [{}],
        [{
            "pipeline_ok": True,
            "protocol_checks_pass": True,
            "expected": {"vector_only": False},
            "observed": {
                "pages": 1, "words": 1, "claims": 1, "digit_claims": 0,
                "title_non_boilerplate": True,
                "section_count_matches_gold": True,
                "figure_count_matches_gold": True,
                "table_count_matches_gold": True,
            },
        }],
        [{"bytes_match": True, "sha256_match": True}],
    )
    assert summary["automated_protocol_status"] == "PASSED"
    assert summary["overall_status"] == "PARTIAL_NOT_ADJUDICATED"
