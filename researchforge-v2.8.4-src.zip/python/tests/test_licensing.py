"""The paywall must actually gate.

Before this existed, `verify()` computed the restricted feature list correctly and
the CLI printed it — and then ran every gated stage anyway. A paywall that only
prints is not a paywall, and invoicing for a feature the customer already has is
not a business.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from researchforge.licensing import COMMUNITY_FEATURES, FEATURE_OF_SKILL, check, load

ROOT = Path(__file__).resolve().parents[2]


def run_skill(project, skill, env_extra=None):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "python")}
    env.pop("RESEARCHFORGE_ALLOW_UNLICENSED", None)
    env.update(env_extra or {})
    p = subprocess.run(
        [sys.executable, "-m", "researchforge.runner", "run", "--skill", skill,
         "--project", str(project), "--model", "offline", "--offline",
         "--schemas", str(ROOT / "schemas")],
        input="{}", capture_output=True, text=True, env=env, cwd=ROOT)
    return json.loads(p.stdout.strip().splitlines()[-1]), p.returncode


def test_community_covers_everything_up_to_the_human_gate():
    free = {"paper-ingest", "paper-model-builder", "literature-search", "citation-resolver",
            "result-reproducer", "reproduction-fallback-planner", "idea-seed-miner",
            "idea-portfolio-generator", "idea-evaluator", "idea-ranker", "user-feedback-gate"}
    for s in free:
        assert check(s) is None, f"{s} must be free: it is where the differentiator is visible"


def test_paid_skills_are_actually_refused(tmp_path):
    for skill in ("experiment-runner", "manuscript-builder", "deck-factory", "release-gate"):
        gate = check(skill)
        assert gate is not None and gate["permitted"] is False, skill
        out, code = run_skill(tmp_path, skill)
        assert code == 14, (skill, out)
        assert out["error"]["kind"] == "licence_required"
        # the refusal has to name the feature and the tier, or the buyer cannot act on it
        assert out["error"]["feature"] == FEATURE_OF_SKILL[skill]
        assert "community" in out["error"]["message"]


def test_the_override_is_explicit_and_leaves_a_record(tmp_path):
    out, code = run_skill(tmp_path, "manuscript-builder",
                          {"RESEARCHFORGE_ALLOW_UNLICENSED": "1"})
    # it gets past the gate and fails for its own reasons, which is the point
    assert code != 14, out
    events = [json.loads(l) for l in (tmp_path / "provenance.jsonl").read_text().splitlines() if l]
    overrides = [e for e in events if e["detail"].get("kind") == "licence_override"]
    assert overrides, "an override that leaves no record is indistinguishable from a patch"
    assert overrides[0]["detail"]["feature"] == "manuscript"


def test_an_unverifiable_licence_file_is_treated_as_community(tmp_path):
    lic = tmp_path / "license.json"
    lic.write_text(json.dumps({
        "license": {"licensee": "attacker", "edition": "site", "expires": None,
                    "features": ["experiment-engine", "manuscript", "deck", "release-gate"],
                    "issued": "2026-01-01"},
        "signature": "bm90LWEtc2lnbmF0dXJl"}))
    os.environ["RESEARCHFORGE_LICENSE"] = str(lic)
    try:
        st = load()
        # a self-written licence must not unlock anything
        assert st.edition == "community"
        assert not st.allows("manuscript")
        assert check("manuscript-builder")["permitted"] is False
    finally:
        os.environ.pop("RESEARCHFORGE_LICENSE", None)


def test_a_licence_issued_by_node_unlocks_the_python_gate(tmp_path, monkeypatch):
    """Both runtimes must verify the issuer's exact signing bytes.

    The issuer signs JSON.stringify(license). Python's default json.dumps adds
    whitespace, so every genuine paid licence used to verify in TypeScript and
    fail at the Python choke point. The non-ASCII licensee also pins UTF-8 rather
    than Python's default ``\\u`` escapes.
    """
    import datetime as dt

    private_key = ROOT / "tools/license/demo/DEMO-THROWAWAY-do-not-use.private.pem"
    public_key = ROOT / "tools/license/demo/DEMO-THROWAWAY-do-not-use.public.pem"
    out = tmp_path / "node-issued-license.json"
    try:
        expires = (dt.date.today() + dt.timedelta(days=30)).isoformat()
        issued = subprocess.run(
            ["node", str(ROOT / "tools/license/issue.mjs"),
             "--licensee", "研究实验室", "--edition", "site",
             "--expires", expires, "--key", str(private_key), "--out", str(out)],
            cwd=ROOT, capture_output=True, text=True)
        assert issued.returncode == 0, issued.stderr
        monkeypatch.setenv("RESEARCHFORGE_LICENSE", str(out))
        monkeypatch.setenv("RESEARCHFORGE_LICENSE_PUBKEY_PEM",
                           public_key.read_text(encoding="utf-8"))
        state = load()
        assert state.edition == "site" and state.licensee == "研究实验室"
        assert check("experiment-runner") is None
    finally:
        out.unlink(missing_ok=True)


def test_a_corrupt_licence_file_degrades_rather_than_crashing(tmp_path):
    lic = tmp_path / "license.json"
    lic.write_text("{not json")
    os.environ["RESEARCHFORGE_LICENSE"] = str(lic)
    try:
        st = load()
        assert st.edition == "community" and st.valid
        assert "unreadable" in st.reason
    finally:
        os.environ.pop("RESEARCHFORGE_LICENSE", None)


@pytest.mark.parametrize("payload", [
    None,
    {"license": None, "signature": "x"},
    {"license": {"licensee": "x", "edition": "site", "expires": None,
                 "features": "release-gate", "issued": "2026-01-01"}, "signature": "x"},
    {"license": {"licensee": "x", "edition": "site", "expires": "2026-02-31",
                 "features": ["release-gate"], "issued": "2026-01-01"}, "signature": "x"},
])
def test_malformed_licence_shapes_degrade_to_community(tmp_path, monkeypatch, payload):
    lic = tmp_path / "license.json"
    lic.write_text(json.dumps(payload))
    monkeypatch.setenv("RESEARCHFORGE_LICENSE", str(lic))
    monkeypatch.setenv("RESEARCHFORGE_LICENSE_PUBKEY_PEM", "not-even-a-key")
    state = load()
    assert state.edition == "community" and state.valid
    assert not state.allows("release-gate")
    assert check("release-gate")["permitted"] is False


def test_every_gated_skill_maps_to_a_real_feature():
    from researchforge.generated import SKILLS
    for skill, feature in FEATURE_OF_SKILL.items():
        assert skill in SKILLS, skill
        assert feature not in COMMUNITY_FEATURES, f"{feature} cannot be both free and paid"


def test_read_only_license_probe_checks_python_gates_without_project_writes(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "python"),
           "RESEARCHFORGE_LICENSE": str(tmp_path / "absent-license.json")}
    env.pop("RESEARCHFORGE_ALLOW_UNLICENSED", None)
    command = [sys.executable, "-m", "researchforge.runner", "license",
               "--license-skill", "experiment-runner",
               "--license-skill", "release-gate"]
    refused = subprocess.run(command, cwd=tmp_path, env=env, text=True,
                             capture_output=True)
    payload = json.loads(refused.stdout)
    assert refused.returncode == 14 and payload["ok"] is False
    assert {row["skill"] for row in payload["checks"]} == {
        "experiment-runner", "release-gate"}
    assert not any(tmp_path.iterdir()), "a preflight probe must not create project evidence"

    env["RESEARCHFORGE_ALLOW_UNLICENSED"] = "1"
    permitted = subprocess.run(command, cwd=tmp_path, env=env, text=True,
                               capture_output=True)
    payload = json.loads(permitted.stdout)
    assert permitted.returncode == 0 and payload["ok"] is True
    assert all(row["allowed"] and row["overridden"] for row in payload["checks"])
    assert not any(tmp_path.iterdir())

    unknown = subprocess.run(
        [sys.executable, "-m", "researchforge.runner", "license",
         "--license-skill", "not-a-paid-skill"],
        cwd=tmp_path, env=env, text=True, capture_output=True)
    assert unknown.returncode == 14
    assert json.loads(unknown.stdout)["checks"][0]["reason"] == "not a known paid skill"

    all_paid = subprocess.run(
        [sys.executable, "-m", "researchforge.runner", "license"],
        cwd=tmp_path, env=env, text=True, capture_output=True, check=True)
    assert {row["skill"] for row in json.loads(all_paid.stdout)["checks"]} == \
        set(FEATURE_OF_SKILL)


def test_a_licence_override_reaches_the_release_manifest(tmp_path):
    """The refusal message promises the operator this, and nothing built it.

    `licensing.check` tells the operator the override "will surface in the
    release manifest", and its own docstring says "the record is what the release
    manifest reads". `ReleaseGate._manifest` built every other field and never
    this one, so the manifest of an unlicensed run was byte-for-byte the shape of
    a licensed one. The whole design of the override is that bypassing leaves a
    mark where an auditor looks.
    """
    from researchforge.provenance import Event, ProvenanceLog
    from researchforge.skills.artifacts_out import ReleaseGate

    prov = ProvenanceLog(tmp_path)
    prov.append(Event(prov.now(), "run-1", "experiment-runner", "gate",
                      detail={"kind": "licence_override", "skill": "experiment-runner",
                              "feature": "sandboxed_execution", "edition": "community",
                              "licence_reason": "no licence file", "overridden": True}))
    prov.append(Event(prov.now(), "run-1", "manuscript-builder", "gate",
                      detail={"kind": "licence", "skill": "manuscript-builder"}))

    class _Ctx:
        pass
    ctx = _Ctx()
    ctx.prov = prov
    got = ReleaseGate._licence_overrides(ctx)
    assert got["count"] == 1
    assert got["skills"] == ["experiment-runner"]
    assert got["events"][0]["feature"] == "sandboxed_execution"
    assert "not licensed to produce them" in got["note"]


def test_a_clean_run_says_so_rather_than_saying_nothing(tmp_path):
    """`count: 0` is how the manifest states that no gate was bypassed. An absent
    field would be indistinguishable from a field nobody wrote."""
    from researchforge.provenance import ProvenanceLog
    from researchforge.skills.artifacts_out import ReleaseGate

    class _Ctx:
        pass
    ctx = _Ctx()
    ctx.prov = ProvenanceLog(tmp_path)
    got = ReleaseGate._licence_overrides(ctx)
    assert got["count"] == 0 and got["skills"] == []
    assert "no licence gate was bypassed" in got["note"]
