import hashlib
import json
import os
import pytest
from pathlib import Path

from researchforge.artifacts import ArtifactStore
from researchforge.errors import ContractViolation, SchemaViolation
from researchforge.provenance import sha256_file

SCHEMAS = Path(__file__).resolve().parents[2] / "schemas"


def store(tmp_path):
    return ArtifactStore(tmp_path, SCHEMAS, run_id="test")


def test_producer_may_write(tmp_path):
    s = store(tmp_path)
    s.write("idea-ranker", "ranked_ideas", {"ideas": []})
    assert s.exists("ranked_ideas")


def test_non_producer_cannot_write(tmp_path):
    s = store(tmp_path)
    with pytest.raises(ContractViolation, match="produced by"):
        s.write("idea-ranker", "paper_model", {"paper_id": "x"})


def test_undeclared_artifact_rejected(tmp_path):
    s = store(tmp_path)
    with pytest.raises(ContractViolation, match="not in the contract"):
        s.write("idea-ranker", "idea_portfolio_v2", {})


def test_reader_must_declare_input(tmp_path):
    s = store(tmp_path)
    s.write("paper-model-builder", "paper_model",
            {"paper_id": "p", "title": "t", "sections": [], "claims": []})
    # citation-resolver does not declare paper_model as an input
    with pytest.raises(ContractViolation, match="not in its declared inputs"):
        s.read("citation-resolver", "paper_model")


def test_schema_is_enforced(tmp_path):
    s = store(tmp_path)
    with pytest.raises(SchemaViolation, match="PaperModel"):
        s.write("paper-model-builder", "paper_model", {"title": "missing required fields"})


def test_missing_upstream_names_its_producer(tmp_path):
    s = store(tmp_path)
    with pytest.raises(ContractViolation, match="producer is 'paper-model-builder'"):
        s.read("idea-seed-miner", "paper_model")


def test_write_is_recorded_in_provenance(tmp_path):
    s = store(tmp_path)
    s.write("idea-ranker", "ranked_ideas", {"ideas": [1]})
    evs = s.prov.events_for("ranked_ideas")
    assert len(evs) == 1 and evs[0].kind == "artifact_write" and evs[0].digest


def test_digest_refuses_symlinked_parent_and_hardlinked_file(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    source = outside / "evidence.txt"
    source.write_text("outside evidence")
    linked_parent = tmp_path / "linked"
    linked_parent.symlink_to(outside, target_is_directory=True)

    with pytest.raises(ContractViolation, match="without following links"):
        sha256_file(linked_parent / source.name)

    ordinary = tmp_path / "ordinary.txt"
    ordinary.write_text("one inode")
    peer = tmp_path / "peer.txt"
    peer.hardlink_to(ordinary)
    with pytest.raises(ContractViolation, match="exclusively owned"):
        sha256_file(ordinary)


def test_directory_member_round_trip_is_fd_bound_and_recorded(tmp_path):
    s = store(tmp_path)
    target = s.write_member("data-analyst", "analysis_plots", "metric.png", b"png")

    assert s.read_member("figure-factory", "analysis_plots", "metric.png") == b"png"
    assert target.read_bytes() == b"png"
    events = s.prov.events_for("analysis_plots")
    assert [event.kind for event in events] == ["artifact_write", "artifact_read"]
    assert all(event.detail["member"] == "metric.png" for event in events)


def test_directory_member_read_refuses_link_and_returns_explicit_default(tmp_path):
    s = store(tmp_path)
    missing = {"missing": True}
    assert s.read_member(
        "figure-factory", "analysis_plots", "_manifest.json", default=missing
    ) is missing
    peer = tmp_path / "peer.json"
    peer.write_text('{"rendered":true}')
    target = s.path_for("analysis_plots") / "_manifest.json"
    target.parent.mkdir(parents=True)
    target.symlink_to(peer)

    with pytest.raises(ContractViolation, match="safe regular file"):
        s.read_member("figure-factory", "analysis_plots", "_manifest.json")


@pytest.mark.parametrize("operation", ["write", "append"])
def test_artifact_writes_refuse_preexisting_symlink(tmp_path, operation):
    s = store(tmp_path)
    peer = tmp_path / "peer.txt"
    peer.write_text("do not overwrite")
    if operation == "write":
        target = s.path_for("ranked_ideas")
        invoke = lambda: s.write("idea-ranker", "ranked_ideas", {"ideas": []})
    else:
        target = s.path_for("analogy_candidates")
        invoke = lambda: s.append_jsonl(
            "idea-seed-miner", "analogy_candidates", [{"candidate": "x"}]
        )
    target.parent.mkdir(parents=True)
    target.symlink_to(peer)

    with pytest.raises(ContractViolation, match="safe regular file"):
        invoke()
    assert peer.read_text() == "do not overwrite"


@pytest.mark.parametrize("operation", ["write", "append"])
def test_artifact_writes_refuse_preexisting_hardlink(tmp_path, operation):
    s = store(tmp_path)
    peer = tmp_path / "peer.txt"
    peer.write_text("do not overwrite")
    if operation == "write":
        target = s.path_for("ranked_ideas")
        invoke = lambda: s.write("idea-ranker", "ranked_ideas", {"ideas": []})
    else:
        target = s.path_for("analogy_candidates")
        invoke = lambda: s.append_jsonl(
            "idea-seed-miner", "analogy_candidates", [{"candidate": "x"}]
        )
    target.parent.mkdir(parents=True)
    target.hardlink_to(peer)

    with pytest.raises(ContractViolation, match="hard links"):
        invoke()
    assert peer.read_text() == "do not overwrite"


def test_artifact_write_refuses_symlinked_parent(tmp_path):
    s = store(tmp_path)
    outside = tmp_path / "outside"
    outside.mkdir()
    (tmp_path / "ideas").symlink_to(outside, target_is_directory=True)

    with pytest.raises(ContractViolation, match="parent component"):
        s.write("idea-ranker", "ranked_ideas", {"ideas": []})
    assert not (outside / "ranked_ideas.json").exists()


@pytest.mark.parametrize("operation", ["read", "exists"])
@pytest.mark.parametrize("link_kind", ["symlink", "hardlink"])
def test_artifact_reads_refuse_linked_targets(tmp_path, operation, link_kind):
    s = store(tmp_path)
    peer = tmp_path / "peer.json"
    peer.write_text('{"paper_id":"outside","title":"peer","sections":[],"claims":[]}')
    target = s.path_for("paper_model")
    target.parent.mkdir(parents=True)
    if link_kind == "symlink":
        target.symlink_to(peer)
        expected = "safe regular file"
    else:
        target.hardlink_to(peer)
        expected = "hard links"

    with pytest.raises(ContractViolation, match=expected):
        if operation == "read":
            s.read("idea-seed-miner", "paper_model")
        else:
            s.exists("paper_model")


@pytest.mark.parametrize("operation", ["read", "exists"])
def test_artifact_reads_refuse_symlinked_parent(tmp_path, operation):
    s = store(tmp_path)
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "paper_model.json").write_text(
        '{"paper_id":"outside","title":"peer","sections":[],"claims":[]}'
    )
    (tmp_path / "source").symlink_to(outside, target_is_directory=True)

    with pytest.raises(ContractViolation, match="parent component"):
        if operation == "read":
            s.read("idea-seed-miner", "paper_model")
        else:
            s.exists("paper_model")


def test_exists_does_not_create_missing_artifact_parents(tmp_path):
    s = store(tmp_path)
    assert s.exists("ranked_ideas") is False
    assert not (tmp_path / "ideas").exists()


def test_atomic_overwrite_does_not_modify_hardlink_swapped_in_at_rename(tmp_path,
                                                                        monkeypatch):
    s = store(tmp_path)
    s.write("idea-ranker", "ranked_ideas", {"ideas": ["old"]})
    target = s.path_for("ranked_ideas")
    peer = tmp_path / "peer.json"
    peer.write_text('{"peer":"must survive"}')
    real_replace = os.replace

    def swap_then_replace(source, destination, *, src_dir_fd=None, dst_dir_fd=None):
        if destination == target.name:
            target.unlink()
            target.hardlink_to(peer)
        return real_replace(source, destination, src_dir_fd=src_dir_fd,
                            dst_dir_fd=dst_dir_fd)

    monkeypatch.setattr(os, "replace", swap_then_replace)
    s.write("idea-ranker", "ranked_ideas", {"ideas": ["new"]})

    assert peer.read_text() == '{"peer":"must survive"}'
    assert json.loads(target.read_text()) == {"ideas": ["new"]}


@pytest.mark.parametrize("operation", ["write", "append"])
def test_provenance_digest_does_not_reopen_replaced_artifact_path(tmp_path, operation,
                                                                  monkeypatch):
    s = store(tmp_path)
    peer = tmp_path / "peer.txt"
    peer.write_text("unrelated outside bytes")
    if operation == "write":
        target = s.path_for("ranked_ideas")
        original = s._write_bytes
        payload = {"ideas": ["bound"]}
        encoded = json.dumps(payload, ensure_ascii=False, indent=1,
                             sort_keys=True).encode("utf-8")

        def replace_after_write(path, content):
            digest = original(path, content)
            path.unlink()
            path.symlink_to(peer)
            return digest

        monkeypatch.setattr(s, "_write_bytes", replace_after_write)
        s.write("idea-ranker", "ranked_ideas", payload)
        artifact_id = "ranked_ideas"
    else:
        target = s.path_for("analogy_candidates")
        original = s._append_bytes
        records = [{"candidate": "bound"}]
        encoded = b'{"candidate": "bound"}\n'

        def replace_after_append(path, content):
            digest = original(path, content)
            path.unlink()
            path.symlink_to(peer)
            return digest

        monkeypatch.setattr(s, "_append_bytes", replace_after_append)
        s.append_jsonl("idea-seed-miner", "analogy_candidates", records)
        artifact_id = "analogy_candidates"

    event = s.prov.events_for(artifact_id)[0]
    assert event.digest == hashlib.sha256(encoded).hexdigest()
    assert event.digest != hashlib.sha256(peer.read_bytes()).hexdigest()
    assert target.is_symlink()


@pytest.mark.parametrize("operation", ["write", "read"])
@pytest.mark.parametrize("link_kind", ["symlink", "hardlink"])
def test_store_operations_refuse_linked_provenance_log(tmp_path, operation, link_kind):
    s = store(tmp_path)
    if operation == "read":
        s.write("paper-model-builder", "paper_model", {
            "paper_id": "p", "title": "t", "sections": [], "claims": [],
        })
        s.prov.path.unlink()
    peer = tmp_path / "peer.log"
    peer.write_text("do not append")
    if link_kind == "symlink":
        s.prov.path.symlink_to(peer)
        expected = "safe regular file"
    else:
        s.prov.path.hardlink_to(peer)
        expected = "hard links"

    with pytest.raises(ContractViolation, match=expected):
        if operation == "write":
            s.write("idea-ranker", "ranked_ideas", {"ideas": []})
        else:
            s.read("idea-seed-miner", "paper_model")
    assert peer.read_text() == "do not append"


@pytest.mark.parametrize("link_kind", ["symlink", "hardlink"])
def test_directory_artifact_member_refuses_linked_target(tmp_path, link_kind):
    s = store(tmp_path)
    peer = tmp_path / "peer.jsonl"
    peer.write_text("do not overwrite\n", encoding="utf-8")
    target = s.path_for("prepared_data") / "train.jsonl"
    target.parent.mkdir(parents=True)
    if link_kind == "symlink":
        target.symlink_to(peer)
        expected = "safe regular file"
    else:
        target.hardlink_to(peer)
        expected = "hard links"

    with pytest.raises(ContractViolation, match=expected):
        s.write_member("data-analyst", "prepared_data", "train.jsonl", b"{}\n")

    assert peer.read_text(encoding="utf-8") == "do not overwrite\n"


def test_directory_artifact_member_refuses_symlinked_parent_and_traversal(tmp_path):
    s = store(tmp_path)
    outside = tmp_path / "outside"
    outside.mkdir()
    (tmp_path / "analysis").mkdir()
    (tmp_path / "analysis" / "prepared").symlink_to(
        outside, target_is_directory=True
    )

    with pytest.raises(ContractViolation, match="parent component"):
        s.write_member("data-analyst", "prepared_data", "train.jsonl", b"{}\n")
    with pytest.raises(ContractViolation, match="safe relative path"):
        s.write_member("data-analyst", "prepared_data", "../outside.json", b"{}\n")

    assert list(outside.iterdir()) == []
