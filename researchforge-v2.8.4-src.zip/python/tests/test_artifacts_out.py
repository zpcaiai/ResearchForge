"""What the output plane refuses to draw, present or ship.

These tests are written against the refusals. A figure generator, a deck builder
and an exporter all have trivially satisfiable happy paths — they emit files. The
only thing worth testing is whether they emit files they should not: a figure
whose numbers disagree with the analysis, a slide whose number came from nowhere,
a release that ships an artifact with no lineage or a placeholder produced by the
offline stub.
"""
import io
import json
import statistics
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from researchforge import skills as _skills  # noqa: F401  registers implementations
from researchforge.artifacts import ArtifactStore
from researchforge.errors import GateBlocked
from researchforge.providers import OfflineStubProvider, QuotaLedger
from researchforge.provenance import Event, ProvenanceLog, sha256_file
from researchforge.skill import Context, get
from researchforge.skills import artifacts_out as artifacts_out_module

SCHEMAS = Path(__file__).resolve().parents[2] / "schemas"

DISCLOSURE = ("The comparison baseline was not reproduced locally (level RL1). All comparisons "
              "are against numbers as reported by the original authors, under a different "
              "environment. Observed shortfalls: HARDWARE_UNAVAILABLE.")

VALUES = {"main": [0.81, 0.8213, 0.83], "probe": [0.77, 0.79, 0.7801]}


# --------------------------------------------------------------------------
# harness
# --------------------------------------------------------------------------
def make_ctx(tmp_path, *, run_id="test", **config):
    prov = ProvenanceLog(tmp_path)
    store = ArtifactStore(tmp_path, SCHEMAS, run_id=run_id, provenance=prov)
    return Context(project=tmp_path, run_id=run_id, mode="auto", store=store, prov=prov,
                   quota=QuotaLedger(tmp_path / "quota.jsonl"), model=OfflineStubProvider(),
                   scholarly=[], config=config, offline=True)


def comparison_mode(mode="CM_REPORTED", level="RL1", *, disclosure=True):
    forbidden = {"CM_NONE": ["outperforms", "improves over", "state-of-the-art"],
                 "CM_REPORTED": ["we reproduce", "our measured baseline",
                                 "under identical conditions"]}.get(mode, [])
    return {
        "mode": mode, "derived_from_level": level,
        "admissible_idea_modes": ["explain_diagnose", "benchmark_evaluate"],
        "forbidden_claim_patterns": forbidden,
        "disclosure_required": {"required": disclosure,
                                "text_template": DISCLOSURE if disclosure else "",
                                "must_appear_in": ["experimental setup", "limitations"]
                                if disclosure else []},
        "substitute_baseline": None, "approved_by": None, "autonomous_decision_id": None,
    }


def ledger():
    rows = []
    for branch, vals in VALUES.items():
        for seed, v in enumerate(vals):
            rows.append({"run_id": f"{branch}-E-1-s{seed}", "experiment_id": "E-1", "status": "ok",
                         "metrics": {"accuracy": v}, "artifacts": [],
                         "provenance": {"seed": seed, "branch": branch,
                                        "evaluator_version": "evaluate.py@1.0.0",
                                        "environment_digest": "sha256:env-a"}})
    return rows


def _group(branch, metric="accuracy", claim="C-1"):
    vals = VALUES[branch]
    mean = statistics.fmean(vals)
    sd = statistics.stdev(vals)
    half = 4.302652729911275 * sd / (len(vals) ** 0.5)          # t(0.975, df=2)
    return {"group_id": f"{branch}::{metric}", "branch": branch, "metric": metric,
            "kind": "confirmatory", "seeds": [0, 1, 2],
            "run_ids": [f"{branch}-E-1-s{i}" for i in range(len(vals))],
            "values": vals, "n": len(vals), "mean": mean, "median": statistics.median(vals),
            "min": min(vals), "max": max(vals), "sd": sd, "sem": sd / (len(vals) ** 0.5),
            "ci95": [mean - half, mean + half],
            "strata": [{"evaluator_version": "evaluate.py@1.0.0",
                        "environment_digest": "sha256:env-a"}]}


def analysis_results(claim="C-1"):
    groups = [_group(b) for b in VALUES]
    return {
        "run_id": "test", "generated_at": 0.0, "analysis_question": "does the probe isolate it",
        "ledger_digest": "sha256:ledger", "n_runs": 6, "n_successful": 6, "n_failed": 0,
        "failure_rate": 0.0, "confirmatory_metrics": ["accuracy"], "exploratory_metrics": [],
        "groups": groups,
        "reported": [{"reported_id": f"r::{g['group_id']}::mean", "group_id": g["group_id"],
                      "branch": g["branch"], "metric": g["metric"], "statistic": "mean",
                      "value": g["mean"], "interval": g["ci95"], "claim_ids": [claim]}
                     for g in groups],
        "comparisons": [],
    }


GRAPH = [{"claim_id": "C-1", "claim_text": "The probe isolates the failure mode.",
          "claim_type": "empirical", "status": "SUPPORTED", "conflicts": [],
          "support_edges": [{"result_id": "E-1", "relation": "supports"}]}]


def spine(statement="The probe isolates the failure mode."):
    return {"thesis": "A diagnostic account of the failure mode",
            "target_venue": "unspecified venue", "comparison_mode": "CM_REPORTED",
            "sections": ["Results", "Limitations"],
            "claims": [{"claim_id": "C-1", "statement": statement, "kind": "empirical",
                        "section": "Results",
                        "evidence": {"ref_ids": [], "result_ids": ["E-1"],
                                     "graph_status": "SUPPORTED"}}],
            "argument_chain": ["C-1"]}


def figure_plan(caption="Per-seed accuracy for each branch.", claim_id="C-1"):
    return {"figures": [{"figure_id": "F-01", "claim_id": claim_id, "kind": "results",
                         "caption": caption, "data_source": {"result_ids": ["E-1"]},
                         "status": "PLANNED"}],
            "comparison_mode": "CM_REPORTED", "no_figure_without_a_claim": True}


def seed_figures(ctx, *, plan=None, results=None):
    s = ctx.store
    s.write("claim-evidence-graph", "evidence_graph", GRAPH)
    s.write("data-analyst", "analysis_results", analysis_results() if results is None else results)
    s.write("data-analyst", "analysis_plots", {"rendered": True, "plots": []})
    s.write("manuscript-builder", "manuscript_spine", spine())
    s.write("manuscript-builder", "figure_plan", figure_plan() if plan is None else plan)
    return ctx


def seed_deck(ctx, *, statement="The probe isolates the failure mode.", mode="CM_REPORTED",
              level="RL1"):
    s = ctx.store
    s.write("manuscript-builder", "manuscript_spine", spine(statement))
    s.write("manuscript-builder", "draft_manifest",
            {"sections": ["Results"], "paragraphs": [], "claim_index": {},
             "every_paragraph_bound_to_a_claim": True, "_synthetic": False})
    s.write("manuscript-builder", "manuscript_draft", "\\section{Results}\n" + DISCLOSURE + "\n")
    s.write("experiment-runner", "experiment_ledger", ledger())
    s.write("experiment-runner", "experiment_tree",
            {"run_id": "test", "validity": {}, "void_experiments": []})
    s.write("integrity-auditor", "meta_analysis", {"id": "MA-1", "evidence_locked": True})
    s.write("reproduction-fallback-planner", "comparison_mode", comparison_mode(mode, level))
    return ctx


# --------------------------------------------------------------------------
# figure-factory
# --------------------------------------------------------------------------
def test_figures_are_vector_editable_and_bound_to_a_claim(tmp_path):
    ctx = seed_figures(make_ctx(tmp_path))
    get("figure-factory")(ctx)

    svgs = sorted((tmp_path / "figures" / "selected").glob("*.svg"))
    assert svgs, "figure-factory produced no SVG"
    root = ET.fromstring(svgs[0].read_text())
    ns = "{http://www.w3.org/2000/svg}"
    # Never flatten: a raster figure cannot be corrected, only redrawn.
    assert not list(root.iter(f"{ns}image"))
    # Text stays text, or the labels are an outline nobody can edit or search.
    assert list(root.iter(f"{ns}text"))

    emap = json.loads((tmp_path / "figures" / "element_map.json").read_text())
    fig = emap["figures"]["F-01"]
    assert fig["claim_id"] == "C-1"
    assert all(e["binds_to"] for e in fig["elements"])
    means = [e for e in fig["elements"] if e["role"] == "mean"]
    plotted = sorted(round(e["values"][0], 6) for e in means)
    expected = sorted(round(statistics.fmean(v), 6) for v in VALUES.values())
    assert plotted == expected

    trace = json.loads((tmp_path / "figures" / "generation_trace.json").read_text())
    assert trace["figures"][0]["rasterized"] is False
    # The editable copy is the shipped copy; two files would be two truths.
    assert (tmp_path / "figures" / "editable" / "F-01.svg").read_bytes() == svgs[0].read_bytes()


def test_figure_whose_numbers_disagree_with_the_analysis_is_refused(tmp_path):
    ctx = seed_figures(make_ctx(tmp_path),
                       plan=figure_plan(caption="Accuracy reaches 0.99 on the probed branch."))
    with pytest.raises(GateBlocked) as e:
        get("figure-factory")(ctx)
    assert e.value.gate == "figure_data_integrity"
    assert "0.99" in str(e.value)
    # Refusal means nothing was drawn, not that a warning was attached to a drawing.
    assert not ctx.store.exists("selected_figure")
    assert not ctx.store.exists("editable_svg")


def test_figure_that_names_no_known_claim_is_refused(tmp_path):
    ctx = seed_figures(make_ctx(tmp_path), plan=figure_plan(claim_id="C-99"))
    with pytest.raises(GateBlocked) as e:
        get("figure-factory")(ctx)
    assert "C-99" in str(e.value)
    assert not ctx.store.exists("selected_figure")


def test_figure_factory_refuses_without_the_analysis(tmp_path):
    ctx = make_ctx(tmp_path)
    ctx.store.write("manuscript-builder", "manuscript_spine", spine())
    ctx.store.write("manuscript-builder", "figure_plan", figure_plan())
    with pytest.raises(GateBlocked) as e:
        get("figure-factory")(ctx)
    assert "analysis_results" in str(e.value)


# --------------------------------------------------------------------------
# deck-factory
# --------------------------------------------------------------------------
def build_deck(ctx):
    get("figure-factory")(ctx)
    get("deck-factory")(ctx)
    from pptx import Presentation
    return Presentation(io.BytesIO((ctx.project / "slides" / "defense.pptx").read_bytes()))


def test_deck_is_native_powerpoint_not_a_stack_of_images(tmp_path):
    ctx = seed_deck(seed_figures(make_ctx(tmp_path)))
    prs = build_deck(ctx)

    from pptx.enum.shapes import MSO_SHAPE_TYPE

    text_frames, tables, pictures = 0, 0, 0
    for slide in prs.slides:
        for shape in slide.shapes:
            if shape.has_text_frame and shape.text_frame.text.strip():
                text_frames += 1
            if getattr(shape, "has_table", False):
                tables += 1
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                pictures += 1
    assert len(prs.slides) >= 5
    assert text_frames >= len(prs.slides), "every slide must carry real, editable text"
    assert tables >= 1, "the results table must be a real table, not a picture of one"
    # The spec forbids a deck of full-slide images; so does auditability.
    assert pictures == 0
    assert all(s.has_notes_slide for s in prs.slides)

    manifest = json.loads((tmp_path / "slides" / "deck_manifest.json").read_text())
    assert manifest["full_slide_images"] == 0
    assert manifest["every_quantitative_element_bound"] is True


def test_every_number_on_a_slide_names_the_artifact_it_came_from(tmp_path):
    ctx = seed_deck(seed_figures(make_ctx(tmp_path)))
    build_deck(ctx)
    evidence = json.loads((tmp_path / "slides" / "slide_evidence.json").read_text())
    quantitative = [e for e in evidence["elements"] if e["quantitative"]]
    assert quantitative
    assert all(e["bound_to"] for e in quantitative)
    assert "experiment_ledger" in evidence["artifacts_referenced"]
    assert evidence["unbound"] == []


def test_slide_number_bound_to_no_artifact_blocks_the_deck(tmp_path):
    ctx = seed_figures(make_ctx(tmp_path))
    seed_deck(ctx, statement="The probe raises accuracy to 0.99 in every setting.")
    with pytest.raises(GateBlocked) as e:
        build_deck(ctx)
    assert e.value.gate == "slide_evidence_binding"
    assert "0.99" in str(e.value)
    assert not ctx.store.exists("defense_deck")


def test_comparative_language_is_removed_under_cm_none(tmp_path):
    ctx = seed_figures(make_ctx(tmp_path))
    seed_deck(ctx, statement="The probe outperforms the published baseline.",
              mode="CM_NONE", level="RL0")
    build_deck(ctx)
    manifest = json.loads((tmp_path / "slides" / "deck_manifest.json").read_text())
    assert manifest["removed_for_comparison_mode"]
    outline = (tmp_path / "slides" / "slide_outline.md").read_text()
    assert "outperforms" not in outline


def test_deck_refuses_without_figures(tmp_path):
    ctx = seed_deck(make_ctx(tmp_path))
    with pytest.raises(GateBlocked) as e:
        get("deck-factory")(ctx)
    assert "selected_figure" in str(e.value)


# --------------------------------------------------------------------------
# release-gate
# --------------------------------------------------------------------------
CLEAN_GATE = {"verdict": "PASS", "submission_permitted": True, "decided_at": 0.0,
              "run_id": "test", "comparison_mode": "CM_REPORTED", "counts": {}, "checks": [],
              "blockers": [], "model_consulted": False, "synthetic_inputs": False,
              "human_reviewed": False}


def seed_release(ctx, *, gate=None, review=None, stats=None, mode="CM_REPORTED", level="RL1",
                 draft=None, manifest_extra=()):
    s = ctx.store
    # Produce sources first, then every audit that authorizes them.  This order is
    # the same contract edge order the release gate verifies; the fixture must not
    # hide a stale-audit release behind matching final digests.
    s.write("result-reproducer", "source_repro_report",
            {"target_paper_id": "p-1", "target_kind": "source_paper", "level": level,
             "assessed_at_run_id": "test", "claim_comparisons": [], "failure_codes": [],
             "environment_digest": "not-captured", "timebox_seconds": 60.0,
             "timebox_exhausted": False, "human_reviewed": False})
    s.write("reproduction-fallback-planner", "comparison_mode", comparison_mode(mode, level))
    s.write("experiment-runner", "experiment_ledger", ledger())
    s.write("experiment-runner", "experiment_tree",
            {"run_id": "test", "validity": {}, "void_experiments": []})
    digest = sha256_file(ctx.project / "experiment_ledger.jsonl")
    s.write("experiment-runner", "artifact_manifest",
            {"project_id": ctx.project.name,
             "artifacts": [{"artifact_id": "experiment_ledger", "path": "experiment_ledger.jsonl",
                            "sha256": digest, "kind": "ledger", "parents": []},
                           *manifest_extra]})
    s.write("citation-resolver", "bibliography", "@misc{R-001,\n  note = {A real work},\n}\n")
    s.write("finding-memory", "findings",
            [{"finding_id": "F-001", "statement": "The probe isolates the failure mode.",
              "result_ids": ["E-1"]}])
    s.write("finding-memory", "finding_memory_graph", {"nodes": ["F-001"], "edges": []})
    s.write("integrity-auditor", "stats_audit",
            {"findings": [], "severity_counts": {},
             "evidence_lock": {"blocked": False, "blocked_by": [], "blocked_claims": []}}
            if stats is None else stats)
    s.write("manuscript-builder", "manuscript_draft",
            "\\section{Results}\nThe probe isolates the failure mode.\n"
            "\\section{Limitations}\n" + DISCLOSURE + "\n" if draft is None else draft)
    s.write("claim-citation-auditor", "integrity_gate", CLEAN_GATE if gate is None else gate)
    s.write("claim-citation-auditor", "submission_blockers",
            "# Submission blockers — verdict: PASS\n\nNo blocker survived the audit.\n")
    s.write("claim-citation-auditor", "claim_audit",
            [{"claim_id": "C-1", "locator": "Results#p0", "verdict": "SUPPORTED",
              "text": "The probe isolates the failure mode.", "citations": []}])
    s.write("claim-citation-auditor", "citation_audit",
            "# Citation audit\n\nNo citation in this draft is unresolved.\n")
    s.write("review-simulator", "review_report",
            {"recommendation": "REVISE_THEN_SUBMIT",
             "recommendation_rationale": "no blocker survived the audit",
             "simulated_reviews": [], "grounded_points": [], "_synthetic": False}
            if review is None else review)
    s.write("deck-factory", "defense_deck", b"PK\x03\x04 stand-in bytes for a built deck")
    return ctx


def release(ctx):
    get("release-gate")(ctx)
    return (json.loads((ctx.project / "release" / "release_manifest.json").read_text()),
            json.loads((ctx.project / "release" / "_manifest.json").read_text()),
            (ctx.project / "release" / "release_report.md").read_text())


def kinds(bundle):
    return {b["kind"] for b in bundle["blockers"]}


def test_clean_release_is_an_assisted_draft_and_never_submission_ready(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manifest, bundle, report = release(ctx)

    assert bundle["released"] is True
    assert bundle["release_status"] == "ASSISTED_DRAFT"
    # A system that writes manuscripts must not be the thing that declares them ready.
    assert manifest["submission_ready"] is False
    assert manifest["ai_participation"]["human_verified"] is False
    assert "ResearchForge" in manifest["ai_participation"]["statement"]
    assert "assisted draft" in report.lower()
    # the deliverables actually landed in the bundle
    assert (tmp_path / "release" / "paper" / "main.tex").exists()
    assert any(d["artifact_id"] == "manuscript_draft" for d in bundle["deliverables"])
    manuscript = next(a for a in manifest["artifacts"]
                      if a["artifact_id"] == "manuscript_draft")
    assert manuscript["path"] == "release/paper/main.tex"
    assert manuscript["source_path"] == "paper/main.tex"
    assert sha256_file(tmp_path / manuscript["path"]) == manuscript["sha256"]
    schema = json.loads((SCHEMAS / "ArtifactManifest.schema.json").read_text())
    Draft202012Validator(schema).validate(manifest)


def test_unresolved_blocker_stops_the_release(tmp_path):
    gate = {**CLEAN_GATE, "verdict": "BLOCK", "submission_permitted": False,
            "blockers": [{"blocker_id": "B-001", "kind": "claim_fabricated", "claim_id": "C-1",
                          "locator": "Results#p0", "detail": "the number 0.99 matches no run",
                          "remediation": "delete the number"}]}
    ctx = seed_release(make_ctx(tmp_path), gate=gate)
    manifest, bundle, report = release(ctx)

    assert bundle["released"] is False
    assert bundle["release_status"] == "BLOCKED"
    assert "unresolved_claim_fabricated" in kinds(bundle)
    assert bundle["deliverables"] == []
    assert not (tmp_path / "release" / "paper" / "main.tex").exists()
    assert "refused" in report.lower()
    assert manifest["released"] is False


def test_synthetic_artifact_stops_the_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path),
                       review={"recommendation": "REVISE_THEN_SUBMIT",
                               "recommendation_rationale": "clean", "simulated_reviews": [],
                               "_synthetic": True})
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "synthetic_artifact_in_release" in kinds(bundle)


def test_artifact_without_provenance_stops_the_release(tmp_path):
    ctx = make_ctx(tmp_path)
    rogue = tmp_path / "analysis" / "rogue_table.csv"
    rogue.parent.mkdir(parents=True, exist_ok=True)
    rogue.write_text("metric,value\naccuracy,0.99\n")
    seed_release(ctx, manifest_extra=[{"artifact_id": "rogue_table",
                                       "path": "analysis/rogue_table.csv",
                                       "sha256": sha256_file(rogue), "kind": "table",
                                       "parents": []}])
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_without_provenance" in kinds(bundle)
    assert any("rogue_table" in b["detail"] for b in bundle["blockers"])


def test_manifest_entry_with_provenance_but_missing_file_stops_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manifest = json.loads((tmp_path / "artifact_manifest.json").read_text())
    # Reuse an id that genuinely has provenance so the missing path itself is the
    # only reason this row must be refused.
    manifest["artifacts"].append({
        "artifact_id": "experiment_ledger", "path": "analysis/vanished.json",
        "sha256": "a" * 64, "kind": "ledger", "parents": [],
    })
    ctx.store.write("experiment-runner", "artifact_manifest", manifest)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_missing_on_disk" in kinds(bundle)
    assert any("vanished.json" in blocker["detail"] for blocker in bundle["blockers"])


def test_manifest_symlink_cannot_read_or_package_a_file_outside_project(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    outside = tmp_path.parent / f"{tmp_path.name}-outside-secret.txt"
    outside.write_text("must not enter the release bundle\n")
    link = tmp_path / "analysis" / "external.txt"
    link.symlink_to(outside)
    manifest = json.loads((tmp_path / "artifact_manifest.json").read_text())
    manifest["artifacts"].append({
        "artifact_id": "experiment_ledger", "path": "analysis/external.txt",
        "sha256": sha256_file(outside), "kind": "ledger", "parents": [],
    })
    ctx.store.write("experiment-runner", "artifact_manifest", manifest)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_path_unsafe" in kinds(bundle)
    assert not (tmp_path / "release" / "analysis" / "external.txt").exists()


def test_preseeded_release_directory_symlink_is_never_followed(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    outside = tmp_path.parent / f"{tmp_path.name}-release-target"
    outside.mkdir()
    (tmp_path / "release").symlink_to(outside, target_is_directory=True)

    with pytest.raises(GateBlocked) as error:
        get("release-gate")(ctx)
    assert error.value.gate == "release_path_unsafe"
    assert list(outside.iterdir()) == []


def test_release_directory_from_a_prior_decision_is_never_reused(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    (tmp_path / "release").mkdir()
    (tmp_path / "release" / "stale.txt").write_text("old decision\n")

    with pytest.raises(GateBlocked) as error:
        get("release-gate")(ctx)
    assert error.value.gate == "release_path_unsafe"
    assert (tmp_path / "release" / "stale.txt").read_text() == "old decision\n"
    assert not (tmp_path / "release" / "paper" / "main.tex").exists()


@pytest.mark.parametrize("record", [
    42,
    {},
    {"ts": 1.0, "run_id": "test", "skill": "manuscript-builder",
     "kind": "artifact_write", "artifact_id": "manuscript_draft",
     "path": "paper/main.tex", "digest": None, "detail": {}},
    {"ts": 1.0, "run_id": "test", "skill": "release-gate",
     "kind": "artifact_read", "artifact_id": None,
     "path": None, "digest": None, "detail": {}},
])
def test_malformed_provenance_event_blocks_instead_of_crashing_release(tmp_path, record):
    ctx = seed_release(make_ctx(tmp_path))
    with (tmp_path / "provenance.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record) + "\n")

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "provenance_log_malformed" in kinds(bundle)


def test_latest_write_from_wrong_producer_cannot_impersonate_contract_owner(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manuscript = tmp_path / "paper" / "main.tex"
    ctx.prov.append(Event(
        ctx.prov.now(), ctx.run_id, "untrusted-producer", "artifact_write",
        "manuscript_draft", "paper/main.tex", sha256_file(manuscript), {},
    ))

    manifest, bundle, _report = release(ctx)

    assert bundle["released"] is False
    assert "artifact_provenance_mismatch" in kinds(bundle)
    assert any("contract-declared producer" in blocker["detail"]
               for blocker in bundle["blockers"])
    manuscript_row = next(row for row in manifest["artifacts"]
                          if row["artifact_id"] == "manuscript_draft")
    assert manuscript_row["provenance_complete"] is False


def test_later_cross_run_write_invalidates_the_earlier_audits(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manuscript = tmp_path / "paper" / "main.tex"
    ctx.prov.append(Event(
        ctx.prov.now(), "stale-unrelated-run", "manuscript-builder", "artifact_write",
        "manuscript_draft", "paper/main.tex", sha256_file(manuscript), {},
    ))

    manifest, bundle, _report = release(ctx)

    assert bundle["released"] is False
    assert "artifact_audit_order_violation" in kinds(bundle)
    manuscript_row = next(row for row in manifest["artifacts"]
                          if row["artifact_id"] == "manuscript_draft")
    assert manuscript_row["source_run_id"] == "stale-unrelated-run"


def test_release_resume_accepts_unchanged_prior_run_outputs_and_discloses_source_run(tmp_path):
    seed_release(make_ctx(tmp_path, run_id="pipeline-original"))
    resumed = make_ctx(tmp_path, run_id="pipeline-resume")

    manifest, bundle, _report = release(resumed)

    assert bundle["released"] is True
    assert not bundle["blockers"]
    assert manifest["run_id"] == "pipeline-resume"
    assert {row["source_run_id"] for row in manifest["artifacts"]} == {"pipeline-original"}


def test_manuscript_rewrite_after_audits_invalidates_their_authorization(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manuscript = tmp_path / "paper" / "main.tex"
    # Even byte-identical output is a new producer write that the already-issued
    # claim/citation/integrity/review artifacts did not inspect.
    ctx.store.write("manuscript-builder", "manuscript_draft", manuscript.read_text())

    _manifest, bundle, _report = release(ctx)

    assert bundle["released"] is False
    assert "artifact_audit_order_violation" in kinds(bundle)
    assert any(blocker["source"] == "artifact:manuscript_draft"
               for blocker in bundle["blockers"])


@pytest.mark.parametrize(("artifact_id", "payload"), [
    ("integrity_gate", {**CLEAN_GATE, "blockers": [42]}),
    ("claim_audit", [42]),
    ("review_report", "not-an-object"),
    ("stats_audit", {"findings": [42], "evidence_lock": "bad"}),
    ("comparison_mode", {}),
    ("comparison_mode", {"mode": "CM_NONE", "disclosure_required": "bad"}),
])
def test_malformed_upstream_release_artifact_blocks_instead_of_crashing(
        tmp_path, artifact_id, payload):
    ctx = seed_release(make_ctx(tmp_path))
    producer = {
        "integrity_gate": "claim-citation-auditor",
        "claim_audit": "claim-citation-auditor",
        "review_report": "review-simulator",
        "stats_audit": "integrity-auditor",
        "comparison_mode": "reproduction-fallback-planner",
    }[artifact_id]
    if artifact_id == "comparison_mode":
        # Deliberately simulate corruption after the schema-checked producer write.
        # Release-gate reads on-disk evidence and must fail closed even when that
        # evidence no longer satisfies the store's write-time schema.
        ctx.store.path_for(artifact_id).write_text(json.dumps(payload))
    else:
        ctx.store.write(producer, artifact_id, payload)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "upstream_artifact_malformed" in kinds(bundle)


def test_manifest_identity_cannot_promote_an_arbitrary_file_into_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    secret = tmp_path / "operator-secret.txt"
    secret.write_text("SHOULD-NOT-SHIP\n")
    manifest = json.loads((tmp_path / "artifact_manifest.json").read_text())
    manifest["artifacts"].append({
        "artifact_id": "experiment_ledger", "path": "operator-secret.txt",
        "sha256": sha256_file(secret), "kind": "deliverable", "parents": [],
    })
    ctx.store.write("experiment-runner", "artifact_manifest", manifest)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_manifest_provenance_mismatch" in kinds(bundle)
    assert not (tmp_path / "release" / "operator-secret.txt").exists()


def test_manifest_duplicate_path_is_corrupt_even_when_rows_are_identical(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    manifest = json.loads((tmp_path / "artifact_manifest.json").read_text())
    manifest["artifacts"].append(dict(manifest["artifacts"][0]))
    ctx.store.write("experiment-runner", "artifact_manifest", manifest)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_manifest_identity_conflict" in kinds(bundle)


def test_preseeded_hardlink_destination_cannot_overwrite_outside_file(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    outside = tmp_path.parent / f"{tmp_path.name}-outside-hardlink.txt"
    outside.write_text("outside sentinel\n")
    destination = tmp_path / "release" / "paper" / "main.tex"
    destination.parent.mkdir(parents=True)
    destination.hardlink_to(outside)

    with pytest.raises(GateBlocked) as error:
        get("release-gate")(ctx)
    assert error.value.gate == "release_path_unsafe"
    assert outside.read_text() == "outside sentinel\n"


def test_hardlinked_release_source_is_refused_as_not_exclusively_project_owned(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    source = tmp_path / "paper" / "main.tex"
    outside = tmp_path.parent / f"{tmp_path.name}-source-hardlink.tex"
    outside.hardlink_to(source)

    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_path_unsafe" in kinds(bundle)
    assert not (tmp_path / "release" / "paper" / "main.tex").exists()
    assert outside.read_bytes() == source.read_bytes()


def test_copy_failure_never_publishes_a_partial_release(tmp_path, monkeypatch):
    ctx = seed_release(make_ctx(tmp_path))
    original = artifacts_out_module._exclusive_copy
    copied = 0

    def fail_after_one(source, destination, expected_sha256):
        nonlocal copied
        copied += 1
        if copied == 2:
            raise OSError("injected staging failure")
        return original(source, destination, expected_sha256)

    monkeypatch.setattr(artifacts_out_module, "_exclusive_copy", fail_after_one)
    with pytest.raises(OSError, match="injected staging failure"):
        get("release-gate")(ctx)
    assert not (tmp_path / "release").exists()
    assert not list(tmp_path.glob(".release-stage-*"))


def test_release_succeeds_through_macos_var_alias_without_partial_path_error(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    alias = Path(str(tmp_path).replace("/private/var/", "/var/", 1))
    if alias == tmp_path or not alias.exists():
        pytest.skip("macOS /var -> /private/var alias is unavailable")
    ctx.project = alias
    ctx.store.project = alias

    manifest, bundle, _report = release(ctx)
    assert bundle["released"] is True
    assert manifest["released"] is True
    assert (tmp_path / "release" / "paper" / "main.tex").exists()


def test_artifact_edited_after_it_was_audited_stops_the_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    # What ships must be what was audited; a later edit breaks that chain silently.
    (tmp_path / "paper" / "main.tex").write_text("\\section{Results}\nAccuracy is 0.99.\n")
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "artifact_digest_drift" in kinds(bundle)


def test_missing_disclosure_under_cm_reported_stops_the_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path),
                       draft="\\section{Results}\nThe probe isolates the failure mode.\n")
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "missing_disclosure" in kinds(bundle)


def test_comparative_claim_does_not_survive_cm_none(tmp_path):
    ctx = seed_release(
        make_ctx(tmp_path), mode="CM_NONE", level="RL0",
        draft="\\section{Results}\nOur method outperforms the published baseline.\n")
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert "comparative_claim_under_CM_NONE" in kinds(bundle)


def test_release_gate_refuses_when_an_upstream_audit_is_missing(tmp_path):
    ctx = seed_release(make_ctx(tmp_path))
    (tmp_path / "review" / "review_report.json").unlink()
    with pytest.raises(GateBlocked) as e:
        get("release-gate")(ctx)
    assert e.value.gate == "release_inputs"
    assert "review_report" in str(e.value)


def test_upstream_statistics_blocker_is_carried_into_the_release(tmp_path):
    ctx = seed_release(make_ctx(tmp_path),
                       stats={"findings": [{"finding_id": "S-1", "severity": "BLOCKER",
                                            "code": "UNDERPOWERED",
                                            "message": "n=3 cannot support this contrast",
                                            "remediation": "run more seeds"}],
                              "evidence_lock": {"blocked": True, "blocked_by": ["S-1"],
                                                "blocked_claims": ["C-1"]}})
    _manifest, bundle, _report = release(ctx)
    assert bundle["released"] is False
    assert {"stats_audit_unresolved", "evidence_not_locked"} <= kinds(bundle)
