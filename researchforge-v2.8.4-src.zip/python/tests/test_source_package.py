from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
from pathlib import PurePosixPath
import subprocess
import sys
import tomllib
import zipfile
import ast

import pytest


ROOT = Path(__file__).resolve().parents[2]
BUILDER = ROOT / "tools/release/build-source-archive.py"
RELEASE_VERSION = "2.8.4"


def _load_builder():
    spec = importlib.util.spec_from_file_location("researchforge_source_archive_builder", BUILDER)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _isolated_source(builder, tmp_path: Path, data: bytes = b"source\n"):
    root = tmp_path / "source-root"
    root.mkdir()
    source = root / "input.txt"
    source.write_bytes(data)
    builder.ROOT = root
    relative = PurePosixPath("input.txt")
    return source, relative


def _listed() -> list[str]:
    run = subprocess.run([sys.executable, str(BUILDER), "--list"], cwd=ROOT,
                         text=True, capture_output=True, check=True)
    return run.stdout.splitlines()


def test_source_archive_allowlist_is_sorted_and_hygienic():
    names = _listed()
    assert names == sorted(set(names))
    assert "fixtures/papers/SOURCES.md" in names
    assert "fixtures/papers/arxiv_1706.03762_abs.html" in names
    assert "packages/contracts/src/generated.ts" in names
    assert "python/researchforge/generated.py" in names
    assert "tools/release/build-source-archive.py" in names
    assert not any(name.startswith(("./", "/")) or "/../" in f"/{name}/" for name in names)
    forbidden = ("/.pytest_cache/", "/__pycache__/", "/node_modules/", "/.venv/",
                 "/dist/", "/build/", ".egg-info/", ".tsbuildinfo")
    assert not any(any(token in f"/{name}" for token in forbidden) for name in names)
    assert not any(name.lower().endswith((".pdf", ".pyc", ".pyo", ".zip")) for name in names)
    private = [name for name in names if "private" in name.lower() or name.endswith(".key")]
    assert private == ["tools/license/demo/DEMO-THROWAWAY-do-not-use.private.pem"]


def test_source_archive_builder_is_byte_reproducible(tmp_path):
    first, second = tmp_path / "first.zip", tmp_path / "second.zip"
    for output in (first, second):
        subprocess.run([sys.executable, str(BUILDER), "--output", str(output)], cwd=ROOT,
                       text=True, capture_output=True, check=True)
    assert hashlib.sha256(first.read_bytes()).digest() == hashlib.sha256(second.read_bytes()).digest()
    with zipfile.ZipFile(first) as archive:
        names = archive.namelist()
        assert names == _listed()
        assert archive.testzip() is None
        assert all(not item.is_dir() for item in archive.infolist())
    assert first.stat().st_mode & 0o777 == 0o644


def test_source_archive_refuses_dangling_output_symlink_before_resolve(tmp_path):
    builder = _load_builder()
    _source, relative = _isolated_source(builder, tmp_path)
    target = tmp_path / "must-not-be-created.zip"
    output = tmp_path / "release.zip"
    output.symlink_to(target)

    with pytest.raises(FileExistsError, match="refusing to overwrite"):
        builder.build_archive(output, (relative,))

    assert output.is_symlink()
    assert not target.exists()


def test_source_archive_preserves_preexisting_destination(tmp_path):
    builder = _load_builder()
    _source, relative = _isolated_source(builder, tmp_path)
    output = tmp_path / "release.zip"
    output.write_bytes(b"preexisting-destination")

    with pytest.raises(FileExistsError, match="refusing to overwrite"):
        builder.build_archive(output, (relative,))

    assert output.read_bytes() == b"preexisting-destination"


def test_source_archive_concurrent_destination_wins_without_clobber(tmp_path, monkeypatch):
    builder = _load_builder()
    _source, relative = _isolated_source(builder, tmp_path)
    output = tmp_path / "release.zip"
    real_link = builder.os.link
    raced = False

    def race_then_link(source_name, destination_name, *, src_dir_fd, dst_dir_fd,
                       follow_symlinks):
        nonlocal raced
        assert not raced
        raced = True
        descriptor = os.open(
            destination_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600,
            dir_fd=dst_dir_fd,
        )
        try:
            os.write(descriptor, b"concurrent-winner")
        finally:
            os.close(descriptor)
        return real_link(
            source_name, destination_name,
            src_dir_fd=src_dir_fd, dst_dir_fd=dst_dir_fd,
            follow_symlinks=follow_symlinks,
        )

    monkeypatch.setattr(builder.os, "link", race_then_link)
    with pytest.raises(FileExistsError):
        builder.build_archive(output, (relative,))

    assert raced
    assert output.read_bytes() == b"concurrent-winner"
    assert not list(tmp_path.glob(".release.zip.*.tmp"))


def test_source_archive_rejects_source_symlink(tmp_path):
    builder = _load_builder()
    source, relative = _isolated_source(builder, tmp_path)
    target = tmp_path / "outside.txt"
    target.write_bytes(b"outside")
    source.unlink()
    source.symlink_to(target)

    with pytest.raises(ValueError, match="without following links"):
        builder.build_archive(tmp_path / "release.zip", (relative,))

    assert not (tmp_path / "release.zip").exists()


def test_source_archive_rejects_multiply_linked_source(tmp_path):
    builder = _load_builder()
    source, relative = _isolated_source(builder, tmp_path)
    os.link(source, tmp_path / "second-name.txt")

    with pytest.raises(ValueError, match="multiple hard links"):
        builder.build_archive(tmp_path / "release.zip", (relative,))

    assert not (tmp_path / "release.zip").exists()


def test_source_archive_rejects_regular_file_swap_after_collection(tmp_path):
    builder = _load_builder()
    source, relative = _isolated_source(builder, tmp_path, b"first-version")
    collected_identity = builder._validated_source_identity(relative)
    collected = builder.CollectedSources((relative,), {relative: collected_identity})
    source.rename(source.with_suffix(".old"))
    source.write_bytes(b"second-version")

    with pytest.raises(ValueError, match="changed after allowlist collection"):
        builder.build_archive(tmp_path / "release.zip", collected)

    assert not (tmp_path / "release.zip").exists()


def test_distribution_version_is_consistent_across_package_managers():
    package = json.loads((ROOT / "package.json").read_text())
    cli = json.loads((ROOT / "packages/cli/package.json").read_text())
    contracts = json.loads((ROOT / "packages/contracts/package.json").read_text())
    lock = json.loads((ROOT / "package-lock.json").read_text())
    pyproject = tomllib.loads((ROOT / "python/pyproject.toml").read_text())
    module_tree = ast.parse((ROOT / "python/researchforge/__init__.py").read_text())
    module_version = next(
        node.value.value for node in module_tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "__version__"
                for target in node.targets)
        and isinstance(node.value, ast.Constant)
        and isinstance(node.value.value, str)
    )
    assert package["version"] == cli["version"] == contracts["version"] == RELEASE_VERSION
    assert lock["version"] == lock["packages"][""]["version"] == RELEASE_VERSION
    assert lock["packages"]["packages/cli"]["version"] == RELEASE_VERSION
    assert lock["packages"]["packages/contracts"]["version"] == RELEASE_VERSION
    assert cli["dependencies"]["@researchforge/contracts"] == RELEASE_VERSION
    assert pyproject["project"]["version"] == module_version == RELEASE_VERSION
