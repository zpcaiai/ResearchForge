"""Provider boundary tests: live search is real, normalized and fail-loud."""
from __future__ import annotations

import hashlib
import json
from types import SimpleNamespace

import pytest

from researchforge.errors import ProviderUnavailable
from researchforge.providers import (DEFAULT_PROVIDERS, FixtureTransport, LiveTransport,
                                     QuotaLedger, ScholarlyCapabilities, ScholarlyProvider)
from researchforge.runner import _scholarly_transport
from researchforge.skills.evidence import LiteratureSearch


class Response:
    def __init__(self, payload=None, *, text="", status=200, headers=None):
        self.payload, self.text, self.status_code = payload, text, status
        self.headers = headers or {}

    def json(self):
        return self.payload


class Client:
    def __init__(self, response):
        self.response, self.calls = response, []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return self.response


class SequenceClient(Client):
    def __init__(self, responses):
        self.responses, self.calls = list(responses), []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return self.responses.pop(0)


def provider(name, base="https://example.test"):
    return ScholarlyProvider(name, base, ScholarlyCapabilities())


def test_openalex_live_results_are_normalized():
    payload = {"results": [{"id": "https://openalex.org/W1", "doi": "https://doi.org/10.1/x",
                            "display_name": "A paper", "publication_year": 2025,
                            "abstract_inverted_index": {"hello": [0], "world": [1]},
                            "primary_location": {"landing_page_url": "https://paper",
                                                 "source": {"display_name": "Venue"}},
                            "authorships": [{"author": {"display_name": "Ada"}}],
                            "cited_by_count": 4}]}
    client = Client(Response(payload))
    rows = LiveTransport(client=client).search(provider("openalex"), "attention", 25)
    assert rows == [{"id": "https://openalex.org/W1", "doi": "10.1/x",
                     "title": "A paper", "year": 2025, "venue": "Venue",
                     "abstract": "hello world", "url": "https://paper",
                     "authors": ["Ada"], "cited_by_count": 4}]
    assert client.calls[0][2]["params"]["search"] == "attention"
    assert "application/json" in client.calls[0][2]["headers"]["Accept"]


def test_arxiv_atom_results_are_normalized():
    xml = """<feed xmlns="http://www.w3.org/2005/Atom"><entry>
      <id>http://arxiv.org/abs/2501.00001v2</id><published>2025-01-02T00:00:00Z</published>
      <title>  A\n paper </title><summary> useful result </summary>
      <author><name>Ada Lovelace</name></author></entry></feed>"""
    rows = LiveTransport(client=Client(Response(text=xml))).search(provider("arxiv"), "x", 1)
    assert rows[0]["arxiv"] == "2501.00001v2"
    assert rows[0]["title"] == "A paper" and rows[0]["year"] == 2025


def test_http_failure_is_not_an_empty_search_result():
    t = LiveTransport(client=Client(Response(text="rate limited", status=429)),
                      rate_limit_retries=0)
    with pytest.raises(ProviderUnavailable, match="HTTP 429"):
        t.search(provider("crossref"), "x", 1)


def test_http_429_gets_one_bounded_retry_then_succeeds():
    client = SequenceClient([
        Response(text="rate limited", status=429, headers={"retry-after": "2"}),
        Response({"results": []}),
    ])
    sleeps = []
    rows = LiveTransport(client=client, sleep=sleeps.append).search(
        provider("openalex"), "x", 1)
    assert rows == []
    assert sleeps == [2.0]
    assert len(client.calls) == 2


def test_http_429_retry_after_is_capped_and_still_fails_loud():
    client = SequenceClient([
        Response(text="rate limited", status=429, headers={"retry-after": "999"}),
        Response(text="still limited", status=429),
    ])
    sleeps = []
    transport = LiveTransport(client=client, max_retry_after=3, sleep=sleeps.append)
    with pytest.raises(ProviderUnavailable, match="HTTP 429"):
        transport.search(provider("openalex"), "x", 1)
    assert sleeps == [3.0]
    assert len(client.calls) == 2


def test_direct_egress_is_an_explicit_transport_choice(monkeypatch):
    import httpx

    calls = []

    def request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        return Response({"results": []})

    monkeypatch.setattr(httpx, "request", request)
    assert LiveTransport(trust_env=False).search(provider("openalex"), "x", 1) == []
    assert calls[0][2]["trust_env"] is False


def test_optional_semantic_scholar_key_does_not_disable_public_search(monkeypatch):
    monkeypatch.delenv("SEMANTIC_SCHOLAR_API_KEY", raising=False)
    semantic_scholar = next(p for p in DEFAULT_PROVIDERS
                            if p.name == "semantic_scholar")
    assert semantic_scholar.api_key_env == "SEMANTIC_SCHOLAR_API_KEY"
    assert semantic_scholar.capabilities.requires_key is False
    assert semantic_scholar.available() is True


def test_a_genuinely_required_key_still_makes_a_provider_unavailable(monkeypatch):
    monkeypatch.delenv("REQUIRED_TEST_KEY", raising=False)
    protected = ScholarlyProvider(
        "protected", "https://example.test",
        ScholarlyCapabilities(requires_key=True), api_key_env="REQUIRED_TEST_KEY")
    assert protected.available() is False


def test_unknown_live_provider_is_refused():
    with pytest.raises(ProviderUnavailable, match="no live transport adapter"):
        LiveTransport(client=Client(Response({}))).search(provider("mystery"), "x", 1)


def test_malformed_provider_json_is_a_provider_failure_not_an_internal_crash():
    class BadResponse(Response):
        def json(self):
            raise ValueError("not json")

    with pytest.raises(ProviderUnavailable, match="malformed JSON"):
        LiveTransport(client=Client(BadResponse())).search(provider("openalex"), "x", 1)


def test_openalex_null_result_row_is_a_provider_failure_not_attribute_error():
    transport = LiveTransport(client=Client(Response({"results": [None]})))
    with pytest.raises(ProviderUnavailable, match=r"openalex.*results\[0\].*object"):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"results": {}}, "results"),
    ({"results": [{"primary_location": []}]}, "primary_location"),
    ({"results": [{"authorships": {}}]}, "authorships"),
    ({"results": [{"authorships": [{"author": []}]}]}, "author"),
    ({"results": [{"abstract_inverted_index": {"word": {}}}]}, "word"),
])
def test_openalex_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"results": [{"id": []}]}, "id"),
    ({"results": [{"doi": {}}]}, "doi"),
    ({"results": [{"display_name": {}}]}, "display_name"),
    ({"results": [{"title": []}]}, "title"),
    ({"results": [{"publication_year": "2025"}]}, "publication_year"),
    ({"results": [{"cited_by_count": True}]}, "cited_by_count"),
    ({"results": [{"primary_location": {"landing_page_url": {}}}]},
     "landing_page_url"),
    ({"results": [{"primary_location": {"source": {"display_name": []}}}]},
     "source.display_name"),
])
def test_openalex_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"message": []}, "message"),
    ({"message": {"items": {}}}, "message.items"),
    ({"message": {"items": [{"title": "not-an-array"}]}}, "title"),
    ({"message": {"items": [{"author": [None]}]}}, "author\\[0\\]"),
    ({"message": {"items": [{"author": [{"given": {}}]}]}}, "given"),
    ({"message": {"items": [{"issued": {"date-parts": [None]}}]}}, "date-parts\\[0\\]"),
])
def test_crossref_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("crossref"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"message": {"items": [{"DOI": {}}]}}, "DOI"),
    ({"message": {"items": [{"URL": []}]}}, "URL"),
    ({"message": {"items": [{"abstract": {}}]}}, "abstract"),
    ({"message": {"items": [{"is-referenced-by-count": "4"}]}},
     "is-referenced-by-count"),
    ({"message": {"items": [{"issued": {"date-parts": [["2025"]]}}]}},
     "date-parts"),
])
def test_crossref_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("crossref"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"data": {}}, "data"),
    ({"data": [None]}, "data\\[0\\]"),
    ({"data": [{"externalIds": []}]}, "externalIds"),
    ({"data": [{"authors": {}}]}, "authors"),
    ({"data": [{"authors": [None]}]}, "authors\\[0\\]"),
    ({"data": [{"authors": [{"name": []}]}]}, "name"),
])
def test_semantic_scholar_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("semantic_scholar"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"data": [{"paperId": {}}]}, "paperId"),
    ({"data": [{"title": []}]}, "title"),
    ({"data": [{"year": "2025"}]}, "year"),
    ({"data": [{"venue": {}}]}, "venue"),
    ({"data": [{"abstract": []}]}, "abstract"),
    ({"data": [{"url": {}}]}, "url"),
    ({"data": [{"citationCount": False}]}, "citationCount"),
    ({"data": [{"externalIds": {"DOI": {}}}]}, "externalIds.DOI"),
    ({"data": [{"externalIds": {"ArXiv": []}}]}, "externalIds.ArXiv"),
])
def test_semantic_scholar_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("semantic_scholar"), "x", 1)


def test_arxiv_non_atom_xml_is_a_provider_failure_not_an_empty_result():
    transport = LiveTransport(client=Client(Response(text="<html><body>ok</body></html>")))
    with pytest.raises(ProviderUnavailable, match="not an Atom feed"):
        transport.search(provider("arxiv"), "x", 1)


def test_offline_runner_never_installs_live_http_without_explicit_fixtures(tmp_path):
    assert _scholarly_transport(offline=True, fixtures="") is None
    assert _scholarly_transport(offline=False, fixtures="").__class__ is LiveTransport
    assert _scholarly_transport(offline=True, fixtures=str(tmp_path)).__class__.__name__ == \
        "FixtureTransport"


@pytest.mark.parametrize("payload", [{"not": "an array"}, [None], ["row"]])
def test_malformed_fixture_shape_is_a_provider_failure(tmp_path, payload):
    p = provider("openalex")
    query = "attention"
    key = hashlib.sha256(f"{p.name}|{query}".encode()).hexdigest()[:16]
    fixture = tmp_path / p.name / f"{key}.json"
    fixture.parent.mkdir(parents=True)
    fixture.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ProviderUnavailable, match="JSON array of objects"):
        FixtureTransport(tmp_path).search(p, query, 25)


@pytest.mark.parametrize("limits", [
    {"max_calls": True}, {"max_calls": -1}, {"max_calls": "3"},
    {"max_usd": True}, {"max_usd": -0.1}, {"max_usd": float("nan")},
    {"max_usd": float("inf")},
])
def test_invalid_quota_limits_fail_closed_instead_of_becoming_unlimited(tmp_path, limits):
    quota = QuotaLedger(tmp_path / "quota.jsonl")
    with pytest.raises(ProviderUnavailable, match="invalid quota budget"):
        quota.budget("openalex", **limits)


@pytest.mark.parametrize("link_kind", ["symlink", "hardlink"])
def test_quota_ledger_refuses_linked_target_without_mutating_peer_or_state(
        tmp_path, link_kind):
    peer = tmp_path / "peer.log"
    peer.write_text("private peer\n", encoding="utf-8")
    target = tmp_path / "literature" / "quota_ledger.jsonl"
    target.parent.mkdir()
    if link_kind == "symlink":
        target.symlink_to(peer)
        expected = "safe regular file"
    else:
        target.hardlink_to(peer)
        expected = "hard links"
    quota = QuotaLedger(target)

    with pytest.raises(ProviderUnavailable, match=expected):
        quota.record("openalex", tokens_in=4)

    assert peer.read_text(encoding="utf-8") == "private peer\n"
    assert quota.state == {}


def test_quota_ledger_refuses_symlinked_parent(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    (project / "literature").symlink_to(outside, target_is_directory=True)
    quota = QuotaLedger(project / "literature" / "quota_ledger.jsonl")

    with pytest.raises(ProviderUnavailable, match="safe directory"):
        quota.record("crossref")

    assert not (outside / "quota_ledger.jsonl").exists()
    assert quota.state == {}


def test_failed_provider_attempt_consumes_max_calls_and_stops_retries(tmp_path):
    class FailingProvider:
        name = "always-fails"

        def __init__(self):
            self.calls = 0

        def search(self, query, limit):
            self.calls += 1
            raise ProviderUnavailable("HTTP 429: shared pool exhausted")

    class Store:
        def __init__(self):
            self.values = {
                "paper_model": {"title": "A sufficiently long paper title", "claims": [],
                                "methods": [], "datasets": [], "metrics": []},
                "provider_registry": {
                    "providers": [{"name": "always-fails", "available": True}]},
                "coverage_report": {"status": "UNKNOWN_COVERAGE",
                                    "named_blind_spots": ["no full-text search"]},
            }

        def read(self, skill, artifact_id):
            return self.values[artifact_id]

        def write(self, skill, artifact_id, payload):
            self.values[artifact_id] = payload

    failing = FailingProvider()
    quota = QuotaLedger(tmp_path / "quota.jsonl")
    quota.budget(failing.name, max_calls=1)
    ctx = SimpleNamespace(
        store=Store(), scholarly=[failing], quota=quota,
        external=lambda key, default=None: default,
    )

    result = LiteratureSearch().execute(ctx)

    assert failing.calls == 1, "a failed request must consume the one-call budget"
    assert quota.state[failing.name].calls == 1
    assert quota.state[failing.name].throttled is True
    assert result.detail["provider_errors"] >= 2
