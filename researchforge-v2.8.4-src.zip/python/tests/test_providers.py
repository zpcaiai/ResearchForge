"""Provider boundary tests: live search is real, normalized and fail-loud."""
from __future__ import annotations

import json

import pytest

from researchforge.errors import ProviderUnavailable
from researchforge.providers import (LiveTransport, ScholarlyCapabilities,
                                     ScholarlyProvider)
from researchforge.runner import _scholarly_transport


class Response:
    def __init__(self, payload=None, *, text="", status=200):
        self.payload, self.text, self.status_code = payload, text, status

    def json(self):
        return self.payload


class Client:
    def __init__(self, response):
        self.response, self.calls = response, []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return self.response


def provider(name, base="https://example.test"):
    return ScholarlyProvider(name, base, ScholarlyCapabilities())


def test_openalex_live_results_are_normalized():
    payload = {"results": [{"id": "https://openalex.org/W1", "doi": "https://doi.org/10.1/x",
                            "display_name": "A paper", "publication_year": 2025,
                            "abstract_inverted_index": {"hello": [0], "world": [1]},
                            "primary_location": {"landing_page_url": "https://paper",
                                                 "source": {"display_name": "Venue"}},
                            "authorships": [{"author": {"display_name": "Ada"}}],
                            "cited_by_count": 4}]}
    client = Client(Response(payload))
    rows = LiveTransport(client=client).search(provider("openalex"), "attention", 25)
    assert rows == [{"id": "https://openalex.org/W1", "doi": "10.1/x",
                     "title": "A paper", "year": 2025, "venue": "Venue",
                     "abstract": "hello world", "url": "https://paper",
                     "authors": ["Ada"], "cited_by_count": 4}]
    assert client.calls[0][2]["params"]["search"] == "attention"


def test_arxiv_atom_results_are_normalized():
    xml = """<feed xmlns="http://www.w3.org/2005/Atom"><entry>
      <id>http://arxiv.org/abs/2501.00001v2</id><published>2025-01-02T00:00:00Z</published>
      <title>  A\n paper </title><summary> useful result </summary>
      <author><name>Ada Lovelace</name></author></entry></feed>"""
    rows = LiveTransport(client=Client(Response(text=xml))).search(provider("arxiv"), "x", 1)
    assert rows[0]["arxiv"] == "2501.00001v2"
    assert rows[0]["title"] == "A paper" and rows[0]["year"] == 2025


def test_http_failure_is_not_an_empty_search_result():
    t = LiveTransport(client=Client(Response(text="rate limited", status=429)))
    with pytest.raises(ProviderUnavailable, match="HTTP 429"):
        t.search(provider("crossref"), "x", 1)


def test_unknown_live_provider_is_refused():
    with pytest.raises(ProviderUnavailable, match="no live transport adapter"):
        LiveTransport(client=Client(Response({}))).search(provider("mystery"), "x", 1)


def test_malformed_provider_json_is_a_provider_failure_not_an_internal_crash():
    class BadResponse(Response):
        def json(self):
            raise ValueError("not json")

    with pytest.raises(ProviderUnavailable, match="malformed JSON"):
        LiveTransport(client=Client(BadResponse())).search(provider("openalex"), "x", 1)


def test_openalex_null_result_row_is_a_provider_failure_not_attribute_error():
    transport = LiveTransport(client=Client(Response({"results": [None]})))
    with pytest.raises(ProviderUnavailable, match=r"openalex.*results\[0\].*object"):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"results": {}}, "results"),
    ({"results": [{"primary_location": []}]}, "primary_location"),
    ({"results": [{"authorships": {}}]}, "authorships"),
    ({"results": [{"authorships": [{"author": []}]}]}, "author"),
    ({"results": [{"abstract_inverted_index": {"word": {}}}]}, "word"),
])
def test_openalex_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"results": [{"id": []}]}, "id"),
    ({"results": [{"doi": {}}]}, "doi"),
    ({"results": [{"display_name": {}}]}, "display_name"),
    ({"results": [{"title": []}]}, "title"),
    ({"results": [{"publication_year": "2025"}]}, "publication_year"),
    ({"results": [{"cited_by_count": True}]}, "cited_by_count"),
    ({"results": [{"primary_location": {"landing_page_url": {}}}]},
     "landing_page_url"),
    ({"results": [{"primary_location": {"source": {"display_name": []}}}]},
     "source.display_name"),
])
def test_openalex_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("openalex"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"message": []}, "message"),
    ({"message": {"items": {}}}, "message.items"),
    ({"message": {"items": [{"title": "not-an-array"}]}}, "title"),
    ({"message": {"items": [{"author": [None]}]}}, "author\\[0\\]"),
    ({"message": {"items": [{"author": [{"given": {}}]}]}}, "given"),
    ({"message": {"items": [{"issued": {"date-parts": [None]}}]}}, "date-parts\\[0\\]"),
])
def test_crossref_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("crossref"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"message": {"items": [{"DOI": {}}]}}, "DOI"),
    ({"message": {"items": [{"URL": []}]}}, "URL"),
    ({"message": {"items": [{"abstract": {}}]}}, "abstract"),
    ({"message": {"items": [{"is-referenced-by-count": "4"}]}},
     "is-referenced-by-count"),
    ({"message": {"items": [{"issued": {"date-parts": [["2025"]]}}]}},
     "date-parts"),
])
def test_crossref_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("crossref"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"data": {}}, "data"),
    ({"data": [None]}, "data\\[0\\]"),
    ({"data": [{"externalIds": []}]}, "externalIds"),
    ({"data": [{"authors": {}}]}, "authors"),
    ({"data": [{"authors": [None]}]}, "authors\\[0\\]"),
    ({"data": [{"authors": [{"name": []}]}]}, "name"),
])
def test_semantic_scholar_malformed_nested_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("semantic_scholar"), "x", 1)


@pytest.mark.parametrize(("payload", "field"), [
    ({"data": [{"paperId": {}}]}, "paperId"),
    ({"data": [{"title": []}]}, "title"),
    ({"data": [{"year": "2025"}]}, "year"),
    ({"data": [{"venue": {}}]}, "venue"),
    ({"data": [{"abstract": []}]}, "abstract"),
    ({"data": [{"url": {}}]}, "url"),
    ({"data": [{"citationCount": False}]}, "citationCount"),
    ({"data": [{"externalIds": {"DOI": {}}}]}, "externalIds.DOI"),
    ({"data": [{"externalIds": {"ArXiv": []}}]}, "externalIds.ArXiv"),
])
def test_semantic_scholar_malformed_scalar_shapes_are_provider_failures(payload, field):
    transport = LiveTransport(client=Client(Response(payload)))
    with pytest.raises(ProviderUnavailable, match=field):
        transport.search(provider("semantic_scholar"), "x", 1)


def test_arxiv_non_atom_xml_is_a_provider_failure_not_an_empty_result():
    transport = LiveTransport(client=Client(Response(text="<html><body>ok</body></html>")))
    with pytest.raises(ProviderUnavailable, match="not an Atom feed"):
        transport.search(provider("arxiv"), "x", 1)


def test_offline_runner_never_installs_live_http_without_explicit_fixtures(tmp_path):
    assert _scholarly_transport(offline=True, fixtures="") is None
    assert _scholarly_transport(offline=False, fixtures="").__class__ is LiveTransport
    assert _scholarly_transport(offline=True, fixtures=str(tmp_path)).__class__.__name__ == \
        "FixtureTransport"
