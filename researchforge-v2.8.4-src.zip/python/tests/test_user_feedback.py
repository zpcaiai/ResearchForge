from types import SimpleNamespace

import pytest

from researchforge.errors import GateBlocked
from researchforge.skills.innovation import UserFeedbackGate


class _Store:
    def __init__(self):
        self.writes = {}
        self.log = []

    def read(self, _skill, artifact, **_kwargs):
        if artifact == "ranked_ideas":
            return {"ranking": [
                {"idea_id": "I-001", "title": "one"},
                {"idea_id": "I-002", "title": "two"},
            ]}
        if artifact == "comparison_mode":
            return {"mode": "CM_NONE", "admissible_idea_modes": ["diagnostic"]}
        raise AssertionError(artifact)

    def write(self, _skill, artifact, payload):
        self.writes[artifact] = payload

    def append_jsonl(self, _skill, artifact, rows):
        self.log.extend((artifact, row) for row in rows)


def _ctx(selected):
    store = _Store()
    return SimpleNamespace(
        mode="guided", run_id="run-test", store=store,
        external=lambda key, default=None: {"selected": selected, "note": "operator decision"}
        if key == "user_feedback" else default,
    )


def test_reject_all_is_recorded_instead_of_becoming_an_unknown_idea():
    ctx = _ctx(["reject"])
    result = UserFeedbackGate().execute(ctx)
    assert result.detail["selected"] == []
    assert ctx.store.writes["selected_direction"]["selected_idea_ids"] == []
    assert ctx.store.writes["selected_direction"]["rejected_but_retained"] == ["I-001", "I-002"]


@pytest.mark.parametrize("selected", [["I-001", "I-001"], ["reject", "I-001"], "I-001"])
def test_malformed_or_ambiguous_selections_fail_closed(selected):
    with pytest.raises(GateBlocked):
        UserFeedbackGate().execute(_ctx(selected))
