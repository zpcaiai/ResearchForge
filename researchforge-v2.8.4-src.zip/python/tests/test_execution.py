"""Behavioural tests for the execution stage — mostly tests of what it refuses.

The interesting assertions here are negative ones. Anyone can check that a runner
writes a ledger; the thing that matters is that when the runner cannot honestly run
anything, the ledger contains no number, the best candidate is null, and the reason
is named. Those are the tests that would fail if someone "helpfully" made the
pipeline produce plausible output on a machine with no sandbox.
"""
from __future__ import annotations

import json
import hashlib
import subprocess
import sys
from pathlib import Path

import pytest

from researchforge import skills as _skills  # noqa: F401  registers implementations
from researchforge.artifacts import ArtifactStore
from researchforge.errors import GateBlocked
from researchforge.provenance import ProvenanceLog
from researchforge.skill import Context, get

ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = ROOT / "schemas"

SPEC = {
    "experiment_id": "E-001",
    "hypothesis": "the candidate beats the baseline on accuracy",
    "baseline": {"name": "baseline-a"},
    "candidate": {"name": "candidate-a"},
    "datasets": ["synthetic-tiny"],
    "metrics": [{"name": "accuracy", "direction": "maximize"}],
    "seeds": [1, 2],
    "invalid_conditions": [{"metric": "accuracy", "op": ">", "value": 0.999}],
}
DOCKER_IMAGE_ID = "sha256:" + "a" * 64
CPU_GPU_EVIDENCE = {"requested": False, "validated": False, "runtime": "none",
                    "selector": "none", "device_count": 0, "devices": []}
CUDA_GPU_EVIDENCE = {
    "requested": True, "validated": True, "runtime": "nvidia", "selector": "all",
    "device_count": 1,
    "devices": [{"index": 0, "name": "Test NVIDIA GPU", "capability": "8.0"}],
    "torch_version": "2.8.0", "cuda_runtime": "12.8",
    "command_contract": "docker --gpus all/torch.cuda/restrictive-runtime",
}
PROVISIONED_CUDA_GPU_EVIDENCE = {**CUDA_GPU_EVIDENCE, "request_run_id": "r1"}
#: The arms SPEC declares, in run order. Every count below is arms x seeds.
ARMS = ["baseline", "candidate"]


# ---------------------------------------------------------------------------
def make_ctx(project: Path, run_id: str = "r1", config: dict | None = None) -> Context:
    prov = ProvenanceLog(project)
    store = ArtifactStore(project, SCHEMAS, run_id, prov)
    return Context(project=project, run_id=run_id, mode="auto", store=store, prov=prov,
                   quota=None, model=None, scholarly=[], config=config or {})


def seed_project(project: Path, *, backend: str = "disabled", evaluator: bool = False,
                 spec: dict | None = None, docker_path: Path | None = None,
                 gpu: bool = False) -> Path:
    """Stand in for the upstream skills that this batch does not implement."""
    ctx = make_ctx(project)
    s = ctx.store
    environment_lock = "pytest==8.0.0\n"
    limits = {"cpus": 2, "memory": "2g", "network": "none", "pids": 256,
              "timeout_seconds": 60}
    if backend == "docker":
        docker_path = docker_path or Path(sys.executable)
        docker_real = docker_path.resolve()
        docker_hash = hashlib.sha256(docker_real.read_bytes()).hexdigest()
        manifest = {
            "profile": "no-network-untrusted-code", "isolation": "container",
            "execution_backend": "docker", "untrusted_code_execution_allowed": True,
            "trusted_host_execution_allowed": False,
            "network_isolation_enforced": True, "container_image_id": DOCKER_IMAGE_ID,
            "gpu_allocation": PROVISIONED_CUDA_GPU_EVIDENCE if gpu else CPU_GPU_EVIDENCE,
            "host": {"platform": "test", "python": sys.version.split()[0]}, "warnings": [],
        }
        config = {
            "engine": "docker", "execution_backend": "docker",
            "image": "python:3.11-slim", "image_id": DOCKER_IMAGE_ID,
            "pull_policy": "never", "read_only_rootfs": True, "limits": limits,
            "mounts": {"code": "ro", "run_tmp": "tmpfs",
                       "hidden_evaluator": "not_mounted"},
            "gpu_allocation": PROVISIONED_CUDA_GPU_EVIDENCE if gpu else CPU_GPU_EVIDENCE,
            "validation": {"validated": True, "daemon_reachable": True,
                           "image_present": True, "image_id": DOCKER_IMAGE_ID,
                           "docker_realpath": str(docker_real),
                           "docker_sha256": docker_hash,
                           "context": "local-test",
                           "endpoint": "unix:///tmp/docker-test.sock",
                           "daemon_id": "daemon-test", "daemon_os": "linux",
                           "gpu": PROVISIONED_CUDA_GPU_EVIDENCE if gpu else CPU_GPU_EVIDENCE,
                           "smoke": {"validated": True}},
            "environment_lock_measurement": {
                "source_backend": "docker", "measured": True,
                "container_image_id": DOCKER_IMAGE_ID,
                "daemon_id": "daemon-test",
                "sha256": hashlib.sha256(environment_lock.encode()).hexdigest()},
        }
    elif backend == "trusted-host":
        manifest = {
            "profile": "trusted-host-code", "isolation": "none",
            "execution_backend": "trusted-host", "untrusted_code_execution_allowed": False,
            "trusted_host_execution_allowed": True,
            "operator_authorization_run_id": "r1",
            "network_isolation_enforced": False,
            "host": {"platform": "test", "python": sys.version.split()[0]},
            "warnings": ["operator asserted code trust"],
        }
        config = {
            "engine": "host", "execution_backend": "trusted-host",
            "code_trust": "user-asserted",
            "operator_authorization": {"literal": True, "run_id": "r1"},
            "limits": {**limits, "network": "host-unrestricted"},
            "mounts": {"project": "host-access", "hidden_evaluator": "not-isolated"},
            "validation": {"validated": False, "reason": "not a container"},
            "environment_lock_measurement": {
                "source_backend": "trusted-host", "measured": True,
                "python_executable": str(Path(sys.executable).resolve()),
                "sha256": hashlib.sha256(environment_lock.encode()).hexdigest()},
        }
    else:
        manifest = {
            "profile": "no-network-untrusted-code", "isolation": "none",
            "execution_backend": "disabled", "untrusted_code_execution_allowed": False,
            "trusted_host_execution_allowed": False,
            "network_isolation_enforced": False,
            "host": {"platform": "test", "python": sys.version.split()[0]},
            "warnings": ["no validated container engine"],
        }
        config = {"engine": "docker", "execution_backend": "disabled", "limits": limits,
                  "mounts": {"code": "ro", "hidden_evaluator": "not_mounted"},
                  "validation": {"validated": False, "reason": "test fixture"}}
    s.write("sandbox-provisioner", "sandbox_manifest", manifest)
    s.write("sandbox-provisioner", "sandbox_container_config", config)
    s.write("sandbox-provisioner", "environment_lock", environment_lock)
    s.write("research-blueprint-compiler", "research_blueprint", {
        "blueprint_id": "B-1", "selected_idea_id": "I-001",
        "hypothesis": SPEC["hypothesis"], "acceptance_criteria": ["accuracy improves"],
        "stages": [{"id": "run", "depends_on": []}], "budgets": {"gpu_hours": 0},
    })
    s.write("research-blueprint-compiler", "acceptance_criteria", "# Acceptance\n- accuracy improves\n")
    s.write("research-blueprint-compiler", "blueprint_dag", {"stages": [{"id": "run"}]})
    s.write("result-reproducer", "baseline_assets", {"repos": [], "checkpoints": [], "datasets": []})
    if evaluator:
        s.write("evaluator-builder", "evaluator_code", "def evaluate(pred, gold):\n    return {}\n")
        s.write("evaluator-builder", "evaluator_spec", "# Evaluator\naccuracy over the tiny split\n")
    (project / "experiments").mkdir(parents=True, exist_ok=True)
    (project / "experiments" / "E-001.yaml").write_text(
        json.dumps(spec or SPEC, indent=1), encoding="utf-8")
    return project


def run_skill(project: Path, name: str, run_id: str = "r1", config: dict | None = None):
    if config is None and name == "experiment-runner":
        config = {"trusted_host_authorized": True}
    return get(name)(make_ctx(project, run_id, config))


def ledger(project: Path) -> list[dict]:
    p = project / "experiment_ledger.jsonl"
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


@pytest.fixture
def project(tmp_path):
    return seed_project(tmp_path)


# ===========================================================================
#  the central refusal: no isolation means no numbers
# ===========================================================================
def test_without_isolation_nothing_runs_and_no_metric_is_invented(project):
    run_skill(project, "codebase-scaffolder")
    res = run_skill(project, "experiment-runner")

    rows = ledger(project)
    # arms x seeds. The runner used to invoke the entry point with no --arm and so
    # measured the candidate twice while calling one of them a baseline; a spec that
    # declares two conditions has to produce two conditions' worth of rows.
    assert len(rows) == len(ARMS) * len(SPEC["seeds"]), \
        "every planned run of every declared arm must be recorded, not just the run ones"
    assert {r["arm"] for r in rows} == set(ARMS)
    for r in rows:
        assert r["status"] == "NOT_RUN"
        assert r["metrics"] == {}, "a NOT_RUN entry with a metric is the failure mode this prevents"
        assert r["not_run_reason"] == "NO_ISOLATION"
        assert r["provenance"]["executed"] is False
        assert "not a security boundary" in r["provenance"]["reason_detail"]
    assert any("untrusted_code_execution_allowed=False" in w for w in res.warnings)
    assert res.detail["executed"] == 0 and res.detail["measured_runs"] == 0


def test_without_isolation_no_number_appears_anywhere_in_the_ledger(project):
    run_skill(project, "codebase-scaffolder")
    run_skill(project, "experiment-runner")
    for r in ledger(project):
        assert not r["metrics"]
        # nothing shaped like a score may hide in the entry either
        assert "accuracy" not in json.dumps(r["metrics"])


def test_nothing_measured_means_no_best_candidate_and_no_ranking(project):
    run_skill(project, "codebase-scaffolder")
    run_skill(project, "experiment-runner")

    best = json.loads((project / "experiments/best_candidate.json").read_text())
    assert best["selected"] is None
    assert "no run produced a measurement" in best["reason"]
    assert "NO_ISOLATION" in best["not_run_reasons"]

    ranked = json.loads((project / "experiments/ranked_branches.json").read_text())
    assert ranked["ranking_possible"] is False
    assert all(b["rank"] is None for b in ranked["branches"])


def test_terminal_codebase_blocks_execution_even_with_isolation(tmp_path):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    # simulate debug-and-repair having given up
    st = json.loads((tmp_path / "experiments/terminal_status.json").read_text())
    st["terminal"] = True
    st["stop_reason"] = "repair_attempt_cap_reached"
    (tmp_path / "experiments/terminal_status.json").write_text(json.dumps(st))

    run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)
    assert rows and all(r["status"] == "NOT_RUN" for r in rows)
    assert all(r["not_run_reason"] == "TERMINAL_CODE_DEFECT" for r in rows)
    assert all(r["metrics"] == {} for r in rows)


def test_missing_evaluator_means_nothing_is_scored(tmp_path):
    seed_project(tmp_path, backend="trusted-host", evaluator=False)
    run_skill(tmp_path, "codebase-scaffolder")
    run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)
    assert all(r["not_run_reason"] == "EVALUATOR_MISSING" and r["metrics"] == {} for r in rows)


# ===========================================================================
#  the ledger is append-only
# ===========================================================================
def test_ledger_is_append_only_across_runs(project):
    run_skill(project, "codebase-scaffolder")
    run_skill(project, "experiment-runner", run_id="run-a")
    p = project / "experiment_ledger.jsonl"
    first = p.read_bytes()
    n_first = len(ledger(project))

    run_skill(project, "experiment-runner", run_id="run-b")
    second = p.read_bytes()

    assert second.startswith(first), "an earlier ledger entry was rewritten or reordered"
    assert len(ledger(project)) == 2 * n_first
    assert {r["run_id"] for r in ledger(project)} == {"run-a", "run-b"}


def test_ledger_entries_validate_against_the_schema(project):
    from jsonschema import Draft202012Validator

    run_skill(project, "codebase-scaffolder")
    run_skill(project, "experiment-runner")
    v = Draft202012Validator(json.loads((SCHEMAS / "ExperimentResult.schema.json").read_text()))
    for r in ledger(project):
        v.validate(r)


# ===========================================================================
#  provenance is consolidated, not clobbered
# ===========================================================================
def test_provenance_log_is_appended_not_overwritten(project):
    run_skill(project, "codebase-scaffolder")
    before = (project / "provenance.jsonl").read_bytes()
    res = run_skill(project, "experiment-runner")
    after = (project / "provenance.jsonl").read_bytes()

    assert after.startswith(before), "the runtime provenance log was rewritten"
    assert res.detail["provenance_log"] == "appended_summary_to_runtime_log"
    # the merged file must still parse as the runtime's own event stream
    events = ProvenanceLog(project).read()
    summaries = [e for e in events if e.kind == "provenance_summary"]
    assert len(summaries) == 1
    assert summaries[0].detail["ledger_statuses"]["NOT_RUN"] == len(ARMS) * len(SPEC["seeds"])


def test_artifact_manifest_hashes_real_files_and_names_lineage(project):
    run_skill(project, "codebase-scaffolder")
    run_skill(project, "experiment-runner")
    man = json.loads((project / "artifact_manifest.json").read_text())
    by_path = {a["path"]: a for a in man["artifacts"]}
    assert "experiment_ledger.jsonl" in by_path
    assert by_path["experiment_ledger.jsonl"]["artifact_id"] == "experiment_ledger"
    assert all(len(a["sha256"]) == 64 for a in man["artifacts"])
    # the generated code is on disk and hashed, not merely described
    assert any(p.startswith("code/e_001/") for p in by_path)
    assert "code_worktree" in by_path["experiment_ledger.jsonl"]["parents"]
    assert "artifact_manifest.json" not in by_path
    assert "provenance.jsonl" not in by_path
    assert not any(path.startswith("release/") for path in by_path)


# ===========================================================================
#  the scaffolder generates real code
# ===========================================================================
def test_scaffolder_writes_real_modules_and_tests(project):
    res = run_skill(project, "codebase-scaffolder")
    entry = project / "code/e_001/experiment.py"
    assert entry.exists() and (project / "code/tests/test_e_001.py").exists()
    assert (project / "code/rf_runtime.py").exists()
    wt = json.loads((project / "code/_manifest.json").read_text())
    assert wt["entry_points"]["E-001"] == "code/e_001/experiment.py"
    assert wt["executed_by_this_skill"] is False
    assert "code/e_001/experiment.py" in (project / "code/implementation_plan.md").read_text()
    assert res.detail["files"] >= 5


def test_generated_tests_pass(project):
    run_skill(project, "codebase-scaffolder")
    r = subprocess.run([sys.executable, "-m", "pytest", "code/tests", "-q", "-p", "no:cacheprovider"],
                       cwd=project, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


def test_generated_entry_point_refuses_to_invent_a_metric(project):
    run_skill(project, "codebase-scaffolder")
    r = subprocess.run([sys.executable, "code/e_001/experiment.py", "--seed", "1"],
                       cwd=project, capture_output=True, text=True)
    assert r.returncode == 3
    payload = json.loads(r.stdout.split("RF_RESULT ", 1)[1])
    assert payload["status"] == "NOT_IMPLEMENTED" and payload["metrics"] == {}
    assert "refuses to synthesize" in payload["error"]


# ===========================================================================
#  repair is capped
# ===========================================================================
def _append_failure(project: Path, run_id: str, cls: str = "SYNTAX_ERROR") -> None:
    ctx = make_ctx(project, run_id)
    ctx.store.append_jsonl("experiment-runner", "experiment_ledger", [{
        "run_id": run_id, "experiment_id": "E-001", "status": "FAILED",
        "metrics": {}, "artifacts": [], "failure_class": cls,
        "provenance": {"skill": "experiment-runner", "executed": True},
    }])


def test_repair_attempts_are_capped_across_invocations(project):
    cap = get("codebase-scaffolder").REPAIR_ATTEMPT_CAP
    for i in range(cap + 4):
        _append_failure(project, f"run-{i}")
        run_skill(project, "codebase-scaffolder", run_id=f"run-{i}")

    commits = [json.loads(l) for l
               in (project / "code/.git/repair_commits").read_text().splitlines() if l.strip()]
    assert len(commits) == cap, f"repair loop ran {len(commits)} times against a cap of {cap}"
    assert [c["attempt"] for c in commits] == list(range(1, cap + 1))
    assert all(c["cap"] == cap for c in commits)

    st = json.loads((project / "experiments/terminal_status.json").read_text())
    assert st["terminal"] is True
    assert st["stop_reason"] == "repair_attempt_cap_reached"
    assert st["repair_attempt_cap"] == cap
    assert st["experiments_at_cap"] == ["E-001"]

    diag = json.loads((project / "experiments/failure_diagnosis.json").read_text())
    d = next(d for d in diag["diagnoses"] if d["experiment_id"] == "E-001")
    assert d["terminal"] is True and d["next_action_owner"] == "human"


def test_unrepairable_failures_are_terminal_on_the_first_look(project):
    _append_failure(project, "run-0", cls="METHOD_NOT_IMPLEMENTED")
    run_skill(project, "codebase-scaffolder")
    assert (project / "code/.git/repair_commits").read_text().strip() == "", \
        "a failure codegen cannot fix must not consume a repair attempt"
    st = json.loads((project / "experiments/terminal_status.json").read_text())
    assert st["terminal"] is True and st["stop_reason"] == "terminal_classification"
    d = json.loads((project / "experiments/failure_diagnosis.json").read_text())["diagnoses"][0]
    assert "must not invent the algorithm" in d["root_cause"]


def test_a_terminal_run_stage_does_not_reset_the_repair_counter(project):
    """A cap that resets on re-invocation is a slower unbounded loop, not a cap."""
    cap = get("codebase-scaffolder").REPAIR_ATTEMPT_CAP
    for i in range(cap):
        _append_failure(project, f"a-{i}")
        run_skill(project, "codebase-scaffolder", run_id=f"a-{i}")
    n = len((project / "code/.git/repair_commits").read_text().strip().splitlines())
    _append_failure(project, "b-0")
    run_skill(project, "codebase-scaffolder", run_id="b-0")
    assert len((project / "code/.git/repair_commits").read_text().strip().splitlines()) == n == cap


# ===========================================================================
#  explicit trusted-host mode: useful for trusted fixtures, never called isolation
# ===========================================================================
IMPL = '''
def candidate(seed, config):
    return {"accuracy": 0.31415}


def baseline(seed, config):
    return {"accuracy": 0.2}
'''


def test_explicit_trusted_host_metric_is_the_one_the_code_returned(tmp_path):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")

    res = run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)
    assert len(rows) == 4 and all(r["status"] == "COMPLETED" for r in rows), rows
    # each arm reports its own number, and they are different numbers
    assert {r["metrics"]["accuracy"] for r in rows if r["arm"] == "candidate"} == {0.31415}
    assert {r["metrics"]["accuracy"] for r in rows if r["arm"] == "baseline"} == {0.2}
    assert all(r["provenance"]["executed"] is True for r in rows)
    assert all(r["provenance"]["exit_code"] == 0 for r in rows)
    assert all(r["provenance"]["limits"]["memory"] == "2g" for r in rows)
    assert all(r["provenance"]["timeout_seconds"] for r in rows)
    assert all(r["provenance"]["invalid_conditions_runtime"] == {
        "checked": True, "fired": [], "unchecked": [], "error": None,
    } for r in rows)
    assert all(r["provenance"]["sandbox"]["execution_backend"] == "trusted-host" for r in rows)
    assert all(r["provenance"]["sandbox"]["isolation"] == "none" for r in rows)
    assert all(not r["provenance"]["sandbox"]["network_isolation_enforced"] for r in rows)
    assert all("not enforced" in r["provenance"]["sandbox"]["network_enforced_by"] for r in rows)
    assert res.detail["measured_runs"] == 4

    best = json.loads((tmp_path / "experiments/best_candidate.json").read_text())
    # the branch is scored by its candidate arm, not by the pool. A pooled mean here
    # would be 0.257 — the average of the method and the thing it is compared to,
    # which describes no condition that was run.
    assert best["selected"] == "E-001" and best["value"] == pytest.approx(0.31415)
    assert best["significance_tested"] is False

    ranked = json.loads((tmp_path / "experiments/ranked_branches.json").read_text())
    branch = ranked["branches"][0]
    assert branch["scored_arm"] == "candidate"
    assert branch["arms"]["baseline"]["accuracy"]["mean"] == pytest.approx(0.2)
    contrast = branch["contrasts"]["candidate_vs_baseline"]["metrics"]["accuracy"]
    assert contrast["difference"] == pytest.approx(0.31415 - 0.2)
    assert branch["contrasts"]["candidate_vs_baseline"]["significance_tested"] is False


def test_a_run_returning_an_undeclared_metric_records_no_metric(tmp_path):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(
        "def candidate(seed, config):\n    return {'made_up_score': 0.99}\n", encoding="utf-8")

    run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)
    assert all(r["status"] == "FAILED" and r["metrics"] == {} for r in rows)
    cand = [r for r in rows if r["arm"] == "candidate"]
    assert cand and all("not declared" in r.get("error", "") for r in cand)
    # the baseline arm has no impl at all, and says so rather than borrowing one
    base = [r for r in rows if r["arm"] == "baseline"]
    assert base and all(r["failure_class"] == "METHOD_NOT_IMPLEMENTED" for r in base)


def test_metrics_without_a_declared_direction_are_not_ranked(tmp_path):
    spec = dict(SPEC, metrics=["accuracy"])   # a bare name says nothing about better
    seed_project(tmp_path, backend="trusted-host", evaluator=True, spec=spec)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")

    res = run_skill(tmp_path, "experiment-runner")
    ranked = json.loads((tmp_path / "experiments/ranked_branches.json").read_text())
    assert ranked["ranking_possible"] is False
    assert "no metric declares a direction" in ranked["reason"]
    best = json.loads((tmp_path / "experiments/best_candidate.json").read_text())
    assert best["selected"] is None
    assert any("refusing to rank" in w for w in res.warnings)


def test_a_run_that_trips_an_invalid_condition_is_not_a_result(tmp_path):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(
        "def candidate(seed, config):\n    return {'accuracy': 1.0}\n", encoding="utf-8")

    run_skill(tmp_path, "experiment-runner")
    rows = [r for r in ledger(tmp_path) if r["arm"] == "candidate"]
    assert rows and all(r["status"] == "INVALID" and r["metrics"] == {} for r in rows)
    assert all(r["provenance"]["invalid_conditions_runtime"]["checked"] is True
               and r["provenance"]["invalid_conditions_runtime"]["fired"] for r in rows)
    best = json.loads((tmp_path / "experiments/best_candidate.json").read_text())
    assert best["selected"] is None


# ===========================================================================
#  gates
# ===========================================================================
def test_runner_without_a_sandbox_manifest_is_a_gate_not_a_guess(tmp_path):
    seed_project(tmp_path)
    (tmp_path / "experiments/sandbox_manifest.json").unlink()
    with pytest.raises(GateBlocked) as e:
        run_skill(tmp_path, "experiment-runner")
    assert e.value.gate == "sandbox_unknown"
    assert "must never" in e.value.reason
    assert not (tmp_path / "experiment_ledger.jsonl").exists()


def test_no_specs_blocks_both_skills(tmp_path):
    seed_project(tmp_path)
    (tmp_path / "experiments/E-001.yaml").unlink()
    for skill in ("codebase-scaffolder", "experiment-runner"):
        with pytest.raises(GateBlocked) as e:
            run_skill(tmp_path, skill)
        assert e.value.gate == "no_experiment_specs" and e.value.remediation


def test_the_ablation_plan_is_not_mistaken_for_an_experiment(project):
    (project / "experiments/ablation_plan.yaml").write_text(
        json.dumps({"ablations": [{"name": "drop-x"}]}), encoding="utf-8")
    run_skill(project, "codebase-scaffolder")
    res = run_skill(project, "experiment-runner")
    assert res.detail["planned_runs"] == len(ARMS) * len(SPEC["seeds"])
    assert {r["experiment_id"] for r in ledger(project)} == {"E-001"}


def test_specs_written_as_one_globbed_file_are_all_found(tmp_path):
    """research-blueprint-compiler writes the whole list to the literal `*.yaml` path.

    The glob in the contract is a path pattern, not a promise about file layout, so
    both layouts have to resolve to the same set of planned runs.
    """
    seed_project(tmp_path)
    (tmp_path / "experiments/E-001.yaml").unlink()
    second = dict(SPEC, experiment_id="E-002", seeds=[7])
    (tmp_path / "experiments" / "*.yaml").write_text(json.dumps([SPEC, second]), encoding="utf-8")

    run_skill(tmp_path, "codebase-scaffolder")
    res = run_skill(tmp_path, "experiment-runner")
    assert res.detail["planned_runs"] == len(ARMS) * 3
    assert {r["experiment_id"] for r in ledger(tmp_path)} == {"E-001", "E-002"}
    assert all(r["status"] == "NOT_RUN" and r["metrics"] == {} for r in ledger(tmp_path))
    assert (tmp_path / "code/e_002/experiment.py").exists()


def test_unspecified_direction_from_the_real_compiler_blocks_ranking(tmp_path):
    """The blueprint compiler emits `direction: "unspecified"` on purpose."""
    spec = dict(SPEC, metrics=[{"name": "accuracy", "direction": "unspecified"}])
    seed_project(tmp_path, backend="trusted-host", evaluator=True, spec=spec)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")
    run_skill(tmp_path, "experiment-runner")
    assert json.loads((tmp_path / "experiments/ranked_branches.json").read_text())["ranking_possible"] is False


# ======================================================================
# v2.8.2: the runner's boundaries
# ======================================================================
def test_a_tie_on_a_minimize_metric_is_not_better():
    """`"better" if (delta > 0) == (d == "maximize")` read `False == False` as better."""
    from researchforge.skills.execution import ExperimentRunner

    arms = {"candidate": {"loss": {"mean": 0.5, "n": 3, "min": 0.5, "max": 0.5}},
            "baseline": {"loss": {"mean": 0.5, "n": 3, "min": 0.5, "max": 0.5}},
            "sota": {"loss": {"mean": 0.4, "n": 3, "min": 0.4, "max": 0.4}}}
    c = ExperimentRunner()._contrasts(arms, {"loss": "minimize"})
    assert c["candidate_vs_baseline"]["metrics"]["loss"]["candidate_is"] == "identical"
    assert c["candidate_vs_sota"]["metrics"]["loss"]["candidate_is"] == "worse"


def test_an_arm_written_as_a_scalar_is_reported_not_dropped():
    from researchforge.skills.execution import _malformed_arms, _spec_arms

    spec = {"experiment_id": "E-001", "baseline": "resnet50",
            "candidate": {"description": "ours"}}
    assert _malformed_arms(spec) == ["baseline"]
    assert _spec_arms(spec) == ["candidate"]


def test_a_nan_metric_does_not_pass_the_runner_gate_as_a_measurement():
    """NaN is a float, so `isinstance(v, float)` admitted it; the analysis plane
    then dropped it with `math.isfinite` and the two artifacts disagreed about
    how many measurements existed."""
    import math

    declared = {"primary"}
    for value in (float("nan"), float("inf"), float("-inf")):
        bad = [k for k, v in {"primary": value}.items()
               if k not in declared or isinstance(v, bool) or not isinstance(v, (int, float))
               or not math.isfinite(float(v))]
        assert bad == ["primary"], value


# ======================================================================
# v2.8.4: the sandbox label and the execution backend must be the same fact
# ======================================================================
def test_gpu_smoke_proves_typed_cuda_devices_under_restrictive_flags(monkeypatch):
    from researchforge.skills import intake

    seen = []
    payload = {"device_count": 1,
               "devices": [{"index": 0, "name": "Test NVIDIA GPU", "capability": "8.0"}],
               "torch_version": "2.8.0", "cuda_runtime": "12.8"}

    def fake_run(cmd, **kwargs):
        seen.append(cmd)
        return subprocess.CompletedProcess(
            cmd, 0, ("RF_GPU_SMOKE " + json.dumps(payload)).encode(), b"")

    monkeypatch.setattr(intake.subprocess, "run", fake_run)
    evidence, reason = intake._smoke_validate_gpu("/usr/bin/docker", DOCKER_IMAGE_ID)
    assert reason is None and evidence == CUDA_GPU_EVIDENCE
    command = seen[0]
    assert command[command.index("--gpus") + 1] == "all"
    assert command[command.index("--network") + 1] == "none"
    assert "--read-only" in command and command[command.index("--user") + 1] == "65534:65534"
    assert command[command.index("--entrypoint") + 1] == "python"
    assert DOCKER_IMAGE_ID in command


def test_docker_on_path_without_a_daemon_does_not_enable_untrusted_code(tmp_path, monkeypatch):
    from researchforge.skills import intake

    monkeypatch.setattr(intake.shutil, "which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr(intake.platform, "platform", lambda: "test-platform")

    def fake_run(cmd, **kwargs):
        if cmd[:2] == ["/usr/bin/docker", "info"]:
            return subprocess.CompletedProcess(cmd, 1, "", "Cannot connect to the Docker daemon")
        if cmd[:3] == [sys.executable, "-m", "pip"]:
            return subprocess.CompletedProcess(cmd, 0, "pytest==9.0.0\n", "")
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(intake.subprocess, "run", fake_run)
    res = get("sandbox-provisioner")(make_ctx(tmp_path))
    manifest = json.loads((tmp_path / "experiments/sandbox_manifest.json").read_text())
    config = json.loads((tmp_path / "experiments/container.yaml").read_text())

    assert manifest["untrusted_code_execution_allowed"] is False
    assert manifest["execution_backend"] == "disabled"
    assert manifest["isolation"] == "none"
    assert config["image"] == "python:3.11-slim"
    assert config["validation"]["daemon_reachable"] is False
    assert any("will not fall back" in w for w in res.warnings)


def test_provisioner_records_a_custom_immutable_local_image_without_pulling(tmp_path, monkeypatch):
    from researchforge.skills import intake

    calls = []
    requested = "registry.example.test/researchforge/cuda-runtime:12.4"
    monkeypatch.setattr(intake.shutil, "which", lambda name: "/usr/bin/docker")
    monkeypatch.setattr(intake.platform, "platform", lambda: "test-platform")
    identity = {"docker_realpath": "/usr/bin/docker", "docker_sha256": "b" * 64,
                "context": "local-test", "endpoint": "unix:///tmp/docker.sock",
                "daemon_id": "daemon-test", "server_version": "27.0.0",
                "daemon_os": "linux"}
    monkeypatch.setattr(intake, "_local_docker_identity", lambda docker: (identity, None))
    monkeypatch.setattr(
        intake, "_smoke_validate_image",
        lambda docker, image_id: ({"validated": True, "python_entrypoint": True,
                                   "nonroot_uid": 65534}, None))
    monkeypatch.setattr(
        intake, "_smoke_validate_gpu",
        lambda docker, image_id: (CUDA_GPU_EVIDENCE, None))
    monkeypatch.setattr(
        intake, "_capture_container_environment",
        lambda docker, image_id, daemon_id: (
            "pip==25.0\n",
            {"source_backend": "docker", "container_image_id": image_id,
             "daemon_id": daemon_id, "measured": True,
             "sha256": hashlib.sha256(b"pip==25.0\n").hexdigest()}, None))

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        if cmd[:3] == ["/usr/bin/docker", "image", "inspect"]:
            assert cmd[-1] == requested
            return subprocess.CompletedProcess(cmd, 0, DOCKER_IMAGE_ID + "\n", "")
        if cmd[:3] == [sys.executable, "-m", "pip"]:
            return subprocess.CompletedProcess(cmd, 0, "pytest==9.0.0\n", "")
        raise AssertionError(f"unexpected command: {cmd}")

    monkeypatch.setattr(intake.subprocess, "run", fake_run)
    get("sandbox-provisioner")(
        make_ctx(tmp_path, config={"sandbox_image": requested,
                                   "sandbox_gpu_required": True}))
    manifest = json.loads((tmp_path / "experiments/sandbox_manifest.json").read_text())
    config = json.loads((tmp_path / "experiments/container.yaml").read_text())

    assert manifest["untrusted_code_execution_allowed"] is True
    assert manifest["container_image_reference"] == config["image"] == requested
    assert manifest["container_image_id"] == config["image_id"] == DOCKER_IMAGE_ID
    assert config["pull_policy"] == "never" and config["read_only_rootfs"] is True
    assert manifest["gpu_allocation"] == config["gpu_allocation"] == \
        PROVISIONED_CUDA_GPU_EVIDENCE
    assert config["validation"]["gpu"] == PROVISIONED_CUDA_GPU_EVIDENCE
    assert not any("pull" in cmd for cmd in calls)


@pytest.mark.parametrize("bad", ["", "--privileged", "image name", "image\n--network=host", "$HOME/x"])
def test_sandbox_image_rejects_empty_option_like_or_unsafe_references(tmp_path, bad):
    from researchforge.generated import SKILLS

    assert "external: sandbox image reference (local-only; default python:3.11-slim)" in \
        SKILLS["sandbox-provisioner"].external
    authorization = "external: literal trusted-host authorization for this invocation"
    gpu_request = "external: literal strict-Docker NVIDIA GPU requirement for this invocation"
    assert authorization in SKILLS["sandbox-provisioner"].external
    assert authorization in SKILLS["experiment-runner"].external
    assert gpu_request in SKILLS["sandbox-provisioner"].external
    with pytest.raises(GateBlocked) as exc:
        get("sandbox-provisioner")(
            make_ctx(tmp_path, config={"sandbox_image": bad}))
    assert exc.value.gate == "sandbox_image"
    assert not (tmp_path / "experiments/sandbox_manifest.json").exists()


@pytest.mark.parametrize("bad", ["true", 1, 0, [], {}])
def test_gpu_requirement_must_be_a_literal_boolean(tmp_path, bad):
    with pytest.raises(GateBlocked) as exc:
        get("sandbox-provisioner")(
            make_ctx(tmp_path, config={"sandbox_gpu_required": bad}))
    assert exc.value.gate == "sandbox_gpu_required"


def test_trusted_host_cannot_claim_gpu_acceptance(tmp_path):
    with pytest.raises(GateBlocked) as exc:
        get("sandbox-provisioner")(make_ctx(tmp_path, config={
            "security_profile": "trusted-host-code", "trusted_host_authorized": True,
            "sandbox_gpu_required": True,
        }))
    assert exc.value.gate == "sandbox_gpu_required"


def test_explicit_trusted_host_profile_never_claims_network_isolation(tmp_path, monkeypatch):
    from researchforge.skills import intake

    monkeypatch.setattr(intake.platform, "platform", lambda: "test-platform")
    monkeypatch.setattr(
        intake.shutil, "which",
        lambda name: (_ for _ in ()).throw(AssertionError("Docker must not be probed")),
    )
    monkeypatch.setattr(
        intake.subprocess, "run",
        lambda cmd, **kwargs: subprocess.CompletedProcess(cmd, 0, "pytest==9.0.0\n", ""),
    )
    ctx = make_ctx(tmp_path, config={"security_profile": "trusted-host-code",
                                    "trusted_host_authorized": True})
    get("sandbox-provisioner")(ctx)
    manifest = json.loads((tmp_path / "experiments/sandbox_manifest.json").read_text())
    config = json.loads((tmp_path / "experiments/container.yaml").read_text())

    assert manifest["untrusted_code_execution_allowed"] is False
    assert manifest["trusted_host_execution_allowed"] is True
    assert manifest["execution_backend"] == "trusted-host"
    assert manifest["isolation"] == "none"
    assert manifest["network_isolation_enforced"] is False
    assert config["limits"]["network"] == "host-unrestricted"


def test_legacy_container_label_cannot_execute_generated_code_on_the_host(tmp_path, monkeypatch):
    """The v2.8.3 bug: these two fields used to authorize a host subprocess."""
    seed_project(tmp_path, backend="docker", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "experiments/sandbox_manifest.json").write_text(json.dumps({
        "profile": "no-network-untrusted-code", "isolation": "container",
        "untrusted_code_execution_allowed": True,
        "host": {"platform": "test", "python": sys.version.split()[0]}, "warnings": [],
    }))
    (tmp_path / "experiments/container.yaml").write_text(json.dumps({
        "engine": "docker",
        "limits": {"cpus": 2, "memory": "2g", "network": "none", "pids": 256},
    }))

    from researchforge.skills import execution
    monkeypatch.setattr(
        execution.subprocess, "run",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("no process may be started")),
    )
    res = run_skill(tmp_path, "experiment-runner")
    assert all(r["status"] == "NOT_RUN" and not r["metrics"] for r in ledger(tmp_path))
    assert all(r["provenance"]["executed"] is False for r in ledger(tmp_path))
    assert any("contract is incomplete" in w and "no host fallback" in w for w in res.warnings)


def test_validated_docker_backend_invokes_docker_not_python_on_the_host(tmp_path, monkeypatch):
    docker = Path(sys.executable).resolve()
    seed_project(tmp_path, backend="docker", evaluator=True, docker_path=docker)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")

    from researchforge.skills import execution
    commands = []
    monkeypatch.setattr(execution.shutil, "which", lambda name: str(docker))
    identity = {"docker_realpath": str(docker),
                "docker_sha256": hashlib.sha256(docker.read_bytes()).hexdigest(),
                "context": "local-test", "endpoint": "unix:///tmp/docker-test.sock",
                "daemon_id": "daemon-test", "server_version": "test", "daemon_os": "linux"}
    from researchforge.skills import intake
    monkeypatch.setattr(intake, "_local_docker_identity", lambda path: (identity, None))

    def fake_docker(cmd, **kwargs):
        commands.append(cmd)
        assert cmd[:2] == [str(docker), "run"]
        arm = cmd[cmd.index("--arm") + 1]
        value = 0.31415 if arm == "candidate" else 0.2
        payload = {"status": "COMPLETED", "metrics": {"accuracy": value}}
        return {"returncode": 0, "stdout": "RF_RESULT " + json.dumps(payload) + "\n",
                "stderr": "", "abort": None, "captured_bytes": 100,
                "output_limit_bytes": 4 << 20}

    monkeypatch.setattr(execution, "_bounded_process", fake_docker)
    res = run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)

    assert len(commands) == 4 and all(r["status"] == "COMPLETED" for r in rows)
    assert res.detail["execution_backend"] == "docker"
    for cmd in commands:
        assert "--pull=never" in cmd
        assert cmd[cmd.index("--network") + 1] == "none"
        assert "--read-only" in cmd and cmd[cmd.index("--cap-drop") + 1] == "ALL"
        assert cmd[cmd.index("--security-opt") + 1] == "no-new-privileges"
        assert DOCKER_IMAGE_ID in cmd
        mount = cmd[cmd.index("--mount") + 1]
        assert mount.endswith("/code,dst=/workspace/code,readonly")
        assert "evaluation" not in mount and "hidden_tests" not in mount
        assert "--gpus" not in cmd
    assert all(r["provenance"]["sandbox"]["execution_backend"] == "docker" for r in rows)
    assert all(r["provenance"]["sandbox"]["network_enforced_by"] ==
               "docker --network none" for r in rows)
    assert all(r["provenance"]["sandbox"]["hidden_evaluator_mounted"] is False for r in rows)


def test_validated_gpu_backend_maps_devices_and_records_exact_evidence(tmp_path, monkeypatch):
    docker = Path(sys.executable).resolve()
    seed_project(tmp_path, backend="docker", evaluator=True, docker_path=docker, gpu=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")

    from researchforge.skills import execution, intake
    commands = []
    monkeypatch.setattr(execution.shutil, "which", lambda name: str(docker))
    identity = {"docker_realpath": str(docker),
                "docker_sha256": hashlib.sha256(docker.read_bytes()).hexdigest(),
                "context": "local-test", "endpoint": "unix:///tmp/docker-test.sock",
                "daemon_id": "daemon-test", "server_version": "test", "daemon_os": "linux"}
    monkeypatch.setattr(intake, "_local_docker_identity", lambda path: (identity, None))

    def fake_docker(cmd, **kwargs):
        commands.append(cmd)
        payload = {"status": "COMPLETED", "metrics": {"accuracy": 0.8}}
        return {"returncode": 0, "stdout": "RF_RESULT " + json.dumps(payload) + "\n",
                "stderr": "", "abort": None, "captured_bytes": 100,
                "output_limit_bytes": 4 << 20}

    monkeypatch.setattr(execution, "_bounded_process", fake_docker)
    run_skill(tmp_path, "experiment-runner", config={"sandbox_gpu_required": True})
    rows = ledger(tmp_path)
    assert len(commands) == 4
    assert all(cmd[cmd.index("--gpus") + 1] == "all" for cmd in commands)
    assert all(row["provenance"]["sandbox"]["gpu_allocation"] ==
               PROVISIONED_CUDA_GPU_EVIDENCE
               for row in rows)
    assert all(row["provenance"]["sandbox"]["current_invocation_gpu_required"] is True
               for row in rows)
    assert all(row["provenance"]["command"][
                   row["provenance"]["command"].index("--gpus") + 1] == "all"
               for row in rows)


def test_preseeded_gpu_artifacts_cannot_authorize_device_exposure(tmp_path, monkeypatch):
    docker = Path(sys.executable).resolve()
    seed_project(tmp_path, backend="docker", evaluator=True, docker_path=docker, gpu=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")
    from researchforge.skills import execution, intake
    monkeypatch.setattr(execution.shutil, "which", lambda name: str(docker))
    identity = {"docker_realpath": str(docker),
                "docker_sha256": hashlib.sha256(docker.read_bytes()).hexdigest(),
                "context": "local-test", "endpoint": "unix:///tmp/docker-test.sock",
                "daemon_id": "daemon-test", "server_version": "test", "daemon_os": "linux"}
    monkeypatch.setattr(intake, "_local_docker_identity", lambda path: (identity, None))
    monkeypatch.setattr(
        execution, "_bounded_process",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("preseeded GPU executed")),
    )
    run_skill(tmp_path, "experiment-runner", config={})
    rows = ledger(tmp_path)
    assert rows and all(row["status"] == "NOT_RUN" for row in rows)
    assert all("runner invocation explicitly requires" in
               row["provenance"]["sandbox"]["backend_evidence"] for row in rows)


def test_validated_docker_disappearing_never_falls_back_to_host(tmp_path, monkeypatch):
    seed_project(tmp_path, backend="docker", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")

    from researchforge.skills import execution
    monkeypatch.setattr(execution.shutil, "which", lambda name: None)
    monkeypatch.setattr(
        execution.subprocess, "run",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("host fallback attempted")),
    )
    run_skill(tmp_path, "experiment-runner")
    rows = ledger(tmp_path)
    assert rows and all(r["status"] == "NOT_RUN" for r in rows)
    assert all(r["not_run_reason"] == "SANDBOX_BACKEND_UNAVAILABLE" for r in rows)
    assert all(r["provenance"]["executed"] is False and not r["metrics"] for r in rows)


def test_forged_trusted_host_artifacts_need_current_literal_authorization(tmp_path, monkeypatch):
    """Project files can request host execution; they cannot authorize it."""
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")
    from researchforge.skills import execution
    monkeypatch.setattr(
        execution, "_bounded_process",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("forged host execution")),
    )
    run_skill(tmp_path, "experiment-runner", config={})
    rows = ledger(tmp_path)
    assert rows and all(r["status"] == "NOT_RUN" and not r["metrics"] for r in rows)
    assert all(r["provenance"]["executed"] is False for r in rows)
    assert all("literal operator authorization" in
               r["provenance"]["sandbox"]["backend_evidence"] for r in rows)


def test_trusted_host_provisioner_authorization_records_must_agree(tmp_path, monkeypatch):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")
    manifest_path = tmp_path / "experiments/sandbox_manifest.json"
    config_path = tmp_path / "experiments/container.yaml"
    manifest = json.loads(manifest_path.read_text())
    config = json.loads(config_path.read_text())
    manifest["operator_authorization_run_id"] = "old-run"
    config["operator_authorization"] = {"literal": True, "run_id": "different-run"}
    manifest_path.write_text(json.dumps(manifest))
    config_path.write_text(json.dumps(config))
    from researchforge.skills import execution
    monkeypatch.setattr(
        execution, "_bounded_process",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("incoherent authorization executed")),
    )
    run_skill(tmp_path, "experiment-runner",
              config={"trusted_host_authorized": True})
    rows = ledger(tmp_path)
    assert rows and all(r["status"] == "NOT_RUN" and not r["metrics"] for r in rows)
    assert all("one coherent run id" in
               r["provenance"]["sandbox"]["backend_evidence"] for r in rows)


def test_resumed_trusted_host_run_uses_current_literal_with_coherent_prior_record(
        tmp_path, monkeypatch):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    (tmp_path / "code/e_001/impl.py").write_text(IMPL, encoding="utf-8")
    manifest_path = tmp_path / "experiments/sandbox_manifest.json"
    config_path = tmp_path / "experiments/container.yaml"
    manifest = json.loads(manifest_path.read_text())
    config = json.loads(config_path.read_text())
    manifest["operator_authorization_run_id"] = "prior-provisioner-run"
    config["operator_authorization"] = {"literal": True,
                                          "run_id": "prior-provisioner-run"}
    manifest_path.write_text(json.dumps(manifest))
    config_path.write_text(json.dumps(config))
    from researchforge.skills import execution
    monkeypatch.setattr(
        execution, "_bounded_process",
        lambda *a, **k: {
            "returncode": 0,
            "stdout": 'RF_RESULT {"status":"COMPLETED","metrics":{"accuracy":0.8}}\n',
            "stderr": "", "abort": None, "captured_bytes": 64,
            "output_limit_bytes": 4 << 20,
        },
    )
    run_skill(tmp_path, "experiment-runner",
              config={"trusted_host_authorized": True})
    rows = ledger(tmp_path)
    assert rows and all(row["status"] == "COMPLETED" for row in rows)


def test_malformed_guard_payload_never_claims_runtime_check():
    from researchforge.skills.execution import _invalid_conditions_runtime
    assert _invalid_conditions_runtime({
        "invalid_conditions_fired": [],
        "invalid_conditions_unchecked": [],
        "invalid_conditions_error": "TypeError: malformed guard",
    }) == {"checked": False, "fired": [], "unchecked": [],
           "error": "TypeError: malformed guard"}
    assert _invalid_conditions_runtime({})["checked"] is False


def test_provisioner_requires_literal_true_for_trusted_host(tmp_path):
    for value in (None, False, "true", 1):
        config = {"security_profile": "trusted-host-code"}
        if value is not None:
            config["trusted_host_authorized"] = value
        with pytest.raises(GateBlocked) as exc:
            get("sandbox-provisioner")(make_ctx(tmp_path / str(value), config=config))
        assert exc.value.gate == "trusted_host_authorization"


def test_symlinked_code_root_is_rejected_before_scaffolding(tmp_path):
    (tmp_path / "real-code").mkdir()
    (tmp_path / "code").symlink_to(tmp_path / "real-code", target_is_directory=True)
    seed_project(tmp_path, evaluator=True)
    with pytest.raises(GateBlocked) as exc:
        run_skill(tmp_path, "codebase-scaffolder")
    assert exc.value.gate == "unsafe_code_root"
    assert "symlink" in exc.value.reason


def test_symlinked_entry_point_never_reaches_a_backend(tmp_path, monkeypatch):
    seed_project(tmp_path, backend="trusted-host", evaluator=True)
    run_skill(tmp_path, "codebase-scaffolder")
    entry = tmp_path / "code/e_001/experiment.py"
    entry.unlink()
    entry.symlink_to(tmp_path / "evaluation/evaluator.py")
    from researchforge.skills import execution
    monkeypatch.setattr(
        execution, "_bounded_process",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("escaped entry executed")),
    )
    run_skill(tmp_path, "experiment-runner")
    assert all(r["status"] == "NOT_RUN" and not r["metrics"] for r in ledger(tmp_path))


def test_bounded_binary_capture_replaces_invalid_utf8_and_caps_output():
    from researchforge.skills.execution import _bounded_process
    result = _bounded_process(
        [sys.executable, "-c", "import os; os.write(1, b'\\xff' * 1024)"],
        timeout=5, cwd=None, env=None, preexec_fn=None, output_limit=64)
    assert result["abort"] == "output_limit"
    assert result["captured_bytes"] == 64
    assert "\ufffd" in result["stdout"]


@pytest.mark.parametrize("line,why", [
    ("RF_RESULT []\n", "not a JSON object"),
    ("RF_RESULT null\n", "not a JSON object"),
    ("RF_RESULT {bad\n", "invalid JSON"),
    ("RF_RESULT {\"n\":" + "9" * 5000 + "}\n", "invalid JSON"),
    ("RF_RESULT {}\nRF_RESULT {}\n", "multiple"),
])
def test_malformed_result_payload_is_a_failure_not_an_exception(line, why):
    from researchforge.skills.execution import _malformed_result_payload
    payload, error = _malformed_result_payload(line)
    assert payload is None and why in error


def test_docker_timeout_force_removes_only_validated_cid(tmp_path, monkeypatch):
    from researchforge.skills import execution
    cid = "c" * 64
    cidfile = tmp_path / "run.cid"
    cidfile.write_text(cid)
    calls = []
    monkeypatch.setattr(
        execution.subprocess, "run",
        lambda cmd, **kwargs: calls.append(cmd) or subprocess.CompletedProcess(cmd, 0, b"", b""),
    )
    cleaned = execution._remove_container("/exact/docker", cidfile)
    assert calls == [["/exact/docker", "rm", "-f", cid]]
    assert cleaned == {"container_id": cid, "attempted": True, "removed": True}
    cidfile.write_text("../../victim")
    calls.clear()
    assert execution._remove_container("/exact/docker", cidfile)["attempted"] is False
    assert calls == []


def test_remote_docker_context_is_refused_before_daemon_probe(tmp_path, monkeypatch):
    from researchforge.skills import intake
    docker = Path(sys.executable).resolve()
    monkeypatch.setenv("DOCKER_HOST", "ssh://worker.example.test")
    monkeypatch.setattr(
        intake.subprocess, "run",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("remote daemon contacted")),
    )
    identity, error = intake._local_docker_identity(str(docker))
    assert identity["docker_realpath"] == str(docker)
    assert "not a local Unix socket" in error


def test_docker_context_override_precedes_local_docker_host(monkeypatch):
    from researchforge.skills import intake
    docker = Path(sys.executable).resolve()
    monkeypatch.setenv("DOCKER_CONTEXT", "remote-worker")
    monkeypatch.setenv("DOCKER_HOST", "unix:///tmp/local.sock")
    commands = []

    def fake_command(command, **kwargs):
        commands.append(command)
        if command[1:3] == ["context", "inspect"]:
            return subprocess.CompletedProcess(command, 0, '"ssh://worker.example.test"\n', "")
        raise AssertionError("remote daemon was contacted")

    monkeypatch.setattr(intake, "_docker_command", fake_command)
    identity, error = intake._local_docker_identity(str(docker))
    assert identity["docker_realpath"] == str(docker)
    assert "not a local Unix socket" in error
    assert len(commands) == 1 and commands[0][2] == "inspect"


def test_changed_docker_engine_fails_revalidation(tmp_path, monkeypatch):
    from researchforge.skills import execution
    docker = Path(sys.executable).resolve()
    validation = {"docker_realpath": str(docker),
                  "docker_sha256": hashlib.sha256(docker.read_bytes()).hexdigest(),
                  "context": "old", "endpoint": "unix:///tmp/old.sock",
                  "daemon_id": "old-daemon", "daemon_os": "linux"}
    monkeypatch.setattr(execution.shutil, "which", lambda name: str(docker))
    from researchforge.skills import intake
    monkeypatch.setattr(intake, "_local_docker_identity", lambda path: ({**validation,
                                                                         "daemon_id": "new-daemon"}, None))
    got, error = execution._revalidate_docker_backend({"validation": validation})
    assert got is None and "daemon_id" in error


def test_image_smoke_uses_nonroot_python_entrypoint_and_no_network(tmp_path, monkeypatch):
    from researchforge.skills import intake
    commands = []
    def fake_run(cmd, **kwargs):
        commands.append(cmd)
        cidfile = Path(cmd[cmd.index("--cidfile") + 1])
        cidfile.write_text("d" * 64)
        return subprocess.CompletedProcess(cmd, 0, b"RF_SANDBOX_SMOKE 65534\n", b"")
    monkeypatch.setattr(intake.subprocess, "run", fake_run)
    smoke, error = intake._smoke_validate_image("/exact/docker", DOCKER_IMAGE_ID)
    assert error is None and smoke["validated"] is True
    cmd = commands[0]
    assert cmd[cmd.index("--network") + 1] == "none"
    assert cmd[cmd.index("--entrypoint") + 1] == "python"
    assert cmd[cmd.index("--user") + 1] == "65534:65534"


def test_container_environment_lock_is_measured_in_exact_image(tmp_path, monkeypatch):
    from researchforge.skills import intake
    commands = []
    def fake_run(cmd, **kwargs):
        commands.append(cmd)
        Path(cmd[cmd.index("--cidfile") + 1]).write_text("e" * 64)
        return subprocess.CompletedProcess(cmd, 0, b"numpy==2.3.0\npip==25.0\n", b"")
    monkeypatch.setattr(intake.subprocess, "run", fake_run)
    lock, measurement, error = intake._capture_container_environment(
        "/exact/docker", DOCKER_IMAGE_ID, "daemon-1")
    assert error is None and measurement["measured"] is True
    assert f"# container_image_id={DOCKER_IMAGE_ID}" in lock and "numpy==2.3.0" in lock
    assert measurement["sha256"] == hashlib.sha256(lock.encode()).hexdigest()
    cmd = commands[0]
    assert cmd[cmd.index("--network") + 1] == "none"
    assert cmd[cmd.index("--entrypoint") + 1] == "python"
    assert cmd[-4:] == ["-m", "pip", "freeze", "--all"]


def test_every_rlimit_failure_is_ignored_as_a_backstop(monkeypatch):
    from researchforge.skills import execution
    seen = []
    monkeypatch.setattr(execution.resource, "getrlimit", lambda limit: (0, 1))
    monkeypatch.setattr(
        execution.resource, "setrlimit",
        lambda limit, pair: seen.append(limit) or (_ for _ in ()).throw(OSError("unsupported")),
    )
    monkeypatch.setattr(execution.os, "setsid", lambda: (_ for _ in ()).throw(OSError("unsupported")))
    execution._rlimits({"timeout_seconds": "invalid", "memory": float("inf"),
                        "pids": "invalid"}, 3)()
    assert len(seen) >= 3


def test_failed_process_group_kill_falls_back_to_child_kill(monkeypatch):
    from researchforge.skills import execution

    class Process:
        pid = 12345

        def __init__(self):
            self.killed = False

        def kill(self):
            self.killed = True

        def wait(self, timeout):
            return 0

    process = Process()
    monkeypatch.setattr(execution.os, "killpg", lambda *a: (_ for _ in ()).throw(OSError()))
    execution._kill_process(process, process_group=True)
    assert process.killed is True
