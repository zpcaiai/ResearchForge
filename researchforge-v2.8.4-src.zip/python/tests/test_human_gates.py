"""Fail-closed tests for the v2.8.4 human evidence execution kit.

The filled records below are synthetic protocol fixtures.  They are not human
evidence and never leave pytest's temporary directory.
"""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[2]
TOOL = ROOT / "docs/human-gates-v2.8.4.py"
SPEC = importlib.util.spec_from_file_location("human_gates_v284", TOOL)
assert SPEC is not None and SPEC.loader is not None
hg = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(hg)


def attestation(declaration, reviewer="human-1", subject_sha256="f" * 64):
    value = hg.blank_attestation(declaration, subject_sha256)
    value.update({
        "actor_kind": "human",
        "reviewer_id": reviewer,
        "full_name": f"Protocol Fixture {reviewer}",
        "organization": "Test fixture only",
        "qualification": "synthetic unit-test fixture; not evidence",
        "signed_at_utc": "2026-08-20T00:00:00Z",
        "signature_evidence_locator": f"fixture://{reviewer}",
        "signature_evidence_sha256": "a" * 64,
        "coordinator_id": "fixture-coordinator",
        "coordinator_verified_human_identity": True,
        "identity_verification_method": "synthetic unit-test fixture",
    })
    return value


def test_blank_or_ai_attestation_never_passes():
    subject = "f" * 64
    with pytest.raises(hg.GateError, match="actor_kind"):
        hg._human(hg.blank_attestation(hg.PDF_DECLARATION, subject),
                  hg.PDF_DECLARATION, "reviewer", subject)
    fake = attestation(hg.PDF_DECLARATION, subject_sha256=subject)
    fake["actor_kind"] = "AI"
    with pytest.raises(hg.GateError, match="exactly 'human'"):
        hg._human(fake, hg.PDF_DECLARATION, "reviewer", subject)


def test_b_arm_prepare_is_deterministic_and_keeps_key_coordinator_only(tmp_path):
    first = hg.prepare_b_arm(tmp_path / "one", 8, 20260812, 8.0)
    second = hg.prepare_b_arm(tmp_path / "two", 8, 20260812, 8.0)
    assert first["issued_packet_sha256"] == second["issued_packet_sha256"]
    assert first["key_sha256"] == second["key_sha256"]
    packet = json.loads((tmp_path / "one/participant.packet.json").read_text())
    assert len(packet["worksheets"]) == 8
    assert all(row["level_reached"] is None for row in packet["worksheets"])
    assert "a_arm_outcomes" not in json.dumps(packet)
    assert (tmp_path / "one").stat().st_mode & 0o777 == 0o700
    assert (tmp_path / "one/participant.packet.json").stat().st_mode & 0o777 == 0o600
    assert (tmp_path / "one/COORDINATOR-ONLY.key.json").stat().st_mode & 0o777 == 0o600


def test_b_arm_pass_needs_every_real_work_field_and_preserves_negative_result(
        tmp_path, monkeypatch):
    hg.prepare_b_arm(tmp_path / "b", 8, 20260812, 8.0)
    packet_path = tmp_path / "b/participant.packet.json"
    packet = json.loads(packet_path.read_text())
    packet["human_attestation"] = attestation(
        hg.B_ARM_DECLARATION, "engineer-1", packet["issued_content_sha256"]
    )
    for row in packet["worksheets"]:
        row.update({
            "level_reached": "RL0", "failure_codes": ["NO_CODE"],
            "wall_clock_hours_used": 1.0, "timebox_exhausted": False,
            "engineer_id": "engineer-1", "saw_a_arm_material": False,
        })
        row["step_0_seed_variance"]["skipped_because"] = "repository had no executable code"
    packet_path.write_text(json.dumps(packet), encoding="utf-8")
    key_path = tmp_path / "b/COORDINATOR-ONLY.key.json"
    manifest_path = tmp_path / "b/manifest.json"
    original_key_text = key_path.read_text()
    original_read_text = Path.read_text

    def refuse_mutable_baseline(path, *args, **kwargs):
        if path == ROOT / "docs/study/all_results.jsonl":
            raise AssertionError("verification must use frozen key outcomes, not mutable ROOT data")
        return original_read_text(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", refuse_mutable_baseline)
    result = hg.verify_b_arm(packet_path, key_path, manifest_path, None)
    assert result["status"] == "PASSED"
    assert result["human_result"] in {"NO_DISCORDANT_PAIRS", "NOT_DETECTABLE"}

    wrong_subject = copy.deepcopy(packet)
    wrong_subject["human_attestation"]["subject_sha256"] = "b" * 64
    packet_path.write_text(json.dumps(wrong_subject), encoding="utf-8")
    with pytest.raises(hg.GateError, match="not bound to this frozen evidence subject"):
        hg.verify_b_arm(packet_path, key_path, manifest_path, None)

    invalid_code = copy.deepcopy(packet)
    invalid_code["worksheets"][0]["failure_codes"] = ["MADE_UP_FAILURE"]
    packet_path.write_text(json.dumps(invalid_code), encoding="utf-8")
    with pytest.raises(hg.GateError, match="evidence incomplete"):
        hg.verify_b_arm(packet_path, key_path, manifest_path, None)

    tampered = copy.deepcopy(packet)
    tampered["timebox_hours"] = 80.0
    tampered["issued_content_sha256"] = hg._b_arm_binding(tampered)
    packet_path.write_text(json.dumps(tampered), encoding="utf-8")
    with pytest.raises(hg.GateError, match="immutable packet design changed"):
        hg.verify_b_arm(packet_path, key_path, manifest_path, None)

    changed_key = json.loads(key_path.read_text())
    changed_key["a_arm_outcomes"][0]["level"] = "RL4"
    changed_key["a_arm_outcomes_sha256"] = hg._sha(changed_key["a_arm_outcomes"])
    key_path.write_text(json.dumps(changed_key), encoding="utf-8")
    packet_path.write_text(json.dumps(packet), encoding="utf-8")
    with pytest.raises(hg.GateError, match="differs from its issuance manifest"):
        hg.verify_b_arm(packet_path, key_path, manifest_path, None)

    # Restore the coordinator key for the remaining returned-packet refusal.
    key_path.write_text(original_key_text, encoding="utf-8")
    packet["worksheets"][0]["level_reached"] = None
    packet_path.write_text(json.dumps(packet), encoding="utf-8")
    with pytest.raises(hg.GateError, match="not attempted"):
        hg.verify_b_arm(packet_path, key_path, manifest_path, None)


def pdf_material(document_id, claims, *, vector=False):
    return {
        "document_id": document_id,
        "filename": f"{document_id}.pdf",
        "source_sha256": "1" * 64,
        "artifact_sha256": "2" * 64,
        "expected_vector_only": vector,
        "extracted_title": "Paper title" if not vector else "(title not detected)",
        "section_titles": ["Abstract", "Introduction", "References"],
        "figure_ids": ["f1"],
        "table_ids": ["t1"],
        "historical_gold_counts": {"sections": 3, "figures": 1, "tables": 1},
        "claims": [
            {"document_id": document_id, "claim_id": f"C-{index:03d}",
             "text": f"Claim {index}", "section": "Introduction",
             "locator": {"anchor_id": "p1", "offset": index},
             "source_sha256": "1" * 64, "artifact_sha256": "2" * 64}
            for index in range(1, claims + 1)
        ],
    }


def complete_pdf(packet):
    packet["human_attestation"] = attestation(
        hg.PDF_DECLARATION, "pdf-expert", packet["issued_content_sha256"]
    )
    for row in packet["document_reviews"]:
        review = row["human_review"]
        if row["expected_vector_only"]:
            review["visual_fallback_is_correct"] = True
        else:
            for field in ("title_correct", "section_map_usable",
                          "figure_index_usable", "table_index_usable"):
                review[field] = True
    for row in packet["claim_sample"]:
        row["human_review"].update({
            "is_genuine_paper_claim": True,
            "quote_matches_pdf": True,
            "locator_points_to_claim": True,
        })
    return packet


def pdf_materials():
    return [pdf_material(f"doc-{index:02d}", 3) for index in range(1, 18)] + [
        pdf_material("doc-18", 0, vector=True)
    ]


def pdf_manifest(packet):
    documents = packet["document_reviews"]
    return {
        "schema_version": 1,
        "gate": "pdf_quality_remeasurement",
        "corpus_id": hg.PDF_CORPUS_ID,
        "document_count": hg.PDF_DOCUMENT_COUNT,
        "document_ids": [row["document_id"] for row in documents],
        "claim_sample_size": hg.PDF_CLAIM_SAMPLE_SIZE,
        "sample_seed": hg.PDF_REVIEW_SEED,
        "issued_content_sha256": packet["issued_content_sha256"],
    }


def test_pdf_packet_is_deterministic_bound_and_thresholded(tmp_path):
    manifest = {"corpus_id": hg.PDF_CORPUS_ID}
    materials = pdf_materials()
    first = hg.build_pdf_packet(
        manifest, materials, hg.PDF_REVIEW_SEED, hg.PDF_CLAIM_SAMPLE_SIZE
    )
    second = hg.build_pdf_packet(
        manifest, materials, hg.PDF_REVIEW_SEED, hg.PDF_CLAIM_SAMPLE_SIZE
    )
    assert first["issued_content_sha256"] == second["issued_content_sha256"]
    assert [row["sample_id"] for row in first["claim_sample"]] == [
        row["sample_id"] for row in second["claim_sample"]]
    complete_pdf(first)
    result_pathless = hg.verify_pdf
    # write once because verify_pdf deliberately consumes a returned packet path
    path = tmp_path / "packet.json"
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps(pdf_manifest(first)), encoding="utf-8")
    path.write_text(json.dumps(first), encoding="utf-8")
    result = result_pathless(path, manifest, None)
    assert result["status"] == "PASSED"
    first["claim_sample"][0]["text"] = "edited after issue"
    # Recomputing the packet's self-declared hash still cannot rewrite the
    # coordinator-retained manifest.
    first["issued_content_sha256"] = hg._pdf_binding(first)
    path.write_text(json.dumps(first), encoding="utf-8")
    with pytest.raises(hg.GateError, match="immutable content changed"):
        result_pathless(path, manifest, None)


def test_pdf_complete_review_below_frozen_threshold_does_not_pass(tmp_path):
    packet = hg.build_pdf_packet(
        {"corpus_id": hg.PDF_CORPUS_ID}, pdf_materials(),
        hg.PDF_REVIEW_SEED, hg.PDF_CLAIM_SAMPLE_SIZE,
    )
    complete_pdf(packet)
    packet["claim_sample"][0]["human_review"].update({
        "is_genuine_paper_claim": False, "quote_matches_pdf": False,
        "locator_points_to_claim": False, "notes": "fixture failure",
    })
    path = tmp_path / "packet.json"
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps(pdf_manifest(packet)), encoding="utf-8")
    path.write_text(json.dumps(packet), encoding="utf-8")
    result = hg.verify_pdf(path, manifest, None)
    assert result["status"] == "FAILED_QUALITY_THRESHOLD"
    assert result["checks"]["locator_correct"] is False


def test_innovation_requires_real_provider_and_two_distinct_reportable_humans(tmp_path):
    with pytest.raises(hg.GateError, match="synthetic=false"):
        hg._provider_evidence({"synthetic": True})
    seeds = []
    for line in (ROOT / "benchmarks/retro-v1/retro_benchmark.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row.get("record_type") == "pair":
            seeds.append(row["seed_id"])
    machine = {seed: [
        {"seed_id": seed, "statement": f"machine direction {seed} {index}"}
        for index in range(10)] for seed in seeds}
    human = [f"human direction {index}" for index in range(sum(map(len, machine.values())))]
    (tmp_path / "machine.json").write_text(json.dumps(machine), encoding="utf-8")
    (tmp_path / "human.json").write_text(json.dumps(human), encoding="utf-8")
    provider = {
        "provider": "fixture-provider", "model": "fixture-model", "run_id": "fixture-run",
        "created_at_utc": "2026-08-20T00:00:00Z", "request_sha256": "1" * 64,
        "response_sha256": "2" * 64,
        "project_artifact_sha256": hg._sha_file(tmp_path / "machine.json"),
        "synthetic": False,
    }
    wrong_provider = dict(provider, project_artifact_sha256="3" * 64)
    (tmp_path / "wrong-provider.json").write_text(json.dumps(wrong_provider), encoding="utf-8")
    with pytest.raises(hg.GateError, match="does not match the machine input bytes"):
        hg.prepare_innovation(tmp_path / "wrong-innovation", tmp_path / "machine.json",
                              tmp_path / "human.json", tmp_path / "wrong-provider.json", 5, 2)
    (tmp_path / "provider.json").write_text(json.dumps(provider), encoding="utf-8")
    package = tmp_path / "innovation"
    hg.prepare_innovation(package, tmp_path / "machine.json", tmp_path / "human.json",
                          tmp_path / "provider.json", 5, 2)

    author_blank = json.loads((package / "human-arm.attestation.json").read_text())
    author = attestation(
        hg.HUMAN_AUTHOR_DECLARATION, "author", author_blank["subject_sha256"]
    )
    (package / "human-arm.attestation.json").write_text(json.dumps(author), encoding="utf-8")
    pairwise_path = package / "adjudicator/pairwise.packet.json"
    pairwise = json.loads(pairwise_path.read_text())
    pairwise["human_attestation"] = attestation(
        hg.PAIRWISE_DECLARATION, "judge",
        pairwise["human_attestation"]["subject_sha256"],
    )
    for row in pairwise["items"]:
        row["verdict"] = "NO_MATCH"
        row["adjudicator"] = "judge"
    pairwise_path.write_text(json.dumps(pairwise), encoding="utf-8")

    blind_spec = importlib.util.spec_from_file_location(
        "blind_for_human_gate_test", ROOT / "tools/benchmark/blind_rubric.py")
    assert blind_spec and blind_spec.loader
    blind = importlib.util.module_from_spec(blind_spec)
    blind_spec.loader.exec_module(blind)
    key = json.loads((package / "coordinator/blind.key.json").read_text())
    arms = {row["entry_id"]: row["arm"] for row in key["key"]}
    for rater_index, path in enumerate(sorted((package / "raters").glob("*.json")), 1):
        packet = json.loads(path.read_text())
        rid = f"expert-{rater_index}"
        packet["human_attestation"] = attestation(
            hg.BLIND_DECLARATION, rid,
            packet["human_attestation"]["subject_sha256"],
        )
        for index, row in enumerate(packet["entries"]):
            row["scores"] = {criterion["id"]: 3 for criterion in blind.CRITERIA}
            actual = arms[row["entry_id"]]
            row["arm_guess"] = (actual if index % 2 == 0 else
                                ("human" if actual == "machine" else "machine"))
            row["rater_id"] = rid
        path.write_text(json.dumps(packet), encoding="utf-8")

    same_person = copy.deepcopy(pairwise)
    same_person["human_attestation"] = attestation(
        hg.PAIRWISE_DECLARATION, "author",
        same_person["human_attestation"]["subject_sha256"],
    )
    for row in same_person["items"]:
        row["adjudicator"] = "author"
    pairwise_path.write_text(json.dumps(same_person), encoding="utf-8")
    with pytest.raises(hg.GateError, match="author and pairwise adjudicator must be distinct"):
        hg.verify_innovation(package, None)
    pairwise_path.write_text(json.dumps(pairwise), encoding="utf-8")

    result = hg.verify_innovation(package, None)
    assert result["status"] == "PASSED"
    assert result["retrospective_scorecard"]["verdict"] == "AT_OR_BELOW_FLOOR"
    assert len(result["blind_panel"]) == 2

    key_path = package / "coordinator/blind.key.json"
    original_key = json.loads(key_path.read_text())
    edited_key = copy.deepcopy(original_key)
    for row in edited_key["key"]:
        row["arm"] = "human" if row["arm"] == "machine" else "machine"
    edited_key["key_hash"] = blind._sha(edited_key["key"])
    key_path.write_text(json.dumps(edited_key), encoding="utf-8")
    with pytest.raises(hg.GateError, match="blind key differs"):
        hg.verify_innovation(package, None)
    key_path.write_text(json.dumps(original_key), encoding="utf-8")

    rater_two_path = package / "raters/rater-2.packet.json"
    original_rater_two = json.loads(rater_two_path.read_text())
    reused_judge = copy.deepcopy(original_rater_two)
    reused_judge["human_attestation"] = attestation(
        hg.BLIND_DECLARATION, "judge",
        reused_judge["human_attestation"]["subject_sha256"],
    )
    for row in reused_judge["entries"]:
        row["rater_id"] = "judge"
    rater_two_path.write_text(json.dumps(reused_judge), encoding="utf-8")
    with pytest.raises(hg.GateError, match="author, adjudicator, and every rater must be distinct"):
        hg.verify_innovation(package, None)

    duplicate = copy.deepcopy(original_rater_two)
    duplicate["human_attestation"] = attestation(
        hg.BLIND_DECLARATION, "expert-1",
        duplicate["human_attestation"]["subject_sha256"],
    )
    for row in duplicate["entries"]:
        row["rater_id"] = "expert-1"
    rater_two_path.write_text(json.dumps(duplicate), encoding="utf-8")
    with pytest.raises(hg.GateError, match="author, adjudicator, and every rater must be distinct"):
        hg.verify_innovation(package, None)
