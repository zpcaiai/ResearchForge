# v2.0.0 — commercial build (2026-08-11)

## Licence issuing and enforcement

- `tools/license/{keygen,issue,server}.mjs` — Ed25519 keypair generation, licence signing with a
  self-check that refuses to emit an unverifiable licence, and a minimal issuing service with an
  admin token, rate limiting and an append-only issuance ledger that never records the key.
- **The paywall now actually gates.** It previously computed the restricted feature list correctly
  and then printed it while running every gated stage anyway. Enforcement now lives at the Python
  boundary, in `researchforge.runner`: every stage passes through it and it is invokable directly,
  so a check placed only in the TypeScript orchestrator would check nothing. The TypeScript CLI
  still only *prints* the restricted list — the refusal comes back from Python. One gate at the
  choke point, not two.
- A licence cannot be made unbypassable in self-hosted software. The design goal is therefore that
  bypass is a deliberate, *recorded* act: `RESEARCHFORGE_ALLOW_UNLICENSED=1` works, and writes itself
  into provenance and the release manifest.
- Fixed a latent bug that would have broken every real licence: the verifier called
  `crypto.verify("sha256", ...)`, and OpenSSL rejects a named digest for Ed25519 rather than
  ignoring it. Every test passed because they all verified against a null key.

## Measured ingestion quality on real PDFs, and three fixes

18 real paper PDFs from 13 GitHub repos. Measured: 73% of extracted claims carried a wrong section
label, 28% were mined from past the References heading, and 1 in 18 PDFs was un-ingestable.

Fixed:
1. **Lone surrogates no longer crash ingestion.** pypdf emits unpaired U+D835 for math-italic
   glyphs; the artifact store died on `.encode()` and a real paper looked like a runtime bug.
   Now transcoded lossily *and the loss is named*, because a silent recovery would hide that the
   formulae on those pages are junk.
2. **`HEAD_RE` now matches `1. Introduction` and roman numerals.** It previously required whitespace
   after the section number, so ICML/PMLR style was invisible: 7 of 18 papers detected exactly two
   sections, and every body claim was filed under "Abstract".
3. **`layout_warnings.md` can no longer claim a clean bill of health.** It used to print
   "none: text extraction produced anchored, ordered content" whenever the warning list happened to
   be empty — an affirmative all-clear for checks that were never run. In a system whose entire pitch
   is refusing to report work it did not do, this was the worst defect in the codebase. It now
   separates what was checked from what was not.

Everything else found is documented in `docs/PDF_INGEST_QUALITY.md` with its measured cost, and
pinned by tests.

## Acceptance harness

`acceptance/` — `RUBRIC.md` (eight dimensions, every threshold traced to a runtime constant or a
stated property), `grade.py` (consumes the existing audits rather than re-deriving them, because two
thresholds means the lower one wins), `run_acceptance.sh` (preflights a key matching the selected
model provider, a visible GPU, an implemented and recorded GPU device mapping, a running Docker
daemon, a healthy built runtime, a verifiable paid
licence or recorded override, a supplied implementation and fresh project directories rather than
degrading to the offline path). A live run also needs permitted egress to the selected model and
scholarly providers.

`NOT_MEASURED` is a distinct outcome from `PASS`, and it blocks acceptance. Grading a project whose
artifacts carry `synthetic: true` is refused outright.

## Commercial proposal

`docs/COMMERCIAL.md` — what is actually being sold, four buyer segments and what each is buying
instead of, tiers mapped onto the feature gates that exist, price points with the reasoning chain,
what will block a sale, and legal exposure. Every guess is marked as one, with how to replace it.

## Corrected: the A′ arm refuted this project's own recommendation

`docs/study/APRIME_FINDINGS.md`. v1.1.0 recommended a "dependency time machine" — a date-pinned wheel
index and a multi-version interpreter pool — as the highest-value engineering investment. Both were
built and tested on the same 20 papers. The date snapshot helped one paper; the interpreter pool
helped none. The apparent gain from switching resolvers evaporated under a real install, because a
dry-run does not execute `setup.py`.

The real blocker is a CUDA build toolchain: `flash-attn` and its class import torch at build time and
then compile. `result-reproducer`'s remediation table has been corrected to say so, and to say
explicitly that the date-pinned index was tested and did not work.

## Step 0, executed

`docs/study/step0_results.json`. 30 seeds per metric on the worked example: **8 of 12 metrics need a
tolerance wider than the 2% floor, one of them 67× wider.** A fixed ±5% tolerance would classify
those metrics' own noise as a failed reproduction. The floor is now documented as a floor and nothing
more.

## Still not done

- **No acceptance run has been performed.** The harness exists, but this environment does not supply
  the complete live-run envelope: matching model credentials and provider egress, a GPU, an
  implemented and recorded GPU device mapping, a running Docker daemon, a paid licence or recorded
  override, a method implementation and two fresh runs.
- **B arm not executed.** The protocol's human-ceiling comparison needs a human; the agent-vs-human gap is unmeasured.
- The innovation engine has never been scored against a benchmark. `retrospective-benchmark-builder`
  correctly refuses without a corpus, and no corpus exists.
- `pubkey.ts` still holds the substitution sentinel: no shipped build can verify a licence until the
  release process substitutes a real public key.

---

# v2.1.0 — the falsifiability mechanism, made real (2026-08-12)

The acceptance grader built in v2.0.0 immediately failed the stock run on two structural
defects. Both were real, both reproduced on any run, and both are now fixed. A grader that
finds nothing on its first outing is a grader nobody should trust.

## 1. Void conditions were prose, so nothing was ever checked

Every `invalid_condition` the blueprint compiler emitted carried a `detect` field written for a
human — "count completed runs per condition in the experiment ledger". No runtime can evaluate
that. Not one condition had ever fired or cleared on any run, which made every experiment the
system produced formally **unfalsifiable** while its spec said otherwise in good English.

`researchforge/invalid_conditions.py` gives each condition a machine-evaluable `check`:
`min_completed_runs_per_condition`, `field_stable_across_runs`, `metric_names_stable`,
`configs_match_except`, `artifact_field_present`, `text_present_in_artifact`. The prose stays
for the reader; the predicate is what binds.

`experiment-runner` evaluates them after the runs and **excludes a void experiment's runs before
ranking**, rather than annotating the ranking afterwards. A void run is not a negative result —
it is nothing, and nothing may be concluded from it.

A condition whose kind is unknown reports `UNCHECKED`, never satisfied. An experiment none of
whose conditions could be evaluated is reported as not falsifiable, which is a distinct and
worse state than void.

Each ledger entry now stamps the evaluator digest, because `EVALUATOR_CHANGED_MID_RUN` was
otherwise permanently `UNCHECKED` — which reads like "fine" and means "we never looked".

## 2. Ablations measured something other than the claim they tested

Ablation specs declared `primary` and `seed_dispersion` while the experiments they ablate
declared domain metrics. Disjoint sets: the contrast an ablation exists to make could never be
constructed from the ledger. The ablation was structurally incapable of answering the only
question it was created to answer.

Ablations now inherit the parent experiment's metrics and add dispersion on top. The worked
example's ablation was rewritten accordingly — and the corrected contract immediately rejected
the old implementation for returning undeclared metrics, which is the gate working.

## 3. A number extractor that silently dropped exponents

Found while diagnosing why a slide number would not bind. `5.3462760410685855e-16` — a
dispersion of essentially zero — was parsed as `5.34628` and rendered on a defense slide as five
and a third. **Wrong by sixteen orders of magnitude.** The binder caught it as "unbound", so the
gate held, but the diagnosis pointed at the wrong thing.

`NUMBER_RE` now matches scientific notation as one quantity, exponent included, while still
keeping digits inside identifiers (`E-001`, `v1.2`) out.

## 4. Two false positives in the claim auditor

Sample sizes (`n=7 runs`) and recorded run scalars (wall-clock, seed) were marked FABRICATED
because the indexes exposed only metric values. Both are recorded facts traceable to a run id.
An auditor that cries wolf on sample sizes is one nobody reads. The worked example now audits
11 of 11 claims as SUPPORTED, and the release is still refused — for the synthetic draft, which
is correct.

## 5. A scoping error I made and then reverted

I first limited `BASELINE_NOT_ESTABLISHED` to comparative specs, reasoning that a diagnostic
experiment at CM_NONE compares against our own implementation and needs no external pin. A test
disagreed and the test was right: an internal reference has to hold still too, or a change in
our own code is credited to the mechanism. The condition applies to every spec; only the *check*
differs — external revision pin for comparative specs, entry-point digest stability for internal ones.

## Verified

300 tests (276 Python + 24 TypeScript). The worked example traverses all 16 states, all three
experiments are non-void and falsifiable with zero unchecked conditions on the two primaries,
11 of 11 claims SUPPORTED, and the release gate still refuses the synthetic draft.

# v2.2.0 — the comparison has a third arm (2026-08-12)

Ablations and baselines now measure against the current strongest method, not only against the
paper the project started from.

## 1. Nothing ever asked who is currently best

`result-reproducer` located the *source paper's* repository and stopped there. Every downstream
comparison was therefore "did we beat what they beat", and every ablation isolated a mechanism
inside a method whose competitiveness nobody had established. Both are real measurements. Neither
answers the question a reviewer asks, and an ablation anchored to a non-competitive full method is
a strawman with extra steps.

- `result-reproducer` now consumes `benchmark_matrix` and `literature_candidates` and writes
  `baseline_assets.sota`: candidates drawn from `--set sota_methods='[...]'`, from the benchmark
  table, and from titles that assert the frontier. `established` is hard-coded **False**, and no code path
  promotes it: a reported candidate would become comparable to our measured number only by being
  run here and graded RL3+, and that ladder is not built. The field is a placeholder, and nothing
  now reads it as a licence — v2.7.0 deleted the void condition that did. A number scraped from a benchmark table is a *reported*
  number; placing our measured result beside someone else's best-case reported one, under their
  hardware and their tuning budget, is the most common way a comparison becomes fiction.
- `research-blueprint-compiler` adds a third condition to every comparative spec when a candidate
  exists, states in the success metric whether that arm is measured or reported, budgets for it
  (`conditions: 3`), and emits `SOTA_NOT_ESTABLISHED` as a machine-checkable invalid condition.
- Ablation specs carry `anchored_to`, including a `strawman_risk` naming which of the two weaknesses
  applies: no sota arm at all, or one declared and never run.
- When no candidate is found the compiler says so and says what it costs: no claim of
  competitiveness can come out of that plan however the runs turn out.
- `claim-citation-auditor` blocks "state-of-the-art" / "outperforms all prior" claims about *this
  work* unless a `sota` arm completed with metrics in the ledger. Reported numbers do not satisfy
  it. Sentences describing the literature are not graded, because a check that misfires in related
  work is a check that gets turned off.

## 2. The runner only ever ran one arm

Found while wiring the above. `experiment-runner` invoked the generated entry point with no
`--arm` at all, so it always executed the default — the candidate. A spec could declare a baseline
and report `conditions: 2`, and the ledger would contain two runs of the same condition.

Every comparison built on such a ledger was the candidate against itself. It could not fail: the
means matched because they were the same runs.

- The runner now executes every arm the spec declares, the generated entry point derives its
  `--arm` choices from the spec rather than a hard-coded pair, and ledger rows carry `arm`.
- A spec that designs more conditions than it names runnable arms now says which ones will never be
  measured, instead of leaving "small effect" and "never ran" indistinguishable downstream.
- `research-blueprint-compiler`'s diagnostic spec said `conditions: 1` while declaring a baseline
  the runner would be asked to execute. The budget was short by half.

## 3. Four places that pooled a method with its own control

Once the arms actually ran, every consumer that grouped by experiment id started averaging the
candidate together with the baseline it was being compared against. The result is arithmetically
valid, describes no condition that was ever run, and passes every integrity check downstream
because it is a real mean of real runs.

- `experiment-runner._rank` scores a branch by its **candidate** arm and reports the others beside
  it, with `contrasts` giving candidate-minus-control per metric. No significance is claimed there;
  `integrity-auditor` owns that question.
- `data-analyst` groups by `(experiment, arm, metric)`. Grouping by arm alone — the first fix, and
  wrong — would have merged E-001's baseline with E-ABL-001's baseline into one group called
  "baseline".
- `integrity-auditor` identifies one control **per experiment**, refuses to pair arms across
  experiments, and no longer fills the multiple-comparison family with contrasts nobody designed.
- `claim-evidence-graph` emits one own-work claim per (experiment, arm, metric). It previously
  emitted "In E-001, failure_mode_incidence measured 0.2131 (n=14 runs)" — 7 seeds of the method
  and 7 of its control, averaged. `figure-factory` caught it: the number matched nothing in the
  analysis. That refusal is the one that made this whole class visible.

# v2.3.0 — the innovation engine has a benchmark, and the benchmark has a floor (2026-08-12)

`retrospective-benchmark-builder` had been correctly refusing to run since v1: no corpus existed,
and it will not invent one. The corpus now exists. Its most important output is not the benchmark.

## The floor is 0.75

Asked to name — from memory, with no corpus, no retrieval and no tools — the papers that beat each
seed on its own benchmark between 2020 and 2022, `claude-opus-5` named **3 of 3** ImageNet gold
directions and **1 of 2** CoNLL 2003 directions. The probe ran in a separate context from the one
that built the corpus, so the answers could not leak from the session that knew them.

**Any recall@10 at or below 0.75 on this benchmark measures the model's reading, not its judgment.**
Without that number the same score would have been reported as a capability, which is the failure
this skill was written to prevent. The floor is a lower bound: it is scored by title containment,
which misses paraphrase and misses recognition that never surfaces as a title.

## Leaderboards, not citations

Forward-citation traversal is the obvious source and the wrong one. A citation edge says one paper
mentioned another; deciding which mentions are *material* is a judgment, and a judgment made by the
model that is about to be scored is not evidence.

`tools/benchmark/build_retro_corpus.py` uses the archived Papers With Code evaluation tables
instead. Per benchmark it takes the record holder as of a cut date as the seed, and the
**record-holder chain** after it as the gold directions: each paper that set a new best, in date
order, deduplicated by arXiv id. The relation `replaces` is then a recorded fact — a published
number on the same benchmark exceeding the previous record — and no text was read to decide it.

What it costs, stated in the shipped report rather than discovered later: the chain contains only
work that improved a headline number. It excludes work that diagnosed the seed, refuted it, changed
the problem, or was tried and lost. A system scoring 0 here has not been shown to be bad at
research; it has been shown not to predict leaderboard succession.

## The skips are findings

Five benchmarks were queried; three were dropped by the rule. Nothing in the Papers With Code
record beat the 2019 leader on **SQuAD1.1 dev** or **MultiNLI** during 2020–2022, and WMT2014 En-De
produced exactly one record-setting successor. Those benchmarks were saturated. A suite that
dropped them quietly would have hidden that, so `benchmarks_skipped` carries each one with its
reason and the builder prints them.

That leaves **2 seeds and 5 gold directions** — small, and labelled as such. The one non-mechanical
step is the benchmark list itself, a convenience enumeration of five widely used benchmarks; it is
recorded in `selection_rule`, and it biases toward heavily-worked benchmarks whose successors are
famous, which *raises* contamination rather than lowering it.

Shipped in `benchmarks/retro-v1/`: the corpus, the raw leaderboard rows as retrieved, the paper
metadata, the frozen benchmark, the run config and the report. A test rebuilds the shipped corpus
from the shipped inputs and asserts byte equality, so the corpus is provably derived rather than
written.

## Still not done

- **Scoring the engine against it** needs a real model provider to generate directions and an
  adjudicator to decide the generated-direction/gold-direction pairs. The offline stub emits
  structural placeholders, and either placeholders or an unfilled adjudication packet yields no
  measurement. The bar, when someone runs it, is not zero — it is 0.75.
- **No blind human rubric.** recall@k is a regression signal between versions. It is not evidence
  that the output is worth anything, and the two do not substitute for each other.
- **No acceptance run** (the full live-run envelope above is unavailable) and **no B arm** (needs a
  human).

# v2.4.0 — the benchmark can now be scored against (2026-08-12)

v2.3.0 shipped a frozen benchmark and a contamination floor. Nothing could score a system against
it: `research-eval-harness` computed recall@k only if handed adjudicated matches, and nothing
produced adjudicated matches. That is the missing half.

## 1. `tools/benchmark/score_directions.py`

Two phases, because matching a generated direction to a gold one is a judgment and the benchmark's
own scoring contract forbids every shortcut — not string overlap, not an embedding threshold, not a
title match. Two directions can share every content word and mean different things ("scale the
teacher" vs "scale the student"); two can share none and mean the same.

- `--emit-packet` writes the **full cross product** of the top-k generated directions against every
  gold direction, with both texts and no verdicts. Deliberately not a shortlist: a shortlisting
  function would be the real matcher while the adjudicator believed they were doing the matching.
- The rubric ships inside the packet, including the rule that does most of the work — a generated
  direction *strictly more general* than the gold one is `NO_MATCH`.
- An unfilled pair is `UNADJUDICATED`. It is excluded from numerator and denominator, and the run
  is reported `INCOMPLETE` rather than as a low score. Counting undecided as wrong is how an
  unreviewed run comes to look measured.
- Scoring (`--packet <filled>`) reports one of six verdicts. `AT_OR_BELOW_FLOOR` names the only thing that matters
  about a number on this benchmark: **the reference point is 0.75, not zero.** A system at or below
  the floor produces the same number a system that had merely read the literature produces.
- A model judge is allowed and is *recorded as one*, with the caveat attached: a model adjudicating
  whether an output matches literature it has also read has the contamination problem one level up.
- `--emit-harness-inputs` converts the filled packet into what `research-eval-harness` consumes. A
  test asserts both paths compute the same recall from one adjudication — two formats for one fact
  is how a project ends up with two numbers and no way to say which is right.

## 2. `tools/benchmark/blind_rubric.py`

recall@k answers one question: does the system name the directions the field took? It cannot say
whether they are any good, and the gap is not academic — the gold set is leaderboard succession, so
a system that only ever proposes "scale it up" scores well while proposing nothing worth reading.

The blind rubric is the other half, and the instrument is the whole thing:

- Five criteria, each defined by what a **1 and a 5** look like. "Rate novelty" collects the rater's
  mood.
- Arms must be **balanced** — a rater who notices the imbalance can guess the majority arm and beat
  chance without reading — and above a minimum size, below which the comparison is a coin flip
  dressed as a rubric.
- **Tells are stripped and reported**: model-voice phrasing, citation markers, numbered-plan
  formatting, emoji, markdown leads. One "as an AI" and the rater is no longer blind for the rest
  of the session.
- The order is shuffled by a **recorded seed**, so a disputed packet can be rebuilt and shown to
  have had the order it claims. The key is a separate file that raters never see.
- Analysis **refuses** in three cases: the packet no longer hashes to its key (edited after the
  fact, so the arm labels attach to text nobody rated); raters guessed the arm above chance (the
  ratings are then ratings of the arm); or the blind check was never run at all — which is not the
  same as it having held.
- A blank score is `not rated`, never a 1.

## What is still missing, and what is no longer missing

Scoring the innovation engine needed a real model provider **and** a scorer. The scorer now exists;
an actual score still needs the provider to generate directions **and** a human or recorded model
adjudicator to fill the pairwise packet. The blind rubric needed an instrument **and** a panel. It
now needs only the panel.

Still absent for the same reasons as before: the acceptance run (the complete live-run envelope is
not available here) and the B arm of the reproduction study (needs a human).

# v2.5.0 — the B arm is built, and the power analysis says it was specified wrong (2026-08-12)

The reproduction study's B arm — the human-ceiling comparison that gives the agent's 15% a
denominator — has been outstanding since v1.1.0 with the note "needs a human". It needed an
instrument too. `docs/study/b-arm/` is that instrument, and building it surfaced a defect in the
protocol itself.

## The finding: n=8 cannot detect any gap anyone expects

`analyse.py` computes the minimum detectable difference before it will report a gap:

| per-arm n | smallest difference detectable at 80% power |
|---:|---:|
| **8 (the protocol)** | **0.70** |
| 16 | 0.50 |
| 25 | 0.40 |
| 44 | 0.30 |
| 99 | 0.20 |

`REPRO_STUDY_PROTOCOL.md` §3 called n=8 "a cost compromise" giving "a rough estimate of the
ceiling". It does not give a rough estimate. On a simulated fill it produced a human rate of 0.375
with a 95% interval from **0.14 to 0.69** — wide enough to contain both "the agent is fine" and
"the agent is useless" — and the analysis correctly returned `NOT_DETECTABLE` on a
thirty-seven-point observed gap.

Run the B arm as specified and the most likely outcome is a week of a skilled engineer's time
spent learning that the sample was too small to tell. **Budget n≈25**, or run 8 knowing you are
collecting failure-code distributions and qualitative notes rather than a ceiling.

`docs/study/FINDINGS.md` has been corrected accordingly. The old row said "not executed"; it now
says the design as written is not usable and what to do instead.

## The packet: blinding that can be audited

- The eight papers are **drawn, not chosen** — a seeded shuffle whose seed is in the packet.
  Picking by hand selects for papers whose difficulty someone already has an opinion about, and
  that opinion comes from the A-arm results this arm must be blind to.
- Every A-arm outcome is withheld — level, rationale, failure codes, timings, notes — and the list
  of what was withheld ships in the packet, because withholding that cannot be audited is
  indistinguishable from forgetting.
- The builder **refuses** if the A-arm records carry a field it does not classify as carried or
  withheld. A field added later becomes an error rather than a leak.
- Each worksheet asks `saw_a_arm_material` after the fact, and says plainly why a truthful "yes"
  costs nothing: it moves the worksheet into a separate sample rather than wasting it.

## The analysis: four refusals

1. **Different papers, no gap.** The returned packet must hash to its key.
2. **A run past its timebox executed a different design.** Reported separately, never merged.
3. **An unattempted paper is `NOT_RUN`, not a failure.** Counting it as RL0 makes the human arm
   look worse and the agent look better — the exact direction of error this study exists to avoid.
4. **RL1 is not a reproduction.** Success is RL3+. "It ran without erroring" and "right direction
   at reduced scale" are progress; folding them into a success rate is how this kind of study
   reports a number several times too high.

## Still needing something this environment does not have

- **The acceptance run**: credentials matching the selected live model, permitted model and
  scholarly-provider egress, a GPU, an implemented and recorded GPU device mapping, a running
  Docker daemon, a healthy built runtime, a verifiable paid licence or recorded override, the method implementation and fresh first/second project
  directories. `acceptance/run_acceptance.sh` collects its locally checkable preconditions and names
  them together, and refuses `--model offline` outright.
- **The B arm itself**: a skilled engineer for the 20 papers already attempted by the A arm. Any
  larger paired design must first add the same new papers to both arms; the existing A arm caps the
  paired sample at 20.
- **Scoring the innovation engine**: a real model provider plus a human or recorded model
  adjudicator to fill the scorer's packet. The scorer exists; the bar at this point was 0.75.
- **The blind rubric**: a panel. The instrument exists.

# v2.6.0 — an adversarial audit of everything shipped in v2.3–v2.5 (2026-08-12)

Two independent audits, each told to find defects that produce **wrong numbers or false
confidence** rather than style problems. Twenty-three were confirmed by executing the code. Every
test suite was green throughout: none of these raised, and most made a number look *better*.

One of them invalidates a claim published one release ago. That one first.

## The correction: the B-arm power analysis used the wrong test

v2.5.0 reported that the reproduction study's B arm at n=8 "cannot detect anything smaller than a
70-point difference" and needed n≈25 for 0.40, n=99 for 0.20. Those figures came from the
two-independent-sample formula. **Both arms attempt the same papers.** That is a paired design; the
correct instrument is McNemar on the discordant pairs, and using the independent formula on a
positively correlated design inflates the sample requirement — by **2.1× at the 25% discordance
rate assumed below**, and by 2.7× at 20% discordance. (The ratio depends entirely on how often the
two arms disagree, so quoting it without that rate says nothing: at 50% discordance it is 1.0×.)

Corrected, at a 25% discordance rate: n=8 resolves about **0.42**, not 0.70, and 0.20 needs **47**
pairs, not 99. The instrument now runs an **exact** McNemar test rather than comparing an observed
difference against a power threshold — the old affirmative branch would emit `DIFFERENCE_OBSERVED`
on four discordant pairs, where the exact test gives p=0.125.

n=8 is still thin — five discordant pairs all one way is p=0.0625, which does not reject at 0.05 —
but "still thin" is a different claim from "cannot detect anything anyone expects", and the earlier
one was overstated. `docs/study/FINDINGS.md` and the B-arm README carry the correction.

## The scorer counted only the questions the system answered

`score()` built its average from the adjudication packet's items, and a seed the system produced
nothing for contributes no items. **Answering one seed out of five and getting it right reported
recall 1.0 and `ABOVE_FLOOR`** — while the packet builder's own stdout said "it scores 0 by
absence, not by error". It did not. The packet now carries the full gold denominator.

Five more in the same file:

- **Two numbers from one adjudication.** `score()` macro-averaged over seeds; the harness
  micro-averages over gold directions. On unequal gold counts they disagreed — 0.5 versus 0.2 — and
  `to_harness_inputs`' docstring promised they could not. The headline is now micro, matching the
  harness, with the macro reported beside it.
- **A score exactly at the floor cleared it.** `round(2/3, 6)` is strictly greater than `2/3`, so a
  system sitting precisely on the contamination floor was handed the capability claim the module
  exists to withhold. Compared unrounded.
- **`list("use a better teacher")`** produced twenty single-character "directions" and a full
  adjudication packet of nonsense for a human to rate. A seed whose value is not a list is refused.
- **A duplicate gold id shrank the denominator** while still emitting a pair to adjudicate: 1 of 3
  real directions reported as 1 of 2. Refused at packet build.
- The harness input file was written *before* the packet was validated, so a run the tool then
  refused to score left a file on disk that says nothing about the refusal.

## The blind rubric's blind check could not fire

`blind_held = accuracy < 0.65` is one-sided, and the guess had to be the literal string `machine`
or `human`. So raters who identified **every** arm correctly and wrote the labels inverted scored
0.00 and were reported as *"at or near chance; the blind held"* — as were raters who wrote "AI",
"model" or "system". The packet never told them which strings were legal. Now two-sided on
`|accuracy − 0.5|`, unrecognised labels are refused rather than graded as misses, and the
instructions name the two legal strings.

Worse, and more structural:

- **The packet was its own key.** `entry_id = sha(arm, index, text)[:10]` over data the packet
  carries — 800 hashes recovered the full arm assignment for a 20-entry packet. Now salted, with
  the salt only in the key; pass it back to rebuild a disputed packet byte-identically.
- **Nothing bound the key's rows to anything.** Flipping every `arm` reversed the reported
  difference and the output still displayed a hash that appeared to attest to it. The key now
  carries its own hash.
- **The shuffle correlated arm with position.** The hand-rolled LCG's low two bits are a counter
  (`state ≡ seed + n mod 4`), so the last swaps were decided by seed parity. A rater guessing purely
  from slot number scored **0.579** — above chance, under the old threshold, reported as held.
  Mersenne Twister now, seeded and still reproducible.
- **`seed_id` was rater-visible** and non-null only for dict-shaped directions, so it identified the
  arm perfectly whenever machine output was structured and human output was typed as prose.
- Blank entries, out-of-range scores and `"n/a"` are handled: blank is refused at build, out of
  range blocks reporting, and `"n/a"` is not-rated rather than a crash that loses the session.

## The corpus builder lost data three ways, all silently

- **The seed tie-break kept the *later* paper.** The key's second term was `True` for every
  pre-cutoff row, so it was constant and ties fell through to file order — picking T5 (1911) over
  the earlier T5-XXL (1910) at an exact 92.0 tie on the shipped MultiNLI table.
- **Same-month record setters were collapsed.** arXiv identifiers carry only `YYYY-MM`; sorting
  `(date, −value)` processed the better paper first, after which the other no longer beat the
  standing record and disappeared. ImageNet has eleven such months in the evaluation window.
  Fixing it **recovered two gold directions** (FixEfficientNet-L2 and LUKE): the corpus went from 5
  to 7, and the order-unknown ambiguity is now stamped rather than resolved invisibly.
- **Dropped rows were invisible.** A row linked to a non-arXiv venue carries no date and leaves the
  pool. If it held the record, the recorded seed is not the record holder and every `replaces`
  claim is wrong while looking identical. Five are dropped across the shipped tables and are now
  listed.
- Latent: `max()` and `>` hardcoded higher-is-better. A WER spec would have seeded on the worst
  method and called every later, worse number a record. `direction` is now a required spec field.

## The B-arm packet leaked two ways

- **An unanswered question read as "no".** Both `saw_a_arm_material` and `wall_clock_hours_used`
  ship as `null`, and `if w.get(...)` treats `null` as falsy. An engineer who filled in only the
  level produced a clean 8/8 ceiling that had passed neither refusal.
- **The unclassified-field tripwire saw only top-level keys.** A carried field whose value is a
  dict was copied wholesale — and `notes` is already a dict in these records. The day someone turns
  `github_repo` into a struct, the whole A-arm outcome rides inside it.
- The draw used the same broken LCG: measured over 200,000 seeds, the last record in the file was
  drawn **half as often** as the first ten. A draw whose bias is a function of file order is still
  a selection, just on something nobody chose.

## Benchmark v2

Corpus `20bd6243a0369fcd`, frozen at `1b40232d45fcc9d4195cbc203d2e436e`, 2 seeds and **7** gold
directions. The contamination floor was re-probed against the enlarged gold set, in fresh contexts
again: **0.71** (3 of 4 ImageNet, 2 of 3 CoNLL). The bar for any system scored against it moves
with it.

379 Python tests, 26 TypeScript. Every defect above has a regression test that fails against the
old code.

# v2.7.0 — the same audit, turned on the older code (2026-08-12)

v2.6.0 audited the tools written in v2.3–v2.5. This one audits what the multi-arm change of v2.2
touched: the runner, the analysis plane, the evidence graph and the manuscript gate. Nine defects,
all reproduced by executing the code, all in a green suite.

The first one is the worst thing this project has shipped.

## 1. Declaring a state-of-the-art candidate deleted every measurement

`SOTA_NOT_ESTABLISHED` was emitted as an **invalid_condition**, and a fired invalid condition means
the experiment is VOID. Its check read `baseline_assets.sota_established` — a field **no runtime
path ever sets True**. `result-reproducer` hard-codes `established: False`, and nothing promotes it.

So: name a SOTA candidate, and the primary experiment could never clear the condition. Three arms,
six completed runs *including a measured state-of-the-art arm at 0.95*, and the runner reported

```
warning: E-001 is VOID: SOTA_NOT_ESTABLISHED
best_candidate: {"selected": null,
                 "reason": "no run produced a measurement, so no branch can be ordered above another."}
```

Six runs measured. The feature added to make comparisons mean more destroyed the comparison, and
the refusal text asserted the opposite of what had happened. The design comment three lines above
it said *"is not void — it is just narrow"*; the code did the other thing.

Fixed by making the distinction real. Specs now carry `narrowing_conditions` beside
`invalid_conditions`: a fired narrowing condition limits what the result may be claimed to show and
leaves the measurement intact. `SOTA_ARM_NOT_MEASURED` checks the **ledger** — a new
`ledger_arm_completed` check kind — so a state-of-the-art arm that actually ran actually clears it.
The frontier claim itself is still hard-blocked by `claim-citation-auditor`, which is where that
enforcement belongs.

## 2. `SEEDS_TOO_FEW` got weaker as an arm got worse

The check counted completed runs per arm — over the arms that *appeared in the ledger*. An arm with
one completed run FIRED; the same arm with **zero** produced no group key and CLEARED. Combined
with defect 8 below, an arm starved to nothing escaped the check entirely. Expected conditions now
come from the spec.

## 3. The cross-experiment guard was void for arm-less rows

`_branch` returned a bare experiment id when a row carried no arm — and the runner's own docstring
says such rows exist, while the ledger is append-only, so one project holds both shapes. For those,
`_experiment_of` returned `""`, so the guard compared `"" != ""` and **passed every pair**,
generating exactly the cross-experiment contrasts it exists to block and inflating the
multiple-comparison family with them. Rows without an arm now read as `candidate`, matching the
documented default.

## 4. An ambiguous control was discarded in silence

An experiment with two control-named arms gets no control — correct — but nothing said so.
`NO_DECLARED_CONTROL` only fires when the control set is *globally* empty, so one clean experiment
elsewhere suppressed it. A real +0.30 effect was filed as "a difference, not an improvement" with
the reading *"without a declared control"* — when a control had been found and thrown away — while
a +0.005 effect elsewhere drove the recommendation. Now an `AMBIGUOUS_CONTROL` finding at HIGH.

## 5. "No metric declares a direction" when the direction was declared

A branch is scored by its candidate arm. If the candidate was starved and only controls measured,
`_rank` fell through to the direction-missing branch and told the operator to add a `direction`
that was already there — sending them to fix the wrong thing and hiding the real cause. Now named:
*"N branch(es) measured something but not their candidate arm."*

## 6. A contrast with no direction reads as an improvement

`_contrasts` reported `difference: +0.70` against the state of the art for a candidate that was
**85% worse** — the metric was `val_loss`, direction `minimize`, and the direction was available in
the same function's caller and simply never passed in. `ranked_branches` is a published artifact.
Each contrast now carries `direction` and an explicit `candidate_is: better | worse | undetermined`.

## 7. The timebox ate the strongest arm without saying so

Arms run `baseline, candidate, sota`, so the timebox is spent last-first and takes the comparison
arm — a defensible priority. `TIMEBOX_EXHAUSTED` was the only NOT_RUN reason with no warning, and
the lost contrast vanished from `contrasts` with no trace. A real run: sota measured nothing, the
winner was declared from a single seed, and the skill's warnings said nothing. Now the exhaustion
is reported with its per-arm counts, and an uncomputed contrast is emitted with `absent_because`
rather than omitted — absent is not zero and is not negative.

## 8. Own-work claims traced to nothing, and unbound their own figures

`_own_claims` listed `run_id`, which `_base_entry` sets to the *orchestration* run for every row —
so a claim promising "a number can be traced to the runs that produced it" listed the same id three
times. Now `attempt_id`. Separately, the edge's `branch` was `E-001:candidate` while the analysis
group for the same arm-less rows was `E-001`, and `_edge_result` returned only the most specific
id: the figure was refused as `figure_data_missing` **for a claim that was fully supported**. The
binder now sees every identifier the edge names, with the numeric read-back check unchanged.

## 9. The frontier gate missed the common phrasings and blocked correct text

Three false negatives, each a real state-of-the-art claim that passed with zero blockers:

| draft | why it passed |
|---|---|
| `ForgeNet outperforms all prior methods on WMT14.` | no self-reference pattern matches a system's own name |
| `Our approach is simple. It outperforms all prior methods.` | the self-reference is in the previous sentence |
| `We report the highest accuracy ever recorded on this benchmark.` | the pattern had no plain-words branch |

And a false positive class: the sentence splitter's lookahead admitted only uppercase letters and
brackets, so **a sentence beginning with a digit never started a new sentence** — routine in results
prose. `"Our method improves over the baseline. 12 recent systems report state-of-the-art numbers."`
merged into one "claim" and became a hard submission blocker on correct text.

Fixed: the splitter admits digits (with abbreviation lookbehinds, so `e.g. 3 datasets` stays
whole); self-reference carries forward within a paragraph across a continuation pronoun; an
unattributed frontier claim is read as this paper's own, because a sentence claiming the frontier
and citing no one is not describing the literature; and a frontier phrase *mentioned* rather than
asserted — `compared to the state of the art`, `e.g. state-of-the-art transformers` — no longer
counts.

389 Python tests, 26 TypeScript. Every defect has a regression test that fails against the old code.

# v2.8.0 — the state-of-the-art arm is now searched for, on this paper's own topic (2026-08-12)

v2.2.0 added a state-of-the-art arm and populated it from whatever was lying around. Three things
were wrong with that, and together they meant an ablation could be anchored to a paper from a
different field.

## 1. Nothing searched for the state of the art

`literature-search` emitted one undifferentiated query family — title, methods, datasets — which
finds neighbours. `result-reproducer` then keyword-filtered those results for titles containing
"state-of-the-art". That is a search for a phrase, not for the frontier.

There is now a tagged **sota query family**: one query per (task, dataset) the paper actually
names — *"state of the art <dataset>"*, *"best performing method <dataset> benchmark results"*,
*"<task> <dataset> outperforms previous state of the art"*. Every hit records the family that found
it, and only the sota family is mined for candidates. The family is never squeezed out by a long
method list, because it is the only one that can answer the question the ablations depend on.

## 2. `benchmark_matrix` contained nobody's results

It wrote one row per source-paper metric, every value the literal string **"see paper"**. An
artifact named *"Benchmarks x reported results"* with no reported result from anybody in it — which
is exactly why the downstream search for a candidate found nothing and reported that as "no
state-of-the-art candidate exists".

It now also carries competing results extracted from sota-family abstracts: a number that
co-occurs with one of the paper's named datasets inside a short window, with **the sentence it came
from kept in the row**. A number lifted out of prose is a claim about what someone wrote, not a
measurement, and the reader has to be able to check it in one click.

## 3. A candidate could come from any field at all

The gate was "the title contains the words state-of-the-art". Protein folding satisfies that.

Every candidate is now gated on topic and the matched evidence is recorded per candidate:

- **`direct`** — names one of this paper's benchmarks. A leaderboard is a shared measuring stick.
- **`weak`** — overlaps the task in at least two content words but names none of the benchmarks.
  Recorded as weak *because it may not be measured the same way at all*.
- **`asserted`** — supplied by the operator via `--set sota_methods`. Not gated, and labelled so a
  reader can see which candidates were asserted rather than found.

Everything else lands in `rejected_off_topic` with its reason. Candidates are ordered
strongest-evidence-first — shared benchmark before task overlap, higher reported number before
lower — because the blueprint takes the top five and the order therefore *is* the selection.

## What reaches the ablation

`spec.sota` now carries `topic_match_strength`, `searched_for` (the task and datasets that were
queried, and the gate itself, so it can be audited), `rejected_off_topic` count and
`retrieval_coverage`. Ablation specs carry a **`topic_risk`** separate from `strawman_risk`,
because "the anchor may not be the same measurement" is a different and worse failure than "the
anchor was never run", and folding them into one caveat lets the worse one read as the milder.

An empty candidate list under `UNKNOWN_COVERAGE` is now reported as a fact about the search:
`absence_means` says so in words. It was previously indistinguishable from "there is no state of
the art in this field".

400 Python tests, 26 TypeScript.

# v2.8.1 — a weak topic anchor is now binding, not annotated (2026-08-13)

v2.8.0 taught the search to tell a same-topic frontier candidate from a stranger, and wrote the
answer into `spec.sota.topic_match_strength`. Nothing downstream read it. A `weak` anchor — shared
task words, none of this paper's benchmarks — produced a real completed run, a real difference, and
a manuscript free to call the result *state-of-the-art*. The caveat existed and sat in a file
nobody's gate consulted.

## The manuscript gate

`claim-citation-auditor` already refused a frontier claim with no measured sota arm. It now also
refuses one where **every measured anchor is weak**, under its own blocker kind,
`sota_claim_on_weak_topic_anchor`:

> the state-of-the-art arm completed, but every candidate it ran against was admitted on shared
> task terms alone (topic_match_strength=weak): HyperMoE names none of this paper's benchmarks
> (WMT14, C4), so 'strongest' here may be strongest at a different measurement. The run is sound;
> the word is not. Retrieval coverage for that search was UNKNOWN_COVERAGE.

The blocker quotes `searched_for` and `retrieval_coverage`, so the author sees what was searched
and how thinly, rather than being told to go find something better with no idea what was already
looked at.

Three properties this was written to keep:

- **One `direct` or `asserted` anchor anywhere licenses the claim.** The caveat on the weaker
  anchors stays in their specs. A project-wide veto over one weak arm would train operators to
  delete the field.
- **The two failures never share a kind or a check.** `sota_claims_have_a_measured_sota_arm` and
  `sota_claims_rest_on_a_same_topic_anchor` are separate lines in `integrity_gate`. Merged, the
  second reads as a milder form of the first — and it is the one that is fixed by finding a
  different comparison rather than by running the one you have.
- **A weak anchor is not itself a defect.** Only the word "strongest" makes it one. Prose that
  claims nothing about the frontier is never touched.

## The acceptance rubric (v1.1.0)

The per-claim gate fires one sentence at a time, and only on a paper that uses the word. A project
could declare a frontier arm, anchor it to a stranger, never run it, write around the word, and
pass every per-claim check ever written. Two project-level checks close that:

- **`E2.4_sota_anchor_topic_declared`** — every spec with `sota.required` records a
  `topic_match_strength`. `NOT_APPLICABLE` when no spec declares a frontier arm.
- **`E2.5_sota_arm_measured_or_declared_unmeasured`** — it ran, or it carries
  `SOTA_ARM_NOT_MEASURED`. The same disjunction as `E2.2`: the rubric does not require the frontier
  to have been run, it requires the project to know which of the two it has.

407 Python tests, 26 TypeScript.

# v2.8.2 — two adversarial audits, 30 confirmed defects (2026-08-13)

Two independent auditors were run over the state-of-the-art chain and over the execution/analysis
planes. Every finding below was reproduced against repo code before it was fixed, and every fix has
a test that fails without it. **453 Python tests, 26 TypeScript** at the time of writing (462 after v2.8.3).

The four that could have published a wrong result.

## A void experiment was analysed and published

`experiment_tree.void_experiments` was written by `experiment-runner` and read by **nobody**. The
runner refused to let a void experiment nominate a best candidate — its own words are "a void run is
not a negative result, it is nothing" — and then `data-analyst`, `integrity-auditor` and
`finding-memory` each read the same rows straight off disk. A void experiment produced a `scientific`
finding at **high** confidence, tagged `positive`.

`_require_ledger` now drops void experiments once, for every skill that analyses the ledger, and
refuses outright when every experiment is void. (Contract amendment: `integrity-auditor` consumes
`experiment_tree`.)

## The keep/kill verdict could be decided by a comparison the candidate was not in

`sota vs baseline` is a real, correctly oriented, frequently significant contrast — between two
methods that are not ours. It entered `evidence.positive` indistinguishably from the candidate's own
result. With a candidate identical to the baseline and 20 points behind the frontier
(g = −104, Holm p = 2.6e-10), the decision artifact read **CONTINUE — "1 comparison(s) remain
significant after Holm correction"**.

Every oriented contrast now carries `decides_the_candidate`, and only those vote. The others are
still reported, with a sentence saying why they do not bear on the decision. Separately,
`candidate vs sota` had no orientable reference at all and fell into `between_variants` — the bucket
that can never become negative evidence — so falling behind the frontier produced no negative
finding anywhere. It does now.

## The seed-count void condition cleared at half the declared seeds

`full_ledger` re-read the ledger that `append_jsonl` had written 28 lines earlier and concatenated
the same entries again. `min_completed_runs_per_condition` — the condition the compiler puts on
every spec — therefore counted every run twice: 3 of 5 seeds reported `{'baseline': 6,
'candidate': 6}` against a need of 5, and CLEARED. Deduped by `run_id`. The check now also counts
**distinct seeds** rather than rows, because a retry is not a sample.

## Paired data was tested as unpaired

The runner executes the same declared seed list for every arm, so the arms are seed-matched.
`_one_test` used `ttest_ind`. A consistent +0.015 gain on all five seeds came back at Welch
p = 0.816 and was filed UNDERPOWERED — *"we could not have detected it"* — for data in which every
seed moved the same way. Now paired when the seeds match, with an exact sign test where the paired
variance is zero, and Welch only where the arms genuinely do not share seeds. Holm is also applied
per stratum, which is what `family_definition` always claimed and the code never did.

## The frontier gate: four silent passes and two false positives

Silent passes — each returned no blocker, and no blocker is a pass:

- a completed `sota` row whose `experiment_id` matched no compiled spec;
- a `sota` row recorded under a spec that declares no sota arm;
- a spec that declared the arm but never recorded a `topic_match_strength`;
- an `experiments/` directory that could not be read at all — a partial write switched the gate off.

All four are now `sota_claim_on_unverifiable_anchor`. Absence of the field is not evidence that the
match was good.

False positives — a gate that blocks correct prose is a gate that gets switched off:

- *"compared to **the** state of the art"* was blocked. `SOTA_MENTION_RE` required the phrase to
  follow the trigger immediately, so the one phrasing the code's own comment names as the canonical
  mention was the one it caught. Nearly all English writes the article.
- *"These top-performing systems are widely adopted."* was blocked as this paper's frontier claim,
  inside any paragraph containing "we". Sentences that open by naming somebody else's work are no
  longer read as ours.

## The search: what it was throwing away

- **The frontier paper was retrieved and then discarded.** Dedup kept the family that saw a hit
  *first*, and the related-work family (which includes one query per dataset) runs first. Both
  consumers filter on that tag, so a paper titled *"HyperMoE sets a new state-of-the-art on
  WikiText-103"* was returned by 4 of 6 queries and dropped from `benchmark_matrix` and from `_sota`
  — after which the system reported that the field has no state of the art. Families are now merged.
- **`"pile" in "compiler"`** graded a tensor-compiler paper as a `direct` benchmark match. Benchmark
  names are matched as names now, with word boundaries.
- **`--set sota_methods=Mamba-2`** iterated the string character by character into five one-character
  `asserted` candidates — and one `asserted` candidate anywhere switched the topic gate off for the
  whole project.
- **Every field of `benchmark_matrix` is quoted on write and was split on raw commas on read.** One
  comma in a title moved the reported number into the citation column and the prose into the number
  column; a comma in a *metric* name defeated the source-paper guard and anchored the paper to a
  fragment of its own metric.
- **Candidates were ordered by `-float(value)` with no metric direction.** On perplexity — or error
  rate, WER, FID, latency, loss — that puts the worst method first, and the blueprint's `[:5]` then
  drops the best one. Ranking now uses the declared direction, and where none is declared it says so
  instead of guessing.
- **Dedup ran before the sort**, in source order, so the operator's bare name displaced the same
  method's shared-benchmark evidence and its reported number, invisibly. Sorted first, and duplicates
  now merge rather than vanish.
- **`searched_for.datasets` claimed benchmarks the search never queried.** The sota family was
  emitted per dataset and then capped, so a paper naming four benchmarks searched two and reported
  four — and the manuscript gate quotes that field back to the author as evidence. Queries are now
  emitted in rounds, every named benchmark gets one, and `searched_for` reports what the retrieval
  log actually contains, with `datasets_never_queried` beside it.

## Smaller, still wrong

- A project with **no known frontier** had its entire primary experiment voided by its own empty
  sota arm: `spec["sota"]` is a dict even when nothing was found, and three rules read "is a dict" as
  "is a runnable arm". `required: False` is now honoured by the arm list, the resource estimate and
  the void condition alike — without deleting the `searched_for` audit trail.
- **Runs that never started were counted as failures**: 8 unstarted runs reported *"8 of 12 runs
  failed (67%)"* and blocked the analysis for a survivorship bias that did not exist. Now
  `RUNS_NEVER_ATTEMPTED`, reported separately, with failure rate over attempted runs.
- **A broken guard destroyed what it guarded**: the generated entry point called
  `check_invalid_conditions` outside every `try`, so a condition missing `value` raised *after* a
  successful measurement and the run was recorded FAILED with empty metrics.
- **`INCOMPARABLE_STRATA` could never fire.** The stratum read `evaluator_version` /
  `environment_digest`; the runner stamps `evaluator_digest` and nests the environment hash inside
  `sandbox`. Every real run landed in one `undeclared` stratum. The runner now stamps the digest
  flat and the reader knows both names.
- **Every metric in every project was labelled `exploratory`.** `experiment_specs` is a glob, so
  `store.read` on it always returned the default: `NO_EXPERIMENT_SPEC` fired on every run and
  `POST_HOC_PROMOTION` was unreachable. Both now resolve specs through the same loader the runner
  uses.
- **A tie on a minimize metric read "better"** — `False == False`.
- **NaN passed the runner's metric gate** as a `float`, was dropped by the analysis plane's
  `isfinite` filter, and the two artifacts disagreed about how many measurements existed.
- **An arm written as a scalar** (`baseline: resnet50`) was dropped in silence, and the resource
  estimate and void condition agreed with the wrong arm list, so nothing could notice.
- The timebox warning asserted which arm was starved instead of naming the ones that were.

## Acceptance rubric v1.1.0, with teeth

`E2.4` and `E2.5` as first written could not fail on anything the compiler produces: the compiler
attaches a topic match to every candidate, and emits `SOTA_ARM_NOT_MEASURED` on exactly the specs
where `sota.required` is true. `E2.4` now requires a strength the manuscript gate can act on
(`direct` / `asserted` / `weak`); `E2.5` requires the condition to carry a machine-evaluable
`check` — a bare code is prose, and `rf_runtime` returns prose as UNCHECKED, never as satisfied.

# v2.8.3 — the changelog audited against the code (2026-08-13)

Two auditors were pointed at `CHANGELOG_v2.md` itself, with one instruction: find claims the code
does not honour. A changelog claim that is not true is a defect — either the code regressed, or the
claim was never accurate — and this file is what a buyer reads to decide what the system does.

Fourteen survived verification. Nine were the code being wrong.

**Ordering.** The file was chronological through v2.7.0 and then reverse-chronological, because each
new entry was prepended. v2.8.0 → v2.8.1 → v2.8.2 now read in order.

## The code was wrong

- **A licence override never reached the release manifest.** The refusal message tells the operator
  the bypass "will surface in the release manifest"; `licensing.check`'s docstring says "the record
  is what the release manifest reads". `ReleaseGate._manifest` built every other field and not that
  one, so an unlicensed run's manifest was the exact shape of a licensed one. The whole design of
  the override is that bypassing leaves a mark where an auditor looks. Now
  `release_manifest.licence_overrides`, with `count: 0` for a clean run — absence would be
  indistinguishable from a field nobody wrote.
- **`claim-evidence-graph` published claims from void experiments.** v2.8.2 fixed this in
  `_require_ledger`, which only three of the six ledger-reading skills call. A fully void experiment
  still produced a `SUPPORTED` own-work claim that the manuscript could then cite — the same defect
  one skill to the left. The void filter is now a shared helper (`invalid_conditions.drop_void`) and
  every ledger reader uses it: the evidence graph, the manuscript auditor, the review simulator and
  the deck factory. Contract amended for all four.
- **`data-analyst` still counted never-started runs as failures.** Only `integrity-auditor` was
  fixed, and `analysis_results.json` is the artifact everything downstream quotes: eight unstarted
  runs published `failure_rate: 0.5` and the report said so in words. Now `n_attempted`,
  `n_never_attempted`, and a separate "Runs that never started" section.
- **An undecided pair was scored as a miss after all.** The scorer's `why` string, its module
  docstring and the rubric shipped inside every rater packet all promise that an `UNADJUDICATED`
  pair "contributes to neither numerator nor denominator". The denominator was `total_gold` — the
  full gold set — so one unfilled pair produced *exactly* the number that grading it `NO_MATCH`
  produces, and only the `INCOMPLETE` verdict stood between that and a reader quoting it. Undecided
  gold directions now leave both, reported as `gold_undecided`. The distinction the fix has to keep:
  a gold direction the system never addressed is still a miss, or a system could answer one and
  report 1.0.
- **`benchmark_matrix` extracted the digits of the benchmark's own name.** The result search started
  *at* the dataset name and `_RESULT_NEAR`'s lookbehind is satisfied by a hyphen, so
  `WikiText-103` yielded `103` — not the 10.2 in the abstract. That became the candidate's
  `reported_value`, which v2.8.2's direction-aware ranking sorts on, so the top-5 selection was
  driven by digits in a benchmark's name. The failing case was this changelog's own worked example.
- **`finding-memory` filed `sota vs baseline` as a confirmatory-candidate positive.** `_decide`
  honoured `decides_the_candidate`; `_from_effects` dropped it and hard-coded the tags, so a contrast
  between two other people's methods entered `findings.jsonl` at **high** confidence — the cross-run
  memory the next experiment is planned from.
- **The weak-anchor blocker stopped naming the paper's benchmarks.** v2.8.2 redefined
  `searched_for.datasets` to mean *what was queried* and moved the paper's list to
  `datasets_named_by_the_paper`; the blocker kept reading the old field. With no retrieval log it
  printed an empty parenthesis and told the author to "compare against a method that reports on this
  paper's benchmark" — the exact "no idea what was already looked at" failure it exists to prevent.
  It now reads both, and says which benchmarks the search actually reached.
- **An unverifiable anchor was hidden by a weak one.** The unverifiable branch was guarded on "no
  other anchor is weak", so in a project with one of each the author was told only about the weak one
  and would fix the wrong experiment. Both kinds are emitted.
- **Every acceptance report stamped the wrong rubric version.** `RUBRIC_VERSION = "1.0.0"` while
  `RUBRIC.md` said 1.1.0 — so a stored verdict could not be matched to the thresholds that produced
  it, which is the one thing a version stamp is for. Read from the rubric now, with a test.

## The changelog was wrong

- **`--score` is not a flag** and there are six verdicts, not four. Scoring is `--packet <filled>`.
  The module docstring said the same thing and is corrected too.
- **"Enforcement on both sides of the language boundary"** — the TypeScript CLI computes the
  restricted list, prints it, and dispatches the gated stage anyway. The gate is at the Python
  boundary, which is where the sentence's own rationale puts it. One gate at the choke point, not
  two.
- **`established` "stays False until…"** promises a transition with no implementation. It is
  hard-coded and nothing promotes it; the field is a placeholder for a ladder that is not built.
- **"2.7× at a 20-point difference"** was quoted next to a 25% discordance rate, where the ratio is
  **2.1×**. 2.7× is the figure at 20% discordance. The ratio is a function of the discordance rate
  alone — at 50% it is 1.0× — so it means nothing quoted without one. Corrected in four files.
- **"asserts byte equality"** described a test that compared parsed JSON. The stronger property does
  hold, so the test was strengthened to assert what was claimed rather than the claim weakened —
  only byte equality rules out a rebuild whose key order or float formatting drifted.

**462 Python tests, 26 TypeScript.**

# v2.8.4 — release and execution claims audited to their boundaries (2026-08-13)

The v2.8.3 audit found claims that were locally true but stopped one boundary short: a sandbox
record could describe a container without proving that the same immutable local image was run; a
licence could verify in TypeScript without proving the paid Python choke point opened; a release
manifest could quote a digest without safely reading the file it described; and an acceptance
report could grade internally coherent JSON while saying nothing about a live provider or GPU.

v2.8.4 closes those software boundaries and narrows the words around the external ones. It is not a
production certification. A 2026-08-20 follow-up completed the full automated PDF18 corpus rerun,
but no live GPU acceptance run, human PDF-quality adjudication, human B arm, complete live-provider
compatibility run or production-key release has been performed.

## Untrusted execution now has one fail-closed path

Generated or third-party experiment code now runs only after `sandbox-provisioner` validates a
strict local Docker boundary:

- the absolute Docker launch entry and its resolved regular client target/digest are bound
  separately, preserving `argv[0]` dispatch for symlinked multicall clients while still proving the
  bytes that implement the client;
- the active context, endpoint and daemon must resolve to the local Unix-socket envelope rather
  than a remote Docker host;
- the image must already exist locally, resolve to an immutable image ID, pass a restrictive
  non-root smoke test and remain the exact image used by the runner; no pull is attempted;
- `project/code` and the requested entry point are canonicalised without symlink traversal and the
  code directory is mounted read-only;
- the container has no network, a read-only root filesystem, dropped capabilities,
  `no-new-privileges`, bounded CPU/memory/process resources, a constrained temporary filesystem and
  a non-root user; and
- output is bounded to 4 MiB, decoded defensively, and the exact container ID from the invocation's
  cidfile is cleaned up on timeout, output overflow and error paths.

There is no host fallback for untrusted code. `trusted-host-code` remains available only for code
the operator explicitly reviewed, and the name now describes the cost: it is **non-isolated**.
Literal `trusted_host_authorized=true` is required by both provisioning and execution, and both
stored authorization records must name the same non-empty provisioner run ID. On resume, the runner
must receive the literal authorization again; coherent prior provisioner evidence may be reused, but
a copied project artifact alone cannot silently unlock host execution.

The environment lock is captured from inside the exact validated image with `pip freeze --all`, not
from the host. Runtime invalid-condition evidence is also taken from the actual parsed `RF_RESULT`:
`checked`, `fired`, `unchecked` and `error` are recorded separately. A predicate mentioned in source,
a comment or dead code is no longer accepted as proof that it ran.

GPU allocation is now an explicit strict-Docker contract rather than an image-name inference.
Literal `sandbox_gpu_required=true` runs a no-network/read-only/non-root `torch.cuda` probe with
Docker `--gpus all`, records typed device/capability and PyTorch/CUDA evidence, reuses the same
device request for every experiment, and binds it into each ledger row. Provisioner and runner
must each receive that literal request; the runner records its current invocation while the three
provisioner records must agree on their source run ID, so preseeded artifacts alone cannot authorize
device exposure. The acceptance grader
requires the manifest, config, validation, executed command and completed rows to agree. CPU runs
remain unchanged; an unavailable or malformed GPU path fails closed without host fallback.

## The frozen PDF defect list is implemented and the automated corpus was rerun

The three optional local real-PDF fixtures now pass all 26 ingestion regressions. The implementation
sanitises lone surrogates; accepts decimal, roman and small-cap headings; excludes post-References
claim mining; reports measured normalization; prefers usable PDF title metadata and removes
repeated running headers; names extractor chunks `text_block`; indexes `Figure`/`Fig.` and roman
tables; refuses numeric/axis/generic cue words as named entities; de-hyphenates line wraps; protects
common scholarly abbreviations during sentence splitting; and uses a numeral-based quantitative
claim signal.

`docs/pdf18-corpus.json` now freezes all 18 operator-local PDFs by commit, path, bytes and SHA-256;
`docs/pdf18-runner.py` verifies those bytes, runs ingestion and modelling offline and serially, then
writes the retained `docs/pdf18-report.json`. The final post-fix run passed 18/18 source-integrity,
18/18 pipeline and 18/18 automated non-human protocol checks over 375 pages and 191,790 words. It
also exposed and closed two more real defects before the final report: repeated bibliography
continuation headings could erase the first `References` boundary, and browser print date/URL
headers could become the title.

The report does not turn an automated pass into a human quality claim. The machine-only result is
named `automated_protocol_status: PASSED`, while report-level `overall_status` remains
`PARTIAL_NOT_ADJUDICATED`; a generic top-level `PASSED` was too easy to quote without its scope. It records 17/17
non-boilerplate titles, only 5/17 exact historical section counts, 16/17 exact figure counts and
17/17 exact table counts. The historical 40-claim sample IDs and labels were not retained, so the
report is scoped `automated_nonhuman_protocol` and complete quality remains `NOT_ADJUDICATED`.

## The licence proof now crosses the language boundary

- Python now verifies the same compact UTF-8 canonical bytes that the Node issuer signs, using
  Ed25519 from `cryptography`. The previous Python verifier could not establish equivalence with a
  genuinely issued licence.
- The TypeScript bridge injects the public key compiled into the build and removes or replaces an
  ambient `RESEARCHFORGE_LICENSE_PUBKEY_PEM`; an ordinary community build cannot be pointed at a
  different key through that variable.
- `tools/license/release-build.mjs` requires both the substitution public key and a matching genuine
  licence. It verifies the compiled fingerprint and licence, proves positive paid Python access
  through the real bridge, and restores the source sentinel after the build. Community refusal is
  exercised separately by the Python gate, runner and read-only preflight tests; the release-builder
  invocation itself does not execute that negative leg.
- The read-only `license-check` preflight covers the exact nine paid pipeline skills declared at the
  bridge — scaffold, evaluator, experiment, manuscript/audits, figures/deck and release — without
  running their project mutations.
- Edition wording was corrected: the default `team` feature set is experiment engine plus
  manuscript; deck and release packaging are present only when explicitly issued. `site` carries
  all four feature families.

The enforcement remains intentionally bypassable in self-hosted source, with an explicit recorded
override. No production private key was created or retained here, no production artifact was
code-signed, and the source bundle contains no root software licence granting public
redistribution.

## `--redo` invalidates what the artifact graph says, safely

Redo previously deleted only the selected skill's own outputs. A downstream artifact could survive
and then appear current even though its build dependency had changed. The CLI now follows every
declared acyclic build-dependent edge transitively and invalidates the complete downstream output
set before rerunning the producer.

Invalidation rejects absolute, escaping and symlinked artifact paths, resolves every target under
the project root, and removes through an atomic quarantine step. A malformed graph or a target that
cannot be proven local is a refusal, not permission to delete. The ordinary execution order and the
redo closure are tested from the same generated contract.

## Release packaging has a filesystem boundary

`release-gate` no longer trusts a path merely because provenance contains a digest:

- every deliverable and provenance-manifest entry must be a project-relative regular file with no
  absolute component, `..` component or symlink traversal;
- every source file is re-read and rehashed before packaging; missing, changed or malformed entries
  block release, and hard links cannot alias a file outside the bundle;
- serialized provenance events are shape-validated, the latest write must name the contract
  producer, canonical path and matching digest, and ordered audit writes must remain newer than the
  inputs they authorize. A resumed release may consume unchanged earlier-run outputs, but records
  each `source_run_id` and requires a fresh release-gate read in the current invocation;
- the release directory and every copy destination must remain canonical descendants of the
  project, with no pre-seeded symlink redirect; a private staging tree is fsynced and published in
  one rename, so a failed copy exposes no partial new release;
- malformed provenance records are blockers instead of parser crashes; and
- packaging uses only fixed contract deliverables that survived those checks; an input manifest
  cannot promote an arbitrary file merely by labelling it `deliverable`.

This is a safe local release boundary, not a signed supply-chain statement. The emitted manifest is
still unsigned and `submission_ready` remains false.

## The inference policy is data, so invalid policy now blocks

The analysis plane previously accepted malformed keep/kill criteria that Python would coerce in
surprising ways — including booleans as numbers, non-finite values and probabilities outside their
domains. `keep_kill_criteria` must now be an object; `alpha` and target power must be finite and
strictly between zero and one; minimum seeds must be an exact integer of at least three; minimum
effect size must be finite and positive; and maximum failure rate must be finite, non-negative and
less than one. An invalid contract raises `invalid_inference_policy` before findings are published.

## Acceptance rubric v1.6.0 fails closed on copied or incoherent evidence

The grader now treats evidence identity and completeness as part of the measurement:

- ledger, tree and state histories must reconcile to one canonical attempt identity; conflicting or
  duplicated identities are corrupt, not extra evidence;
- completed-run denominators, per-arm seed sets, planned arms and release state are cross-checked;
- void experiments cannot contribute claims, findings, figures or release evidence;
- a claim must bind both an exact locator and text, numeric-check booleans must be literal booleans,
  and statistical thresholds must be finite and valid;
- ablation coverage is derived from the declared parent mechanism and actually completed seed
  identities per arm, not a self-reported count;
- the second-run requirement checks coherent and distinct run IDs across ledger, tree, state and
  release evidence, with an arm-aware fingerprint; and
- release and environment dimensions safely rehash artifact paths, reconcile both release
  manifests one-to-one with every physical non-metadata bundle file, require the complete sandbox
  configuration and require every completed row to carry the exact environment lock and NVIDIA
  allocation command/evidence when acceptance requires a GPU.

The legacy inline invalid-condition route now consumes only
`provenance.invalid_conditions_runtime`. The acceptance harness also validates its own invocation:
reserved flags cannot be smuggled through pass-through arguments, the selected provider must match
the available key, Docker must pass the same local immutable-image checks, implementation mapping
must be complete and fresh project directories must be safe. `grade.py` remains an artifact grader:
absence of a synthetic marker is not proof that a live model or scholarly provider was used; GPU
allocation passes only through the persisted strict provisioner/command/ledger proof above.
Version 1.6.0 also binds evidence, experiment specs, SVGs and release inputs to no-follow file
descriptors, rejects hard links, and verifies identity before and after each read. A path validated
as local cannot be swapped to an external `PASS` symlink between validation and grading.

## Scholarly providers fail loudly instead of becoming fixtures

OpenAlex, Crossref, Semantic Scholar and arXiv now have live HTTP adapters, bounded response parsing
and explicit capability reporting. Offline fixture replay remains a separate mode. An actually
required key, HTTP failure or malformed live response reports the provider unavailable; it does not
silently return fixture evidence. Semantic Scholar public paper search accepts the optional
`SEMANTIC_SCHOLAR_API_KEY`, separate from `RESEARCHFORGE_CONTACT_EMAIL` used for the
OpenAlex/Crossref polite pools. The registry no longer mistakes that optional key for a prerequisite.

These adapters are covered by deterministic fixture, retry and failure tests. The request boundary
sends a standard `Accept` header, performs one bounded 429 retry, respects a capped `Retry-After`,
and exposes system-proxy trust as an explicit run option rather than silently bypassing enterprise
egress. The focused suite passed 52/52. Direct one-result probes succeeded for OpenAlex, Crossref
and arXiv on 2026-08-20; Semantic Scholar's shared unauthenticated pool returned HTTP 429 twice
without `Retry-After`, while its official status remained operational. That partial observation
does not verify a full live pipeline, service availability or current end-to-end API compatibility,
which remain external gates.

## External evidence follow-up (2026-08-20)

`docs/external-gates-v2.8.4.json` and its Markdown companion preserve six external gates and the
readiness subgates actually observed:

- the corrected OrbStack Docker launch-entry/client/daemon identity preflight passed, while the
  Apple M3 host measurably lacks NVIDIA tooling and runtime;
- the B-arm packet, blind rubric and direction scorer ran 71 instrument checks successfully, but no
  human returned a completed worksheet and no real innovation portfolio was adjudicated;
- `docs/human-gates-v2.8.4.py` and `docs/HUMAN_GATES_v2.8.4.md` now freeze and verify coordinator-
  bound B-arm, PDF18-human and real-provider innovation packets. Six fail-closed regressions reject
  AI/blank attestations, attestations copied to a different frozen subject, mutable baselines,
  rehashed blind-key arm flips, unrelated provider digests, reused human identities, invalid
  failure codes and incomplete or tampered returns; this tooling is readiness evidence, not a claim
  that the named people performed the work;
- the PDF18 source, offline pipeline and automated protocol passed 18/18, while complete human
  quality remains unadjudicated;
- 52/52 live-provider compatibility/refusal tests passed, and OpenAlex, Crossref and arXiv returned
  a normalized direct live result; Semantic Scholar remained blocked by two HTTP 429 responses from
  its shared public pool while the optional key was unset; and
- a fresh ephemeral key/licence crossed issuer, compiled fingerprint, TypeScript verification and
  the Python paid-stage gate, while production key custody and signed-release evidence remain absent.

Each subgate names its evidence run and interpretation limit. None is promoted to GPU acceptance,
human performance, innovation quality, full service compatibility or production certification.

## One distribution version and one reproducible source archive

The root package, workspaces, lockfile, Python project metadata and Python module now all report
`2.8.4`. The `0.3.0` values in skill frontmatter, `skill-catalog.json` and `merge-map.json` are the
separately versioned skill-contract lineage, not package-version drift. Python dependencies now name
the libraries used by ingestion, statistics, figures, deck generation, schemas, licensing and live
HTTP; a clean test installation is `pip install -e 'python[dev]'`.

`tools/release/build-source-archive.py` builds from a sorted explicit allowlist, uses fixed archive
timestamps/modes and stored entries, rejects symlinks and non-regular files, and refuses to overwrite
an existing target. The two shipped study workbooks are exact allowlist entries rather than a suffix-wide
exception; OOXML macros/external links and private-key markers hidden in otherwise allowlisted
content fail closed. Two independent temporary builds are asserted byte-identical. The rootless
source archive excludes virtual environments, `node_modules`, build output, caches, egg metadata,
nested archives, production keys and real-PDF fixtures.

The bundle deliberately omits three real-PDF fixtures whose redistribution terms are not
established. As a result, **26 fixture-dependent tests are skipped** in the bundled-source run.
Those skips do not count as passes and do not re-measure PDF ingestion quality.

## Final adversarial closure (2026-08-24)

The final source pass found and closed additional code-level gaps without promoting any external
gate:

- the CLI now rejects unknown, duplicate, pseudo-boolean and prototype-reserved arguments; compact
  artifact alternatives, directory markers and experiment globs share one safe resolver; redo
  clears public and skill-private outputs and refuses dangling links or a filesystem-root project;
- the Python bridge bounds stdout/stderr, decodes split UTF-8 correctly, validates timeouts, waits
  for the direct child to exit, and accepts success only from status zero with the requested skill
  and declared unique outputs. Contract digests now retain the full 64 hexadecimal characters;
- TypeScript and Python licence readers validate exact schemas, real dates and canonical Ed25519
  signatures. Issuance/key generation reject ambiguous options and physical path aliases and use
  atomic no-clobber publication, while forced replacement does not follow a destination link;
- runner, provider and experiment boundaries reject malformed JSON/config/quota/result shapes,
  count failed provider calls, validate finite timeouts and literal GPU flags, refuse duplicate or
  colliding experiment identities, and publish generated source atomically without adjacent bytecode;
- ArtifactStore, provenance and quota paths are opened with directory descriptors and no-follow
  semantics. Scalar and directory-member writes are fd-bound and atomic, linked reads fail closed,
  and release-gate converts unsafe inputs into explicit `artifact_path_unsafe` blockers rather than
  aborting without a release report;
- remote paper ingest rejects credentials, non-public or mixed DNS answers and every unsafe redirect,
  ignores ambient proxies, limits redirects to five and caps the decompressed response at 64 MiB;
  and
- human-return packets bind the frozen subject and coordinator manifest; PDF automation is labelled
  `PASSED` only at the automated-protocol subgate; and the 187-file source allowlist inspects both
  exact workbooks internally while preserving all six honest external statuses.

## Verification

Focused runs made each boundary falsifiable before the complete run:

- 190 acceptance and output-plane checks;
- 84 execution-boundary, 66 provider, 32 artifact-store and 19 pipeline checks;
- 18 licensing/user-feedback and 17 source-package/external/human-evidence checks;
- 68 TypeScript tests; and
- code generation reconciled 128 artifacts, 32 skills, 16 states and the 32-skill order in both
  generated languages.

These focused sets overlap and are not summed. Final bundled-source result:
**799 Python tests passed, 26 skipped; 68 TypeScript tests passed.**

## Still external, still not certified

- **Live acceptance: BLOCKED / NOT RUN.** GPU allocation and persisted proof are implemented, but
  this Apple M3 host is not an NVIDIA Container Toolkit host. The complete live envelope (matching
  provider credential and egress, compatible immutable PyTorch/CUDA image, paid licence or recorded
  override, supplied implementation and two fresh projects) has not been executed.
- **PDF quality: PARTIAL / NOT ADJUDICATED.** The frozen 18-PDF byte, pipeline and automated
  non-human checks passed 18/18. Human claim precision was not reproducible from the historical
  sample, and the retained section/figure differences still require blind review. The source bundle
  intentionally contains only the manifest, runner and report, never the non-redistributed PDFs.
- **Human B arm: NOT RUN.** A human-ceiling comparison requires an actual paired human run.
- **Innovation quality: NOT MEASURED.** No real-provider direction run has been adjudicated against
  the frozen corpus or through the blind expert panel.
- **Live scholarly compatibility: NOT VERIFIED.** One-result adapter probes against OpenAlex,
  Crossref and arXiv succeeded on 2026-08-20; Semantic Scholar returned HTTP 429 before and after a
  bounded retry, with no `Retry-After`, while its optional API key was unset. The provider is now
  correctly available for public unauthenticated search and 52/52 compatibility/refusal tests pass,
  but this partial observation is neither a full live pipeline nor a compatibility or
  service-availability certification.
- **Production licensing/release: NOT CERTIFIED.** A fresh ephemeral key/licence again passed issuer
  self-check, compiled fingerprint verification and the real Python paid-stage bridge, with the
  source sentinel hash unchanged afterward. Those are test-credential facts; no production key
  custody, code signature or retained production release evidence exists.
- **Redistribution terms: UNDECIDED.** There is no root software licence, so this archive itself
  supplies no public redistribution grant.

The bundled worked example is no longer an external gate. Its v2.8.4 offline run completed 42/42
ledger rows, created 56 editable SVG candidates and a 20-slide native deck, then correctly produced
a blocked release with no packaged deliverables. That is a deterministic machinery check, not live
research evidence.
