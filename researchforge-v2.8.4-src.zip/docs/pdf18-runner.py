#!/usr/bin/env python3
"""Run and score the frozen ResearchForge PDF18 corpus without network access.

The PDF bytes are intentionally not part of the source distribution.  Supply a
directory containing exactly the filenames in ``pdf18-corpus.json``.  The
runner verifies every byte before executing any skill, runs one document at a
time in a temporary project, verifies the input again afterwards, and writes a
single JSON evidence report.  Temporary projects and source PDFs are never
copied into the repository.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import tempfile
from typing import Any
from urllib.parse import quote


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = Path(__file__).with_name("pdf18-corpus.json")
REQUIRED_SKILLS = ("project-repo-manager", "paper-ingest", "paper-model-builder")
IMPLEMENTATION_INPUTS = (
    "python/researchforge/skills/intake.py",
    "python/researchforge/runner.py",
    "python/researchforge/artifacts.py",
    "python/researchforge/generated.py",
    "schemas/PaperModel.schema.json",
)
HEX_40 = re.compile(r"[0-9a-f]{40}\Z")
HEX_64 = re.compile(r"[0-9a-f]{64}\Z")
SAFE_ID = re.compile(r"[a-z0-9][a-z0-9_-]*\Z")
TRUNCATED_ABBREVIATION = re.compile(r"(?:Fig|Tab|Sec|Eq|eq)\.\s*$")
PRINT_HEADER = re.compile(r"^\d{1,2}/\d{1,2}/\d{2,4}(?:,|\s)")


class ProtocolError(RuntimeError):
    """A deterministic protocol or evidence failure."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ProtocolError(f"cannot read JSON evidence {path}: {exc}") from exc


def _artifact_digest(project: Path, relative: str) -> str | None:
    path = project / relative
    return _sha256(path) if path.is_file() and not path.is_symlink() else None


def _write_report(output: Path, report: dict[str, Any]) -> None:
    if output.is_symlink():
        raise ProtocolError(f"refusing to replace symlink output: {output}")
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    descriptor, temporary = tempfile.mkstemp(
        prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, output)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _validate_manifest(manifest: Any) -> list[dict[str, Any]]:
    if not isinstance(manifest, dict) or manifest.get("schema_version") != 1:
        raise ProtocolError("manifest must be a schema_version=1 JSON object")
    documents = manifest.get("documents")
    if not isinstance(documents, list) or not documents:
        raise ProtocolError("manifest.documents must be a non-empty list")
    if manifest.get("document_count") != len(documents):
        raise ProtocolError("manifest document_count does not match documents")

    ids: set[str] = set()
    filenames: set[str] = set()
    repositories: set[str] = set()
    total_bytes = 0
    total_pages = 0
    required = {
        "id", "repository", "commit", "path", "filename", "bytes", "sha256",
        "source_url", "expected_vector_only", "expected_pages", "gold_sections",
        "gold_figures", "gold_tables",
    }
    for index, document in enumerate(documents):
        if not isinstance(document, dict) or required - document.keys():
            missing = sorted(required - set(document) if isinstance(document, dict) else required)
            raise ProtocolError(f"document {index} is not an object or misses {missing}")
        document_id = document["id"]
        filename = document["filename"]
        repository = document["repository"]
        commit = document["commit"]
        relative = document["path"]
        digest = document["sha256"]
        size = document["bytes"]
        pages = document["expected_pages"]
        if not isinstance(document_id, str) or not SAFE_ID.fullmatch(document_id):
            raise ProtocolError(f"unsafe document id: {document_id!r}")
        if document_id in ids:
            raise ProtocolError(f"duplicate document id: {document_id}")
        if not isinstance(filename, str) or Path(filename).name != filename \
                or not filename.lower().endswith(".pdf"):
            raise ProtocolError(f"unsafe PDF filename for {document_id}: {filename!r}")
        if filename in filenames:
            raise ProtocolError(f"duplicate PDF filename: {filename}")
        if not isinstance(repository, str) or repository.count("/") != 1:
            raise ProtocolError(f"invalid repository for {document_id}")
        if not isinstance(commit, str) or not HEX_40.fullmatch(commit):
            raise ProtocolError(f"invalid commit for {document_id}")
        if not isinstance(relative, str) or relative.startswith("/") \
                or ".." in Path(relative).parts or not relative.lower().endswith(".pdf"):
            raise ProtocolError(f"unsafe repository path for {document_id}")
        if not isinstance(digest, str) or not HEX_64.fullmatch(digest):
            raise ProtocolError(f"invalid sha256 for {document_id}")
        if not isinstance(size, int) or isinstance(size, bool) or size <= 0:
            raise ProtocolError(f"invalid byte count for {document_id}")
        if not isinstance(pages, int) or isinstance(pages, bool) or pages <= 0:
            raise ProtocolError(f"invalid expected_pages for {document_id}")
        if not isinstance(document["expected_vector_only"], bool):
            raise ProtocolError(f"expected_vector_only must be boolean for {document_id}")
        for field in ("gold_sections", "gold_figures", "gold_tables"):
            value = document[field]
            if value is not None and (not isinstance(value, int) or isinstance(value, bool)
                                      or value < 0):
                raise ProtocolError(f"{field} must be a non-negative integer or null")
        expected_url = (
            f"https://raw.githubusercontent.com/{repository}/{commit}/{quote(relative, safe='/')}"
        )
        if document["source_url"] != expected_url:
            raise ProtocolError(f"source_url is not commit-pinned for {document_id}")
        ids.add(document_id)
        filenames.add(filename)
        repositories.add(repository)
        total_bytes += size
        total_pages += pages

    if manifest.get("repository_count") != len(repositories):
        raise ProtocolError("manifest repository_count does not match unique repositories")
    if manifest.get("total_bytes") != total_bytes:
        raise ProtocolError("manifest total_bytes does not match document bytes")
    if manifest.get("total_expected_pages") != total_pages:
        raise ProtocolError("manifest total_expected_pages does not match documents")
    return documents


def _validate_inputs(pdf_dir: Path, documents: list[dict[str, Any]]) -> tuple[
        list[dict[str, Any]], list[str]]:
    if not pdf_dir.is_dir() or pdf_dir.is_symlink():
        raise ProtocolError(f"--pdf-dir is not a real directory: {pdf_dir}")
    expected = {document["filename"] for document in documents}
    actual = {path.name for path in pdf_dir.glob("*.pdf")}
    unexpected = sorted(actual - expected)
    missing = sorted(expected - actual)
    if missing or unexpected:
        raise ProtocolError(
            f"PDF directory differs from frozen manifest: missing={missing}, unexpected={unexpected}"
        )

    evidence: list[dict[str, Any]] = []
    failures: list[str] = []
    for document in documents:
        path = pdf_dir / document["filename"]
        if path.is_symlink() or not path.is_file():
            failures.append(f"{document['id']}: input is missing, a symlink, or not regular")
            continue
        metadata = path.stat()
        digest = _sha256(path)
        size_ok = metadata.st_size == document["bytes"]
        digest_ok = digest == document["sha256"]
        evidence.append({
            "id": document["id"],
            "filename": document["filename"],
            "bytes": metadata.st_size,
            "sha256": digest,
            "bytes_match": size_ok,
            "sha256_match": digest_ok,
        })
        if not size_ok or not digest_ok:
            failures.append(
                f"{document['id']}: expected {document['bytes']}/{document['sha256']}, "
                f"observed {metadata.st_size}/{digest}"
            )
    return evidence, failures


def _package_versions() -> dict[str, str | None]:
    packages = (
        "beautifulsoup4", "jsonschema", "lxml", "pypdf", "researchforge"
    )
    versions: dict[str, str | None] = {}
    for package in packages:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    return versions


def _environment_evidence(manifest_path: Path) -> dict[str, Any]:
    implementation = {}
    for relative in IMPLEMENTATION_INPUTS:
        path = ROOT / relative
        implementation[relative] = _sha256(path) if path.is_file() else None
    return {
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "packages": _package_versions(),
        "manifest_sha256": _sha256(manifest_path),
        "runner_sha256": _sha256(Path(__file__)),
        "implementation_sha256": implementation,
        "network_mode": "offline",
        "execution_order": "manifest order, one PDF at a time",
    }


def _run_skill(project: Path, document_id: str, skill: str,
               config: dict[str, Any], timeout_seconds: int) -> dict[str, Any]:
    command = [
        sys.executable, "-m", "researchforge.runner", "run", "--skill", skill,
        "--project", str(project), "--run-id", f"pdf18-{document_id}",
        "--mode", "guided", "--model", "offline", "--offline",
        "--schemas", str(ROOT / "schemas"),
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(ROOT / "python")
    environment["PYTHONHASHSEED"] = "0"
    request = json.dumps({"config": config}, ensure_ascii=False)
    try:
        process = subprocess.run(
            command, input=request, capture_output=True, text=True, encoding="utf-8",
            errors="replace", cwd=ROOT, env=environment, timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "skill": skill, "ok": False, "returncode": None, "timed_out": True,
            "error": {"kind": "timeout", "message": f"exceeded {timeout_seconds}s"},
            "stderr_tail": (exc.stderr or "")[-2000:] if isinstance(exc.stderr, str) else "",
        }
    lines = [line for line in process.stdout.splitlines() if line.strip()]
    response: dict[str, Any]
    try:
        parsed = json.loads(lines[-1]) if lines else {}
        response = parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        response = {}
    result = {
        "skill": skill,
        "ok": process.returncode == 0 and response.get("ok") is True,
        "returncode": process.returncode,
        "timed_out": False,
        "produced": sorted(response.get("produced") or []),
        "warnings": response.get("warnings") or [],
        "next_state": response.get("next_state"),
        "detail": response.get("detail") or {},
    }
    if not result["ok"]:
        result["error"] = response.get("error") or {
            "kind": "invalid_runner_output", "message": "runner did not return success JSON"
        }
        result["stdout_tail"] = process.stdout[-2000:]
        result["stderr_tail"] = process.stderr[-2000:]
    return result


def _read_artifacts(project: Path) -> dict[str, Any]:
    source = project / "source"
    required_json = (
        "source_manifest.json", "locator_map.json", "section_map.json",
        "figure_table_index.json", "paper_model.json",
    )
    artifacts = {name: _load_json(source / name) for name in required_json}
    try:
        artifacts["layout_warnings.md"] = (source / "layout_warnings.md").read_text(
            encoding="utf-8"
        )
        artifacts["normalized_text.md"] = (source / "normalized_text.md").read_text(
            encoding="utf-8"
        )
    except (OSError, UnicodeError) as exc:
        raise ProtocolError(f"cannot read text evidence under {source}: {exc}") from exc
    return artifacts


def _score_document(document: dict[str, Any], project: Path,
                    skills: list[dict[str, Any]], post_sha256: str) -> dict[str, Any]:
    pipeline_ok = all(result["ok"] for result in skills)
    base: dict[str, Any] = {
        "id": document["id"],
        "filename": document["filename"],
        "source_sha256": document["sha256"],
        "source_unchanged_after_run": post_sha256 == document["sha256"],
        "pipeline_ok": pipeline_ok,
        "skills": skills,
    }
    if not pipeline_ok:
        base.update({"protocol_checks_pass": False, "artifact_error": "pipeline failed"})
        return base
    try:
        artifacts = _read_artifacts(project)
    except ProtocolError as exc:
        base.update({"protocol_checks_pass": False, "artifact_error": str(exc)})
        return base

    manifest = artifacts["source_manifest.json"]
    locator_map = artifacts["locator_map.json"]
    section_map = artifacts["section_map.json"]
    float_index = artifacts["figure_table_index.json"]
    model = artifacts["paper_model.json"]
    layout = artifacts["layout_warnings.md"]
    text = artifacts["normalized_text.md"]
    sections = section_map.get("sections") or []
    figures = float_index.get("figures") or []
    tables = float_index.get("tables") or []
    claims = model.get("claims") or []
    warnings = [warning for result in skills for warning in result.get("warnings", [])]
    warning_text = " ".join(str(warning) for warning in warnings).lower()
    words = manifest.get("words")
    expected_vector = document["expected_vector_only"]
    observed_vector = (
        isinstance(words, int) and words < 300
        and ("vector-only" in warning_text or "visual fallback" in warning_text)
    )
    references = [
        section.get("start") for section in sections
        if str(section.get("title", "")).lower() == "references"
        and isinstance(section.get("start"), int)
    ]
    reference_start = min(references) if references else None
    claims_after_references = (
        sum(1 for claim in claims
            if isinstance((claim.get("locator") or {}).get("offset"), int)
            and (claim.get("locator") or {})["offset"] > reference_start)
        if reference_start is not None else None
    )
    digit_claims = [claim for claim in claims if re.search(r"\d", str(claim.get("text", "")))]
    quantitative_misses = [
        claim.get("claim_id") for claim in digit_claims if claim.get("quantitative") is not True
    ]
    abbreviation_fragments = [
        claim.get("claim_id") for claim in claims
        if TRUNCATED_ABBREVIATION.search(str(claim.get("text", "")))
    ]
    header_pollution = [
        claim.get("claim_id") for claim in claims
        if "journal of l atex class files" in str(claim.get("text", "")).lower()
    ]
    title = str(model.get("title") or "")
    title_non_boilerplate = None if expected_vector else bool(
        title and title != "(title not detected)"
        and "journal of l atex class files" not in title.lower()
        and not PRINT_HEADER.search(title)
    )
    section_match = (
        None if document["gold_sections"] is None
        else len(sections) == document["gold_sections"]
    )
    figure_match = (
        None if document["gold_figures"] is None
        else len(figures) == document["gold_figures"]
    )
    table_match = (
        None if document["gold_tables"] is None
        else len(tables) == document["gold_tables"]
    )
    residual_hyphenation = len(re.findall(r"[a-z]-\n[a-z]", text))
    generic_entities = {
        "datasets": sorted(
            value for value in model.get("datasets") or []
            if str(value).lower() in {"dataset", "datasets", "corpus", "benchmark", "benchmarks"}
        ),
        "methods": sorted(
            value for value in model.get("methods") or []
            if str(value).lower() in {"architecture", "algorithm", "loss", "objective",
                                      "encoder", "decoder"}
        ),
        "numeric_metrics": sorted(
            value for value in model.get("metrics") or [] if re.match(r"\d", str(value))
        ),
    }
    references_required = not expected_vector and bool(claims) and document["gold_sections"] != 0
    references_verified = reference_start is not None or not references_required
    no_late_claims = claims_after_references == 0 if reference_start is not None else not references_required
    classification_match = observed_vector if expected_vector else isinstance(words, int) and words >= 300
    checks = {
        "page_count_matches": manifest.get("page_count") == document["expected_pages"],
        "vector_classification_matches": classification_match,
        "locator_granularity_is_text_block": locator_map.get("granularity") == "text_block",
        "layout_has_no_false_all_clear": (
            "none: text extraction produced anchored, ordered content" not in layout.lower()
        ),
        "references_boundary_verified_when_claims_exist": references_verified,
        "no_claims_after_references": no_late_claims,
        "digit_claims_are_quantitative": not quantitative_misses,
        "no_abbreviation_truncated_claims": not abbreviation_fragments,
        "no_running_header_in_claims": not header_pollution,
        "no_residual_lowercase_line_hyphenation": residual_hyphenation == 0,
        "named_entities_are_not_generic_or_numeric": not any(generic_entities.values()),
    }
    if title_non_boilerplate is not None:
        checks["title_is_not_known_boilerplate"] = title_non_boilerplate
    artifact_digests = {
        relative: _artifact_digest(project, relative)
        for relative in (
            "source/normalized_text.md", "source/source_manifest.json",
            "source/locator_map.json", "source/layout_warnings.md",
            "source/section_map.json", "source/figure_table_index.json",
            "source/paper_model.json",
        )
    }
    base.update({
        "protocol_checks_pass": all(checks.values()) and base["source_unchanged_after_run"],
        "protocol_checks": checks,
        "expected": {
            "vector_only": expected_vector,
            "pages": document["expected_pages"],
            "gold_sections": document["gold_sections"],
            "gold_figures": document["gold_figures"],
            "gold_tables": document["gold_tables"],
        },
        "observed": {
            "pages": manifest.get("page_count"),
            "words": words,
            "anchors": len(locator_map.get("anchors") or []),
            "locator_granularity": locator_map.get("granularity"),
            "vector_only": observed_vector,
            "title": title,
            "title_non_boilerplate": title_non_boilerplate,
            "sections": len(sections),
            "section_count_matches_gold": section_match,
            "figures": len(figures),
            "figure_count_matches_gold": figure_match,
            "tables": len(tables),
            "table_count_matches_gold": table_match,
            "claims": len(claims),
            "digit_claims": len(digit_claims),
            "claims_after_references": claims_after_references,
            "quantitative_miss_ids": quantitative_misses,
            "abbreviation_fragment_ids": abbreviation_fragments,
            "running_header_pollution_ids": header_pollution,
            "residual_lowercase_line_hyphenation": residual_hyphenation,
            "generic_or_numeric_entities": generic_entities,
            "warnings": warnings,
        },
        "artifact_sha256": artifact_digests,
    })
    return base


def _count_matches(results: list[dict[str, Any]], field: str) -> dict[str, int]:
    values = [
        result.get("observed", {}).get(field) for result in results
        if result.get("observed", {}).get(field) is not None
    ]
    return {"matched": sum(value is True for value in values), "measured": len(values)}


def _aggregate(documents: list[dict[str, Any]], results: list[dict[str, Any]],
               input_evidence: list[dict[str, Any]]) -> dict[str, Any]:
    execution_pass = len(results) == len(documents) and all(
        result.get("pipeline_ok") is True for result in results
    )
    protocol_pass = execution_pass and all(
        result.get("protocol_checks_pass") is True for result in results
    )
    observed_docs = [result for result in results if "observed" in result]
    non_vector = [
        result for result in observed_docs if not result["expected"]["vector_only"]
    ]
    return {
        "source_integrity": {
            "status": "PASSED" if all(
                row["bytes_match"] and row["sha256_match"] for row in input_evidence
            ) and len(input_evidence) == len(documents) else "FAILED",
            "verified": len(input_evidence),
            "expected": len(documents),
        },
        "pipeline_execution": {
            "status": "PASSED" if execution_pass else "FAILED",
            "completed": sum(result.get("pipeline_ok") is True for result in results),
            "expected": len(documents),
        },
        "automated_protocol_acceptance": {
            "status": "PASSED" if protocol_pass else "FAILED",
            "documents_passing": sum(
                result.get("protocol_checks_pass") is True for result in results
            ),
            "expected": len(documents),
        },
        "quality_snapshot": {
            "status": "MEASURED" if len(observed_docs) == len(documents) else "INCOMPLETE",
            "documents_measured": len(observed_docs),
            "pages": sum(result["observed"]["pages"] or 0 for result in observed_docs),
            "words": sum(result["observed"]["words"] or 0 for result in observed_docs),
            "claims": sum(result["observed"]["claims"] for result in observed_docs),
            "digit_claims": sum(result["observed"]["digit_claims"] for result in observed_docs),
            "titles_non_boilerplate": sum(
                result["observed"]["title_non_boilerplate"] is True for result in non_vector
            ),
            "titles_measured": len(non_vector),
            "section_count_exact_matches": _count_matches(
                observed_docs, "section_count_matches_gold"
            ),
            "figure_count_exact_matches": _count_matches(
                observed_docs, "figure_count_matches_gold"
            ),
            "table_count_exact_matches": _count_matches(
                observed_docs, "table_count_matches_gold"
            ),
        },
        "human_claim_precision": {
            "status": "NOT_ADJUDICATED",
            "reason": "the historical 40-claim seed, selected IDs and labels were not retained",
        },
        "overall_scope": "automated_nonhuman_protocol",
        "complete_quality_status": "NOT_ADJUDICATED",
        "overall_status": "PASSED" if protocol_pass else "FAILED",
    }


def _base_report(manifest: dict[str, Any], manifest_path: Path) -> dict[str, Any]:
    return {
        "report_schema_version": 1,
        "corpus_id": manifest.get("corpus_id"),
        "frozen_on": manifest.get("frozen_on"),
        "environment": _environment_evidence(manifest_path),
        "pdf_redistributed": False,
        "input_evidence": [],
        "documents": [],
        "summary": {"overall_status": "FAILED"},
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf-dir", required=True, type=Path,
                        help="directory containing exactly the 18 frozen PDF filenames")
    parser.add_argument("--output", required=True, type=Path,
                        help="JSON report destination; written atomically")
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST,
                        help="frozen corpus manifest (default: docs/pdf18-corpus.json)")
    parser.add_argument("--work-dir", type=Path,
                        help="optional parent for temporary per-document projects")
    parser.add_argument("--timeout-seconds", type=int, default=180,
                        help="timeout per ResearchForge skill (default: 180)")
    args = parser.parse_args(argv)
    if args.timeout_seconds <= 0:
        parser.error("--timeout-seconds must be positive")
    manifest_path = args.manifest.resolve()
    manifest = _load_json(manifest_path)
    report = _base_report(manifest, manifest_path)
    try:
        documents = _validate_manifest(manifest)
        input_evidence, failures = _validate_inputs(args.pdf_dir.resolve(), documents)
        report["input_evidence"] = input_evidence
        if failures:
            raise ProtocolError("; ".join(failures))
        work_parent = args.work_dir.resolve() if args.work_dir else None
        if work_parent is not None:
            work_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="researchforge-pdf18-", dir=work_parent) as tmp:
            temporary_root = Path(tmp)
            for document in documents:
                source = args.pdf_dir.resolve() / document["filename"]
                project = temporary_root / document["id"]
                project.mkdir()
                skills = [
                    _run_skill(
                        project, document["id"], "project-repo-manager",
                        {"paper_locator": str(source), "project_intent": "pdf18 quality rerun"},
                        args.timeout_seconds,
                    ),
                    _run_skill(
                        project, document["id"], "paper-ingest",
                        {"paper_locator": str(source)}, args.timeout_seconds,
                    ),
                ]
                if all(result["ok"] for result in skills):
                    skills.append(_run_skill(
                        project, document["id"], "paper-model-builder", {},
                        args.timeout_seconds,
                    ))
                else:
                    skills.append({
                        "skill": "paper-model-builder", "ok": False, "returncode": None,
                        "timed_out": False, "error": {
                            "kind": "upstream_failed",
                            "message": "not run because project setup or ingestion failed",
                        },
                    })
                report["documents"].append(_score_document(
                    document, project, skills, _sha256(source)
                ))
        report["summary"] = _aggregate(
            documents, report["documents"], report["input_evidence"]
        )
    except ProtocolError as exc:
        report["protocol_error"] = str(exc)
        report["summary"] = {"overall_status": "FAILED", "status": "FAILED_PRECONDITION"}
    _write_report(args.output, report)
    print(json.dumps({
        "ok": report["summary"].get("overall_status") == "PASSED",
        "output": str(args.output.resolve()),
        "summary": report["summary"],
    }, ensure_ascii=False, sort_keys=True))
    return 0 if report["summary"].get("overall_status") == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
