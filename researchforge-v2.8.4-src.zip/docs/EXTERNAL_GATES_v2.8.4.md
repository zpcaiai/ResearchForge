# ResearchForge v2.8.4 external evidence gates

This is the human-readable companion to
`docs/external-gates-v2.8.4.json`. It separates tested instruments and bounded live smokes from
the real-world evidence those instruments are intended to measure.

## Snapshot

| External gate | Overall status | Verified subgate on 2026-08-20 | Why the overall gate remains open |
|---|---|---|---|
| Live GPU acceptance | `BLOCKED_NOT_RUN` | strict local Docker identity preflight `PASSED` | local Apple M3/arm64 daemon has no NVIDIA tooling or runtime; no complete two-project run on a compatible NVIDIA Container Toolkit host |
| Human B-arm | `NOT_RUN` | instrument readiness `PASSED` | no blinded human returned completed worksheets |
| Complete PDF quality remeasurement | `PARTIAL_NOT_ADJUDICATED` | 18/18 byte integrity, offline pipeline and automated non-human protocol `PASSED` | historical human claim sample cannot be reproduced; section/figure gold-count differences remain measured |
| Real innovation quality review | `NOT_MEASURED` | evaluation instruments `PASSED` | no real-provider portfolio, complete adjudication, or reportable blind expert panel |
| Live scholarly compatibility | `NOT_VERIFIED` | OpenAlex, Crossref, and arXiv one-result smokes `PASSED`; Semantic Scholar blocked | 3/4 reachability is not an end-to-end or service-envelope certification |
| Production key/signing release | `NOT_CERTIFIED` | ephemeral test-credential TypeScript-to-Python bridge proof `PASSED` | no retained production key-custody, production signature, and independent verification evidence |

No overall external gate is marked passed. The narrower passed results are useful readiness and
compatibility evidence, but they do not substitute for the named external activity.

## Frozen PDF18 measurement

The post-fix runner verified all 18 pinned PDFs by size and SHA-256, then executed
`project-repo-manager`, `paper-ingest` and `paper-model-builder` offline and serially. All 18
pipelines and all 18 fail-closed automated protocol checks passed over 375 pages and 191,790 words.
The expected vector-only paper yielded zero words and a loud visual-fallback warning. The retained
quality snapshot reports 17/17 non-boilerplate titles, 5/17 exact historical section counts, 16/17
exact figure counts and 17/17 exact table counts.

That is a real complete-corpus automated remeasurement, so the old `NOT_RE_MEASURED` status is no
longer accurate. It is not complete human quality adjudication: the historical 40-claim seed,
selected IDs and labels were not retained, and the section/figure differences still require review.
The gate is therefore `PARTIAL_NOT_ADJUDICATED`, with the automated subgates explicitly `PASSED`.
The frozen manifest, runner and final report are `docs/pdf18-corpus.json`,
`docs/pdf18-runner.py` and `docs/pdf18-report.json`; no PDF bytes are shipped.

## Instrument evidence

The definitive corrected protocol-test command was:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=python \
/opt/homebrew/opt/python@3.11/bin/python3.11 -m pytest -q -p no:cacheprovider \
python/tests/test_b_arm.py \
python/tests/test_blind_rubric.py \
python/tests/test_score_directions.py
```

Result: **71 passed, 0 failed in 5.55 seconds**.

This verifies B-arm packet/analysis refusals, the blind innovation rubric, and the retrospective
direction scorer. It does not mean a human performed the B-arm or that anyone rated real model
directions. An in-memory readiness check could deterministically draw 8 blinded worksheets from
the 20 classified A-arm records with seed `20260812`; all returned-study fields remained unfilled.

## Live scholarly smoke

At `2026-08-20T14:31:03+08:00`, ResearchForge's `LiveTransport.search` queried each built-in
provider for one result using `attention is all you need`:

- OpenAlex: `PASSED`, one normalized result.
- Crossref: `PASSED`, one normalized result.
- arXiv: `PASSED`, one normalized result.
- Semantic Scholar: `BLOCKED`, HTTP 429; `SEMANTIC_SCHOLAR_API_KEY` was unset.

OpenAlex and arXiv passed on the first attempt. Crossref encountered a transient TLS EOF and passed
on retry. Semantic Scholar returned HTTP 429. Those observations are another reason to keep the
overall status `NOT_VERIFIED`: a single successful response is not a service-availability claim.

`RESEARCHFORGE_CONTACT_EMAIL` was also unset, so OpenAlex and Crossref were not exercised in the
configured polite-pool envelope. A complete compatibility pass still requires all configured
providers, persisted registry/quota/search evidence, named blind spots, and measured seeded recall,
saturation, and cross-provider agreement over a real objective.

## Credential boundary

Only presence was checked; values were never printed. The following were unset in this snapshot:

- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `SEMANTIC_SCHOLAR_API_KEY`
- `RESEARCHFORGE_CONTACT_EMAIL`
- `RESEARCHFORGE_LICENSE_KEY`
- `RESEARCHFORGE_LICENSE`
- `RESEARCHFORGE_ALLOW_UNLICENSED`

Missing model keys prevent a real-provider innovation run. Missing scholarly configuration keeps
the four-provider envelope incomplete. Missing licence variables are not, by themselves, proof
that no key exists elsewhere, so production certification additionally requires an explicit
custody record, retained signed artifacts, digest verification, signer identity, and publication
evidence.

## Docker and licence readiness

The corrected Docker identity probe passed on this host. It kept `/usr/local/bin/docker` as the
launch entry while separately resolving and hashing OrbStack's multicall `docker-tools` target,
then bound the `desktop-linux` context to a local Unix socket and Linux `aarch64` daemon. The host is
an Apple M3 and has no `nvidia-smi`, NVIDIA Container Toolkit utilities or NVIDIA Docker runtime.
That is a passed local-runtime preflight and a measured explanation for `BLOCKED_NOT_RUN`; it is
not GPU acceptance.

A fresh throwaway Ed25519 key and perpetual `site` licence also passed the issuer self-check,
compiled-key fingerprint check, TypeScript licence verification and real Python paid-stage gate.
The public-key source file had SHA-256
`7b039b5a18a06bdb8cdf19de33648752de182ade663af054671e43ca8e4409a0` both before and after the
builder restored its sentinel. Those ephemeral credentials prove the release-build bridge only.
They are not production key custody, artifact signing, notarization, publication or certification.

## Reading rule

Use `overall_status` in the JSON for release claims. Use `passed_subgates` only for the exact
instrument or one-result adapter scope stated there. Never promote a subgate to the overall gate
without adding the required real-world evidence and changing the snapshot with a new observation.
