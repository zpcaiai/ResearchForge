#!/usr/bin/env python3
"""Prepare and verify the three ResearchForge v2.8.4 human evidence gates.

The program can freeze packets and mechanically validate returned evidence.  It
cannot be a study participant, adjudicator, reviewer, author, or identity
verifier.  Every ``PASSED`` result therefore requires a completed human
attestation whose identity was independently checked by the named coordinator.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import tempfile
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
HEX64 = re.compile(r"[0-9a-f]{64}\Z")

B_ARM_DECLARATION = (
    "I am a human engineer. I personally performed the blinded B-arm work, did not "
    "delegate judgments to an AI system, and answered the blinding and timebox questions "
    "truthfully."
)
PDF_DECLARATION = (
    "I am a human reviewer. I personally inspected the frozen PDFs and the extracted "
    "artifacts, did not delegate judgments to an AI system, and recorded every judgment "
    "truthfully."
)
PAIRWISE_DECLARATION = (
    "I am a human adjudicator. I personally adjudicated every generated/gold direction "
    "pair under the supplied rubric and did not delegate judgments to an AI system."
)
BLIND_DECLARATION = (
    "I am a human domain expert. I personally scored every blinded direction before "
    "guessing its arm and did not delegate judgments to an AI system."
)
HUMAN_AUTHOR_DECLARATION = (
    "I am a human researcher. I personally authored the human comparison directions "
    "without model assistance and attest that they were frozen before seeing the blind key."
)


class GateError(RuntimeError):
    """A fail-closed evidence or packet error."""


def _module(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    if spec is None or spec.loader is None:
        raise GateError(f"cannot load {relative}")
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def _sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise GateError(f"cannot read JSON {path}: {exc}") from exc


def _write_new(path: Path, value: Any, mode: int = 0o600) -> None:
    parent_existed = path.parent.exists()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not parent_existed:
        os.chmod(path.parent, 0o700)
    payload = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    descriptor = os.open(path, flags, mode)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        raise


def _new_package(path: Path) -> Path:
    if path.exists() or path.is_symlink():
        raise GateError(f"refusing to overwrite package path: {path}")
    path.mkdir(parents=True, mode=0o700)
    os.chmod(path, 0o700)
    return path.resolve()


def blank_attestation(declaration: str) -> dict[str, Any]:
    return {
        "actor_kind": None,
        "reviewer_id": None,
        "full_name": None,
        "organization": None,
        "qualification": None,
        "signed_at_utc": None,
        "declaration": declaration,
        "signature_evidence_locator": None,
        "signature_evidence_sha256": None,
        "coordinator_id": None,
        "coordinator_verified_human_identity": None,
        "identity_verification_method": None,
    }


def _human(attestation: Any, declaration: str, label: str) -> dict[str, Any]:
    if not isinstance(attestation, dict):
        raise GateError(f"{label}: human attestation is absent")
    required = (
        "reviewer_id", "full_name", "organization", "qualification", "signed_at_utc",
        "signature_evidence_locator", "coordinator_id", "identity_verification_method",
    )
    if attestation.get("actor_kind") != "human":
        raise GateError(f"{label}: actor_kind must be exactly 'human'")
    if attestation.get("declaration") != declaration:
        raise GateError(f"{label}: the required no-AI-delegation declaration changed")
    missing = [field for field in required if not str(attestation.get(field) or "").strip()]
    if missing:
        raise GateError(f"{label}: incomplete identity/attestation fields: {missing}")
    digest = str(attestation.get("signature_evidence_sha256") or "")
    if not HEX64.fullmatch(digest):
        raise GateError(f"{label}: signature_evidence_sha256 must bind the retained signature")
    if attestation.get("coordinator_verified_human_identity") is not True:
        raise GateError(f"{label}: coordinator did not verify human identity")
    return attestation


def _result(gate: str, status: str, **detail: Any) -> dict[str, Any]:
    return {"schema_version": 1, "gate": gate, "status": status, **detail}


# ---------------------------------------------------------------------------
# Human B arm

def _b_arm_binding(packet: dict[str, Any]) -> str:
    worksheets = []
    for row in packet.get("worksheets") or []:
        step = row.get("step_0_seed_variance") or {}
        worksheets.append({
            "paper": row.get("paper"),
            "timebox_hours": row.get("timebox_hours"),
            "may_contact_authors": row.get("may_contact_authors"),
            "step_0_instruction": step.get("instruction"),
            "level_options": row.get("level_options"),
            "failure_code_vocabulary": row.get("failure_code_vocabulary"),
            "claim_comparison_rule": row.get("claim_comparison_rule"),
            "saw_a_arm_material_note": row.get("saw_a_arm_material_note"),
        })
    return _sha({key: packet.get(key) for key in (
        "packet_version", "arm", "purpose", "draw", "timebox_hours", "blinding",
        "reporting_rule", "return_contract",
    )} | {"worksheets": worksheets})

def prepare_b_arm(output: Path, n: int, seed: int, timebox: float) -> dict[str, Any]:
    if (n, seed, timebox) != (8, 20260812, 8.0):
        raise GateError("v2.8.4 B-arm design is frozen at n=8, seed=20260812, timebox=8h")
    package = _new_package(output)
    builder = _module("rf_b_arm_builder", "docs/study/b-arm/build_packet.py")
    rows = [json.loads(line) for line in
            (ROOT / "docs/study/all_results.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()]
    packet, key = builder.build(rows, n, seed, timebox)
    packet["human_attestation"] = blank_attestation(B_ARM_DECLARATION)
    packet["return_contract"] = {
        "all_worksheets_attempted": True,
        "one_qualified_human_engineer": True,
        "rl3_or_rl4_requires_complete_claim_comparison": True,
        "step_0_requires_three_unique_seeds_or_an_explicit_failure_reason": True,
    }
    packet["issued_content_sha256"] = _b_arm_binding(packet)
    key["issued_content_sha256"] = packet["issued_content_sha256"]
    key["a_arm_source_sha256"] = _sha_file(ROOT / "docs/study/all_results.jsonl")
    key["a_arm_outcomes_sha256"] = _sha(key["a_arm_outcomes"])
    packet_path = package / "participant.packet.json"
    key_path = package / "COORDINATOR-ONLY.key.json"
    _write_new(packet_path, packet)
    _write_new(key_path, key, 0o600)
    manifest = {
        "schema_version": 1,
        "gate": "human_b_arm",
        "issued_packet_sha256": _sha(packet),
        "key_sha256": _sha(key),
        "draw": packet["draw"],
        "a_arm_sha256": key["a_arm_source_sha256"],
        "distribution_rule": "give participant.packet.json to the engineer; never give the key",
    }
    _write_new(package / "manifest.json", manifest)
    return manifest


def _valid_step0(worksheet: dict[str, Any]) -> bool:
    step = worksheet.get("step_0_seed_variance") or {}
    seeds = step.get("seeds_run")
    complete = (
        isinstance(seeds, list) and len(set(map(str, seeds))) >= 3
        and str(step.get("metric") or "").strip()
        and isinstance(step.get("sd"), (int, float)) and not isinstance(step.get("sd"), bool)
        and step["sd"] >= 0
        and isinstance(step.get("tolerance_used"), (int, float))
        and not isinstance(step.get("tolerance_used"), bool)
        and step["tolerance_used"] >= 0
    )
    if complete:
        return True
    return (worksheet.get("level_reached") in {"RL0", "RL1", "RL2"}
            and bool(str(step.get("skipped_because") or "").strip()))


def _valid_claim_comparison(worksheet: dict[str, Any]) -> bool:
    if worksheet.get("level_reached") not in {"RL3", "RL4"}:
        codes = worksheet.get("failure_codes")
        vocabulary = set(worksheet.get("failure_code_vocabulary") or [])
        return (isinstance(codes, list) and bool(codes) and bool(vocabulary)
                and all(isinstance(code, str) and code in vocabulary for code in codes))
    required = ("claim_id", "paper_reported_value", "paper_locator",
                "local_measured_value", "tolerance", "run_id")
    for row in worksheet.get("claim_comparisons") or []:
        if all(row.get(field) is not None and str(row.get(field)).strip() for field in required) \
                and row.get("verdict") in {"PASS", "FAIL"}:
            return True
    return False


def verify_b_arm(packet_path: Path, key_path: Path, manifest_path: Path,
                 output: Path | None) -> dict[str, Any]:
    packet, key, manifest = _read(packet_path), _read(key_path), _read(manifest_path)
    if manifest.get("key_sha256") != _sha(key):
        raise GateError("B-arm coordinator key differs from its issuance manifest")
    if key.get("a_arm_source_sha256") != manifest.get("a_arm_sha256"):
        raise GateError("B-arm frozen A-arm source binding differs from issuance manifest")
    outcomes = key.get("a_arm_outcomes")
    if not isinstance(outcomes, list) or key.get("a_arm_outcomes_sha256") != _sha(outcomes):
        raise GateError("B-arm frozen A-arm outcomes are absent or changed")
    binding = _b_arm_binding(packet)
    if key.get("issued_content_sha256") != binding \
            or packet.get("issued_content_sha256") != binding:
        raise GateError("B-arm immutable packet design changed after issue")
    att = _human(packet.get("human_attestation"), B_ARM_DECLARATION, "B-arm engineer")
    worksheets = packet.get("worksheets") or []
    expected = int((packet.get("draw") or {}).get("n") or 0)
    if len(worksheets) != expected or expected <= 0:
        raise GateError("B-arm: returned worksheet count differs from the frozen draw")
    problems: list[str] = []
    for index, worksheet in enumerate(worksheets, 1):
        if worksheet.get("engineer_id") != att["reviewer_id"]:
            problems.append(f"worksheet {index}: engineer_id does not match attestation")
        if worksheet.get("level_reached") is None:
            problems.append(f"worksheet {index}: not attempted")
        if worksheet.get("saw_a_arm_material") is not False:
            problems.append(f"worksheet {index}: blind absent or broken")
        hours = worksheet.get("wall_clock_hours_used")
        if not isinstance(hours, (int, float)) or isinstance(hours, bool) or hours < 0:
            problems.append(f"worksheet {index}: invalid wall-clock hours")
        if not isinstance(worksheet.get("timebox_exhausted"), bool):
            problems.append(f"worksheet {index}: timebox_exhausted unanswered")
        if not _valid_step0(worksheet):
            problems.append(f"worksheet {index}: Step 0 incomplete without valid failure reason")
        if not _valid_claim_comparison(worksheet):
            problems.append(f"worksheet {index}: reproduction/failure evidence incomplete")
    if problems:
        raise GateError("B-arm return is incomplete: " + "; ".join(problems))

    paper_ids = [str(row.get("paper", {}).get("arxiv_id")) for row in worksheets]
    outcome_ids = [str(row.get("arxiv_id")) for row in outcomes]
    if len(set(outcome_ids)) != expected or sorted(outcome_ids) != sorted(paper_ids):
        raise GateError("B-arm frozen outcomes do not cover exactly the issued papers")
    analyser = _module("rf_b_arm_analyser", "docs/study/b-arm/analyse.py")
    analysis = analyser.analyse(packet, key, outcomes)
    if analysis.get("n_paired") != expected or any(
        analysis.get(field) for field in
        ("excluded_unblinded", "excluded_unanswered", "excluded_over_timebox", "not_run")
    ):
        raise GateError("B-arm analysis excluded a worksheet; the complete execution gate is open")
    result = _result(
        "human_b_arm", "PASSED", evidence_scope="complete blinded human execution",
        human_result=analysis.get("finding"), analysis=analysis,
        identity_truth_note="coordinator attestation, not inferred by software",
    )
    if output:
        _write_new(output, result)
    return result


# ---------------------------------------------------------------------------
# Complete human PDF18 quality review

def _pdf_binding(packet: dict[str, Any]) -> str:
    documents = []
    for row in packet.get("document_reviews") or []:
        documents.append({key: row.get(key) for key in (
            "document_id", "filename", "source_sha256", "artifact_sha256",
            "expected_vector_only", "extracted_title", "section_titles",
            "figure_ids", "table_ids", "historical_gold_counts",
        )})
    claims = []
    for row in packet.get("claim_sample") or []:
        claims.append({key: row.get(key) for key in (
            "sample_id", "document_id", "claim_id", "text", "section", "locator",
            "source_sha256", "artifact_sha256",
        )})
    return _sha({"documents": documents, "claims": claims,
                 "sample": packet.get("sample"), "thresholds": packet.get("thresholds")})


def _rank_claim(seed: int, row: dict[str, Any]) -> str:
    return _sha([seed, row["document_id"], row.get("claim_id"), row.get("text"),
                 row.get("locator")])


def build_pdf_packet(manifest: dict[str, Any], materials: list[dict[str, Any]],
                     seed: int, sample_size: int) -> dict[str, Any]:
    claims = [claim for material in materials for claim in material.pop("claims")]
    if len(claims) < sample_size:
        raise GateError(f"PDF18 has only {len(claims)} claims; cannot draw {sample_size}")
    selected: list[dict[str, Any]] = []
    by_doc: dict[str, list[dict[str, Any]]] = {}
    for claim in claims:
        by_doc.setdefault(claim["document_id"], []).append(claim)
    for document_id in sorted(by_doc):
        selected.extend(sorted(by_doc[document_id], key=lambda row: _rank_claim(seed, row))[:2])
    selected_ids = {(row["document_id"], row.get("claim_id")) for row in selected}
    remaining = [row for row in claims
                 if (row["document_id"], row.get("claim_id")) not in selected_ids]
    selected.extend(sorted(remaining, key=lambda row: _rank_claim(seed, row))[
                    :max(0, sample_size - len(selected))])
    selected = sorted(selected[:sample_size], key=lambda row: _rank_claim(seed, row))
    for index, row in enumerate(selected, 1):
        row["sample_id"] = f"Q-{index:03d}"
        row["human_review"] = {
            "is_genuine_paper_claim": None,
            "quote_matches_pdf": None,
            "locator_points_to_claim": None,
            "notes": None,
        }
    for row in materials:
        row["human_review"] = {
            "title_correct": None,
            "section_map_usable": None,
            "figure_index_usable": None,
            "table_index_usable": None,
            "visual_fallback_is_correct": None,
            "notes": None,
        }
    non_vector = sum(not row["expected_vector_only"] for row in materials)
    packet = {
        "schema_version": 1,
        "gate": "pdf_quality_remeasurement",
        "corpus_id": manifest.get("corpus_id"),
        "human_attestation": blank_attestation(PDF_DECLARATION),
        "sample": {
            "seed": seed,
            "size": sample_size,
            "method": "two hash-ranked claims per document, then global hash-ranked fill",
        },
        "thresholds": {
            "claim_joint_correct_min": math.ceil(sample_size * 0.90),
            "quote_matches_min": math.ceil(sample_size * 0.95),
            "locator_correct_required": sample_size,
            "title_correct_min": math.ceil(non_vector * 0.90),
            "section_map_usable_min": math.ceil(non_vector * 0.90),
            "figure_index_usable_min": math.ceil(non_vector * 0.90),
            "table_index_usable_min": math.ceil(non_vector * 0.90),
            "vector_fallback_correct_required": sum(
                row["expected_vector_only"] for row in materials),
        },
        "document_reviews": materials,
        "claim_sample": selected,
    }
    packet["issued_content_sha256"] = _pdf_binding(packet)
    return packet


def prepare_pdf(output: Path, pdf_dir: Path, seed: int, sample_size: int,
                timeout: int) -> dict[str, Any]:
    if (seed, sample_size) != (20260820, 40):
        raise GateError("v2.8.4 PDF human review is frozen at seed=20260820 and sample-size=40")
    package = _new_package(output)
    runner = _module("rf_pdf18_runner", "docs/pdf18-runner.py")
    manifest_path = ROOT / "docs/pdf18-corpus.json"
    manifest = runner._load_json(manifest_path)
    documents = runner._validate_manifest(manifest)
    evidence, failures = runner._validate_inputs(pdf_dir.resolve(), documents)
    if failures:
        raise GateError("PDF18 source validation failed: " + "; ".join(failures))
    materials: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="researchforge-pdf18-human-") as temporary:
        for document in documents:
            source = pdf_dir.resolve() / document["filename"]
            project = Path(temporary) / document["id"]
            project.mkdir()
            skills = [
                runner._run_skill(project, document["id"], "project-repo-manager",
                                  {"paper_locator": str(source),
                                   "project_intent": "pdf18 human quality packet"}, timeout),
                runner._run_skill(project, document["id"], "paper-ingest",
                                  {"paper_locator": str(source)}, timeout),
            ]
            if all(row["ok"] for row in skills):
                skills.append(runner._run_skill(project, document["id"],
                                                "paper-model-builder", {}, timeout))
            if len(skills) != 3 or not all(row["ok"] for row in skills):
                raise GateError(f"{document['id']}: pipeline failed while freezing human packet")
            artifacts = runner._read_artifacts(project)
            model = artifacts["paper_model.json"]
            sections = artifacts["section_map.json"].get("sections") or []
            floats = artifacts["figure_table_index.json"]
            artifact_sha = runner._artifact_digest(project, "source/paper_model.json")
            common = {
                "document_id": document["id"], "filename": document["filename"],
                "source_sha256": document["sha256"], "artifact_sha256": artifact_sha,
            }
            claims = [{**common, "claim_id": claim.get("claim_id"),
                       "text": claim.get("text"), "section": claim.get("section"),
                       "locator": claim.get("locator")}
                      for claim in model.get("claims") or []]
            materials.append({
                **common,
                "expected_vector_only": document["expected_vector_only"],
                "extracted_title": model.get("title"),
                "section_titles": [row.get("title") for row in sections],
                "figure_ids": [row.get("id") for row in floats.get("figures") or []],
                "table_ids": [row.get("id") for row in floats.get("tables") or []],
                "historical_gold_counts": {
                    "sections": document["gold_sections"],
                    "figures": document["gold_figures"],
                    "tables": document["gold_tables"],
                },
                "claims": claims,
            })
    packet = build_pdf_packet(manifest, materials, seed, sample_size)
    _write_new(package / "reviewer.packet.json", packet)
    result = {
        "schema_version": 1, "gate": "pdf_quality_remeasurement",
        "issued_content_sha256": packet["issued_content_sha256"],
        "manifest_sha256": _sha_file(manifest_path),
        "source_evidence_sha256": _sha(evidence),
        "distribution_rule": "PDF bytes stay operator-local; send packet plus read-only PDF access",
    }
    _write_new(package / "manifest.json", result)
    return result


def verify_pdf(packet_path: Path, manifest_path: Path, output: Path | None) -> dict[str, Any]:
    packet, manifest = _read(packet_path), _read(manifest_path)
    _human(packet.get("human_attestation"), PDF_DECLARATION, "PDF reviewer")
    binding = _pdf_binding(packet)
    if manifest.get("issued_content_sha256") != binding \
            or packet.get("issued_content_sha256") != binding:
        raise GateError("PDF packet immutable content changed after issue")
    documents, claims = packet.get("document_reviews") or [], packet.get("claim_sample") or []
    thresholds = packet.get("thresholds") or {}
    required_doc = ("title_correct", "section_map_usable", "figure_index_usable",
                    "table_index_usable")
    for row in documents:
        review = row.get("human_review") or {}
        fields = (("visual_fallback_is_correct",) if row.get("expected_vector_only")
                  else required_doc)
        if any(not isinstance(review.get(field), bool) for field in fields):
            raise GateError(f"PDF {row.get('document_id')}: document review is incomplete")
        if any(review.get(field) is False for field in fields) \
                and not str(review.get("notes") or "").strip():
            raise GateError(f"PDF {row.get('document_id')}: failed judgment needs notes")
    for row in claims:
        review = row.get("human_review") or {}
        fields = ("is_genuine_paper_claim", "quote_matches_pdf", "locator_points_to_claim")
        if any(not isinstance(review.get(field), bool) for field in fields):
            raise GateError(f"claim {row.get('sample_id')}: review is incomplete")
        if any(review.get(field) is False for field in fields) \
                and not str(review.get("notes") or "").strip():
            raise GateError(f"claim {row.get('sample_id')}: failed judgment needs notes")
    non_vector = [row for row in documents if not row.get("expected_vector_only")]
    vector = [row for row in documents if row.get("expected_vector_only")]
    counts = {
        "claim_joint_correct": sum(all((row["human_review"][field] for field in
            ("is_genuine_paper_claim", "quote_matches_pdf", "locator_points_to_claim")))
            for row in claims),
        "quote_matches": sum(row["human_review"]["quote_matches_pdf"] for row in claims),
        "locator_correct": sum(row["human_review"]["locator_points_to_claim"] for row in claims),
        "title_correct": sum(row["human_review"]["title_correct"] for row in non_vector),
        "section_map_usable": sum(row["human_review"]["section_map_usable"] for row in non_vector),
        "figure_index_usable": sum(row["human_review"]["figure_index_usable"] for row in non_vector),
        "table_index_usable": sum(row["human_review"]["table_index_usable"] for row in non_vector),
        "vector_fallback_correct": sum(
            row["human_review"]["visual_fallback_is_correct"] for row in vector),
    }
    checks = {
        "claim_joint_correct": counts["claim_joint_correct"] >= thresholds["claim_joint_correct_min"],
        "quote_matches": counts["quote_matches"] >= thresholds["quote_matches_min"],
        "locator_correct": counts["locator_correct"] >= thresholds["locator_correct_required"],
        "title_correct": counts["title_correct"] >= thresholds["title_correct_min"],
        "section_map_usable": counts["section_map_usable"] >= thresholds["section_map_usable_min"],
        "figure_index_usable": counts["figure_index_usable"] >= thresholds["figure_index_usable_min"],
        "table_index_usable": counts["table_index_usable"] >= thresholds["table_index_usable_min"],
        "vector_fallback_correct": counts["vector_fallback_correct"]
                                   >= thresholds["vector_fallback_correct_required"],
    }
    status = "PASSED" if all(checks.values()) else "FAILED_QUALITY_THRESHOLD"
    result = _result("pdf_quality_remeasurement", status, counts=counts, checks=checks,
                     thresholds=thresholds, reviewed_documents=len(documents),
                     reviewed_claims=len(claims),
                     identity_truth_note="coordinator attestation, not inferred by software")
    if output:
        _write_new(output, result)
    return result


# ---------------------------------------------------------------------------
# Real-provider innovation quality + two-person blind panel

def _pairwise_binding(packet: dict[str, Any]) -> str:
    items = [{key: row.get(key) for key in (
        "pair_id", "seed_id", "generated_rank", "generated", "gold_direction_id",
        "gold_split", "gold",
    )} for row in packet.get("items") or []]
    return _sha({key: packet.get(key) for key in (
        "packet_version", "benchmark_content_hash", "benchmark_version", "k",
        "contamination_floor", "seeds_with_no_generated_directions", "gold_by_seed", "rubric",
    )} | {"items": items})


def _blind_binding(packet: dict[str, Any]) -> str:
    return _sha({
        "packet_version": packet.get("packet_version"),
        "shuffle_seed": packet.get("shuffle_seed"),
        "criteria": packet.get("criteria"),
        "instructions": packet.get("instructions"),
        "entries": [{"entry_id": row.get("entry_id"), "text": row.get("text")}
                    for row in packet.get("entries") or []],
    })


def _real_machine_output(value: Any) -> None:
    def walk(node: Any) -> bool:
        if isinstance(node, dict):
            if node.get("_synthetic") is True:
                return False
            return all(walk(item) for item in node.values())
        if isinstance(node, list):
            return all(walk(item) for item in node)
        if isinstance(node, str) and "[synthetic]" in node.lower():
            return False
        return True
    if not walk(value):
        raise GateError("machine portfolio contains offline/synthetic markers")

def _flatten_directions(raw: Any) -> list[Any]:
    if isinstance(raw, dict) and "ideas" not in raw:
        return [item for seed in sorted(raw) for item in (raw[seed] or [])]
    ideas = raw.get("ideas") if isinstance(raw, dict) else raw
    if not isinstance(ideas, list):
        raise GateError("direction input must be a list, {ideas:[...]}, or seed-to-list map")
    return ideas


def _provider_evidence(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("synthetic") is not False:
        raise GateError("provider evidence must explicitly say synthetic=false")
    required = ("provider", "model", "run_id", "created_at_utc", "request_sha256",
                "response_sha256", "project_artifact_sha256")
    missing = [field for field in required if not str(value.get(field) or "").strip()]
    if missing:
        raise GateError(f"real-provider evidence is incomplete: {missing}")
    for field in ("request_sha256", "response_sha256", "project_artifact_sha256"):
        if not HEX64.fullmatch(str(value[field])):
            raise GateError(f"provider evidence {field} is not a SHA-256 digest")
    return value


def prepare_innovation(output: Path, machine_path: Path, human_path: Path,
                       provider_path: Path, seed: int, panel_size: int) -> dict[str, Any]:
    if panel_size < 2:
        raise GateError("innovation quality requires a blind expert panel of at least two humans")
    package = _new_package(output)
    scorer = _module("rf_score_directions", "tools/benchmark/score_directions.py")
    blind = _module("rf_blind_rubric", "tools/benchmark/blind_rubric.py")
    provider = _provider_evidence(_read(provider_path))
    machine_raw, human_raw = _read(machine_path), _read(human_path)
    _real_machine_output(machine_raw)
    machine_sha256 = _sha_file(machine_path)
    if provider["project_artifact_sha256"] != machine_sha256:
        raise GateError("provider project_artifact_sha256 does not match the machine input bytes")
    machine_map = scorer.load_directions(machine_path)
    freeze, pairs = scorer.load_benchmark(ROOT / "benchmarks/retro-v1/retro_benchmark.jsonl")
    pairwise = scorer.emit_packet(freeze, pairs, machine_map, 10)
    pairwise["human_attestation"] = blank_attestation(PAIRWISE_DECLARATION)
    machine, human = _flatten_directions(machine_raw), _flatten_directions(human_raw)
    if len(machine) != len(human):
        raise GateError(f"blind arms must balance: {len(machine)} machine vs {len(human)} human")
    blind_packet, key = blind.build(machine, human, seed, 10)
    _write_new(package / "adjudicator" / "pairwise.packet.json", pairwise)
    _write_new(package / "coordinator" / "blind.key.json", key, 0o600)
    for index in range(1, panel_size + 1):
        packet = copy.deepcopy(blind_packet)
        packet["human_attestation"] = blank_attestation(BLIND_DECLARATION)
        _write_new(package / "raters" / f"rater-{index}.packet.json", packet)
    _write_new(package / "human-arm.attestation.json",
               blank_attestation(HUMAN_AUTHOR_DECLARATION))
    manifest = {
        "schema_version": 1, "gate": "innovation_quality",
        "provider_evidence": provider,
        "machine_input_sha256": machine_sha256,
        "human_input_sha256": _sha_file(human_path),
        "pairwise_issued_sha256": _pairwise_binding(pairwise),
        "blind_issued_sha256": _blind_binding(blind_packet),
        "blind_packet_hash": key["packet_hash"],
        "blind_key_hash": key["key_hash"],
        "panel_size": panel_size,
        "distribution_rule": "separate blind.key.json from every rater and adjudicator",
    }
    _write_new(package / "manifest.json", manifest)
    return manifest


def verify_innovation(package: Path, output: Path | None) -> dict[str, Any]:
    scorer = _module("rf_score_directions_verify", "tools/benchmark/score_directions.py")
    blind = _module("rf_blind_rubric_verify", "tools/benchmark/blind_rubric.py")
    manifest = _read(package / "manifest.json")
    provider = _provider_evidence(manifest.get("provider_evidence"))
    if provider["project_artifact_sha256"] != manifest.get("machine_input_sha256"):
        raise GateError("provider artifact digest differs from the frozen machine input digest")
    author_att = _human(_read(package / "human-arm.attestation.json"),
                        HUMAN_AUTHOR_DECLARATION, "human-arm author")
    pairwise = _read(package / "adjudicator/pairwise.packet.json")
    if manifest.get("pairwise_issued_sha256") != _pairwise_binding(pairwise):
        raise GateError("innovation pairwise packet immutable content changed after issue")
    pair_att = _human(pairwise.get("human_attestation"), PAIRWISE_DECLARATION,
                      "pairwise adjudicator")
    role_ids = {author_att["reviewer_id"]}
    if pair_att["reviewer_id"] in role_ids:
        raise GateError("human author and pairwise adjudicator must be distinct people")
    role_ids.add(pair_att["reviewer_id"])
    items = pairwise.get("items") or []
    if not items or any(str(row.get("verdict") or "UNADJUDICATED").upper()
                        == "UNADJUDICATED" for row in items):
        raise GateError("innovation pairwise adjudication is incomplete")
    if any(row.get("adjudicator") != pair_att["reviewer_id"] for row in items):
        raise GateError("innovation pairwise rows do not bind to the attested adjudicator")
    scorecard = scorer.score(pairwise, "human", pair_att["reviewer_id"])
    if scorecard.get("verdict") == "INCOMPLETE" or scorecard.get("recall_at_k") is None:
        raise GateError("innovation retrospective score is not a complete measurement")

    key = _read(package / "coordinator/blind.key.json")
    rater_paths = sorted((package / "raters").glob("rater-*.packet.json"))
    if len(rater_paths) != int(manifest.get("panel_size") or 0) or len(rater_paths) < 2:
        raise GateError("innovation blind panel is absent or smaller than frozen manifest")
    panel = []
    for path in rater_paths:
        packet = _read(path)
        if manifest.get("blind_issued_sha256") != _blind_binding(packet):
            raise GateError(f"{path.name}: blind packet immutable content changed after issue")
        att = _human(packet.get("human_attestation"), BLIND_DECLARATION, path.name)
        if att["reviewer_id"] in role_ids:
            raise GateError("innovation author, adjudicator, and every rater must be distinct")
        role_ids.add(att["reviewer_id"])
        entries = packet.get("entries") or []
        if any(row.get("rater_id") != att["reviewer_id"] for row in entries):
            raise GateError(f"{path.name}: every row must bind to its attested rater")
        analysis = blind.analyse(packet, key)
        if analysis.get("reportable") is not True:
            raise GateError(f"{path.name}: blind result not reportable: "
                            f"{analysis.get('why_not_reportable')}")
        panel.append({"reviewer_id": att["reviewer_id"], "analysis": analysis})
    result = _result(
        "innovation_quality", "PASSED",
        evidence_scope="complete real-provider retrospective adjudication and blind expert panel",
        provider={key: manifest["provider_evidence"][key]
                  for key in ("provider", "model", "run_id", "created_at_utc")},
        retrospective_scorecard=scorecard, blind_panel=panel,
        quality_outcome_note=("PASSED is completion of the predeclared review gate; retain the "
                              "measured score and panel differences even if they are unfavorable"),
        identity_truth_note="coordinator attestations, not inferred by software",
    )
    if output:
        _write_new(output, result)
    return result


# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    bprep = sub.add_parser("prepare-b-arm")
    bprep.add_argument("--out", required=True, type=Path)
    bprep.add_argument("--n", type=int, default=8)
    bprep.add_argument("--seed", type=int, default=20260812)
    bprep.add_argument("--timebox-hours", type=float, default=8.0)
    bverify = sub.add_parser("verify-b-arm")
    bverify.add_argument("--packet", required=True, type=Path)
    bverify.add_argument("--key", required=True, type=Path)
    bverify.add_argument("--manifest", required=True, type=Path,
                         help="coordinator-retained prepare-b-arm manifest")
    bverify.add_argument("--out", type=Path)

    pprep = sub.add_parser("prepare-pdf")
    pprep.add_argument("--pdf-dir", required=True, type=Path)
    pprep.add_argument("--out", required=True, type=Path)
    pprep.add_argument("--seed", type=int, default=20260820)
    pprep.add_argument("--sample-size", type=int, default=40)
    pprep.add_argument("--timeout-seconds", type=int, default=180)
    pverify = sub.add_parser("verify-pdf")
    pverify.add_argument("--packet", required=True, type=Path)
    pverify.add_argument("--manifest", required=True, type=Path,
                         help="coordinator-retained prepare-pdf manifest")
    pverify.add_argument("--out", type=Path)

    iprep = sub.add_parser("prepare-innovation")
    iprep.add_argument("--machine", required=True, type=Path)
    iprep.add_argument("--human", required=True, type=Path)
    iprep.add_argument("--provider-evidence", required=True, type=Path)
    iprep.add_argument("--out", required=True, type=Path)
    iprep.add_argument("--seed", type=int, default=20260820)
    iprep.add_argument("--panel-size", type=int, default=2)
    iverify = sub.add_parser("verify-innovation")
    iverify.add_argument("--package", required=True, type=Path)
    iverify.add_argument("--out", type=Path)

    args = parser.parse_args(argv)
    try:
        if args.command == "prepare-b-arm":
            value = prepare_b_arm(args.out, args.n, args.seed, args.timebox_hours)
        elif args.command == "verify-b-arm":
            value = verify_b_arm(args.packet, args.key, args.manifest, args.out)
        elif args.command == "prepare-pdf":
            value = prepare_pdf(args.out, args.pdf_dir, args.seed, args.sample_size,
                                args.timeout_seconds)
        elif args.command == "verify-pdf":
            value = verify_pdf(args.packet, args.manifest, args.out)
        elif args.command == "prepare-innovation":
            value = prepare_innovation(args.out, args.machine, args.human,
                                       args.provider_evidence, args.seed, args.panel_size)
        else:
            value = verify_innovation(args.package, args.out)
    except (GateError, SystemExit) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, sort_keys=True))
        return 2
    print(json.dumps({"ok": value.get("status") == "PASSED" or "status" not in value,
                      "result": value}, ensure_ascii=False, sort_keys=True))
    return 0 if value.get("status") in {None, "PASSED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
