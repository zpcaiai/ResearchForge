# v2.8.4 human evidence execution kit

This kit closes the non-human preparation for the three external gates that require real people.
It does **not** make an AI a study participant or reviewer. Until returned packets pass the
verifier, the release statuses remain `NOT_RUN`, `PARTIAL_NOT_ADJUDICATED`, and `NOT_MEASURED`.

The verifier checks packet identity, completeness, blinding, predeclared thresholds, distinct
reviewer IDs, retained signature-evidence hashes, a subject digest tying each attestation to the
exact frozen packet or human-authored input, and a coordinator's identity-verification record.
Software cannot prove that a person told the truth. The coordinator must retain the signature
evidence, confirm that it visibly covers the attestation's `subject_sha256`, and independently
verify each human identity; inventing those fields is not a technical workaround, it is false
evidence.

## Roles

| gate | irreducible people | rule |
|---|---|---|
| Human B arm | one qualified human engineer | attempts all frozen papers blind to A-arm outcomes; the coordinator alone retains the key |
| PDF18 complete quality | one qualified human paper/PDF reviewer | inspects the 18 operator-local PDFs, all document-level dimensions, and the frozen 40-claim sample |
| Innovation quality | one human direction author, one human pairwise adjudicator, and at least two distinct blind domain experts | real-provider output only; each blind expert independently rates the complete balanced packet |

The same person should not hold both a blind packet and its key. For the innovation panel, two
files with two aliases for one person are still one reviewer and invalidate the gate.

Every attestation has `subject_sha256`, `signature_evidence_locator` and
`signature_evidence_sha256`. Preparation fills the subject digest; do not edit it. The locator may
refer to a coordinator-held signed PDF, institutional form, or detached signature, but that retained
evidence must display or cryptographically cover the same subject digest. A declaration signed for
one packet cannot be copied onto another packet. Do not put private identity documents or signature
bytes into the source archive.

## 1. Human B arm

Prepare the deterministic eight-paper packet:

```sh
python3 docs/human-gates-v2.8.4.py prepare-b-arm \
  --n 8 --seed 20260812 --timebox-hours 8 \
  --out /secure/coordinator/rf-v284-b-arm
```

Give only `participant.packet.json` to the engineer. Never distribute
`COORDINATOR-ONLY.key.json`, the A-arm ledger, results, timings, notes, or transcripts. The engineer
must complete every worksheet, including identity, blinding, timebox, Step 0 and reproduction or
failure evidence. A failed reproduction is a legitimate RL0/RL1/RL2 result; an unattempted paper
is `NOT_RUN` and does not close the gate. RL3/RL4 requires a fully bound claim comparison.

After the signed packet returns:

```sh
python3 docs/human-gates-v2.8.4.py verify-b-arm \
  --packet /secure/coordinator/rf-v284-b-arm/participant.packet.json \
  --key /secure/coordinator/rf-v284-b-arm/COORDINATOR-ONLY.key.json \
  --manifest /secure/coordinator/rf-v284-b-arm/manifest.json \
  --out /secure/coordinator/rf-v284-b-arm/result.json
```

`PASSED` means the complete blinded human execution occurred and survived the protocol refusals.
The retained `human_result` may still be `NOT_DETECTABLE`; a valid negative or underpowered result
must not be rewritten as a performance win.

## 2. Complete PDF18 human quality review

Restore all 18 PDFs under their manifest filenames in one operator-local directory. Preparation
rehashes every byte, reruns the three-stage offline pipeline in temporary projects, freezes up to
two available hash-ranked claims per document plus a deterministic global fill to 40, and then
destroys those temporary projects. Documents from which the pipeline emitted fewer than two claims
contribute only the available claims; they are still covered by the document-level review. The PDFs
are never copied into the package.

```sh
python3 docs/human-gates-v2.8.4.py prepare-pdf \
  --pdf-dir /operator-local/frozen-pdf18 \
  --seed 20260820 --sample-size 40 \
  --out /secure/coordinator/rf-v284-pdf-human
```

Give `reviewer.packet.json` and read-only access to the exact local PDFs to one qualified human
reviewer. They must inspect all non-vector titles, section maps, figure indexes and table indexes;
confirm the vector-only fallback; and judge every sampled claim for claimhood, verbatim fidelity,
and locator correctness. A `false` judgment needs a note.

The thresholds are frozen before review: at least 36/40 jointly correct claims, 38/40 exact quotes,
40/40 correct locators, at least 90% usable/correct results for every non-vector document dimension,
and every expected vector fallback correct. They are included in the packet binding and cannot be
edited after seeing labels.

```sh
python3 docs/human-gates-v2.8.4.py verify-pdf \
  --packet /secure/coordinator/rf-v284-pdf-human/reviewer.packet.json \
  --manifest /secure/coordinator/rf-v284-pdf-human/manifest.json \
  --out /secure/coordinator/rf-v284-pdf-human/result.json
```

`FAILED_QUALITY_THRESHOLD` is a completed measurement that found inadequate quality. It is not a
passed gate and must be retained rather than relabelled.

## 3. Real innovation-quality review

First run the innovation engine with a real provider against the frozen benchmark seeds. Preserve
the request, response and project-artifact SHA-256 digests in a provider-evidence JSON object:

```json
{
  "provider": "provider name",
  "model": "exact model/version",
  "run_id": "immutable run id",
  "created_at_utc": "RFC3339 timestamp",
  "request_sha256": "64 lowercase hex characters",
  "response_sha256": "64 lowercase hex characters",
  "project_artifact_sha256": "64 lowercase hex characters",
  "synthetic": false
}
```

The machine file must be the unedited real-provider portfolio, grouped by benchmark `seed_id`;
`project_artifact_sha256` must equal that file's actual SHA-256. The
human file must contain the same number of independently human-authored directions. Then prepare
the full-cross-product adjudication packet and two independent blind packets:

```sh
python3 docs/human-gates-v2.8.4.py prepare-innovation \
  --machine /secure/run/machine-directions.json \
  --human /secure/run/human-directions.json \
  --provider-evidence /secure/run/provider-evidence.json \
  --panel-size 2 --seed 20260820 \
  --out /secure/coordinator/rf-v284-innovation
```

Distribution is strict:

1. The human author completes `human-arm.attestation.json` without seeing the blind key.
2. A human adjudicator completes every item in `adjudicator/pairwise.packet.json`, using only
   `MATCH` or `NO_MATCH`, binding every `adjudicator` field to their attested reviewer ID.
3. Each distinct domain expert receives one `raters/rater-N.packet.json`. They complete all five
   scores first, then every legal `arm_guess`, and bind each row's `rater_id` to their attestation.
4. Only the coordinator retains `coordinator/blind.key.json`. A rater who saw it is replaced and a
   new packet/key is prepared.

The human direction author, pairwise adjudicator, and every blind rater must all have mutually
distinct verified reviewer IDs; one person cannot satisfy two roles under aliases.

Verify only after all returns and identity checks:

```sh
python3 docs/human-gates-v2.8.4.py verify-innovation \
  --package /secure/coordinator/rf-v284-innovation \
  --out /secure/coordinator/rf-v284-innovation/result.json
```

The verifier requires a complete retrospective score beside the frozen contamination floor and a
reportable result from every blind expert. It also binds the coordinator-only blind key to the
issuance manifest, so recomputing the key's own self-hash after flipping arm labels cannot reverse
the result. `PASSED` closes the evidence-collection/review gate; the scorecard and per-criterion
machine-human differences remain the quality outcome and must be reported even when unfavorable.

## Evidence retention

Retain returned packets, keys, result JSON, provider traces, signature evidence, coordinator
identity checks, exact source/artifact digests, and commands in access-controlled storage. Publish
redacted hashes and aggregate results, not keys, private identity material, credentials, or the PDF
bytes. None of these runtime packages belongs in the source ZIP.
