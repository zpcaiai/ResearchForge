# ResearchForge — commercial packaging and pricing

**Status: PROPOSAL. Not a decision.**

Everything here is either a **RECOMMENDATION** (my judgement, argued, overridable) or a
**FOUNDER DECISION** (a call I am explicitly not making for you). Numbers that come from
this repository's own measurements are cited to the file that measured them. Numbers that
come from my judgement rather than from data are marked **[GUESS]** and are collected again
in §8 so you can see all of them in one place. There is no market data in this document,
because I have none: no competitor price, no win rate, no willingness-to-pay survey. Where a
decision needs a number I do not have, §8 names the number and says how to get it.

Read §5 first if you only read one section. The most expensive remaining questions are release
certification and unperformed acceptance/quality measurements, not price.

---

## 1. What is actually being sold

ResearchForge is **self-hosted software with an offline-verified licence key**. The customer
installs it on their own machine or cluster, supplies their own model credentials
(`ANTHROPIC_API_KEY` / `OPENAI_API_KEY`), and runs it against their own compute. The licence
is an Ed25519-signed JSON file verified against a public key compiled into the build
(`packages/cli/src/license.ts`, `packages/cli/src/pubkey.ts`). **Licence verification** has no
phone-home, telemetry or licence server in the customer's path. That narrow property is
deliberate: a six-hour run must not die at hour five because a licensing service restarted.

It is not a no-egress product during a live research run. Calls to Anthropic or OpenAI send the
request context and credentials to the selected model provider; live literature search calls the
configured scholarly services; remote paper locators are fetched; and reproduction may clone a
discovered source repository. `--offline` with local inputs and scholarly fixtures avoids those calls, but
they produce synthetic or replayed evidence and cannot stand in for live acceptance. The honest
security claim is therefore: the software and artifact store are self-hosted, and licensing never
calls home; live-provider data flow is governed by the customer's provider agreements and network
controls. Do not claim that papers, unpublished data or API keys categorically never leave the
machine.

What the customer gets, mechanically: a 16-state research pipeline
(`packages/cli/src/state.ts`) driven by 32 implemented skills, in which the state machine stops on
a failed skill response and also refuses to advance unless the previous stage's required
*artifacts* exist. Reproduction of the source paper runs before ideation, and
`IDEAS_READY` is structurally unreachable except through `REPRO_LEVEL_ESTABLISHED`. Literature
coverage is measured, and under `UNKNOWN_COVERAGE` no candidate may be certified
`NOVEL_ENOUGH` by rule rather than by judgement. Every number in a draft is traced to the
run that produced it or marked `FABRICATED`. Figures are verified by reading the numbers back
off the rendered artists. The release gate either blocks the bundle or emits an
`ASSISTED_DRAFT`; it never marks output submission-ready.

### What it does not do — state this in the first paragraph of every sales conversation

- **It does not supply models.** BYOK. The customer's contract with the model provider
  governs cost, availability, output ownership and data retention. We are not in that path
  and take no margin on it.
- **It does not supply compute.** No GPU is shipped, rented or brokered. Untrusted execution is
  enabled only after strict local Docker/client/daemon/image validation; otherwise it remains
  disabled and no host fallback occurs. The explicit `trusted-host-code` profile is not isolation.
  GPU exposure is explicit, NVIDIA-only and acceptance-gated: the backend requires an in-container
  `torch.cuda` probe and records `--gpus all` plus the device evidence. It is not a cluster scheduler.
- **It does not supply datasets.** No mirrors, no licences, no access brokerage.
- **It does not write the method under test.** `codebase-scaffolder` generates the harness —
  CLI, seeding, invalid-condition checks, result emission — and deliberately refuses to
  generate the algorithm being measured, because a generator that writes the thing it also
  measures produces evidence about itself. The worked example makes the researcher supply
  `impl/`. Any pitch that implies "it writes the code" will be falsified in the customer's
  first real run.
- **It does not guarantee a publishable paper, and it never marks output submission-ready.**
  `release-gate` hard-codes `submission_ready: False` with a stated reason
  (`artifacts_out.py`). See §6.
- **It could not begin reproduction for 40% of the frozen sample.** This repo's 20-paper
  study (`docs/study/FINDINGS.md`) found that **8 of 20 sampled papers (40%, CI [22%, 61%])
  could not begin reproduction for reasons intrinsic to those sampled releases**: 20% published
  no code and another 20% published no dependency declaration in the inspected tree. Within that
  frozen protocol/sample, P(RL≥1) was bounded at **60%, CI [39%, 78%]**. This is not a universal
  or permanent upper bound on all source papers.

The product's answer to that 40% is not to pretend otherwise. It is the degradation path: the
achieved reproduction level sets the comparison mode, and at `CM_NONE` the run keeps going and
produces a *non-empty but narrower* portfolio — reproducibility studies, negative-result
reports, evaluation-methodology work — using the failure taxonomy it just generated as the
evidence. That is honest research, and for some buyers it is the more valuable output. It is
also, unambiguously, **not** what a buyer who wants "beat the SOTA baseline" was hoping for.

**RECOMMENDATION:** put the 40% number in the marketing copy, above the fold, as a stated
limit. A buyer who discovers it in week two feels defrauded. A buyer who was told it in week
zero and bought anyway has self-selected into the segment that values the degradation path,
which is the segment that will renew.

---

## 2. Who buys this, and what they are buying instead

The honest differentiator is **the gates** — reproduction before ideation, measured coverage
with named blind spots, claim-to-run traceability, and a release gate that blocks unsafe bundles
and never declares a bundle submission-ready. It is not
"AI writes your paper", which is both false here and already commoditised elsewhere.

| Segment | Alternative today | What is specifically better here | Willingness to pay |
|---|---|---|---|
| **A. Individual PhD student / postdoc** | Their own time, plus a consumer LLM subscription and ad-hoc prompting | The gates stop the failure mode they cannot self-detect: an idea whose novelty was assessed against a literature search that silently returned nothing, or a delta estimated against a baseline nobody ran. Reproduction-first is exactly the step a lone student skips. | Very low. Pays personally, out of a stipend. **[GUESS]** |
| **B. University lab (PI + 5–15 people)** | A first-year student's time, spent on reproducing a baseline instead of on their own work | Compresses the reproduction-and-triage phase that every new student burns a term on, and produces a *record* of it (failure taxonomy, coverage report, decision log) that outlives the student. The PI's real problem is not idea generation; it is that the lab's institutional memory walks out of the door every three years. `finding-memory` and the artifact store address that directly. | Low-to-moderate. Pays from a grant with a software/equipment line. **[GUESS]** |
| **C. Industrial research group** | An in-house agent framework, or an existing general agent framework wired up by an engineer | Two things they do not get by default from a general framework: (i) a refusal architecture — the artifact-store API rejects undeclared ownership/read edges and the stage gate checks outputs exist, though built-in skills retain host filesystem access; (ii) self-hosting with explicit egress boundaries — no licensing or telemetry call-home, while model and scholarly endpoints remain visible for the customer's security review and network policy. Their alternative costs an engineer's quarter to build and rarely includes the integrity auditor. | Moderate-to-high. Pays from an R&D budget where the licence is small next to compute. **[GUESS]** |
| **D. Research-tooling reseller / core facility / CRO** | **Provisional alternative:** people-hours or an internally assembled workflow; no competitor survey has established that a self-hostable comparable is absent | Wants to run it on behalf of third parties. This is the only segment that needs terms the licence schema does not currently express (see §3, redistribution). Highest revenue per contract, highest legal complexity, and the worst fit while the innovation engine has not been scored on the frozen benchmark. | High per deal, but premature. **[GUESS]** |

**RECOMMENDATION:** sell to B and C first. A is the acquisition channel, not a revenue line —
students become postdocs who become PIs who buy, and a student who has to pay will simply not
use it. D should be deferred until §5's blockers are closed, because a reseller's customers
discover your defects at N× the rate your direct customers do, and the reputational damage
lands on you without the direct relationship that lets you fix it.

**FOUNDER DECISION:** whether to pursue D at all. It is the fastest path to a large first
contract and the fastest path to a public failure.

---

## 3. Tiering — mapping onto the gates that exist

The code already defines the shape. `license.ts` has three editions
(`community | team | site`) and exactly four paid features:

| Feature key | What it gates (verbatim from `PAID_FEATURES`) | Pipeline states |
|---|---|---|
| `experiment-engine` | multi-branch experiment execution with strict Docker isolation for untrusted code and an explicitly non-isolated trusted-host option | `BLUEPRINT_READY` → `EXPERIMENTING` → `EVIDENCE_LOCKED` |
| `manuscript` | evidence-bound manuscript drafting and citation audit | `WRITING`, `REVIEWING` |
| `deck` | native editable defense deck generation | `DEFENSE_READY` |
| `release-gate` | release packaging with full provenance verification | `RELEASED` |

Community gets `ingest, literature, reproduction, innovation, human-gate` — states `INGESTED`
through `DIRECTION_SELECTED`. The cut lands exactly at the human selection gate: **everything
up to and including the human's decision is free; everything that executes on that decision is
paid.**

### Is each gate a viable paywall?

A gate is viable if working around it is meaningfully harder than paying. Judged one at a time:

**`experiment-engine` — the strongest gate, and the one to build the price on.** What sits
behind it is not "running a script": it is worktree branching, bounded repair with a hard cap,
strict local no-network Docker execution for untrusted code, an append-only ledger, provenance
binding every metric to code SHA + config + seed + environment, and — critically — evaluator
isolation, where the hidden tests live outside the agent's view. Docker identity, daemon locality,
the immutable image and the read-only code mount are validated before execution; there is no host
fallback for untrusted code. An operator may instead choose the explicit `trusted-host-code`
profile for supplied code, but that path is **non-isolated** and its authorization is tied to the
current runner invocation; coherent provisioner evidence can be reused on resume. A determined
engineer *can* replace this with a
shell script and a spreadsheet. What they cannot cheaply replace is the property that the
downstream integrity auditor recomputes every reported statistic from that ledger. Break the
ledger and you lose the audit, which is the thing being bought. **Viable.**

**`manuscript` — the weakest gate, and the one most likely to be worked around.** A user who
has `findings`, `evidence_graph` and `stats_audit` in hand — artifacts that are not individually
feature-gated, but whose normal production depends on the paid experiment engine —
can paste them into any chat assistant and get prose. What they do not get is the
claim-to-run binding and the citation audit that distinguishes a real-but-irrelevant citation
(`NOT_SUPPORTED`) from a supporting one, and a number with no run behind it (`FABRICATED`)
from a real one. That is genuinely valuable and genuinely hard to reproduce by hand — but it
is *invisible* value, and invisible value is what customers refuse to pay for. **Viable only
if the audit output is made loudly visible.**

**`deck` — a nice-to-have, not a paywall.** Native PPTX with real text frames instead of
flat images is a real engineering achievement and a small purchasing consideration. Nobody
buys a research runtime for the slides. It belongs in the paid bundle because it costs
nothing to include, not because it sells anything.

**`release-gate` — the commercially strangest gate, and the most interesting.** The customer
is paying for software whose headline behaviour is to tell them *no* when evidence is unsafe.
Framed as "packaging", it sounds like a formality. Framed correctly, it is the compliance
artifact: a machine-readable `release_manifest.json` carrying the AI-participation disclosure,
the achieved comparison mode, the provenance chain, and an explicit `submission_ready: False`
with a stated reason. The manifest is not cryptographically signed.
For segment C and for any institution with a research-integrity office, *that document is the
product* — it is what lets them say, on the record, that the lab has a mechanised control on
undisclosed generative-model involvement.

This creates a genuine conflict. The release gate is simultaneously (a) the highest-value
compliance deliverable and (b) the mechanism that stops an undisclosed AI manuscript reaching
a venue. Paywalling (b) means the unpaid user's path of least resistance is to write their own
disclosure, or not to.

**RECOMMENDATION:** split the feature in two. A *refusal-only* release gate — it can say no,
and it emits the disclosure text — belongs in community, on ethics grounds. The *packaging and
provenance bundle* — the manifest, the reproducibility commands, the artifact bundle —
stays paid. **This is not built.** Today `release-gate` is one feature key, and splitting it
means a code change and a second key (e.g. `release-package`). Adding a key is safe: the
verifier re-serialises whatever it parsed, so existing signed licences continue to verify
unchanged.

**FOUNDER DECISION:** whether the ethics argument outweighs losing the single most
institution-legible paid deliverable from the paid bundle. I lean toward the split. You may
reasonably decide that an institution that will not pay for the compliance artifact is not
going to run a disciplined process anyway.

### Is community too generous?

Community gives away ingestion, literature, reproduction, the innovation engine and the human
gate. That is a lot — arguably the intellectually hardest parts of the system.

**RECOMMENDATION: keep it. It is correct, for three independent reasons.**

*First, it is the evaluation surface.* Nobody buys a research runtime on a demo. They buy it
after feeding it three of their own papers and watching what happens. If the free tier stops
before reproduction, the buyer never sees the one thing that differentiates the product — that
`IDEAS_READY` is unreachable except through `REPRO_LEVEL_ESTABLISHED` — and the trial teaches
them nothing. A gate that blocks evaluation kills adoption, and the gate is *specifically*
what is being sold.

*Second, community is where the measured ingestion limits live.* The original PDF study measured
a 73% wrong/unknown section-label rate, 0 of 9 IEEE-style figures indexed, and one crash in 18
papers. All twelve prioritised parser fixes are now implemented and the three optional local PDFs
pass 26/26 fixture regressions. The pinned post-fix PDF18 runner then verified 18/18 source hashes,
18/18 offline pipelines and 18/18 automated non-human protocol checks. It also retained the
uncomfortable measurements: only 5/17 exact historical section counts and 16/17 exact figure
counts. Human claim precision is still not adjudicated. Giving this layer away with that boundary
documented keeps an incompletely certified subsystem from becoming a paid promise.

*Third, the paid tier is where the customer's own money is already committed.* By the time a
user reaches `EXPERIMENTING` they have chosen a direction and are about to spend real compute
and API budget. That is the moment of maximum
commitment and the correct moment to
ask for money.

**FOUNDER DECISION:** whether community should be time-limited or project-limited (e.g. three
projects, then a licence). I recommend against — a limit that bites during evaluation is a
limit that ends the evaluation — but it is a defensible way to convert freeloading labs.

### What the licence schema cannot express

`License` is `{ licensee, edition, expires, features, issued }`. There is **no seat count, no
host binding, and no redistribution flag**. So "team, up to 10 named users" is a contractual
term with no technical enforcement, and a reseller arrangement (segment D) has no expression
in the artefact at all. Adding `seats` / `hosts` / `redistribution` fields is backward
compatible for verification (the verifier re-serialises the parsed object, so old licence
files still verify), but every issuing path and the issuance ledger have to change.

**RECOMMENDATION:** add the fields before the first `site` or reseller contract. Do not add
them before the first `team` contract; a named-user count in the EULA is sufficient at that
scale and the field is worthless until the contract, issuer and issuance ledger enforce it.

---

## 4. Price points and the reasoning behind them

**All four numbers below are [GUESS].** They are anchored on three reasoning chains — the cost
of the buyer's alternative, the size of the licence relative to the buyer's own compute spend,
and the size of the purchase relative to the approval threshold that triggers procurement.
None is anchored on an observed comparable, because I have no comparable. Treat them as
starting hypotheses to test against the interviews in §8, not as a price list.

### The reasoning chains

**Chain 1 — fraction of the alternative.** For segment B the alternative is a first-year
student spending a term reproducing a baseline. The right price is a defensible fraction of
the fully-loaded cost of that time. I do not know that cost in your target geography and will
not invent it (§8, number 1). What I can say is the *shape*: a tool that plausibly saves
weeks-not-months of one junior person's time supports a low single-digit percentage of a
person-year, not a double-digit one, because the saving is probabilistic and the buyer knows it.

**Chain 2 — size relative to compute spend.** This one decides whether the purchase is easy.
A licence that is small next to the monthly GPU and API bill gets waved through as a rounding
error on an existing budget line. A licence that dominates that bill has to be justified on
its own merits, against a product whose benchmark instruments exist but whose innovation engine
has not been scored (§5). So the licence must be priced as a
*fraction of the customer's existing research-infrastructure spend*, and the segments split
sharply on this:

| Segment | Rough monthly compute + API spend **[GUESS]** | A $6k/yr licence is… | Verdict |
|---|---|---|---|
| A. Individual student | $0–200 (often free cluster + small API spend) | 2.5×–∞ their spend | Impossible. Must be free. |
| B. University lab | $1k–10k | 5%–50% | Buyable at the low end of the licence range; painful at the high end |
| C. Industrial group | $20k–200k+ | <3% | Trivially approvable |

**Chain 3 — the procurement threshold.** Below some amount a PI signs and expenses it; above
it, a purchase order, a security review and a legal review appear, and the cycle goes from days
to two quarters. I do not know that threshold at your target institutions (§8, number 2), but
it is the single most important number in this document for revenue *velocity*, and it is
cheap to find out. Price the entry tier deliberately under it.

### Recommended prices

| Tier | Edition key | Features | Recommended list | Range | Term |
|---|---|---|---|---|---|
| **Community** | `community` | ingest, literature, reproduction, innovation, human-gate | **$0** | — | perpetual |
| **Academic single seat** | `team` (1 named user) | default: experiment engine + manuscript; deck/release only when explicitly issued | **$0** for enrolled students/postdocs; **$400/yr** otherwise | $0–800 | annual |
| **Lab / Team** | `team` (≤10 named users) | default: experiment engine + manuscript; deck/release only when explicitly issued | **$6,000/yr** | $3,000–12,000 | annual |
| **Commercial team** | `team` (≤10 named users) | same default feature set, commercial-use terms | **$24,000/yr** | $15,000–36,000 | annual |
| **Site** | `site` | institution-wide, offline installation/licence support, named support contact, priority on the fix list | **$35,000/yr** | $25,000–60,000 | annual |

The table follows the issuer, not the marketing shorthand: `team` defaults to
`experiment-engine,manuscript`, while `site` defaults to all known features. If a team contract
includes deck or release packaging, the issuing workflow must pass the complete explicit feature
list and the read-only `researchforge license-check` preflight must pass before delivery.

Reasoning, tier by tier:

**Academic single seat at $0 for students.** Chain 2 says it plainly: a student's licence would
cost several times their entire monthly compute spend. There is no price at which this segment
converts, and pricing it at $200 just converts a future advocate into a non-user. The $400
non-student figure exists so that the *edition* is not free-forever by definition, which
matters when an industrial user tries to buy the cheapest thing on the list.

**Lab at $6,000/yr.** This is chain 1 and chain 3 meeting. It is a plausible single-digit
percentage of one junior person-year **[GUESS]**, it is $500/month against a lab compute bill
of $1k–10k/month, and it is — I believe, but do not know — under the threshold at which a PI
must open a procurement case. The range is wide because the answer changes completely
depending on §8 numbers 1 and 2. If the threshold turns out to be $5,000, price at $4,800 and
do not argue with it.

**Commercial team at 4× academic.** Academic/commercial differentiation is standard and
uncontroversial, and chain 2 says the industrial buyer will not notice. I have chosen 4×
rather than 2× or 10× on judgement alone **[GUESS]**; the honest justification is that a
commercial customer costs more to support, carries more legal exposure, and derives revenue
from the output. If you cannot defend the multiple in a sales call, lower it — an
indefensible multiple costs more trust than it earns margin.

**Site at $35,000/yr.** What justifies the jump from $24k is not more software; it is the
support envelope: a named contact, offline installation/licence support, and — the part that
actually sells — **influence over the priority of the fix list**. An institution buying this
is buying the ability to say "our ICML-style PDFs must parse correctly" and have that be
scheduled. That is a genuine, deliverable commitment, and it is the only thing at this price
point that a customer can verify you kept.

### Perpetual vs annual

`License.expires` supports `null` for perpetual. **RECOMMENDATION: do not sell perpetual yet.**
All twelve prioritised PDF-ingestion code paths and the complete automated corpus rerun are built,
but human quality adjudication and the retained section/figure differences are not closed. The
date-pinned dependency snapshot and interpreter pool were tested without material lift; the
CUDA-aware path remains unbuilt and unmeasured. A perpetual licence sold today would freeze those
evidence gaps into the purchased version.

The exception is a site that needs offline installation and licence renewal, where annual
re-issuance is operationally painful and perpetual-plus-maintenance-window is the norm. This does
not make live research air-gapped: model and scholarly calls still require customer-approved
egress unless the run is explicitly synthetic/replayed. **FOUNDER DECISION:** whether to offer
perpetual + 12-month maintenance at roughly 2.5–3× the annual price **[GUESS]** for such `site`
customers only.

---

## 5. What will actually block a sale

Being adversarial with the product. Ordered by when the buyer hits it.

### Day one: certify the paywall in the build you ship

**The licence gate now gates paid skills.** TypeScript verifies and displays licence status and
restrictions, then injects the public key compiled into the release build across the subprocess
boundary. The enforceable refusal lives once, at the Python choke point:
`python/researchforge/licensing.py` maps paid skills to features and
`python/researchforge/runner.py` checks that map before dispatch. Invoking the Python runner
directly therefore does not bypass the gate. The explicit self-hosted override remains possible
and is recorded in provenance and the release manifest.

The source `pubkey.ts` deliberately retains
`__RESEARCHFORGE_LICENSE_PUBLIC_KEY_PEM__`, so an ordinary source build is community-only. The
release builder requires both `--pubkey` and `--verify-with`: it compiles the key, checks the
reported fingerprint, verifies a genuine matching licence, crosses the TypeScript/Python boundary
to prove a paid Python skill unlocks, and then restores the source sentinel. A key substitution
without that proof is refused as an uncertified build.

The mitigation is not "make the gate uncrackable" — this is self-hosted software the customer
can read and edit, so a determined customer will always win. The mitigation is to make the
gate *real enough to be an honest statement of what was sold*, and to put the commercial weight
on updates, the support envelope, fix-list priority and indemnity. The current release builder
proves key substitution and paid Python access; it does **not** code-sign the build or manifest.

**Answer:** ship only a release artifact produced by that proof path, keep the production private
key outside the repository, and retain the build fingerprint and verification evidence. Test both
directions for every release: community refuses a paid Python skill, and the matching paid licence
unlocks it. The remaining commercial risk is release/key custody and artifact provenance, not a
missing runtime gate.

### Week one: ingestion quality is still only partially re-measured

The buyer will feed it five of their own PDFs. The original 18-paper study measured these
**pre-fix** failures:

- **1 of 18 (5.6%) hard-crashes** on unpaired UTF-16 surrogates, and reports as a generic
  internal crash indistinguishable from a runtime bug.
- On ICML/PMLR and ICLR-style papers — which is most of the target market — **exactly two
  sections are ever detected**, because `HEAD_RE` demands whitespace after the section number
  and those styles write `1. Introduction`. One character of regex.
- Consequently **189 of 258 claims (73%) carry a wrong or unknown section label**. Twelve of
  twelve claims in one paper are filed as living in the Abstract; one of them does.
- **28% of extracted "claims" are appendix or bibliography bookkeeping**, including raw LaTeX
  algebra with a page footer welded into the middle of it.
- Titles are exactly right on **9 of 18**, while 8 of 18 carry the correct title in PDF
  metadata the pipeline never reads.
- IEEE-style figures and tables are indexed at **0 of 9**, with no warning.

All twelve prioritised parser paths are now implemented: surrogate repair; decimal, roman and
small-cap headings; pre-References claim mining; measured warnings; metadata title hints and
running-header removal; honest text-block locators; broader figure/table captions; conservative
metric and named-entity extraction; de-hyphenation; abbreviation-safe sentence splitting; and
numeral-based quantitative claims. A pinned offline rerun now verifies all 18 source hashes and
passes the pipeline and automated non-human protocol on all 18 documents (375 pages). The measured
snapshot reports 17/17 non-boilerplate titles, 5/17 exact historical section counts, 16/17 exact
figure counts and 17/17 exact table counts. Those are current automated measurements; the old 73%
section-error rate is historical, and human claim precision remains `NOT_ADJUDICATED` because the
old sample IDs and labels were not retained.

**Answer:** retain the automated report, freeze a new deterministic claim sample, have it blind
human-adjudicated, and review the section/figure count differences before making a complete quality
claim. A visible defect in a beta is survivable. A silent one—or an automated pass presented as a
human certification—in a product about evidence is not.

### Week one to three: their own baseline will not reproduce

The buyer's first real test is their own paper or a competitor's. Keep two results from the same
frozen 20-paper study separate. First, **8/20 (40%) could not begin reproduction for reasons
intrinsic to the sampled releases**: four had no public code and four had code but no dependency
declaration in the inspected tree. Separately, the study's final failure classification tagged
**9/20 (45%) `DEPENDENCY_UNRESOLVABLE`**. The latter denominator is the full sample, not “observed
failures”, and it overlaps the study's broader account of why attempts failed; it must not be added
to 8/20. Several resolvability failures involved pinned PyTorch/CUDA wheels unavailable from PyPI.

There are two honest halves to the answer:

*The engineerable half.* The first recommendation was tested rather than assumed. A date-pinned
wheel snapshot helped one of the same 20 papers and the multi-version interpreter pool helped none;
the apparent resolver gain disappeared under a real install because dry-run resolution does not
execute `setup.py`. Do not sell that "dependency time machine" as a solution. The observed blocker
is the CUDA build toolchain used by packages such as `flash-attn`; conda/PyTorch-index and build
environment support remain possible engineering work, but their lift is unmeasured.

*The unengineerable half.* In the frozen sample, `NO_CODE` + `CONFIG_AMBIGUOUS` covered 8/20 and no
amount of resolver or sandbox engineering could create code or environment declarations absent
from those sampled releases. The answer there was the `CM_NONE` degradation path — the only
in-scope route for those eight releases.

**Answer:** build and measure the CUDA-aware path before promising lift, and sell the degradation
path honestly rather than hiding it. Say to the buyer, in the first meeting: "eight of twenty
sampled papers did not begin reproduction for repository-intrinsic reasons, and here is exactly
what the tool does instead."

### Week two to four: "is the innovation any good?"

**There is no measured answer to this question today, and that should worry you more than the
ingestion defects.** The frozen retrospective corpus, its 0.71 contamination floor, the packet
builder/scorer and the blind-rubric instrument now exist. The innovation engine itself has still
not been scored. Producing a defensible recall number requires a real model provider to generate
directions and then a human or explicitly recorded model adjudicator to fill the complete pairwise
packet. Establishing that the ideas are useful, rather than merely recalling literature, separately
requires the blind expert panel.

A sophisticated buyer — which is every buyer in segment C — will ask "how do you know the
ideas are good?" and the truthful answer is "we don't; we know they are grounded in a
reproduction that actually ran, and we know the system refuses to certify novelty it cannot
support." That is a real and defensible answer about *process*. It is not an answer about
*quality*, and you should not let a sales conversation blur the two.

**Answer:** run the engine with a real provider, adjudicate the full packet, and publish the first
recall@k beside the 0.71 floor, even if the result is bad. Then run the blind panel before making a
quality claim. The benchmark was frozen before tuning; preserve that ordering so improvement can
be distinguished from drift.

### Throughout: synthetic/replay runs are not acceptance

`--offline` marks model-derived artifacts/provenance synthetic and the release gate refuses that
output; scholarly fixtures are replay, not live coverage. That is correct behaviour and a useful machinery test. As
far as this repository shows, however, no end-to-end acceptance run has been certified. The harness
requires credentials matching the selected live model, permitted model and scholarly-provider
   egress, a visible NVIDIA GPU, a validated and recorded NVIDIA Container Toolkit mapping, a running Docker daemon,
   a healthy built runtime, a verifiable paid licence
or recorded override, the method implementation, and two fresh project directories for the
determinism check. Before charging, supply that complete envelope and preserve the resulting
acceptance report; a model key alone proves nothing.

---

## 6. Legal and ethical exposure

### Why `ASSISTED_DRAFT` is commercially correct, not merely cautious

`release-gate` sets `release_status` to `ASSISTED_DRAFT` or `BLOCKED`, hard-codes
`submission_ready: False`, and emits `why_not_submission_ready`: the disclosure must be carried
into the venue's LLM-use declaration, and a named human author must verify the claims.

Four reasons this is the commercially right default, in descending order of how much money it
saves you:

**It puts the accountable party where authorship norms already put them.** Venues hold *named
human authors* responsible for a manuscript's content. A tool that declared output
"submission-ready" would be asserting a judgement it has no standing to make and the customer
cannot delegate. The default aligns the product's claim with the accountability structure the
customer is actually operating in, which is why a research-integrity office can approve it.

**It converts an unbounded promise into a bounded deliverable.** "Produces a publishable paper"
is unfalsifiable at sale and indefensible at renewal. "Produces an assisted draft with a
provenance manifest and a disclosure block, every quantitative claim traced to a run or marked
fabricated" is a specification you can put in a contract and be measured against. Bounded
deliverables are what make enterprise contracts signable.

**Venue policies vary and change faster than the software.** Disclosure requirements differ by
venue and are revised between cycles. Any product that certified readiness against them would
be asserting knowledge of a moving target it does not track, and would be wrong on some
customer's venue on some cycle. Refusing to certify is not caution; it is declining to make a
claim about facts you do not have.

**The tail risk is asymmetric and lands on you.** One customer retraction traceable to an
undisclosed generated manuscript costs more reputation than the entire first year of revenue.
The default makes it structurally hard for a customer to reach a venue without a disclosure,
and — more importantly — makes it *documented* that they were told.

**RECOMMENDATION:** do not merely keep this default. Sell it. It is the single most credible
thing in the product for an institutional buyer, and it is the reason §3 recommends putting a
refusal-only release gate in the free tier.

### Upstream repository and dataset licences

`result-reproducer` already writes a `baseline_license_risk` artifact, which is the right
instinct and more than most tools do. It does not resolve the exposure:

- **Reproducing a baseline means cloning and running someone else's repository.** Many research
  repos are unlicensed (no licence = all rights reserved, not public domain), and others carry
  GPL, CC-BY-NC or research-only terms. A commercial customer deriving from a non-commercial
  baseline is a licence violation the tool facilitated.
- **Benchmark datasets frequently carry research-only or no-redistribution terms.** Segment C
  running a standard benchmark for commercial R&D is a real and common exposure.
- **Model provider terms are the customer's**, which is good for you: BYOK means the customer's
  own agreement governs output ownership, retention and training-on-output. Do not accidentally
  take that on by offering to supply keys.
- **Sensitive data.** Self-hosting keeps the artifact store on the customer's infrastructure; it
  does not stop context sent in live model calls, queries sent to scholarly providers, remote paper
  retrieval, or source-repository clones from leaving it. Only `--offline` with local inputs and/or
  fixture replay, as applicable, avoids those network paths; those modes
  produce synthetic or replayed evidence. This is *not* a HIPAA/GDPR/IRB compliance claim. You
  have no BAA, no DPA and no audit.

**RECOMMENDATION:** allocate this contractually and explicitly. The customer warrants that they
have the right to use every paper, repository and dataset they point the tool at; that they are
responsible for compliance with venue disclosure policies; and that they will not treat any
output as verified without a named human author's review. You warrant that the software does
what the docs say and nothing about the correctness of research conclusions. Cap liability at
fees paid. **FOUNDER DECISION:** whether to offer any IP indemnity at the `site` tier — it is
sometimes the thing that closes an institutional deal, and it is a real liability against a
product with the defect profile in §5. My inclination is no, this year.

### One thing to add that does not exist

`baseline_license_risk` should be promoted into a release-gate **blocker** when the detected
upstream licence is incompatible with the customer's declared use, rather than remaining an
informational artifact. That is a small change with a large sales effect: it is the kind of
control an institutional buyer's legal team asks about by name. Not built.

---

## 7. What to do before charging anyone

Ordered. Items marked **[not built]** are work, not decisions.

1. **Certify the release gate path.** Generate and retain the production private key outside the
   repository; issue a matching real licence; run `tools/license/release-build.mjs --pubkey ...
   --verify-with ...`; retain its fingerprint/proof; and test both community refusal and paid
   Python-stage access from the exact artifact to be shipped. The enforcement and proof tooling are
   built; producing and preserving production release evidence is an operation, not an assumption.
2. **Finish the human leg of the frozen PDF-quality study.** The twelve prioritised code paths,
   three-fixture regression, 18/18 source-integrity check, 18/18 offline pipeline and 18/18 automated
   protocol are complete. Freeze and blind-adjudicate a new claim sample and review the retained
   section/figure differences. **[automated corpus passed; human quality not adjudicated]**
3. **Run the acceptance harness with its complete live envelope** — matching provider key and
   egress, an NVIDIA Container Toolkit GPU and compatible immutable PyTorch/CUDA image, running Docker daemon, paid licence or recorded override, supplied implementation,
   and two fresh project directories — and preserve the report. The mapping/proof code is built;
   the external run has not happened. **[not run]**
4. **Build and measure the CUDA-aware dependency path.** The date snapshot and interpreter pool
   were tested and produced no material lift; do not repeat that recommendation. Conda/PyTorch-index
   and CUDA build-toolchain support remain unproved work. **[not built / not measured]**
5. **Score the innovation engine against the frozen corpus.** Use a real provider, adjudicate the
   complete pairwise packet, and publish recall@k beside the 0.71 contamination floor; then run the
   blind expert panel before claiming output quality. The instruments exist. **[not run]**
6. **Do the pricing interviews in §8** before quoting anyone. Five to ten PIs and three
   industrial research leads is enough to replace four of the six guesses below.
7. **Write the EULA and the support envelope.** Warranty disclaimer, liability cap at fees
   paid, customer warranties on input rights and venue disclosure, and a written definition of
   what `site` support actually promises. **[not built]**
8. **Sign three design partners at $0** — one segment B, one segment C, one that wants the
   `CM_NONE` degradation path specifically — in exchange for a written case study and
   permission to quote a number. Do this *while* 1–5 are in progress, not after.
9. **Then set list prices**, using the interview data rather than §4's guesses.

Selling before item 1 is selling something you have not certified. Selling before items 2 and 3 is
selling something whose quality and acceptance evidence are incomplete. Items 4 and 5 can trail the first
paid contract if the design partners know what they are getting.

---

## 8. Every number I guessed, and how to replace it

I have no market data. The following are judgement calls, listed so they can be attacked
individually rather than inherited silently.

| # | The guess | Where it appears | How to replace it |
|---|---|---|---|
| 1 | Fully-loaded annual cost of a junior researcher in the target geography, and what fraction of it a tool like this defensibly captures | Chain 1, all of §4 | Ask five PIs directly what a first-year student costs their grant, and what they have previously paid for research software. Public salary scales give the floor; the overhead multiplier is institution-specific |
| 2 | The procurement threshold — the amount above which a PI cannot simply expense a purchase | Chain 3, the $6,000 lab price | One question to any PI or department administrator at three target institutions. Cheapest and highest-leverage number here |
| 3 | Whether the innovation engine produces good ideas | §5, the whole value proposition | Run a real-provider engine against the frozen corpus, adjudicate every pair, report recall@k beside the measured contamination floor, then run the blind expert panel |
| 4 | Monthly compute + API spend per segment (the §4 table) | Chain 2, which segments can afford which tier | Ask design partners for their actual monthly cloud and API bill. They will tell you; it is not sensitive |
| 5 | The 4× academic-to-commercial multiple | Commercial tier price | Judgement; test by quoting it to two industrial prospects and watching whether they argue |
| 6 | 2.5–3× annual for perpetual + maintenance | Perpetual option | Standard-shaped, unverified. Only matters if a site requiring offline installation/licence renewal appears; live research still needs approved provider egress |

Two further things I could not determine from the repository, which are not guesses but gaps:

- **Whether any of the 32 skills has ever been run at scale by someone who is not the author.**
  Everything in this document about defect rates comes from the author's own measurement of the
  author's own system, which is admirable and unusually honest, and is still a single observer.
- **What the support load looks like.** A self-hosted product with BYOK, a Python subprocess
  boundary and documented remaining ingestion limits will generate support tickets at a rate nobody has
  observed. If that rate is high, the $6,000 lab tier may be underwater on support alone. The
  design-partner phase is what measures it, which is another reason to run it before pricing.

---

## Summary of the recommendation

Give away everything through the human gate, because that is where the differentiator is
visible and where the measured defects live. Charge at the moment of commitment, when the
customer is about to spend their own compute. Price the lab tier under whatever the procurement
threshold turns out to be, and price the commercial tier as a rounding error on an R&D compute
budget. Sell the refusal — the release gate's `submission_ready: False` is the most credible
asset in the product for an institutional buyer.

And before any of that: certify the exact paid build you intend to ship, because source-tree tests
and a substituted key are not production release evidence.
