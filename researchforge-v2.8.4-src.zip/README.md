# ResearchForge

**v2.8.4.** The changelog audit now reaches the release path, execution boundary and acceptance
grader: genuine issued licences cross TypeScript into the Python gate; untrusted experiments run
only in a validated no-network Docker invocation; live scholarly adapters exist; `--redo`
invalidates every transitive declared build-dependent output; and the acceptance grader fails closed on duplicated,
corrupt, void, stale or copied evidence. v2.8.3 found fourteen false changelog claims, nine caused
by code defects. See `CHANGELOG_v2.md` for the evidence and remaining gates.

Self-hosted research runtime. One paper in; a ranked portfolio of research directions, a human
decision, code, experiments, a manuscript and a defense deck out—subject to the recorded gates.

```bash
researchforge run paper.pdf --project ./my-project
researchforge select --project ./my-project
researchforge status --project ./my-project
researchforge doctor
```

## Measuring the innovation engine

`benchmarks/retro-v1/` holds the retrospective benchmark: seed papers paired with the work that
actually beat them afterwards, derived from archived Papers With Code leaderboards. Read its
README before reading any score from it — the contamination floor is **0.71**, and a system at or
below that number has demonstrated memory, not judgment. `benchmarks/retro-v1/SCORING.md` is how to
score a system against it; `tools/benchmark/blind_rubric.py` is the other half, the one recall@k
cannot supply.

## What is actually built

This repository is honest about its own completeness, because the failure it is designed against is
a system that reports work it did not do.

**All 32 skills are implemented. There are no stubs.** The bundled worked example exercises the
full machinery with explicitly trusted supplied code and synthetic prose. Its v2.8.4 rerun completed
42/42 ledger rows, created 56 editable SVG candidates and a 20-slide native deck, then correctly
blocked release with no packaged deliverables. This is a machinery check, not research evidence.
The NVIDIA Docker mapping/provenance path is implemented, but the live GPU-backed acceptance run
remains blocked on a suitable external host and has not been performed.

| plane | what actually runs |
|---|---|
| intake | repo + git init, sandbox provisioning, PDF/HTML ingestion with anchored locators, paper model, contribution atoms |
| evidence | provider capability registry, quota ledger, live/fixture scholarly adapters with fail-loud errors, measured coverage with named blind spots, search, citation resolution, claim/evidence graph |
| reproduction | clone, dependency detection, environment capture, RL0–RL4 grading, fixed failure taxonomy, comparison-mode degradation |
| innovation | three seed-mining modes, portfolio under mode constraints, novelty + feasibility, Pareto ranking, human gate |
| planning | blueprint whose *shape* follows the comparison mode, falsifiable specs with invalid conditions, ablations, an isolated grader with hidden tests |
| execution | code generation, bounded repair with a hard cap, validated no-network Docker execution by immutable image ID (or an explicitly non-isolated trusted-host profile), append-only ledger, provenance |
| analysis | leakage checks before any statistic, Hedges' g with intervals, Holm–Bonferroni, fabrication detection against the raw ledger, findings including negative results |
| writing | argument spine before prose, per-paragraph claim binding, claim/citation audit, reviewer simulation |
| artifacts | SVG figures verified against the analysis by reading numbers back off the rendered artists, native PPTX, release gate |

The gates are the product. Reproduction runs before ideation; coverage is measured before novelty is
claimed; a number in the draft is traced to the run that produced it or marked fabricated; a figure
that disagrees with its own data is refused; nothing synthetic can be released.

## The three things this design is actually about

**Reproduction runs before ideation.** `IDEAS_READY` is unreachable except through
`REPRO_LEVEL_ESTABLISHED`. An idea whose feasibility and delta were estimated against a code base
nobody tried to run is not an estimate.

**A failed reproduction narrows the project instead of ending it.** The achieved level (RL0–RL4)
sets the comparison mode, and the comparison mode sets which innovation modes remain open:

| RL | comparison mode | admissible innovation modes |
|---|---|---|
| RL3–RL4 | `CM_MEASURED` | all six |
| RL2 | `CM_RELATIVE` | all six, deltas stated relatively |
| RL1 | `CM_REPORTED` | diagnose, evaluate, systemize, guarded transfer |
| RL0 | `CM_NONE` | explain/diagnose and benchmark/evaluate |

At RL0 the run keeps going and produces a non-empty portfolio — of reproducibility studies,
negative-result reports and evaluation-methodology work. The failure taxonomy it just generated is
the evidence for them.

**Coverage is measured, so "we did not find prior work" cannot be confused with "we could not
look."** Under `UNKNOWN_COVERAGE` no candidate may be certified `NOVEL_ENOUGH` — by rule, not by
judgment.

## Architecture

```
manifests/artifact-graph.json     the contract: 128 artifacts, one producer each
        │
        ├─ tools/codegen ──► packages/contracts/src/generated.ts   (TypeScript)
        └─ tools/codegen ──► python/researchforge/generated.py     (Python)

packages/cli        TypeScript: state machine, gating, human interface, licensing
python/researchforge  Python: skills, artifact store, providers, provenance
```

The TypeScript layer owns orchestration and the human gate. The boundary is generated from the
contract rather than separately hand-described: both sides share artifact IDs and dependencies;
Python enforces store ownership/schema checks, while TypeScript gates stage progression on declared
path existence.

Each skill runs as its own subprocess. A crash or timeout is therefore a normal observable outcome
rather than corrupted orchestrator state. The request JSON is passed over standard input but is not
currently stored as a replay artifact. Reproduction requires the inputs, provider responses and
environment to be captured separately; process isolation alone does not supply them.

## The artifact store is where the contract stops being a document

The artifact-store API rejects a skill that reads an undeclared artifact or writes one it does not
own:

```
ContractViolation: skill 'idea-ranker' tried to write 'paper_model',
which is produced by 'paper-model-builder'. Every artifact has exactly one
producer; two writers means no one owns whether it is correct.
```

This is a contract/API invariant, not an OS capability boundary: built-in Python skills run with
host filesystem access and some deliberately manage directory-valued artifacts directly. Generated
experiment code is the code that runs inside the separate Docker sandbox. Ownership is checked for
all store-mediated writes; the nine artifacts with declared schemas are schema-validated there. The acceptance
grader separately treats malformed or mutually inconsistent on-disk evidence as `NOT_MEASURED`.

## BYOK

No model key ships with this. Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` for a live model run.
`RESEARCHFORGE_CONTACT_EMAIL` identifies OpenAlex/Crossref requests for their polite pools; it does
not configure arXiv and it is not a credential. Set `SEMANTIC_SCHOLAR_API_KEY` separately when the
Semantic Scholar provider is enabled; the provider is reported unavailable rather than silently
substituting fixture data when that key is absent.

`--offline` runs without a model or live scholarly HTTP. Model-derived artifacts and provenance are
stamped synthetic, the CLI reports `[SYNTHETIC]`, and the release gate treats that as a blocker.
It exists to exercise the machinery. It is not a demo mode and it is not research.

## Worked example

One command, from an abstract-page fixture to a synthetic, submission-refused result, with no GPU,
model key or network call:

```bash
./examples/attention-length-generalization/run.sh /tmp/example
```

The script uses the explicit `trusted-host-code` profile only for its bundled, operator-trusted
implementation; that profile provides no isolation. Do not use it for generated or third-party code.
See the example README for why the method under test must be supplied rather than invented.

## Install

The distribution/runtime version is 2.8.4. The `0.3.0` values in skill frontmatter,
`skill-catalog.json` and `merge-map.json` identify the separately versioned skill-contract lineage;
they are not stale Python/npm package versions.

```bash
npm ci && npm run build               # TypeScript, from the committed lockfile
pip install -e 'python[dev]'          # Python core plus the test runner
node packages/cli/dist/cli.js doctor  # check the wiring
```

## Test

```bash
npm test        # current TypeScript contract, ordering, licensing and redo suite
npm run test:py # 689 Python passes, 26 fixture-dependent skips; see the v2.8.4 changelog
```

The source bundle deliberately omits three real-PDF fixtures whose redistribution terms are not
established. Consequently 26 fixture-dependent tests report `SKIPPED` in the bundled-source run;
they do not count as passes and they are not evidence that PDF quality was re-measured.

The Python suite is mostly tests that something is correctly *refused*: an abstract page is reported
as insufficient; zero search results do not become evidence of novelty; a comparative experiment is
not compiled under CM_NONE; no metric is invented when isolation is unavailable; a leak is a blocker;
runs scored by different evaluator versions are refused for aggregation; a real-but-irrelevant
citation is NOT_SUPPORTED; a number with no run behind it is FABRICATED; a slide number bound to no
artifact blocks the deck; a skill edit that improves train but regresses held-out is rejected.

## Licensing

Self-hosted, offline-verified, Ed25519. **Licence verification** has no phone-home: a six-hour run
must not die because a licensing server was unreachable. This is not a claim that live research has
no egress; live model/scholarly calls, remote paper retrieval and source-repository clones use the
network unless the run deliberately uses `--offline` with local inputs and fixture replay.

The enforceable gate lives at the Python choke point in `python/researchforge/licensing.py`, because
`researchforge.runner` is invokable directly and a gate that lives only upstream gates nothing. The
TypeScript CLI displays licence status and restrictions and injects its compiled public key into the
Python subprocess; the release builder proves a matching genuine licence unlocks a paid Python skill.
The gate cannot be made unbypassable in self-hosted software, and pretending otherwise produces
hostile DRM that punishes honest users. It refuses by default and makes an override an explicit,
*recorded* act that surfaces in the run's provenance and release manifest.

Issuing lives in `tools/license/` — `keygen.mjs`, `issue.mjs` (self-checks every licence before
emitting it), and `server.mjs` (admin-token gated, rate-limited, append-only issuance ledger, never
logs the key). Run it where the customer cannot reach it.

Community includes ingestion, literature, reproduction, the innovation engine and the human gate —
everything up to the decision a person should make. `docs/COMMERCIAL.md` argues why that is the right
free tier and proposes prices; it is a proposal, and it marks every place it had to guess.

## Measured quality, including where it is bad

- `docs/study/FINDINGS.md` — 20 real papers probed. **In that frozen sample, 40% could not begin
  reproduction at all** (no code, or no environment spec anywhere in the tree). The frozen decision rule was NOT triggered, and the
  document explains why claiming otherwise would have been the exact error the study exists to prevent.
- `docs/study/APRIME_FINDINGS.md` — the "dependency time machine" this project recommended was built
  and tested on the same 20 papers. **It produced zero real lift.** The recommendation was wrong and
  has been corrected in the code.
- `docs/PDF_INGEST_QUALITY.md` — the pre-fix study plus the pinned post-fix PDF18 rerun. All 18
  source hashes, all 18 offline pipelines and all 18 automated non-human protocol checks passed
  over 375 pages; the report retains the less flattering quality snapshot too (5/17 exact section
  counts and 16/17 exact figure counts). Human claim precision remains `NOT_ADJUDICATED`, so the
  automated pass is not presented as complete quality certification.
- `acceptance/` — the rubric and grader for the full run on real keys and a GPU. That run has not
  been performed. The strict backend now exposes a GPU only after literal opt-in and a restrictive
  in-container `torch.cuda` probe; the runner records the exact `--gpus all` command and the grader
  requires every ledger row to agree. This Apple M3 host cannot clear that NVIDIA gate, and nothing
  here claims a certified acceptance result.

## Where to go next

The 20-paper reproduction study, A-prime dependency probe, retrospective corpus, PDF18 automated
rerun and acceptance instrument are built. GPU mapping and persisted proof are implemented. The
remaining evidence gates are concrete: run two fresh projects on an NVIDIA Container Toolkit host
with a compatible immutable PyTorch/CUDA image; freeze and blind-adjudicate a new PDF claim sample
and investigate the retained section/figure mismatches; execute the paired human B arm;
score/adjudicate a real-provider innovation run; verify the complete live-service envelope; and
perform the production-key/signing release. `docs/EXTERNAL_GATES_v2.8.4.md` and its JSON companion
separate every passed readiness subgate from those still-open real-world outcomes.

This source bundle does not include a root software licence. It therefore supplies no standalone
public-redistribution grant; selecting commercial/open-source terms is an owner decision, not one
the build may silently make.
