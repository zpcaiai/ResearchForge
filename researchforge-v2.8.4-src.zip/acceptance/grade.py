#!/usr/bin/env python3
"""The acceptance grader: does a finished ResearchForge project contain acceptable research?

This is intended to run after the live acceptance harness and answers one
artifact-level question with a machine-checkable result. The v2.8.4 project
contract does not immutably attest model credentials or live provider transport,
so this grader makes no claim about those external preconditions. GPU allocation
is graded only when the strict provisioner, executed Docker command and every
completed ledger row persist mutually consistent NVIDIA device evidence. It is
deliberately NOT a second opinion
on the questions the pipeline already answers. `claim-citation-auditor` decides
whether a claim is fabricated; `integrity-auditor` decides whether the statistics
hold; `release-gate` decides whether an artifact may ship. Re-deriving any of
those verdicts here would create a second threshold for the same question, and the
lower of two thresholds is the one that governs — which means the careful one
upstream would silently stop mattering. So those verdicts are CONSUMED.

What this file adds is the set of quantities nothing upstream computes, because
every upstream check is per-item and this one is per-project: coverage and ratio.
The gate refuses one fabricated claim; it has nothing to say about a manuscript
where 40% of the claims are only partially supported. The figure factory refuses
one figure bound to an unknown claim; it has nothing to say about a claim with no
figure. The blueprint compiler writes an ablation per mechanism; nothing checks
that the ablation ever ran.

The other rule this file keeps is that a dimension it could not measure is
NOT_MEASURED, which is a distinct outcome from PASS and blocks acceptance exactly
as a FAIL does. A grader that scores an absent artifact as a pass is the failure
mode the whole system is built against, reappearing in the grader.

Usage:
    python3 grade.py PROJECT_DIR [--second-run DIR] [--out DIR] [--quiet]

Exit codes: 0 ACCEPTED, 1 REJECTED, 2 INCOMPLETE (something was not measurable),
3 REFUSED (synthetic project, or the grader could not start).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:  # Matches execution._parse_structured; compiler output remains JSON-subset YAML.
    import yaml as _yaml
except Exception:  # pragma: no cover - stripped operator install
    _yaml = None

#: Read from RUBRIC.md rather than duplicated, because it was duplicated and it
#: drifted: every acceptance report stamped 1.0.0 while the rubric it applied was
#: 1.1.0, so a stored verdict could not be matched to the thresholds that produced
#: it — which is the one thing a version stamp is for.
def _rubric_version(default: str = "0.0.0") -> str:
    try:
        head = (Path(__file__).with_name("RUBRIC.md")).read_text(encoding="utf-8")[:200]
    except OSError:
        return default
    m = re.search(r"^#\s*Acceptance rubric\s+v([0-9]+\.[0-9]+\.[0-9]+)", head, re.M)
    return m.group(1) if m else default


RUBRIC_VERSION = _rubric_version()

PASS, FAIL, NOT_MEASURED, NOT_APPLICABLE = "PASS", "FAIL", "NOT_MEASURED", "NOT_APPLICABLE"

# --------------------------------------------------------------------------
# Thresholds that already exist somewhere in the runtime.
#
# These are copies, and a copy that drifts is worse than no copy at all: the
# grader would then hold the project to a number the project never agreed to. So
# `_assert_constants_agree` re-reads them from the package when the package is
# importable and refuses to grade on a disagreement rather than quietly using the
# stale value. Every one of them is sourced, not chosen.
# --------------------------------------------------------------------------
#: python/researchforge/skills/planning.py::MIN_SEEDS_FOR_COMPARATIVE
#: python/researchforge/skills/analysis.py::MIN_SEEDS_FOR_INFERENCE
MIN_SEEDS_INFERENTIAL = 3
#: analysis.py::_summary refuses an interval below n=2 ("a single observation
#: carries no dispersion information"), so 2 is the floor for any claim that
#: reports a spread at all, even a purely descriptive one.
MIN_SEEDS_DESCRIPTIVE = 2
#: analysis.py::DEFAULT_ALPHA — overridden per project by stats_audit["alpha"]
DEFAULT_ALPHA = 0.05
#: analysis.py::IntegrityAuditor.execute, criteria["max_failure_rate"] default
MAX_FAILURE_RATE = 0.34

#: artifacts_out.py::SYNTHETIC_KEYS — the same markers the release gate refuses on
SYNTHETIC_KEYS = ("synthetic", "_synthetic", "is_synthetic")

#: Baseline kinds planning.py::_baseline emits per comparison mode. A spec whose
#: baseline kind belongs to another mode is making a comparison the mode does not
#: license, whatever its prose says.
BASELINE_KIND_FOR_MODE = {
    "CM_MEASURED": {"locally_measured"},
    "CM_RELATIVE": {"locally_measured_reduced_scale"},
    "CM_REPORTED": {"reported_by_authors"},
    "CM_NONE": {"internal_reference_condition"},
}
#: Ablation and evaluation specs are internal contrasts against our own artifact,
#: so their baseline is not drawn from the mode's external-baseline vocabulary.
INTERNAL_BASELINE_KINDS = {"own_full_method", "metric_under_test",
                           "internal_reference_condition"}

#: planning.py claim types that assert a between-condition difference. These are
#: the ones that need dispersion, i.e. MIN_SEEDS_INFERENTIAL.
INFERENTIAL_CLAIM_TYPES = {"comparative", "ablation"}

#: python/researchforge/invalid_conditions.py::evaluate.  The standalone grader
#: cannot assume the package is importable, but it must recognise the predicate
#: vocabulary the compiler writes.  Unknown kinds remain prose/unchecked rather
#: than becoming acceptable merely because a ``check`` object exists.
REGISTERED_INVALID_CHECK_KINDS = {
    "min_completed_runs_per_condition",
    "ledger_arm_completed",
    "field_stable_across_runs",
    "metric_names_stable",
    "configs_match_except",
    "artifact_field_present",
    "text_present_in_artifact",
}
LEGACY_INVALID_OPERATORS = {">", ">=", "<", "<=", "==", "!="}

#: The strict sandbox provisioner and experiment runner both bind execution to
#: Docker's content-addressed image and daemon-issued container identities.
#: Tags are useful operator input, but they are not acceptance evidence.
DOCKER_IMAGE_ID_RE = re.compile(r"sha256:[0-9a-f]{64}\Z")
DOCKER_CONTAINER_ID_RE = re.compile(r"[0-9a-f]{64}\Z")
SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
STRICT_SANDBOX_PROFILE = "no-network-untrusted-code"


class GraderRefusal(Exception):
    """The grader will not produce a score. Not a low score — no score."""


# --------------------------------------------------------------------------
# results model
# --------------------------------------------------------------------------
@dataclass
class Check:
    id: str
    outcome: str
    detail: str
    measured: Any = None
    threshold: Any = None

    def as_dict(self) -> dict[str, Any]:
        return {"id": self.id, "outcome": self.outcome, "measured": self.measured,
                "threshold": self.threshold, "detail": self.detail}


@dataclass
class Dimension:
    id: str
    title: str
    checks: list[Check] = field(default_factory=list)

    def add(self, check: Check) -> Check:
        self.checks.append(check)
        return check

    @property
    def outcome(self) -> str:
        outs = [c.outcome for c in self.checks]
        if not outs:
            return NOT_MEASURED
        # FAIL outranks NOT_MEASURED: a dimension with one proven defect is failed
        # whether or not some other part of it was measurable. Both block
        # acceptance, so the ordering only affects what the operator is told to fix
        # first, and a proven defect is the more actionable of the two.
        if FAIL in outs:
            return FAIL
        if NOT_MEASURED in outs:
            return NOT_MEASURED
        if all(o == NOT_APPLICABLE for o in outs):
            return NOT_APPLICABLE
        return PASS

    def as_dict(self) -> dict[str, Any]:
        return {"id": self.id, "title": self.title, "outcome": self.outcome,
                "checks": [c.as_dict() for c in self.checks]}


def ok(cid: str, detail: str, measured: Any = None, threshold: Any = None) -> Check:
    return Check(cid, PASS, detail, measured, threshold)


def bad(cid: str, detail: str, measured: Any = None, threshold: Any = None) -> Check:
    return Check(cid, FAIL, detail, measured, threshold)


def unmeasured(cid: str, detail: str) -> Check:
    return Check(cid, NOT_MEASURED, detail)


def na(cid: str, detail: str) -> Check:
    return Check(cid, NOT_APPLICABLE, detail)


def gate(cid: str, condition: bool, pass_detail: str, fail_detail: str,
         measured: Any = None, threshold: Any = None) -> Check:
    return (ok(cid, pass_detail, measured, threshold) if condition
            else bad(cid, fail_detail, measured, threshold))


# --------------------------------------------------------------------------
# project loading
# --------------------------------------------------------------------------
class Project:
    """Artifact access by contract id, never by hardcoded path.

    Paths come from manifests/artifact-graph.json because that file is the only
    source of truth for where an artifact lives (docs/CONTRACT.md). A grader with
    its own copy of the layout would grade a project the runtime does not produce.
    """

    def __init__(self, project: Path, repo_root: Path) -> None:
        self.project = Path(project).resolve()
        self.repo_root = Path(repo_root).resolve()
        graph_path = self.repo_root / "manifests" / "artifact-graph.json"
        if not graph_path.exists():
            raise GraderRefusal(
                f"cannot read the artifact contract at {graph_path}. The grader resolves every "
                f"artifact through the contract and will not guess paths; pass --repo-root or set "
                f"RESEARCHFORGE_ROOT to the repository that produced this project.")
        graph = json.loads(graph_path.read_text(encoding="utf-8"))
        self.specs_by_id: dict[str, dict[str, Any]] = dict(graph.get("artifacts") or {})
        for owner, internals in (graph.get("internal_artifacts") or {}).items():
            for aid, spec in internals.items():
                # Internal artifacts leave the public contract but not the disk
                # (CONTRACT.md rule 5). The grader is not a skill and is not bound by
                # the read rules, but it must still find them where they actually are.
                self.specs_by_id.setdefault(aid, {**spec, "producer": owner, "internal": True})
        self._cache: dict[str, Any] = {}
        self._experiment_specs_cache: list[dict[str, Any]] | None = None
        self.missing: set[str] = set()
        self.corrupt: set[str] = set()

    # -- paths ----------------------------------------------------------
    def rel(self, aid: str) -> str:
        spec = self.specs_by_id.get(aid)
        if spec is None:
            raise GraderRefusal(f"'{aid}' is not in the artifact contract")
        return str(spec["path"]).split("|")[0]

    def path(self, aid: str) -> Path:
        return self.project / self.rel(aid)

    def is_dir_artifact(self, aid: str) -> bool:
        return self.rel(aid).endswith("/")

    def exists(self, aid: str) -> bool:
        p = self.path(aid)
        return (p / "_manifest.json").exists() if self.is_dir_artifact(aid) else p.exists()

    # -- reads ----------------------------------------------------------
    def get(self, aid: str, default: Any = None) -> Any:
        """Read an artifact, or record that it was absent and return `default`.

        Every absence is remembered. A dimension that consumed a missing artifact
        must report NOT_MEASURED, and it can only know to do that if the loader
        keeps the list.
        """
        if aid in self._cache:
            return self._cache[aid]
        p = self.path(aid)
        if self.is_dir_artifact(aid):
            p = p / "_manifest.json"
        if not p.exists():
            self.missing.add(aid)
            return default
        try:
            if p.suffix == ".jsonl":
                value: Any = [json.loads(line) for line in
                              p.read_text(encoding="utf-8").splitlines() if line.strip()]
            elif p.suffix == ".json":
                value = json.loads(p.read_text(encoding="utf-8"))
            else:
                value = p.read_text(encoding="utf-8", errors="replace")
        except (json.JSONDecodeError, OSError):
            # An artifact that exists but cannot be parsed is not a pass and is not
            # an absence: it is a corrupt input, and the dimension that needed it
            # must say so rather than fall through to a default.
            self.missing.add(aid)
            return default
        self._cache[aid] = value
        return value

    def experiment_specs(self) -> list[dict[str, Any]]:
        """Resolve the `experiments/*.yaml` glob the way execution.py resolves it.

        Same rule as `_load_experiment_specs`: a file in `experiments/` without an
        `experiment_id` is not an experiment. `ablation_plan.yaml` lives there too,
        and counting it as a spec would invent a planned run.
        """
        if self._experiment_specs_cache is not None:
            return list(self._experiment_specs_cache)

        root = self.project / "experiments"
        out: list[dict[str, Any]] = []
        if not root.is_dir():
            self.missing.add("experiment_specs")
            self._experiment_specs_cache = out
            return out
        # The glob overlaps two separately contracted YAML artifacts. They are
        # not ExperimentSpecs and their own consumers decide whether they parse.
        # Every other matching file belongs to this collection: silently skipping
        # one would grade a partial plan as though it were the whole plan.
        non_specs = {self.rel(aid) for aid in ("sandbox_container_config", "ablation_plan")
                     if aid in self.specs_by_id}
        malformed: list[str] = []
        for p in sorted(list(root.glob("*.yaml")) + list(root.glob("*.yml"))):
            rel = str(p.relative_to(self.project))
            if rel in non_specs:
                continue
            try:
                text_value = p.read_text(encoding="utf-8")
                obj = (_yaml.safe_load(text_value) if _yaml is not None
                       else json.loads(text_value))
            except Exception:  # same parser boundary as the runner; one corrupt member poisons all
                malformed.append(rel)
                continue
            items = obj if isinstance(obj, list) else [obj]
            if not items or any(not isinstance(item, dict) or not item.get("experiment_id")
                                for item in items):
                malformed.append(rel)
                continue
            out.extend(dict(item) for item in items)
        if malformed:
            # A subset is more dangerous than no collection: ledger rows for the
            # unreadable specs then become invisible to every per-spec check.
            out = []
            self.corrupt.add("experiment_specs")
            self.missing.add("experiment_specs")
        elif not out:
            self.missing.add("experiment_specs")
        self._experiment_specs_cache = out
        return list(out)


# --------------------------------------------------------------------------
# small shared readings of the ledger — deliberately the same conventions the
# analysis plane uses, so the grader and the auditor are looking at one dataset
# --------------------------------------------------------------------------
def entry_ok(entry: dict) -> bool:
    """analysis.py::_ok — the statuses that count as a measurement."""
    return str(entry.get("status", "")).lower() in (
        "ok", "success", "succeeded", "completed", "pass")


def entry_seed(entry: dict) -> Any:
    if entry.get("seed") is not None:
        return entry["seed"]
    provenance = entry.get("provenance")
    return provenance.get("seed") if isinstance(provenance, dict) else None


def entry_arm(entry: dict) -> str:
    """The runner's arm convention, including legacy candidate-only rows."""
    provenance = entry.get("provenance")
    provenance_arm = provenance.get("arm") if isinstance(provenance, dict) else None
    return str(provenance_arm or entry.get("arm") or "candidate")


def spec_arms(spec: dict) -> list[str]:
    """The arms the current runner would execute for this spec."""
    arms = [arm for arm in ("baseline", "candidate", "sota")
            if isinstance(spec.get(arm), dict) and spec[arm].get("required") is not False]
    return arms or ["candidate"]


def metric_names(spec: dict) -> list[str]:
    out = []
    for m in spec.get("metrics") or []:
        if isinstance(m, str):
            out.append(m)
        elif isinstance(m, dict) and m.get("name"):
            out.append(str(m["name"]))
    return out


def numeric_metrics(entry: dict) -> dict[str, float]:
    out = {}
    metrics = entry.get("metrics")
    if not isinstance(metrics, dict):
        return out
    for k, v in metrics.items():
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            continue
        out[k] = float(v)
    return out


def valid_alpha(value: Any) -> float | None:
    """Return a literal finite probability strictly inside (0, 1)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    alpha = float(value)
    return alpha if math.isfinite(alpha) and 0.0 < alpha < 1.0 else None


def _canonical_record(record: dict) -> str:
    """Stable JSON used only to tell identical output from a conflict."""
    return json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False)


def _normalise_records(raw: Any, *, artifact: str, identity) \
        -> tuple[list[dict] | None, str | None]:
    """Collapse identical records and reject two bodies for one logical identity.

    Repeated output is one observation, not extra evidence. Two different records
    that both claim to be that observation are worse: choosing either would let the
    grader manufacture a result, so the artifact becomes unmeasurable.
    """
    if not isinstance(raw, list):
        return None, f"{artifact} is not a JSONL record list"
    out: list[dict] = []
    seen: dict[Any, str] = {}
    for index, record in enumerate(raw):
        if not isinstance(record, dict):
            return None, f"{artifact} record {index + 1} is {type(record).__name__}, not an object"
        try:
            key = identity(record)
            body = _canonical_record(record)
        except (TypeError, ValueError) as e:
            return None, f"{artifact} record {index + 1} is not canonical JSON ({type(e).__name__})"
        if key is None:
            return None, f"{artifact} record {index + 1} has no stable identity"
        previous = seen.get(key)
        if previous is None:
            seen[key] = body
            out.append(record)
        elif previous != body:
            return None, f"{artifact} contains conflicting records for identity {key!r}"
        # An identical body for the same identity is duplicate output. It is not a
        # second planned run or a second audited claim and is deliberately omitted.
    return out, None


def _ledger_identity(entry: dict) -> tuple[Any, ...] | None:
    # Canonical JSON alone only proves the row can be serialised. These mappings
    # are dereferenced throughout the grader, so a scalar in either position is a
    # corrupt ledger record rather than an empty mapping or an operator crash.
    if not isinstance(entry.get("metrics"), dict):
        raise ValueError("metrics is not an object")
    if entry.get("provenance") is not None and not isinstance(entry.get("provenance"), dict):
        raise ValueError("provenance is not an object")
    provenance = entry.get("provenance") or {}
    if (entry.get("arm") not in (None, "") and provenance.get("arm") not in (None, "")
            and str(entry["arm"]) != str(provenance["arm"])):
        raise ValueError("top-level arm conflicts with provenance.arm")
    if (entry.get("seed") is not None and provenance.get("seed") is not None
            and str(entry["seed"]) != str(provenance["seed"])):
        raise ValueError("top-level seed conflicts with provenance.seed")
    if not isinstance(entry.get("status"), str) or not entry.get("status"):
        raise ValueError("status is not a non-empty string")
    attempt = entry.get("attempt_id")
    if attempt not in (None, ""):
        return ("attempt", str(attempt))
    run_id, experiment_id, seed = entry.get("run_id"), entry.get("experiment_id"), entry_seed(entry)
    if run_id in (None, "") or experiment_id in (None, "") or seed is None:
        return None
    return ("run", str(run_id), str(experiment_id), entry_arm(entry), str(seed))


def normalise_ledger(raw: Any) -> tuple[list[dict] | None, str | None]:
    return _normalise_records(raw, artifact="experiment_ledger",
                              identity=_ledger_identity)


def _claim_audit_identity(record: dict) -> tuple[str, str] | None:
    locator, text_value = record.get("locator"), record.get("text")
    if not isinstance(locator, str) or not locator or not isinstance(text_value, str) or not text_value:
        return None
    # `_atomic_claims` emits one record per sentence at a manuscript locator. The
    # claim marker is an attribute of that sentence, not a second identity. If it
    # changes for the same locator/text, the audit conflicts with itself; making
    # it part of the key would let relabelled copies inflate the support ratio.
    return (locator, text_value)


def normalise_claim_audit(raw: Any) -> tuple[list[dict] | None, str | None]:
    # One paragraph can contain several atomic sentences with the same claim_id
    # and locator, so text is part of the producer's logical record identity.
    return _normalise_records(raw, artifact="claim_audit",
                              identity=_claim_audit_identity)


def valid_ledger(p: Project, raw: list[dict] | None) -> tuple[list[dict] | None, set[str]]:
    """Remove experiments the runner declared void, or refuse to infer validity.

    A void experiment ran, so its rows still count when measuring execution
    reliability. Scientifically it is nothing: it cannot satisfy seed adequacy,
    a frontier-arm requirement, or ablation coverage. The runtime centralised
    this rule in ``invalid_conditions.drop_void``; the standalone grader cannot
    import the package reliably, so it applies the same small reading here.

    ``None`` means the validity artifact was absent or malformed. Treating that
    as an empty void list would turn a partial write into an acceptance pass.
    """
    if raw is None:
        return None, set()
    tree = p.get("experiment_tree", default=None)
    if not isinstance(tree, dict) or not isinstance(tree.get("void_experiments"), list):
        return None, set()
    raw_void = tree["void_experiments"]
    if (any(not isinstance(v, str) or not v.strip() for v in raw_void)
            or len(set(raw_void)) != len(raw_void)):
        p.corrupt.add("experiment_tree")
        return None, set()
    void = {v.strip() for v in raw_void}

    # Current experiment trees carry the decision twice on purpose: each
    # per-experiment validity record says whether a predicate fired, and the
    # top-level list is what downstream readers drop. Those two facts must be
    # identical. Choosing the empty list when a FIRED verdict says otherwise is
    # precisely how a void result becomes publishable evidence.
    validity = tree.get("validity")
    if isinstance(validity, list):
        derived_void: set[str] = set()
        seen: set[str] = set()
        for record in validity:
            if not isinstance(record, dict) or not isinstance(record.get("experiment_id"), str) \
                    or not record["experiment_id"].strip():
                p.corrupt.add("experiment_tree")
                return None, set()
            experiment_id = record["experiment_id"].strip()
            if experiment_id in seen or not isinstance(record.get("void"), bool) \
                    or not isinstance(record.get("verdicts"), list) \
                    or not isinstance(record.get("fired"), list):
                p.corrupt.add("experiment_tree")
                return None, set()
            seen.add(experiment_id)
            verdicts = record["verdicts"]
            if any(not isinstance(v, dict) or v.get("status") not in
                   ("CLEAR", "FIRED", "UNCHECKED") for v in verdicts):
                p.corrupt.add("experiment_tree")
                return None, set()
            fired_codes = [str(v.get("code", "?")) for v in verdicts
                           if v.get("status") == "FIRED"]
            if (any(not isinstance(code, str) for code in record["fired"])
                    or sorted(record["fired"]) != sorted(fired_codes)
                    or record["void"] is not bool(fired_codes)):
                p.corrupt.add("experiment_tree")
                return None, set()
            if record["void"]:
                derived_void.add(experiment_id)
        if derived_void != void:
            p.corrupt.add("experiment_tree")
            return None, set()
    elif validity is not None and not isinstance(validity, dict):
        # A mapping is the pre-v2 legacy shape and carries no per-condition facts
        # to reconcile. Any other shape is neither legacy nor current.
        p.corrupt.add("experiment_tree")
        return None, set()
    return [e for e in raw if str(e.get("experiment_id") or "") not in void], void


def planned_run_identities(specs: list[dict], tree: dict) \
        -> tuple[list[tuple[str, ...]] | None, str | None]:
    """Return the immutable denominator identities for E1.2.

    Current runners record one ``run:ATTEMPT_ID`` node for every planned
    experiment/arm/seed tuple.  Legacy trees have no nodes, so the exact same
    plan can be reconstructed from the specs.  A partial or duplicate node set is
    not allowed to silently fall back: that would let deleting a failed node
    shrink the denominator just as deleting its ledger row used to do.
    """
    expected: list[tuple[str, str, str]] = []
    for spec in specs:
        experiment_id = str(spec.get("experiment_id") or "")
        raw_seeds = [int(seed) for seed in (spec.get("seeds") or [])
                     if str(seed).lstrip("-").isdigit()] or [0]
        for arm in spec_arms(spec):
            expected.extend((experiment_id, arm, str(seed)) for seed in raw_seeds)
    if not expected:
        return None, "the ExperimentSpecs produce no planned run identity"
    if len(set(expected)) != len(expected):
        return None, "the ExperimentSpecs contain duplicate experiment/arm/seed plan identities"

    nodes_present = "nodes" in tree
    if not nodes_present:
        declared = tree.get("planned_runs")
        if declared is not None and (isinstance(declared, bool)
                                     or not isinstance(declared, int)
                                     or declared != len(expected)):
            return None, (f"experiment_tree.planned_runs={declared!r} conflicts with the "
                          f"{len(expected)} identities derived from the specs")
        return [("logical", *identity) for identity in expected], None

    nodes = tree.get("nodes")
    if not isinstance(nodes, list):
        return None, "experiment_tree.nodes is present but is not a list"
    run_nodes = [node for node in nodes
                 if isinstance(node, dict) and node.get("kind") == "run"]
    if any(not isinstance(node, dict) for node in nodes):
        return None, "experiment_tree.nodes contains a non-object record"
    logical: list[tuple[str, str, str]] = []
    attempts: list[tuple[str, ...]] = []
    for index, node in enumerate(run_nodes):
        experiment_id, arm, seed = node.get("experiment_id"), node.get("arm"), node.get("seed")
        node_id = node.get("node_id")
        if (experiment_id in (None, "") or arm in (None, "") or seed is None
                or not isinstance(node_id, str) or not node_id.startswith("run:")
                or not node_id[4:]):
            return None, f"experiment_tree run node {index + 1} has no stable plan identity"
        logical.append((str(experiment_id), str(arm), str(seed)))
        attempts.append(("attempt", node_id[4:]))
    if len(set(logical)) != len(logical) or len(set(attempts)) != len(attempts):
        return None, "experiment_tree contains duplicate or conflicting planned run identities"
    if set(logical) != set(expected):
        missing = sorted(set(expected) - set(logical))
        extra = sorted(set(logical) - set(expected))
        return None, (f"experiment_tree run nodes disagree with the ExperimentSpecs; "
                      f"missing={missing[:5]}, extra={extra[:5]}")
    declared = tree.get("planned_runs")
    if declared is not None and (isinstance(declared, bool)
                                 or not isinstance(declared, int)
                                 or declared != len(attempts)):
        return None, (f"experiment_tree.planned_runs={declared!r} conflicts with "
                      f"{len(attempts)} run nodes")
    return attempts, None


def tree_ledger_coherence(tree: dict, ledger: list[dict]) -> str | None:
    """Validate facts duplicated by the runner in its tree and ledger.

    The tree is the immutable plan used as E1.2's denominator, but current tree
    run nodes also copy each entry's logical identity, status and metrics. Once
    both artifacts exist, a disagreement is corruption: selecting whichever body
    produces the better grade would be a fail-open.
    """
    if "nodes" not in tree:                  # legacy tree: no duplicated facts
        return None
    nodes = tree.get("nodes")
    if not isinstance(nodes, list):
        return "experiment_tree.nodes is not a list"
    run_nodes = [node for node in nodes
                 if isinstance(node, dict) and node.get("kind") == "run"]
    by_attempt: dict[str, dict] = {}
    for index, node in enumerate(run_nodes):
        node_id = node.get("node_id")
        if not isinstance(node_id, str) or not node_id.startswith("run:") or not node_id[4:]:
            return f"experiment_tree run node {index + 1} has no attempt identity"
        attempt = node_id[4:]
        if attempt in by_attempt:
            return f"experiment_tree repeats attempt {attempt!r}"
        if (not isinstance(node.get("status"), str) or not node["status"]
                or not isinstance(node.get("metrics"), dict)):
            return f"experiment_tree run node {attempt!r} has malformed status or metrics"
        by_attempt[attempt] = node

    rows: dict[str, dict] = {}
    for entry in ledger:
        attempt = entry.get("attempt_id")
        if not isinstance(attempt, str) or not attempt:
            return "a current-tree ledger row has no string attempt_id"
        if attempt not in by_attempt:
            return f"ledger attempt {attempt!r} has no run node in experiment_tree"
        rows[attempt] = entry       # normalise_ledger already proved uniqueness

    for attempt, node in by_attempt.items():
        entry = rows.get(attempt)
        if entry is None:
            # Omitted failed/NOT_RUN rows still remain in the denominator. A node
            # claiming completion without its ledger evidence is instead a partial
            # write whose metrics cannot be trusted.
            if entry_ok(node):
                return f"completed tree attempt {attempt!r} has no ledger row"
            continue
        node_identity = (str(node.get("experiment_id")), str(node.get("arm")),
                         str(node.get("seed")))
        row_identity = (str(entry.get("experiment_id")), entry_arm(entry),
                        str(entry_seed(entry)))
        if node_identity != row_identity:
            return (f"attempt {attempt!r} has tree identity {node_identity!r} but ledger "
                    f"identity {row_identity!r}")
        if str(node["status"]) != str(entry.get("status")):
            return (f"attempt {attempt!r} has tree status {node['status']!r} but ledger status "
                    f"{entry.get('status')!r}")
        if _canonical_record(node["metrics"]) != _canonical_record(entry["metrics"]):
            return f"attempt {attempt!r} has conflicting tree and ledger metrics"
    return None


def completion_against_plan(ledger: list[dict], plan: list[tuple[str, ...]]) \
        -> tuple[int | None, str | None]:
    """Count completed planned identities once, never ledger rows."""
    if plan and plan[0][0] == "attempt":
        rows = {("attempt", str(entry.get("attempt_id"))): entry for entry in ledger
                if entry.get("attempt_id") not in (None, "")}
    else:
        plan_set = set(plan)
        grouped: dict[tuple[str, ...], list[dict]] = {}
        for entry in ledger:
            key = ("logical", str(entry.get("experiment_id") or ""), entry_arm(entry),
                   str(entry_seed(entry)))
            if key in plan_set:
                grouped.setdefault(key, []).append(entry)
        ambiguous = [key for key, records in grouped.items() if len(records) > 1]
        if ambiguous:
            return None, ("legacy plan identities match multiple ledger attempts: "
                          f"{ambiguous[:5]}")
        rows = {key: records[0] for key, records in grouped.items()}
    return sum(1 for identity in plan if identity in rows and entry_ok(rows[identity])), None


def synthetic_hits(label: str, payload: Any, path: str = "") -> list[str]:
    """artifacts_out.py::_synthetic_hits, applied to the same markers.

    Only `is True` counts. `"_synthetic": false` is the runtime saying the opposite
    of what this looks for, and treating a present-but-false flag as a hit would
    make the grader refuse every honest project.
    """
    hits: list[str] = []
    if isinstance(payload, dict):
        for k, v in payload.items():
            here = f"{path}.{k}" if path else k
            if k in SYNTHETIC_KEYS and v is True:
                hits.append(f"{label}:{here}")
            hits += synthetic_hits(label, v, here)
    elif isinstance(payload, list):
        for i, v in enumerate(payload):
            hits += synthetic_hits(label, v, f"{path}[{i}]")
    return hits


# --------------------------------------------------------------------------
# D1 — experiment engineering
# --------------------------------------------------------------------------
def dim_experiments(p: Project) -> Dimension:
    d = Dimension("experiment_engineering", "Experiment engineering")
    specs = p.experiment_specs()
    raw_ledger = p.get("experiment_ledger", default=None)
    if not specs:
        d.add(unmeasured("E1.specs_present",
                         "no ExperimentSpec is on disk under experiments/, so nothing about the "
                         "experiments can be measured — not their metrics, seeds or conditions"))
        return d
    if raw_ledger is None:
        d.add(unmeasured("E1.ledger_present",
                         "experiment_ledger.jsonl is absent, so whether the specs ever ran is "
                         "unknown"))
        return d
    canonical_ledger, ledger_error = normalise_ledger(raw_ledger)
    if canonical_ledger is None:
        p.corrupt.add("experiment_ledger")
        d.add(unmeasured("E1.ledger_valid",
                         f"experiment_ledger.jsonl is corrupt: {ledger_error}. Duplicate output "
                         f"cannot become extra evidence, and conflicting attempts cannot be "
                         f"resolved by choosing one."))
        return d
    ledger, void_ids = valid_ledger(p, canonical_ledger)
    if ledger is None:
        d.add(unmeasured("E1.validity_present",
                         "experiments/experiment_tree.json is absent, unreadable, or carries no "
                         "void_experiments list. The grader cannot tell a valid measurement from "
                         "one the runner declared void, and unknown validity is not a pass."))
        return d
    tree = p.get("experiment_tree")
    plan, plan_error = planned_run_identities(specs, tree)
    if plan is None:
        d.add(unmeasured(
            "E1.2_completion_rate",
            f"the planned-run denominator is corrupt or ambiguous: {plan_error}. Failed attempts "
            f"cannot be omitted from the ledger or plan to improve the completion rate."))
        return d
    coherence_error = tree_ledger_coherence(tree, canonical_ledger)
    if coherence_error:
        p.corrupt.update(("experiment_tree", "experiment_ledger"))
        d.add(unmeasured(
            "E1.tree_ledger_coherent",
            f"experiment_tree and experiment_ledger disagree: {coherence_error}. Both are "
            f"runner outputs for the same attempts, so the grader cannot choose the more "
            f"favourable body."))
        return d

    by_experiment: dict[str, list[dict]] = {}
    for e in ledger:
        by_experiment.setdefault(str(e.get("experiment_id")), []).append(e)

    # -- E1.1 every spec produced at least one measured run --------------
    never_ran = [s["experiment_id"] for s in specs
                 if not any(entry_ok(e) and numeric_metrics(e)
                            for e in by_experiment.get(str(s["experiment_id"]), []))]
    d.add(gate("E1.1_every_spec_ran",
               not never_ran,
               f"all {len(specs)} specs produced at least one completed run carrying metrics",
               f"specs that never produced a measured run: {never_ran}. A spec that did not run "
               f"is a plan, and the paper cannot cite a plan.",
               measured=len(specs) - len(never_ran), threshold=len(specs)))

    # -- E1.2 run success rate -------------------------------------------
    # Completion is an engineering property of every attempted row. A void run
    # still completed; it simply cannot support a scientific check below.
    completed, completion_error = completion_against_plan(canonical_ledger, plan)
    floor = 1.0 - MAX_FAILURE_RATE
    if completed is None:
        d.add(unmeasured(
            "E1.2_completion_rate",
            f"the planned-run denominator is corrupt or ambiguous: "
            f"{plan_error or completion_error}. Failed attempts cannot be omitted from the "
            f"ledger or plan to improve the completion rate."))
    else:
        total = len(plan)
        rate = completed / total
        d.add(gate("E1.2_completion_rate",
                   rate >= floor - 1e-9,
                   f"{completed}/{total} planned runs completed ({rate:.0%})",
                   f"only {completed}/{total} planned runs completed ({rate:.0%}); the project's own "
                   f"max_failure_rate of {MAX_FAILURE_RATE} puts the floor at {floor:.0%}. Above that "
                   f"failure rate the surviving runs are a filtered sample, not the experiment.",
                   measured=round(rate, 4), threshold=round(floor, 4)))

    # -- E1.3 every metric declared in its spec ---------------------------
    undeclared: list[str] = []
    for s in specs:
        declared = set(metric_names(s))
        for e in by_experiment.get(str(s["experiment_id"]), []):
            if not entry_ok(e):
                continue
            for m in numeric_metrics(e):
                if m not in declared:
                    undeclared.append(f"{s['experiment_id']}:{m}")
    d.add(gate("E1.3_metrics_declared",
               not undeclared,
               "every metric in every completed run is declared by its spec",
               f"metrics recorded but never declared: {sorted(set(undeclared))}. A metric that "
               f"appears only after the run is a metric chosen with the data in view; there is no "
               f"acceptable fraction of that, so the threshold is zero.",
               measured=len(set(undeclared)), threshold=0))

    # -- E1.4 seed adequacy per claim type --------------------------------
    seed_rows, inadequate = [], []
    for s in specs:
        claim_type = str(s.get("claim_type") or "unspecified")
        required = (MIN_SEEDS_INFERENTIAL if claim_type in INFERENTIAL_CLAIM_TYPES
                    else MIN_SEEDS_DESCRIPTIVE)
        # Declared seeds are an intention. The seeds that completed are the sample
        # size the claim actually rests on, so that is what is graded.
        completed_by_arm = {
            arm: len({str(entry_seed(e))
                      for e in by_experiment.get(str(s["experiment_id"]), [])
                      if entry_ok(e) and numeric_metrics(e) and entry_seed(e) is not None
                      and entry_arm(e) == arm})
            for arm in spec_arms(s)
        }
        seed_rows.append({"experiment_id": s["experiment_id"], "claim_type": claim_type,
                          "seeds_declared": len(s.get("seeds") or []),
                          "seeds_completed_by_arm": completed_by_arm,
                          "seeds_required_per_arm": required})
        thin = {arm: got for arm, got in completed_by_arm.items() if got < required}
        if thin:
            inadequate.append(f"{s['experiment_id']} ({claim_type}): "
                              + ", ".join(f"{arm}={got} < {required}"
                                          for arm, got in thin.items()))
    d.add(gate("E1.4_seed_adequacy",
               not inadequate,
               f"every spec completed at least the seeds its claim type requires "
               f"({MIN_SEEDS_INFERENTIAL} for a between-condition claim, "
               f"{MIN_SEEDS_DESCRIPTIVE} otherwise)",
               f"under-seeded specs: {inadequate}. Below the floor the dispersion the claim is "
               f"compared against cannot be estimated, so the claim is a single draw.",
               measured=seed_rows, threshold={"inferential": MIN_SEEDS_INFERENTIAL,
                                              "descriptive": MIN_SEEDS_DESCRIPTIVE}))

    # -- E1.5 invalid_conditions: declared, machine-evaluable, and executed
    without = [s["experiment_id"] for s in specs if not (s.get("invalid_conditions") or [])]
    d.add(gate("E1.5a_invalid_conditions_declared",
               not without,
               "every spec declares the conditions under which its result is void",
               f"specs with no invalid_conditions: {without}. An experiment that cannot come back "
               f"void is not an experiment, it is a plan to produce numbers.",
               measured=len(specs) - len(without), threshold=len(specs)))

    def evaluable_modes(cond: Any) -> set[str]:
        """The two invalid-condition evaluators shipped by the runtime.

        Generated entry points retain the original per-run metric comparator.
        Current compiler output uses registered, ledger/artifact-aware predicates
        that ``experiment-runner`` evaluates after the batch and records in
        ``experiment_tree.validity``.  Treating only either path as real would
        falsely reject a supported generation of ExperimentSpec.
        """
        if not isinstance(cond, dict):
            return set()
        modes: set[str] = set()
        if (cond.get("metric") is not None and cond.get("op") in LEGACY_INVALID_OPERATORS
                and "value" in cond):
            modes.add("inline")
        check = cond.get("check")
        if (isinstance(check, dict)
                and str(check.get("kind") or "") in REGISTERED_INVALID_CHECK_KINDS):
            modes.add("registered")
        return modes

    no_evaluable = [s["experiment_id"] for s in specs
                    if not any(evaluable_modes(c) for c in (s.get("invalid_conditions") or []))]
    d.add(gate("E1.5b_invalid_conditions_machine_evaluable",
               not no_evaluable,
               "every spec carries at least one invalid_condition supported by a shipped runtime "
               "evaluator",
               f"specs whose invalid_conditions are prose or use unknown predicates: "
               f"{no_evaluable}. A condition no registered evaluator understands is returned as "
               f"*unchecked*, never satisfied, so it is documentation rather than a guard.",
               measured=len(specs) - len(no_evaluable), threshold=len(specs)))

    inline_specs = {
        str(s["experiment_id"]) for s in specs
        if any("inline" in evaluable_modes(c) for c in (s.get("invalid_conditions") or []))
    }
    registered = {
        str(s["experiment_id"]): [c for c in (s.get("invalid_conditions") or [])
                                  if "registered" in evaluable_modes(c)]
        for s in specs
    }
    registered = {experiment_id: conditions for experiment_id, conditions in registered.items()
                  if conditions}

    # Source is not runtime evidence.  An AST Call can sit below ``if False``, in
    # an unused function, or after an early return; comments were an even easier
    # false pass.  The runner therefore persists the parsed result payload's guard
    # verdict on each relevant ledger row.  Consume that exact record and bind
    # every reported condition back to the spec it claims to have evaluated.
    unverifiable: list[str] = []
    malformed_runtime: list[str] = []
    specs_by_id = {str(s["experiment_id"]): s for s in specs}
    for experiment_id in sorted(inline_specs):
        declared = specs_by_id[experiment_id].get("invalid_conditions") or []
        declared_bodies: dict[str, set[str]] = {}
        declared_inline: set[str] = set()
        try:
            for condition in declared:
                if not isinstance(condition, dict) or not isinstance(condition.get("code"), str) \
                        or not condition["code"].strip():
                    continue
                code = condition["code"].strip()
                declared_bodies.setdefault(code, set()).add(_canonical_record(condition))
                if "inline" in evaluable_modes(condition):
                    declared_inline.add(code)
        except (TypeError, ValueError):
            malformed_runtime.append(f"{experiment_id}: invalid condition is not canonical JSON")
            continue
        if any(len(bodies) != 1 for bodies in declared_bodies.values()):
            malformed_runtime.append(
                f"{experiment_id}: duplicate condition code names different predicates")
            continue

        relevant = [e for e in canonical_ledger
                    if str(e.get("experiment_id") or "") == experiment_id
                    and (entry_ok(e) or str(e.get("status") or "").upper() == "INVALID")]
        if not relevant:
            unverifiable.append(f"{experiment_id}: no completed or invalid run has guard evidence")
            continue
        for entry in relevant:
            label = (f"{experiment_id}:arm={entry_arm(entry)}:seed={entry_seed(entry)}")
            provenance = entry.get("provenance")
            runtime = (provenance.get("invalid_conditions_runtime")
                       if isinstance(provenance, dict) else None)
            if runtime is None:
                unverifiable.append(f"{label}: invalid_conditions_runtime is absent")
                continue
            if (not isinstance(runtime, dict)
                    or set(runtime) != {"checked", "fired", "unchecked", "error"}
                    or not isinstance(runtime.get("checked"), bool)
                    or not isinstance(runtime.get("fired"), list)
                    or not isinstance(runtime.get("unchecked"), list)
                    or (runtime.get("error") is not None
                        and not isinstance(runtime.get("error"), str))):
                malformed_runtime.append(f"{label}: runtime guard record has an invalid schema")
                continue
            if runtime["checked"] is not True or runtime["error"] is not None:
                unverifiable.append(
                    f"{label}: guard was not checked cleanly ({runtime['error']!r})")
                continue

            reported: dict[str, str] = {}
            report_error = None
            for bucket in ("fired", "unchecked"):
                for condition in runtime[bucket]:
                    if (not isinstance(condition, dict)
                            or not isinstance(condition.get("code"), str)
                            or not condition["code"].strip()):
                        report_error = f"{bucket} contains a condition without an identity"
                        break
                    code = condition["code"].strip()
                    try:
                        body = _canonical_record(condition)
                    except (TypeError, ValueError):
                        report_error = f"{bucket} contains non-canonical condition {code!r}"
                        break
                    if code in reported:
                        report_error = f"condition {code!r} is duplicated across runtime verdicts"
                        break
                    if body not in declared_bodies.get(code, set()):
                        report_error = f"condition {code!r} does not exactly match the spec"
                        break
                    reported[code] = bucket
                if report_error:
                    break
            if report_error:
                malformed_runtime.append(f"{label}: {report_error}")
                continue
            unresolved_inline = sorted(declared_inline & {
                code for code, bucket in reported.items() if bucket == "unchecked"
            })
            if unresolved_inline:
                unverifiable.append(
                    f"{label}: inline conditions were unchecked: {unresolved_inline}")
            fired = list(runtime["fired"])
            if ((entry_ok(entry) and fired)
                    or (str(entry.get("status") or "").upper() == "INVALID" and not fired)):
                malformed_runtime.append(
                    f"{label}: ledger status {entry.get('status')!r} contradicts fired verdicts")

    if malformed_runtime:
        p.corrupt.add("experiment_ledger")
        unverifiable.extend(malformed_runtime)

    if registered:
        tree = p.get("experiment_tree", default=None)
        validity = tree.get("validity") if isinstance(tree, dict) else None
        if not isinstance(validity, list):
            unverifiable.append("experiment_tree.validity is absent or is not a list")
        else:
            by_id: dict[str, list[dict]] = {}
            malformed_validity = False
            for record in validity:
                if not isinstance(record, dict) or not record.get("experiment_id"):
                    malformed_validity = True
                    continue
                by_id.setdefault(str(record["experiment_id"]), []).append(record)
            if malformed_validity:
                unverifiable.append("experiment_tree.validity contains a malformed record")
            for experiment_id, conditions in registered.items():
                records = by_id.get(experiment_id, [])
                if len(records) != 1:
                    unverifiable.append(
                        f"{experiment_id}: expected one batch validity record, found {len(records)}")
                    continue
                verdicts = records[0].get("verdicts")
                if not isinstance(verdicts, list):
                    unverifiable.append(f"{experiment_id}: validity verdicts are absent")
                    continue
                for cond in conditions:
                    kind = str((cond.get("check") or {}).get("kind") or "")
                    code = str(cond.get("code", "?"))
                    matches = [v for v in verdicts if isinstance(v, dict)
                               and str(v.get("code", "?")) == code
                               and str(v.get("check_kind") or "") == kind]
                    if len(matches) != 1:
                        unverifiable.append(
                            f"{experiment_id}:{code}/{kind} has {len(matches)} runtime verdict(s)")
                    elif matches[0].get("status") not in ("CLEAR", "FIRED"):
                        unverifiable.append(
                            f"{experiment_id}:{code}/{kind} is "
                            f"{matches[0].get('status')!r}, not CLEAR or FIRED")
    if unverifiable:
        d.add(unmeasured("E1.5c_invalid_conditions_checked_at_runtime",
                         f"persisted runtime guard evidence is absent, malformed or incoherent: "
                         f"{sorted(set(unverifiable))[:5]}. Source text cannot prove that a call "
                         f"executed, and unknown is not a pass."))
    else:
        d.add(ok("E1.5c_invalid_conditions_checked_at_runtime",
                 "every machine-evaluable invalid condition has one persisted batch runtime "
                 "verdict; source text is not treated as execution evidence"))
    return d


# --------------------------------------------------------------------------
# D2 — baselines
# --------------------------------------------------------------------------
def dim_baselines(p: Project) -> Dimension:
    d = Dimension("baselines", "Baselines")
    specs = p.experiment_specs()
    cm = p.get("comparison_mode")
    if not specs:
        d.add(unmeasured("E2.specs_present", "no ExperimentSpec on disk; no baseline to grade"))
        return d
    if not isinstance(cm, dict) or not cm.get("mode"):
        d.add(unmeasured("E2.mode_present",
                         "reproduction/comparison_mode.json is absent, so what comparison the "
                         "project was licensed to make is unknown"))
        return d
    mode = str(cm["mode"])

    no_baseline = [s["experiment_id"] for s in specs
                   if not isinstance(s.get("baseline"), dict) or not s["baseline"].get("kind")]
    d.add(gate("E2.1_baseline_condition_exists",
               not no_baseline,
               f"all {len(specs)} specs name a baseline condition",
               f"specs with no baseline condition: {no_baseline}. Without a referent, a number is "
               f"a measurement of nothing in particular.",
               measured=len(specs) - len(no_baseline), threshold=len(specs)))

    # -- E2.2 established, or explicitly declared unestablished ----------
    silent: list[str] = []
    for s in specs:
        b = s.get("baseline") or {}
        if b.get("kind") in INTERNAL_BASELINE_KINDS or b.get("established") is True:
            continue
        codes = {str(c.get("code")) for c in (s.get("invalid_conditions") or [])
                 if isinstance(c, dict)}
        # An unpinned baseline is acceptable; an unpinned baseline nobody wrote
        # down is not. The compiler's own remedy is BASELINE_NOT_ESTABLISHED as an
        # invalid condition, so its presence is what "explicitly declared" means.
        if "BASELINE_NOT_ESTABLISHED" not in codes:
            silent.append(str(s["experiment_id"]))
    d.add(gate("E2.2_baseline_pinned_or_declared_unpinned",
               not silent,
               "every external baseline is either pinned or carries BASELINE_NOT_ESTABLISHED as an "
               "invalid condition",
               f"specs with an unpinned baseline and no BASELINE_NOT_ESTABLISHED condition: "
               f"{silent}. An unpinned baseline can change between conditions, and every "
               f"difference then belongs to the baseline.",
               measured=len(specs) - len(silent), threshold=len(specs)))

    # -- E2.3 the mode permits the comparison actually made --------------
    allowed = BASELINE_KIND_FOR_MODE.get(mode, set()) | INTERNAL_BASELINE_KINDS
    wrong = [f"{s['experiment_id']}:{(s.get('baseline') or {}).get('kind')}" for s in specs
             if (s.get("baseline") or {}).get("kind") not in allowed]
    comparative_under_none = [s["experiment_id"] for s in specs
                              if mode == "CM_NONE" and (s.get("claim_type") == "comparative"
                                                        or s.get("comparative_claim") is True)]
    fail_detail = (
        f"under {mode} these baselines are not admissible: {wrong}; comparative specs under "
        f"CM_NONE: {comparative_under_none}. The comparison mode is what licenses the comparison; "
        f"a spec outside it is comparing against something the project never established.")
    d.add(gate("E2.3_comparison_permitted_by_mode",
               not wrong and not comparative_under_none,
               f"every baseline kind is admissible under {mode}",
               fail_detail,
               measured={"mode": mode, "offending_specs": len(wrong) + len(comparative_under_none)},
               threshold=0))

    # -- E2.4 / E2.5 the frontier anchor ---------------------------------
    # Nothing upstream asks these two across the whole project. The manuscript
    # gate adjudicates one sentence at a time and only for papers that use the
    # word "strongest"; a project can therefore plan a frontier arm, anchor it to
    # a candidate matched on task words alone, never run it, write around the
    # word, and pass every per-claim check ever written.
    sota_specs = [s for s in specs if (s.get("sota") or {}).get("required")]
    if not sota_specs:
        d.add(na("E2.4_sota_anchor_topic_declared",
                 "no spec declares a state-of-the-art arm, so there is no frontier anchor to "
                 "grade. Whether one should have been declared is dimension 7's question about "
                 "what the manuscript claims, not this one's."))
    else:
        # A known value, not merely a present one. The compiler attaches a
        # topic_match to every candidate it emits, so "the field exists" is
        # satisfied by construction on pipeline output and the check would grade
        # nothing. What is worth grading is whether the recorded strength is one
        # the manuscript gate knows how to act on: it licenses `direct` and
        # `asserted`, blocks `weak`, and treats anything else as unverifiable.
        known = {"direct", "asserted", "weak"}
        undeclared = [str(s["experiment_id"]) for s in sota_specs
                      if str((s.get("sota") or {}).get("topic_match_strength") or "")
                      not in known]
        strengths = sorted({str((s.get("sota") or {}).get("topic_match_strength") or "undeclared")
                            for s in sota_specs})
        d.add(gate("E2.4_sota_anchor_topic_declared",
                   not undeclared,
                   f"every state-of-the-art arm records how its candidate was matched to this "
                   f"paper's topic ({', '.join(strengths)})",
                   f"specs whose sota arm records no topic_match_strength: {undeclared}. Without "
                   f"it there is no way to tell a candidate that reports on this paper's benchmark "
                   f"from one that merely shares task words, and only the first makes 'strongest' "
                   f"mean strongest at this measurement.",
                   measured=len(sota_specs) - len(undeclared), threshold=len(sota_specs)))

        raw_ledger = p.get("experiment_ledger", default=None)
        if raw_ledger is None:
            d.add(unmeasured("E2.5_sota_arm_measured_or_declared_unmeasured",
                             "experiment_ledger.jsonl is absent; whether the declared "
                             "state-of-the-art arm ever ran is unknown"))
        else:
            canonical_ledger, ledger_error = normalise_ledger(raw_ledger)
            if canonical_ledger is None:
                p.corrupt.add("experiment_ledger")
                d.add(unmeasured(
                    "E2.5_sota_arm_measured_or_declared_unmeasured",
                    f"experiment_ledger.jsonl is corrupt: {ledger_error}"))
                return d
            ledger, void_ids = valid_ledger(p, canonical_ledger)
            if ledger is None:
                d.add(unmeasured(
                    "E2.5_sota_arm_measured_or_declared_unmeasured",
                    "experiment_tree is absent or malformed, so the grader cannot tell whether "
                    "the completed state-of-the-art rows belong to a void experiment"))
                return d
            ran = {str(e.get("experiment_id")) for e in ledger
                   if str((e.get("provenance") or {}).get("arm") or e.get("arm") or "") == "sota"
                   and str(e.get("status", "")).upper() == "COMPLETED" and (e.get("metrics") or {})}
            silent_arm = []
            for s in sota_specs:
                if str(s["experiment_id"]) in ran:
                    continue
                # The condition has to be MACHINE-EVALUABLE, for the same reason
                # E1.5b requires it of the invalid conditions: `rf_runtime`
                # returns a prose condition as *unchecked*, never as satisfied, so
                # a bare code string is documentation and not a guard. Accepting
                # the code alone also made this check vacuous — the compiler emits
                # SOTA_ARM_NOT_MEASURED on exactly the specs where `sota.required`
                # is true, so the two sets were identical by construction and the
                # disjunction was always satisfied.
                evaluable = [c for c in ((s.get("narrowing_conditions") or [])
                                         + (s.get("invalid_conditions") or []))
                             if isinstance(c, dict)
                             and str(c.get("code")) == "SOTA_ARM_NOT_MEASURED"
                             and str((c.get("check") or {}).get("kind") or "") ==
                             "ledger_arm_completed"]
                if not evaluable:
                    silent_arm.append(str(s["experiment_id"]))
            d.add(gate("E2.5_sota_arm_measured_or_declared_unmeasured",
                       not silent_arm,
                       f"{len(ran)}/{len(sota_specs)} declared state-of-the-art arm(s) completed "
                       f"with metrics; the rest carry SOTA_ARM_NOT_MEASURED",
                       f"specs that declared a state-of-the-art arm, never completed one, and "
                       f"carry no machine-evaluable SOTA_ARM_NOT_MEASURED condition: {silent_arm}. "
                       f"A bare code with no `check` is prose: rf_runtime returns it as UNCHECKED "
                       f"and it will not fire on the run it was written for. Same disjunction as "
                       f"E2.2 — the rubric does "
                       f"not require the frontier to have been run, it requires the project to know "
                       f"which of the two it has. An arm that is silently absent reads downstream "
                       f"as a comparison that happened.",
                       measured=len(sota_specs) - len(silent_arm), threshold=len(sota_specs)))
    return d


# --------------------------------------------------------------------------
# D3 — ablations
# --------------------------------------------------------------------------
def dim_ablations(p: Project) -> Dimension:
    d = Dimension("ablations", "Ablations")
    plan, plan_error = _structured_mapping(p, "ablation_plan")
    specs = p.experiment_specs()
    raw_ledger = p.get("experiment_ledger", default=None)
    if not isinstance(plan, dict):
        d.add(unmeasured("E3.plan_present",
                         "experiments/ablation_plan.yaml is absent or unreadable, so the set of "
                         "claimed mechanisms is unknown and coverage over it cannot be computed"
                         + (f": {plan_error}" if plan_error else "")))
        return d
    if not specs:
        d.add(unmeasured("E3.specs_present",
                         "the ExperimentSpec collection is absent or corrupt, so the ablation "
                         "plan cannot be mapped to executed isolation tests"))
        return d
    if raw_ledger is None:
        d.add(unmeasured("E3.ledger_present",
                         "experiment_ledger.jsonl is absent; whether the ablations ran is unknown"))
        return d
    canonical_ledger, ledger_error = normalise_ledger(raw_ledger)
    if canonical_ledger is None:
        p.corrupt.add("experiment_ledger")
        d.add(unmeasured("E3.ledger_valid",
                         f"experiment_ledger.jsonl is corrupt: {ledger_error}"))
        return d
    ledger, void_ids = valid_ledger(p, canonical_ledger)
    if ledger is None:
        d.add(unmeasured("E3.validity_present",
                         "experiment_tree is absent or malformed, so a void ablation cannot be "
                         "distinguished from a valid isolation test"))
        return d

    raw_mechanisms, raw_ablations = plan.get("mechanisms"), plan.get("ablations")
    if not isinstance(raw_mechanisms, list) or not isinstance(raw_ablations, list):
        p.corrupt.add("ablation_plan")
        d.add(unmeasured(
            "E3.plan_valid", "ablation_plan.mechanisms and ablation_plan.ablations must both be "
            "lists. Coverage cannot use the ablation rows themselves as the mechanism denominator."))
        return d
    malformed_mechanisms = [i + 1 for i, mechanism in enumerate(raw_mechanisms)
                            if not isinstance(mechanism, dict)
                            or not isinstance(mechanism.get("mechanism_id"), str)
                            or not mechanism["mechanism_id"].strip()]
    malformed_ablations = [i + 1 for i, ablation in enumerate(raw_ablations)
                           if not isinstance(ablation, dict)
                           or not isinstance(ablation.get("ablation_id"), str)
                           or not ablation["ablation_id"].strip()
                           or not isinstance(ablation.get("mechanism_id"), str)
                           or not ablation["mechanism_id"].strip()]
    if malformed_mechanisms or malformed_ablations:
        p.corrupt.add("ablation_plan")
        d.add(unmeasured(
            "E3.plan_valid", f"ablation_plan contains mechanism rows {malformed_mechanisms} or "
            f"ablation rows {malformed_ablations} without stable identities"))
        return d
    ablations = list(raw_ablations)
    mechanism_ids = [str(m["mechanism_id"]).strip() for m in raw_mechanisms]
    ablation_ids = [str(a["ablation_id"]).strip() for a in ablations]
    if len(set(mechanism_ids)) != len(mechanism_ids) or len(set(ablation_ids)) != len(ablation_ids):
        p.corrupt.add("ablation_plan")
        d.add(unmeasured(
            "E3.plan_valid", "ablation_plan repeats a mechanism_id or ablation_id; duplicate plan "
            "identities cannot become extra isolation coverage"))
        return d
    unknown_mechanisms = sorted({str(a["mechanism_id"]).strip() for a in ablations}
                                - set(mechanism_ids))
    if unknown_mechanisms:
        p.corrupt.add("ablation_plan")
        d.add(unmeasured(
            "E3.plan_valid", f"ablations reference mechanisms absent from plan.mechanisms: "
            f"{unknown_mechanisms}"))
        return d
    if not mechanism_ids:
        d.add(na("E3.mechanisms_declared",
                 "the ablation plan claims no mechanism, so there is nothing to isolate"))
        return d

    specs_for_ablation: dict[str, list[dict]] = {}
    for spec in specs:
        if spec.get("ablation_ref"):
            specs_for_ablation.setdefault(str(spec["ablation_ref"]), []).append(spec)
    duplicate_spec_refs = sorted(ref for ref, rows in specs_for_ablation.items() if len(rows) != 1)
    if duplicate_spec_refs:
        p.corrupt.add("experiment_specs")
        d.add(unmeasured(
            "E3.specs_valid", f"multiple ExperimentSpecs claim the same ablation_ref: "
            f"{duplicate_spec_refs}. The grader cannot choose which isolation ran."))
        return d
    spec_by_ablation = {ref: rows[0] for ref, rows in specs_for_ablation.items()}
    spec_ids = [str(s.get("experiment_id")) for s in specs if s.get("experiment_id")]
    if len(set(spec_ids)) != len(spec_ids):
        p.corrupt.add("experiment_specs")
        d.add(unmeasured(
            "E3.specs_valid", "multiple ExperimentSpecs claim the same experiment_id; an explicit "
            "ablation parent cannot be resolved unambiguously"))
        return d
    spec_by_id = {str(s.get("experiment_id")): s for s in specs if s.get("experiment_id")}
    measured_ids = {str(e.get("experiment_id")) for e in ledger
                    if entry_ok(e) and numeric_metrics(e)}

    def parent_id(spec: dict) -> tuple[str | None, str | None]:
        inherited = spec.get("inherits_metrics_from")
        anchored = spec.get("anchored_to")
        anchored_id = anchored.get("parent_experiment_id") if isinstance(anchored, dict) else None
        named = {str(value).strip() for value in (inherited, anchored_id)
                 if isinstance(value, str) and value.strip()}
        if not named:
            return None, "no explicit inherits_metrics_from/anchored_to parent"
        if len(named) != 1:
            return None, f"conflicting explicit parents {sorted(named)}"
        ident = next(iter(named))
        parent = spec_by_id.get(ident)
        if parent is None or parent.get("claim_type") == "ablation":
            return None, f"parent {ident!r} is absent or is itself an ablation"
        return ident, None

    # -- E3.1 an isolation test per claimed mechanism, that ran ----------
    uncovered: list[str] = []
    covered = 0
    for mechanism_id in mechanism_ids:
        planned = [a for a in ablations if str(a["mechanism_id"]).strip() == mechanism_id]
        if not planned:
            uncovered.append(f"{mechanism_id} (no ablation is planned)")
            continue
        if len(planned) != 1:
            uncovered.append(f"{mechanism_id} ({len(planned)} ablations make coverage ambiguous)")
            continue
        ablation = planned[0]
        spec = spec_by_ablation.get(str(ablation["ablation_id"]))
        if spec is None:
            uncovered.append(f"{mechanism_id} (no spec compiles {ablation['ablation_id']})")
        elif str(spec["experiment_id"]) not in measured_ids:
            uncovered.append(f"{mechanism_id} ({spec['experiment_id']} produced no measured run)")
        else:
            covered += 1
    coverage = covered / len(mechanism_ids)
    d.add(gate("E3.1_isolation_test_per_mechanism",
               not uncovered,
               f"all {len(mechanism_ids)} claimed mechanism(s) have an isolation test that produced "
               f"measurements",
               f"mechanisms with no executed isolation test: {uncovered}. An uncovered mechanism "
               f"is an unfalsified mechanism, and a partial threshold would license claiming "
               f"exactly the ones nobody tested.",
               measured=round(coverage, 4), threshold=1.0))

    # -- E3.2 compute matched, in the plan and in the runs ---------------
    unmatched: list[str] = []
    matched_ablations = 0
    completed_seeds: dict[tuple[str, str], set[str]] = {}
    for entry in ledger:
        seed = entry_seed(entry)
        if entry_ok(entry) and numeric_metrics(entry) and seed is not None:
            key = (str(entry.get("experiment_id")), entry_arm(entry))
            completed_seeds.setdefault(key, set()).add(str(seed))
    for a in ablations:
        errors_before = len(unmatched)
        controls = {str(c.get("kind")) for c in (a.get("counterfactual_controls") or [])
                    if isinstance(c, dict)}
        if "matched_compute" not in controls:
            unmatched.append(f"{a.get('ablation_id')}: no matched_compute control in the plan")
            continue
        s = spec_by_ablation.get(str(a.get("ablation_id")))
        if s is None:
            unmatched.append(f"{a.get('ablation_id')}: no compiled ablation spec")
            continue
        parent, parent_error = parent_id(s)
        if parent is None:
            unmatched.append(f"{a.get('ablation_id')}: {parent_error}")
            continue
        for arm in spec_arms(s):
            ablation_seeds = completed_seeds.get((str(s["experiment_id"]), arm), set())
            parent_seeds = completed_seeds.get((parent, arm), set())
            if not ablation_seeds or ablation_seeds != parent_seeds:
                unmatched.append(
                    f"{a.get('ablation_id')}: arm={arm} completed seeds "
                    f"{sorted(ablation_seeds)} vs parent {parent} {sorted(parent_seeds)}")
        if len(unmatched) == errors_before:
            matched_ablations += 1
    d.add(gate("E3.2_compute_matched",
               not unmatched,
               "every ablation declares a matched-compute counterfactual and has the same completed "
               "seed identities per arm as its explicit parent experiment",
               f"ablations whose compute is not matched: {unmatched}. Without it, a degradation on "
               f"removal is explained just as well by the mechanism having cost more.",
               measured=matched_ablations, threshold=len(ablations)))

    # -- E3.3 a null result is reported, not re-metered ------------------
    disjoint = []
    for a in ablations:
        s = spec_by_ablation.get(str(a.get("ablation_id")))
        if s is None:
            continue
        parent, parent_error = parent_id(s)
        if parent is None:
            disjoint.append(f"{s['experiment_id']}: {parent_error}")
            continue
        parent_metrics = metric_names(spec_by_id[parent])
        shared = [m for m in metric_names(s) if m in parent_metrics]
        if not shared:
            disjoint.append(f"{s['experiment_id']}: {metric_names(s)} vs "
                            f"explicit parent {parent} {sorted(parent_metrics)}")
    d.add(gate("E3.3a_ablation_shares_a_metric_with_its_primary_experiment",
               not disjoint,
               "every ablation measures at least one metric its explicit parent experiment measures",
               f"ablations whose metric set is disjoint from their explicit parent's: {disjoint}. "
               f"Nothing can be concluded from such an isolation: analysis groups the ledger by "
               f"(branch, metric), so a disjoint metric set means no contrast between the ablation "
               f"and the experiment it is supposed to isolate a mechanism for can ever be "
               f"computed. It is also the shape a null result rescued by a new metric takes.",
               measured=len(disjoint), threshold=0))

    stats = p.get("stats_audit")
    negatives = p.get("negative_findings", default=None)
    findings = p.get("findings", default=[])
    if not isinstance(stats, dict) or negatives is None:
        d.add(unmeasured("E3.3b_null_results_reported",
                         "stats_audit.json or findings/negative_findings.jsonl is absent, so "
                         "whether a null ablation was written down or quietly dropped cannot be "
                         "determined"))
        return d

    recorded = json.dumps(list(negatives) + list(findings or []), default=str)
    null_ablations, unreported = [], []
    for t in stats.get("tests") or []:
        branches = {str(t.get("branch_a")), str(t.get("branch_b"))}
        for a in ablations:
            s = spec_by_ablation.get(str(a.get("ablation_id")))
            if s is None or str(s["experiment_id"]) not in branches:
                continue
            # Significant-after-correction is a positive result and needs nothing
            # here. Everything else — non-significant, or refused for want of data
            # — is a null the project owes the reader.
            if t.get("significant_corrected") is True:
                continue
            null_ablations.append(str(s["experiment_id"]))
            if (str(s["experiment_id"]) not in recorded
                    and str(a.get("ablation_id")) not in recorded
                    and str(a.get("mechanism_id")) not in recorded):
                unreported.append(str(s["experiment_id"]))
    if not null_ablations:
        d.add(ok("E3.3b_null_results_reported",
                 "no ablation produced a null result, so there is none to report",
                 measured=0, threshold=0))
    else:
        d.add(gate("E3.3b_null_results_reported",
                   not unreported,
                   f"all {len(set(null_ablations))} null ablation(s) appear in the findings",
                   f"null ablations that appear in no finding: {sorted(set(unreported))}. A null "
                   f"result that is not written down is indistinguishable from one that was "
                   f"retried until it stopped being null.",
                   measured=len(set(null_ablations)) - len(set(unreported)),
                   threshold=len(set(null_ablations))))
    return d


# --------------------------------------------------------------------------
# D4 — evidence support
# --------------------------------------------------------------------------
def dim_evidence(p: Project) -> Dimension:
    d = Dimension("evidence_support", "Evidence support")
    raw_audit = p.get("claim_audit", default=None)
    gate_art = p.get("integrity_gate")
    if raw_audit is None:
        d.add(unmeasured("E4.claim_audit_present",
                         "review/claim_audit.jsonl is absent. Claim support is the one thing this "
                         "grader will not estimate: without the auditor's verdicts there is no "
                         "measurement to report."))
        return d
    audit, audit_error = normalise_claim_audit(raw_audit)
    if audit is None:
        p.corrupt.add("claim_audit")
        d.add(unmeasured("E4.claim_audit_valid",
                         f"review/claim_audit.jsonl is corrupt: {audit_error}. Repeated output "
                         f"cannot improve a support ratio, and conflicting verdicts cannot be "
                         f"resolved by choosing one."))
        return d
    if not isinstance(gate_art, dict):
        d.add(unmeasured("E4.0_integrity_gate_permits_submission",
                         "review/integrity_gate.json is absent, so the auditor's submission "
                         "permission cannot be consumed. The independent claim-audit checks below "
                         "remain measurable where their own inputs exist."))
        gate_art = None
    gate_verdict = str(gate_art.get("verdict") or "") if gate_art is not None else ""
    if gate_art is not None and (gate_verdict == "BLOCK"
                                 or gate_art.get("submission_permitted") is False):
        d.add(bad("E4.0_integrity_gate_permits_submission",
                  f"the integrity gate returned {gate_verdict or '<missing>'} with submission_permitted="
                  f"{gate_art.get('submission_permitted')!r}. This upstream verdict is consumed, "
                  f"not recomputed.", measured={"verdict": gate_verdict,
                                                "submission_permitted":
                                                gate_art.get("submission_permitted")},
                  threshold={"verdict": "PASS or PASS_WITH_CONDITIONS",
                             "submission_permitted": True}))
    elif gate_art is not None and (gate_verdict not in ("PASS", "PASS_WITH_CONDITIONS")
                                   or gate_art.get("submission_permitted") is not True):
        d.add(unmeasured("E4.0_integrity_gate_permits_submission",
                         "integrity_gate has no recognised permitting verdict and explicit true "
                         "submission_permitted field"))
    elif gate_art is not None:
        d.add(ok("E4.0_integrity_gate_permits_submission",
                 f"the integrity gate recorded {gate_verdict} and permits submission"))

    # The counts are the auditor's, read as given. Nothing here re-grades a claim.
    # Counts are consumed for the upstream fabrication verdict, but duplicate
    # JSONL output must not inflate either side of the project-level ratio below.
    counts = dict(gate_art.get("counts") or {}) if gate_art is not None else {}
    if counts:
        malformed_counts = [key for key, value in counts.items()
                            if isinstance(value, bool) or not isinstance(value, int) or value < 0]
        if malformed_counts:
            p.corrupt.add("integrity_gate")
            d.add(unmeasured(
                "E4.1_zero_fabricated", f"integrity_gate counts are malformed for "
                f"{malformed_counts}; truthy strings and negative counts are not an audit tally"))
        else:
            fabricated = counts.get("FABRICATED", 0)
            d.add(gate("E4.1_zero_fabricated",
                       fabricated == 0,
                       "the auditor found no fabricated claim",
                       f"{fabricated} claim(s) are FABRICATED: a number or a citation in the "
                       f"manuscript corresponds to nothing that exists. One is disqualifying; "
                       f"there is no rate at which fabrication is acceptable.",
                       measured=fabricated, threshold=0))
    else:
        counts = {}
        for rec in audit:
            counts[str(rec.get("verdict"))] = counts.get(str(rec.get("verdict")), 0) + 1
        fabricated = counts.get("FABRICATED", 0)
        d.add(gate("E4.1_zero_fabricated",
                   fabricated == 0,
                   "the claim audit contains no fabricated claim",
                   f"{fabricated} claim(s) in claim_audit are FABRICATED",
                   measured=fabricated, threshold=0))

    graded = [rec for rec in audit
              if str(rec.get("verdict")) in ("SUPPORTED", "PARTIALLY_SUPPORTED", "NOT_SUPPORTED",
                                             "FABRICATED", "SCOPE_MISMATCH")
              and rec.get("kind") != "disclosure"]
    supported = sum(1 for rec in graded if str(rec.get("verdict")) == "SUPPORTED")
    ratio = supported / len(graded) if graded else None

    stats = p.get("stats_audit")
    raw_alpha = stats.get("alpha", DEFAULT_ALPHA) if isinstance(stats, dict) else DEFAULT_ALPHA
    alpha = valid_alpha(raw_alpha)
    alpha_valid = alpha is not None
    floor = 1.0 - alpha if alpha is not None else None
    if not alpha_valid:
        if isinstance(stats, dict):
            p.corrupt.add("stats_audit")
        d.add(unmeasured(
            "E4.2_support_ratio", f"stats_audit.alpha={raw_alpha!r} is not a literal finite number "
            f"strictly between 0 and 1, so the support floor 1-alpha is undefined"))
    elif ratio is None:
        d.add(unmeasured("E4.2_support_ratio",
                         "the claim audit graded no claim, so a support ratio has no denominator"))
    else:
        d.add(gate("E4.2_support_ratio",
                   ratio >= floor - 1e-9,
                   f"{supported}/{len(graded)} graded claims are fully SUPPORTED ({ratio:.0%})",
                   f"only {supported}/{len(graded)} graded claims are fully SUPPORTED ({ratio:.0%}); "
                   f"the floor is {floor:.0%}. The integrity gate blocks FABRICATED, NOT_SUPPORTED "
                   f"and SCOPE_MISMATCH individually but lets PARTIALLY_SUPPORTED through in any "
                   f"quantity, so this ratio is the only thing standing between a passing gate and "
                   f"a manuscript that overstates its evidence throughout.",
                   measured=round(ratio, 4), threshold=round(floor, 4)))

    # -- E4.3 every quantitative claim traces to a run -------------------
    malformed_checks: list[str] = []
    quantitative = [rec for rec in audit if rec.get("quantitative") is True]
    untraced = []
    for rec in quantitative:
        identity = f"{rec.get('claim_id')}@{rec.get('locator')}"
        checks = rec.get("number_checks")
        if not isinstance(checks, list) or not checks:
            untraced.append(identity)
            continue
        if any(not isinstance(item, dict) or not isinstance(item.get("matched"), bool)
               for item in checks):
            malformed_checks.append(identity)
            continue
        if not all(item["matched"] is True for item in checks):
            untraced.append(identity)
    if not quantitative:
        d.add(na("E4.3_quantitative_claims_traced",
                 "the manuscript states no quantitative claim, so there is no number to trace"))
    elif malformed_checks:
        p.corrupt.add("claim_audit")
        d.add(unmeasured(
            "E4.3_quantitative_claims_traced", f"quantitative claims have malformed number_checks "
            f"whose matched field is not a literal boolean: {malformed_checks[:8]}. A truthy string "
            f"is not an auditor verdict."))
    else:
        d.add(gate("E4.3_quantitative_claims_traced",
                   not untraced,
                   f"all {len(quantitative)} quantitative claims trace to a recorded ledger value",
                   f"quantitative claims with an untraced number: {untraced[:8]}. A number with no "
                   f"run behind it is fabricated regardless of how it got there.",
                   measured=len(quantitative) - len(untraced), threshold=len(quantitative)))
    return d


# --------------------------------------------------------------------------
# D5 — statistical validity
# --------------------------------------------------------------------------
def dim_statistics(p: Project) -> Dimension:
    d = Dimension("statistical_validity", "Statistical validity")
    stats = p.get("stats_audit")
    if not isinstance(stats, dict):
        d.add(unmeasured("E5.stats_audit_present",
                         "analysis/stats_audit.json is absent; the statistics were never audited, "
                         "and this grader does not compute them itself"))
        return d

    raw_alpha = stats.get("alpha", DEFAULT_ALPHA)
    alpha = valid_alpha(raw_alpha)
    if alpha is None:
        p.corrupt.add("stats_audit")
        d.add(unmeasured(
            "E5.alpha_valid",
            f"stats_audit.alpha={raw_alpha!r} is not a literal finite number strictly between "
            "0 and 1; statistical decisions made against that threshold cannot be consumed"))
        return d

    lock = stats.get("evidence_lock") or {}
    d.add(gate("E5.1_evidence_lock_clear",
               lock.get("blocked") is False,
               "the integrity auditor locked the evidence: no BLOCKER or HIGH finding survives",
               f"the integrity auditor refused evidence lock ({lock.get('blocked_by')}). This "
               f"verdict is consumed, not recomputed: a claim whose statistics did not survive "
               f"that audit cannot be written as a result.",
               measured=lock.get("blocked"), threshold=False))

    tests = list(stats.get("tests") or [])
    live = [t for t in tests if t.get("p_raw") is not None]
    if not tests:
        d.add(na("E5.2_effect_sizes_with_intervals",
                 "the audit ran no between-condition test, so there is no effect size to report"))
        d.add(na("E5.3_correction_named", "no test family exists to correct over"))
        d.add(na("E5.4_no_claim_on_fewer_than_min_seeds", "no test to check the arm sizes of"))
        return d

    missing_ci = [t.get("test_id") for t in live
                  if not ((t.get("effect_size") or {}).get("ci95")
                          or (t.get("effect_size") or {}).get("refused"))]
    d.add(gate("E5.2_effect_sizes_with_intervals",
               not missing_ci,
               f"all {len(live)} live tests carry an effect size with an interval (or an explicit "
               f"refusal to compute one)",
               f"tests reporting an effect with no interval: {missing_ci}. A point estimate with "
               f"no interval is the format in which noise gets published.",
               measured=len(live) - len(missing_ci), threshold=len(live)))

    corr = stats.get("multiple_comparison_correction") or {}
    family = int(corr.get("family_size") or 0)
    method = str(corr.get("method") or "")
    named = bool(method) and method != "none"
    d.add(gate("E5.3_correction_named",
               named or family <= 1,
               (f"family of {family}; correction: {method}" if family > 1 else
                f"family of {family}: a single test needs no correction, and the audit says so "
                f"explicitly rather than silently omitting one"),
               f"a family of {family} simultaneous comparisons was corrected by "
               f"{method or 'nothing named'}. An uncorrected family of that size has roughly a "
               f"{1 - (1 - DEFAULT_ALPHA) ** max(family, 1):.0%} chance of at least one false "
               f"positive, and a correction that is not named cannot be checked.",
               measured={"family_size": family, "method": method}, threshold="named when n>1"))

    min_seeds = int(stats.get("min_seeds_required") or MIN_SEEDS_INFERENTIAL)
    thin = [t.get("test_id") for t in tests
            if (int(t.get("n_a") or 0) < min_seeds or int(t.get("n_b") or 0) < min_seeds)
            and not t.get("refusal")]
    d.add(gate("E5.4_no_claim_on_fewer_than_min_seeds",
               not thin,
               f"no test below {min_seeds} seeds per arm produced a p-value; the thin ones were "
               f"refused rather than reported weakly",
               f"tests reporting a result on fewer than {min_seeds} seeds per arm without a "
               f"refusal: {thin}. Below that there is not enough data to say anything, and saying "
               f"it weakly is still saying it.",
               measured=len(thin), threshold=0))
    return d


# --------------------------------------------------------------------------
# D6 — figures
# --------------------------------------------------------------------------
def _svg_is_vector(path: Path) -> tuple[bool, str]:
    """A .svg extension is not vector. What is inside it is.

    An embedded raster is the way a bitmap ships inside a file everyone reads as
    a vector, and it is exactly what a reviewer cannot zoom into.
    """
    try:
        raw = path.read_bytes()
        root = ET.fromstring(raw.decode("utf-8", errors="replace"))
    except (OSError, ET.ParseError, UnicodeDecodeError) as e:
        return False, f"not parseable as SVG ({type(e).__name__})"
    if not root.tag.endswith("svg"):
        return False, f"root element is {root.tag}, not <svg>"
    for el in root.iter():
        if el.tag.endswith("image"):
            return False, "contains an <image> element: a raster embedded in a vector wrapper"
    return True, "vector"


def dim_figures(p: Project) -> Dimension:
    d = Dimension("figures", "Figures")
    selected = p.get("selected_figure")
    element_map = p.get("svg_element_map")
    results = p.get("analysis_results")
    spine = p.get("manuscript_spine")
    if not isinstance(selected, dict):
        plan = p.get("figure_plan")
        if isinstance(plan, dict) and not (plan.get("figures") or []):
            d.add(na("E6.figures_planned",
                     "the figure plan declares no figure, so there is none to grade"))
            return d
        d.add(unmeasured("E6.selected_figure_present",
                         "figures/selected/_manifest.json is absent, so what would ship is unknown"))
        return d
    figures = list(selected.get("figures") or [])
    if not figures:
        d.add(na("E6.figures_produced", "no figure was selected, so there is none to grade"))
        return d

    # -- E6.1 vector, not raster -----------------------------------------
    problems = []
    root_dir = p.path("selected_figure")
    for f in figures:
        fp = root_dir / str(f.get("file"))
        if not fp.exists():
            problems.append(f"{f.get('figure_id')}: {f.get('file')} is not on disk")
            continue
        vector, why = _svg_is_vector(fp)
        if not vector:
            problems.append(f"{f.get('figure_id')}: {why}")
    if selected.get("rasterized") is True:
        problems.append("selected_figure declares rasterized=true")
    d.add(gate("E6.1_vector_not_raster",
               not problems,
               f"all {len(figures)} shipped figures parse as vector SVG with no embedded raster",
               f"figures that are not vector: {problems}. A raster figure cannot be zoomed into, "
               f"corrected, or read back against its data.",
               measured=len(figures) - len(problems), threshold=len(figures)))

    # -- E6.2 every figure bound to a claim -------------------------------
    if not isinstance(spine, dict):
        d.add(unmeasured("E6.2_figure_claim_binding",
                         "paper/manuscript_spine.json is absent, so a figure's claim_id cannot be "
                         "checked against the argument it is supposed to support"))
    else:
        known = {str(c.get("claim_id")) for c in (spine.get("claims") or [])}
        unbound = [str(f.get("figure_id")) for f in figures
                   if not f.get("claim_id") or str(f["claim_id"]) not in known]
        bound_ratio = (len(figures) - len(unbound)) / len(figures)
        d.add(gate("E6.2_figure_claim_binding",
                   not unbound,
                   f"all {len(figures)} figures name a claim that is in the spine",
                   f"figures bound to no spine claim: {unbound}. A figure that argues for nothing "
                   f"in the paper is a picture; the reader will still read it as evidence.",
                   measured=round(bound_ratio, 4), threshold=1.0))

    # -- E6.3 the numbers on the figure are the numbers in the analysis ---
    if not isinstance(element_map, dict) or not isinstance(results, dict):
        d.add(unmeasured("E6.3_figure_numbers_match_analysis",
                         "figures/element_map.json or analysis/analysis_results.json is absent, so "
                         "the values drawn cannot be compared with the values analysed"))
        return d
    groups = {str(g.get("group_id")): g for g in (results.get("groups") or [])}
    drift, uncheckable = [], 0
    for fid, entry in (element_map.get("figures") or {}).items():
        for el in entry.get("elements") or []:
            binds = el.get("binds_to") or {}
            gid, stat = str(binds.get("group_id")), str(binds.get("statistic"))
            g = groups.get(gid)
            if g is None or stat in ("None", "", "values"):
                if binds.get("artifact") == "analysis_results":
                    uncheckable += 1
                continue
            drawn = [float(v) for v in (el.get("values") or [])]
            if stat == "mean":
                expected = [float(g["mean"])] if isinstance(g.get("mean"), (int, float)) else None
            elif stat == "ci95":
                expected = [float(v) for v in (g.get("ci95") or [])] or None
            elif stat == "n":
                expected = [float(g.get("n") or 0)]
            else:
                expected = None
            if expected is None:
                uncheckable += 1
                continue
            if len(drawn) != len(expected) or any(
                    abs(a - b) > 1e-9 + 1e-6 * max(abs(a), abs(b))
                    for a, b in zip(drawn, expected)):
                drift.append(f"{fid}/{el.get('element_id')}: drew {drawn} for {stat}={expected}")
    d.add(gate("E6.3_figure_numbers_match_analysis",
               not drift,
               f"every bound element matches analysis_results ({uncheckable} element(s) carried no "
               f"comparable statistic and were not counted either way)",
               f"figure elements that disagree with the analysis: {drift[:6]}. A figure is believed "
               f"faster than a sentence and checked later.",
               measured=len(drift), threshold=0))
    return d


# --------------------------------------------------------------------------
# D7 — writing / argumentation
# --------------------------------------------------------------------------
def dim_writing(p: Project) -> Dimension:
    d = Dimension("writing", "Writing and argumentation")
    manifest = p.get("draft_manifest")
    spine = p.get("manuscript_spine")
    draft = p.get("manuscript_draft")
    cm = p.get("comparison_mode")
    review = p.get("review_report")
    if not isinstance(manifest, dict) or not isinstance(spine, dict):
        d.add(unmeasured("E7.draft_present",
                         "paper/draft_manifest.json or paper/manuscript_spine.json is absent, so "
                         "the draft cannot be compared with the argument it was built from"))
        return d

    if not isinstance(review, dict) or not review.get("recommendation"):
        d.add(unmeasured("E7.0_review_verdict_present",
                         "review/review_report.json is absent, corrupt, or carries no recommendation; "
                         "whether the manuscript survived review is unknown"))
    elif str(review.get("recommendation")) == "DO_NOT_SUBMIT" \
            or review.get("submission_permitted_by_integrity_gate") is False:
        d.add(bad("E7.0_review_verdict_present",
                  f"the review simulator recorded recommendation="
                  f"{review.get('recommendation')!r} and submission_permitted_by_integrity_gate="
                  f"{review.get('submission_permitted_by_integrity_gate')!r}. Its upstream verdict "
                  f"is consumed, not recomputed."))
    elif str(review.get("recommendation")) != "REVISE_THEN_SUBMIT" \
            or review.get("submission_permitted_by_integrity_gate") is not True:
        d.add(unmeasured("E7.0_review_verdict_present",
                         "review_report has no recognised permitting recommendation and explicit "
                         "integrity permission"))
    else:
        d.add(ok("E7.0_review_verdict_present",
                 "the review simulator recorded REVISE_THEN_SUBMIT after a permitting integrity gate"))

    paragraphs = list(manifest.get("paragraphs") or [])
    if not paragraphs:
        d.add(unmeasured("E7.paragraphs_present",
                         "the draft manifest records no paragraph; there is no prose to grade"))
        return d
    bound = sum(1 for r in paragraphs if r.get("claim_id"))
    ratio = bound / len(paragraphs)
    d.add(gate("E7.1_paragraph_claim_coverage",
               bound == len(paragraphs) and manifest.get("every_paragraph_bound_to_a_claim") is True,
               f"all {len(paragraphs)} paragraphs name a claim id",
               f"{len(paragraphs) - bound} paragraph(s) name no claim ({ratio:.0%} bound). A "
               f"paragraph that cannot name its claim has no evidence behind it, and the builder "
               f"drops those — so a shortfall here means the manifest disagrees with itself.",
               measured=round(ratio, 4), threshold=1.0))

    spine_ids = {str(c.get("claim_id")) for c in (spine.get("claims") or [])}
    draft_ids = {str(r.get("claim_id")) for r in paragraphs if r.get("claim_id")}
    # MC-DISCLOSURE is inserted by the renderer, not by the spine. It is a required
    # sentence about what was not established, not a claim, so it is not an orphan.
    extra = sorted(draft_ids - spine_ids - {"MC-DISCLOSURE"})
    unwritten = sorted(set(manifest.get("unwritten_claims") or []) | (spine_ids - draft_ids))
    d.add(gate("E7.2_spine_claims_are_the_drafts_claims",
               not extra and not unwritten,
               f"the draft argues exactly the spine's {len(spine_ids)} claims",
               f"claims in the draft but not the spine: {extra}; spine claims never written: "
               f"{unwritten}. A spine claim with no paragraph is an argument the paper promised "
               f"and did not make; a paragraph claim outside the spine was never audited.",
               measured={"only_in_draft": len(extra), "only_in_spine": len(unwritten)},
               threshold=0))

    if not isinstance(cm, dict):
        d.add(unmeasured("E7.3_disclosure_present",
                         "comparison_mode.json is absent, so whether a disclosure was required is "
                         "unknown"))
        d.add(unmeasured("E7.4_no_forbidden_claim_pattern",
                         "comparison_mode.json is absent, so the forbidden patterns for this mode "
                         "are unknown"))
        return d

    disclosure = manifest.get("disclosure") or {}
    required = bool((cm.get("disclosure_required") or {}).get("required"))
    if not required:
        d.add(na("E7.3_disclosure_present",
                 f"{cm.get('mode')} requires no comparison-mode disclosure"))
    else:
        missing = list(disclosure.get("missing_sections") or [])
        where = missing or "every section that requires it"
        d.add(gate("E7.3_disclosure_present",
                   not missing and bool(disclosure.get("inserted_in")),
                   f"the disclosure required by {cm.get('mode')} appears in "
                   f"{disclosure.get('inserted_in')}",
                   f"the disclosure required by {cm.get('mode')} is missing from {where}. Under a "
                   f"degraded comparison mode that sentence is what makes every other number in "
                   f"the section readable.",
                   measured=len(disclosure.get("inserted_in") or []),
                   threshold=len(disclosure.get("must_appear_in") or [])))

    if not isinstance(draft, str) or not draft.strip():
        d.add(unmeasured("E7.4_no_forbidden_claim_pattern",
                         "the manuscript draft is absent, so the bytes that would ship cannot be "
                         "scanned"))
        return d
    # manuscript-builder filters forbidden language out of the paragraphs it was
    # given; nothing re-reads the rendered file afterwards. This is that read, on
    # the artifact that actually ships rather than on the inputs it was made from.
    hits = []
    for pattern in (cm.get("forbidden_claim_patterns") or []):
        if re.search(re.escape(str(pattern)), draft, re.I):
            hits.append(str(pattern))
    d.add(gate("E7.4_no_forbidden_claim_pattern",
               not hits,
               f"the rendered draft uses none of the {len(cm.get('forbidden_claim_patterns') or [])} "
               f"claim patterns {cm.get('mode')} forbids",
               f"the rendered draft contains claim language forbidden under {cm.get('mode')}: "
               f"{hits}. The filter runs on the paragraphs; this reads the file that ships.",
               measured=len(hits), threshold=0))
    return d


# --------------------------------------------------------------------------
# D8 — reproducibility of the run itself
# --------------------------------------------------------------------------
def _state_fingerprint(p: Project) -> tuple[dict[str, Any] | None, str | None]:
    """What "the same state" means, reduced to something two runs can be compared on.

    Not a digest of the project directory: timestamps, run ids and absolute paths
    differ between two correct runs and would make every comparison fail. What must
    match is the state the machine reached and the measurements it recorded.
    """
    state = p.get("research_state") or p.get("progress_state")
    tree = p.get("experiment_tree", default=None)
    raw_ledger = p.get("experiment_ledger", default=None)
    if not isinstance(state, dict) or not str(state.get("state") or "").strip() \
            or raw_ledger is None:
        return None, "the final state or experiment ledger is absent"
    ledger, ledger_error = normalise_ledger(raw_ledger)
    if ledger is None:
        p.corrupt.add("experiment_ledger")
        return None, f"the experiment ledger is corrupt: {ledger_error}"
    if not isinstance(tree, dict):
        p.corrupt.add("experiment_tree")
        return None, "experiment_tree is absent or is not an object"
    coherence_error = tree_ledger_coherence(tree, ledger)
    if coherence_error:
        p.corrupt.update(("experiment_tree", "experiment_ledger"))
        return None, f"experiment_tree and ledger disagree: {coherence_error}"
    runs = sorted(
        (str(e.get("experiment_id")),
         entry_arm(e),
         str(entry_seed(e)), str(e.get("status")),
         sorted((k, round(v, 12)) for k, v in numeric_metrics(e).items()))
        for e in ledger)
    release = p.get("release_manifest")
    if (not isinstance(release, dict)
            or not str(release.get("release_status") or "").strip()
            or not isinstance(release.get("released"), bool)
            or not isinstance(release.get("blockers"), list)):
        p.corrupt.add("release_manifest")
        return None, "release_manifest has no valid top-level release verdict"

    ledger_ids = [e.get("run_id") for e in ledger]
    if (not ledger_ids or any(not isinstance(run_id, str) or not run_id.strip()
                              for run_id in ledger_ids)):
        p.corrupt.add("experiment_ledger")
        return None, "every ledger row must carry a non-empty string run_id"
    ledger_run_ids = {run_id.strip() for run_id in ledger_ids}
    if len(ledger_run_ids) != 1:
        p.corrupt.add("experiment_ledger")
        return None, f"one project contains multiple ledger run ids: {sorted(ledger_run_ids)}"
    ledger_run_id = next(iter(ledger_run_ids))

    named_ids = {
        "ledger": ledger_run_id,
        "experiment_tree": tree.get("run_id"),
        "research_state": state.get("run_id"),
        "release_manifest": release.get("run_id"),
    }
    if any(not isinstance(run_id, str) or not run_id.strip()
           for run_id in named_ids.values()):
        p.corrupt.update(("experiment_tree", "release_manifest"))
        return None, f"run identity is absent in one or more artifacts: {named_ids}"
    named_ids = {name: str(run_id).strip() for name, run_id in named_ids.items()}
    if len(set(named_ids.values())) != 1:
        p.corrupt.update(("experiment_tree", "experiment_ledger", "release_manifest"))
        return None, f"run identity conflicts across artifacts: {named_ids}"

    run_id = ledger_run_id
    if "nodes" in tree:
        bad_attempts = [str(e.get("attempt_id")) for e in ledger
                        if not isinstance(e.get("attempt_id"), str)
                        or not e["attempt_id"].endswith(f":{run_id}")]
        if bad_attempts:
            p.corrupt.update(("experiment_tree", "experiment_ledger"))
            return None, (f"ledger attempt ids do not belong to run {run_id!r}: "
                          f"{bad_attempts[:5]}")
        root = tree.get("root")
        if root is not None and root != f"root:{run_id}":
            p.corrupt.add("experiment_tree")
            return None, f"experiment_tree root {root!r} conflicts with run {run_id!r}"
    return {
        "state": str(state["state"]),
        "runs": runs,
        "run_id": run_id,
        "release_status": release.get("release_status"),
        "released": release.get("released"),
        "release_blocked": bool(release.get("blockers")),
    }, None


def _structured_mapping(p: Project, aid: str) -> tuple[dict[str, Any] | None, str | None]:
    """Read a JSON-subset YAML artifact as a mapping.

    ``sandbox_container_config`` has a ``.yaml`` contract path, but ArtifactStore
    serialises its mapping payload as JSON.  Keep the YAML fallback for operator
    projects written by older compatible stores; a scalar or an unreadable body
    is corruption, never an empty configuration.
    """
    raw = p.get(aid, default=None)
    if raw is None:
        return None, f"{aid} is absent or unreadable"
    if isinstance(raw, dict):
        return raw, None
    if not isinstance(raw, str) or not raw.strip():
        p.corrupt.add(aid)
        return None, f"{aid} is not a non-empty structured document"
    try:
        value = _yaml.safe_load(raw) if _yaml is not None else json.loads(raw)
    except Exception:
        p.corrupt.add(aid)
        return None, f"{aid} is not parseable JSON-subset YAML"
    if not isinstance(value, dict):
        p.corrupt.add(aid)
        return None, f"{aid} parses as {type(value).__name__}, not an object"
    return value, None


def _released_artifact_digest(project: Path, declared_path: Any) \
        -> tuple[str | None, str | None]:
    """Hash one declared released file without following a symlink or escaping root."""
    if not isinstance(declared_path, str) or not declared_path.strip() or "\x00" in declared_path:
        return None, "path is not a non-empty safe string"
    relative = Path(declared_path)
    if relative.is_absolute():
        return None, "path is absolute rather than project-relative"
    root = project.resolve()
    lexical = root / relative
    try:
        rel_parts = relative.parts
        if any(part in ("", ".", "..") for part in rel_parts):
            return None, "path contains an empty, dot or parent component"
        cursor = root
        for part in rel_parts:
            cursor = cursor / part
            if cursor.is_symlink():
                return None, f"path crosses symbolic link {cursor.relative_to(root)}"
        resolved = lexical.resolve(strict=True)
        resolved.relative_to(root)
    except FileNotFoundError:
        return None, "declared file is missing"
    except (OSError, RuntimeError, ValueError) as exc:
        return None, f"path does not resolve safely inside the project ({type(exc).__name__})"
    if not resolved.is_file():
        return None, "declared path is not a regular file"
    try:
        if resolved.stat().st_nlink != 1:
            return None, "declared path is a hard link rather than a private bundle copy"
    except OSError as exc:
        return None, f"declared file metadata cannot be read ({type(exc).__name__})"
    digest = hashlib.sha256()
    try:
        with resolved.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b""):
                digest.update(chunk)
    except OSError as exc:
        return None, f"declared file cannot be read ({type(exc).__name__})"
    return digest.hexdigest(), None


_RELEASE_METADATA_PATHS = {
    "release/_manifest.json",
    "release/release_manifest.json",
    "release/release_report.md",
}


def _physical_release_files(project: Path) -> tuple[set[str] | None, list[str]]:
    """Inventory the public bundle without following links or ignoring rogue files."""
    root = project.resolve()
    release = root / "release"
    if release.is_symlink():
        return None, ["release is a symbolic link"]
    if not release.exists():
        return None, ["release directory is missing"]
    if not release.is_dir():
        return None, ["release is not a directory"]

    files: set[str] = set()
    errors: list[str] = []
    pending = [release]
    while pending:
        directory = pending.pop()
        try:
            children = sorted(directory.iterdir(), key=lambda item: item.name)
        except OSError as exc:
            errors.append(
                f"cannot enumerate {directory.relative_to(root)} ({type(exc).__name__})")
            continue
        for child in children:
            relative = child.relative_to(root).as_posix()
            try:
                if child.is_symlink():
                    errors.append(f"{relative} is a symbolic link")
                elif child.is_dir():
                    pending.append(child)
                elif child.is_file():
                    if relative not in _RELEASE_METADATA_PATHS:
                        files.add(relative)
                else:
                    errors.append(f"{relative} is not a regular file")
            except OSError as exc:
                errors.append(f"cannot inspect {relative} ({type(exc).__name__})")
    return files, errors


def _release_bundle_reconciliation_errors(
        p: Project, release: dict[str, Any], released_rows: list[dict[str, Any]],
        physical_release_paths: set[str] | None) -> list[str]:
    """Bind release/_manifest.json to both the gate verdict and shipped bytes.

    The release manifest is the gate's audit record, while the bundle manifest is
    the inventory shipped beside the files.  Neither is allowed to vouch for the
    other through truthy coercions, partial overlap or duplicate identities.
    """
    bundle = p.get("release_bundle", default=None)
    errors: list[str] = []
    if not isinstance(bundle, dict):
        return ["release/_manifest.json is absent, unreadable or not an object"]

    bundle_run_id = bundle.get("run_id")
    release_run_id = release.get("run_id")
    if not isinstance(bundle_run_id, str) or not bundle_run_id.strip():
        errors.append("bundle run_id is not a non-empty string")
    elif bundle_run_id != release_run_id:
        errors.append(
            f"bundle run_id {bundle_run_id!r} disagrees with release_manifest run_id "
            f"{release_run_id!r}")
    if bundle.get("released") is not True:
        errors.append("bundle released is not literal true")
    if bundle.get("release_status") != "ASSISTED_DRAFT":
        errors.append("bundle release_status is not ASSISTED_DRAFT")
    bundle_blockers = bundle.get("blockers")
    if not isinstance(bundle_blockers, list):
        errors.append("bundle blockers is not a list")
    elif bundle_blockers:
        errors.append("bundle blockers is not empty")

    raw_deliverables = bundle.get("deliverables")
    bundle_records: set[tuple[str, str, str]] = set()
    bundle_paths: set[str] = set()
    if not isinstance(raw_deliverables, list):
        errors.append("bundle deliverables is not a list")
    else:
        seen_ids: set[str] = set()
        seen_paths: set[str] = set()
        for index, row in enumerate(raw_deliverables):
            label = f"bundle deliverable {index + 1}"
            if not isinstance(row, dict):
                errors.append(f"{label} is not an object")
                continue
            artifact_id = row.get("artifact_id")
            declared_path = row.get("path")
            digest = row.get("sha256")
            valid = True
            if not isinstance(artifact_id, str) or not artifact_id.strip():
                errors.append(f"{label} artifact_id is absent")
                valid = False
            elif artifact_id in seen_ids:
                errors.append(f"{label} duplicates artifact_id {artifact_id!r}")
                valid = False
            else:
                seen_ids.add(artifact_id)
            if not isinstance(declared_path, str) or not declared_path.strip():
                errors.append(f"{label} path is absent")
                valid = False
            elif declared_path in seen_paths:
                errors.append(f"{label} duplicates path {declared_path!r}")
                valid = False
            else:
                seen_paths.add(declared_path)
                bundle_paths.add(declared_path)
            if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
                errors.append(f"{label} sha256 is malformed")
                valid = False
            if valid:
                bundle_records.add((artifact_id, declared_path, digest))

    release_records = {
        (row["artifact_id"], row["path"], row["sha256"]) for row in released_rows
    }
    if bundle_records != release_records:
        missing = sorted(release_records - bundle_records)
        extra = sorted(bundle_records - release_records)
        errors.append(
            "bundle deliverables disagree with released artifact identities: "
            f"missing={missing[:4]}, extra={extra[:4]}")
    if physical_release_paths is not None and bundle_paths != physical_release_paths:
        missing_paths = sorted(physical_release_paths - bundle_paths)
        extra_paths = sorted(bundle_paths - physical_release_paths)
        errors.append(
            "bundle deliverable paths disagree with physical non-metadata files: "
            f"missing={missing_paths[:8]}, extra={extra_paths[:8]}")
    return errors


def _environment_capture_check(p: Project) -> Check:
    """Prove that completed measurements used the current strict Docker contract.

    The sandbox manifest is a permission record; the container config records what
    was validated; each ledger row records what the runner actually used.  No one
    of those artifacts can vouch for the other two, so acceptance requires their
    independently written facts to agree.
    """
    cid = "E8.2_environment_captured"
    env = p.get("environment_lock", default=None)
    sandbox = p.get("sandbox_manifest", default=None)
    config, config_error = _structured_mapping(p, "sandbox_container_config")
    raw_ledger = p.get("experiment_ledger", default=None)
    if env is None or sandbox is None or config is None or raw_ledger is None:
        detail = config_error or (
            "environment.lock, sandbox_manifest, sandbox_container_config and experiment_ledger "
            "must all be present to bind measurements to their execution environment")
        return unmeasured(cid, detail)
    if not isinstance(env, str) or not isinstance(sandbox, dict):
        if not isinstance(sandbox, dict):
            p.corrupt.add("sandbox_manifest")
        return unmeasured(
            cid, "environment_lock is not text or sandbox_manifest is not an object; the recorded "
                 "execution environment is malformed")

    ledger, ledger_error = normalise_ledger(raw_ledger)
    if ledger is None:
        p.corrupt.add("experiment_ledger")
        return unmeasured(cid, f"experiment_ledger is corrupt: {ledger_error}")

    validation = config.get("validation")
    limits = config.get("limits")
    mounts = config.get("mounts")
    lock_measurement = config.get("environment_lock_measurement")
    smoke = validation.get("smoke") if isinstance(validation, dict) else None
    gpu = config.get("gpu_allocation")
    validation_gpu = validation.get("gpu") if isinstance(validation, dict) else None
    manifest_gpu = sandbox.get("gpu_allocation")
    shape_errors: list[str] = []

    def require(obj: Any, key: str, kind: type, label: str) -> None:
        if not isinstance(obj, dict) or key not in obj:
            shape_errors.append(f"{label}.{key} is absent")
            return
        value = obj[key]
        if kind is bool:
            valid = isinstance(value, bool)
        elif kind is int:
            valid = isinstance(value, int) and not isinstance(value, bool)
        else:
            valid = isinstance(value, kind)
        if not valid or (kind is str and not value.strip()):
            shape_errors.append(f"{label}.{key} is not a valid {kind.__name__}")

    for key, kind in (
        ("profile", str), ("isolation", str), ("execution_backend", str),
        ("untrusted_code_execution_allowed", bool),
        ("trusted_host_execution_allowed", bool),
        ("network_isolation_enforced", bool), ("container_image_id", str),
        ("container_image_reference", str), ("host", dict),
    ):
        require(sandbox, key, kind, "sandbox_manifest")
    for key, kind in (
        ("engine", str), ("execution_backend", str), ("image", str),
        ("image_id", str), ("pull_policy", str), ("read_only_rootfs", bool),
        ("limits", dict), ("mounts", dict), ("validation", dict),
        ("environment_lock_measurement", dict), ("gpu_allocation", dict),
    ):
        require(config, key, kind, "sandbox_container_config")
    for key, kind in (
        ("validated", bool), ("validated_at", (int, float)),
        ("daemon_reachable", bool), ("image_present", bool), ("image", str),
        ("image_id", str), ("docker_path", str), ("docker_realpath", str),
        ("docker_sha256", str),
        ("context", str), ("endpoint", str), ("daemon_id", str),
        ("server_version", str), ("daemon_os", str), ("smoke", dict), ("gpu", dict),
    ):
        # ``require`` accepts a tuple through isinstance as well; its error label
        # intentionally remains the human-readable Python type name only for the
        # ordinary scalar cases above.
        if isinstance(kind, tuple):
            value = validation.get(key) if isinstance(validation, dict) else None
            if isinstance(value, bool) or not isinstance(value, kind):
                shape_errors.append(f"sandbox validation.{key} is not numeric")
        else:
            require(validation, key, kind, "sandbox validation")
    for key, kind in (
        ("validated", bool), ("python_entrypoint", bool),
        ("nonroot_uid", int), ("command_contract", str),
    ):
        require(smoke, key, kind, "sandbox smoke test")
    for key, kind in (
        ("source_backend", str), ("measured", bool),
        ("container_image_id", str), ("daemon_id", str),
        ("command", str), ("sha256", str),
    ):
        require(lock_measurement, key, kind, "environment lock measurement")
    for label, record in (("sandbox GPU allocation", manifest_gpu),
                          ("container GPU allocation", gpu),
                          ("validation GPU allocation", validation_gpu)):
        for key, kind in (
            ("requested", bool), ("validated", bool), ("runtime", str),
            ("selector", str), ("device_count", int), ("devices", list),
            ("torch_version", str), ("cuda_runtime", str),
            ("command_contract", str), ("request_run_id", str),
        ):
            require(record, key, kind, label)
        devices = record.get("devices") if isinstance(record, dict) else None
        count = record.get("device_count") if isinstance(record, dict) else None
        if isinstance(devices, list) and isinstance(count, int) and not isinstance(count, bool):
            if count <= 0 or len(devices) != count:
                shape_errors.append(f"{label}.devices does not match a positive device_count")
            for index, device in enumerate(devices):
                if not isinstance(device, dict):
                    shape_errors.append(f"{label}.devices[{index}] is not an object")
                    continue
                require(device, "index", int, f"{label}.devices[{index}]")
                require(device, "name", str, f"{label}.devices[{index}]")
                require(device, "capability", str, f"{label}.devices[{index}]")

    image_id = config.get("image_id")
    manifest_image_id = sandbox.get("container_image_id")
    validation_image_id = validation.get("image_id") if isinstance(validation, dict) else None
    if isinstance(image_id, str) and not DOCKER_IMAGE_ID_RE.fullmatch(image_id):
        shape_errors.append("sandbox_container_config.image_id is not an immutable sha256 image id")
    if isinstance(manifest_image_id, str) and not DOCKER_IMAGE_ID_RE.fullmatch(manifest_image_id):
        shape_errors.append("sandbox_manifest.container_image_id is not an immutable sha256 image id")
    if isinstance(validation_image_id, str) and not DOCKER_IMAGE_ID_RE.fullmatch(validation_image_id):
        shape_errors.append("sandbox validation.image_id is not an immutable sha256 image id")
    docker_sha = validation.get("docker_sha256") if isinstance(validation, dict) else None
    if isinstance(docker_sha, str) and not SHA256_RE.fullmatch(docker_sha):
        shape_errors.append("sandbox validation.docker_sha256 is not a sha256 digest")
    lock_sha = lock_measurement.get("sha256") if isinstance(lock_measurement, dict) else None
    if isinstance(lock_sha, str) and not SHA256_RE.fullmatch(lock_sha):
        shape_errors.append("environment lock measurement.sha256 is not a sha256 digest")
    docker_launch = validation.get("docker_path") if isinstance(validation, dict) else None
    docker_path = validation.get("docker_realpath") if isinstance(validation, dict) else None
    endpoint = validation.get("endpoint") if isinstance(validation, dict) else None
    if isinstance(docker_launch, str) and not Path(docker_launch).is_absolute():
        shape_errors.append("sandbox validation.docker_path is not absolute")
    if isinstance(docker_path, str) and not Path(docker_path).is_absolute():
        shape_errors.append("sandbox validation.docker_realpath is not absolute")
    if isinstance(endpoint, str) and not endpoint.startswith("unix:///"):
        shape_errors.append("sandbox validation.endpoint is not an absolute local Unix socket")
    if shape_errors:
        p.corrupt.update(("sandbox_manifest", "sandbox_container_config"))
        return unmeasured(
            cid, f"strict sandbox evidence is malformed or legacy: {shape_errors[:8]}. Labels "
                 "without the current validation record do not prove container execution.")

    pinned = [line for line in env.splitlines() if "==" in line]
    unsafe: list[str] = []
    expected = (
        (sandbox.get("profile") == STRICT_SANDBOX_PROFILE,
         f"profile is {STRICT_SANDBOX_PROFILE}"),
        (sandbox.get("isolation") == "container", "manifest isolation is container"),
        (sandbox.get("execution_backend") == "docker", "manifest backend is docker"),
        (sandbox.get("untrusted_code_execution_allowed") is True,
         "manifest permits untrusted code"),
        (sandbox.get("trusted_host_execution_allowed") is False,
         "manifest refuses trusted-host execution"),
        (sandbox.get("network_isolation_enforced") is True,
         "manifest records network isolation"),
        (config.get("engine") == "docker", "config engine is docker"),
        (config.get("execution_backend") == "docker", "config backend is docker"),
        (config.get("pull_policy") == "never", "image pulls are disabled"),
        (config.get("read_only_rootfs") is True, "container root is read-only"),
        (limits.get("network") == "none", "container network is disabled"),
        (mounts.get("code") == "ro", "generated code mount is read-only"),
        (mounts.get("run_tmp") == "tmpfs", "run scratch space is tmpfs"),
        (mounts.get("hidden_evaluator") == "not_mounted",
         "hidden evaluator is not mounted"),
        (validation.get("validated") is True, "daemon and image were validated"),
        (validation.get("daemon_reachable") is True, "Docker daemon was reachable"),
        (validation.get("image_present") is True, "image was already local"),
        (validation.get("daemon_os") == "linux", "daemon uses Linux containers"),
        (smoke.get("validated") is True, "restrictive image smoke test passed"),
        (smoke.get("python_entrypoint") is True, "image Python entrypoint worked"),
        (smoke.get("nonroot_uid") == 65534, "image ran as uid 65534"),
        (smoke.get("command_contract") == "no-network/read-only/nonroot/no-new-privileges",
         "smoke test used the strict command contract"),
        (lock_measurement.get("source_backend") == "docker",
         "environment lock source is Docker"),
        (lock_measurement.get("measured") is True,
         "environment lock was measured rather than declared"),
        (lock_measurement.get("command") == "python -m pip freeze --all",
         "environment lock used the provisioner's package measurement command"),
        (gpu.get("requested") is True, "NVIDIA GPU allocation was explicitly required"),
        (gpu.get("validated") is True, "NVIDIA GPU allocation passed the container probe"),
        (gpu.get("runtime") == "nvidia", "GPU runtime is NVIDIA"),
        (gpu.get("selector") == "all", "Docker GPU selector is all"),
        (gpu.get("command_contract") ==
         "docker --gpus all/torch.cuda/restrictive-runtime",
         "GPU probe used Docker allocation and torch.cuda under the restrictive runtime"),
    )
    failed_expected = [label for passed, label in expected if not passed]
    if not pinned:
        unsafe.append("environment.lock contains no pinned dependency")
    unsafe.extend(failed_expected)
    if unsafe:
        return bad(
            cid, f"the recorded environment is not the current strict Docker profile: "
                 f"{unsafe[:8]}",
            measured={"pinned": len(pinned),
                      "strict_checks": len(expected) - len(failed_expected)},
            threshold={"pinned": ">0", "strict_docker_contract": "all"})

    coherence: list[str] = []
    image_ref = config.get("image")
    validation_image_ref = validation.get("image")
    if len({image_id, manifest_image_id, validation_image_id}) != 1:
        coherence.append("manifest, config and validation name different immutable image ids")
    if len({image_ref, sandbox.get("container_image_reference"), validation_image_ref}) != 1:
        coherence.append("manifest, config and validation name different image references")

    env_digest = hashlib.sha256(env.encode("utf-8")).hexdigest()
    if lock_measurement.get("container_image_id") != image_id:
        coherence.append("environment lock was measured in a different container image")
    if lock_measurement.get("daemon_id") != validation.get("daemon_id"):
        coherence.append("environment lock and validation name different Docker daemons")
    if lock_measurement.get("sha256") != env_digest:
        coherence.append("environment lock measurement digest does not match environment.lock")
    if gpu != validation_gpu or gpu != manifest_gpu:
        coherence.append("manifest, config and validation name different GPU allocations")
    completed = [row for row in ledger if entry_ok(row)]
    if not completed:
        return unmeasured(
            cid, "the ledger contains no completed run, so no measurement can be bound to the "
                 "recorded sandbox")
    if not gpu.get("request_run_id"):
        coherence.append("GPU provisioner request has no source run id")
    row_errors: list[str] = []
    for row in completed:
        attempt = str(row.get("attempt_id") or row.get("experiment_id") or "?")
        provenance = row.get("provenance")
        row_sandbox = provenance.get("sandbox") if isinstance(provenance, dict) else None
        if not isinstance(provenance, dict) or not isinstance(row_sandbox, dict):
            row_errors.append(f"{attempt}: completed row has no sandbox provenance")
            continue
        row_expected = {
            "isolation": "container",
            "declared_isolation": "container",
            "profile": STRICT_SANDBOX_PROFILE,
            "execution_backend": "docker",
            "untrusted_code_execution_allowed": True,
            "trusted_host_execution_allowed": False,
            "current_invocation_trusted_host_authorized": False,
            "current_invocation_gpu_required": True,
            "host_execution": False,
            "environment_lock_sha256": env_digest,
            "container_image": image_ref,
            "container_image_id": image_id,
            "network_isolation_enforced": True,
            "network_enforced_by": "docker --network none",
            "hidden_evaluator_mounted": False,
            "gpu_allocation": gpu,
        }
        mismatched = [key for key, value in row_expected.items()
                      if row_sandbox.get(key) != value]
        if row_sandbox.get("host") != sandbox.get("host"):
            mismatched.append("host")
        if row_sandbox.get("limits") != limits:
            mismatched.append("limits")
        if provenance.get("environment_digest") != env_digest:
            mismatched.append("provenance.environment_digest")
        if provenance.get("executed") is not True:
            mismatched.append("provenance.executed")
        command = provenance.get("command")
        if not isinstance(command, list) or not all(isinstance(part, str) for part in command):
            mismatched.append("provenance.command")
        elif command.count("--gpus") != 1 or command.index("--gpus") + 1 >= len(command) \
                or command[command.index("--gpus") + 1] != "all":
            mismatched.append("provenance.command GPU allocation")
        container_id = provenance.get("container_id")
        if not isinstance(container_id, str) or not DOCKER_CONTAINER_ID_RE.fullmatch(container_id):
            mismatched.append("provenance.container_id")
        if mismatched:
            row_errors.append(f"{attempt}: {sorted(set(mismatched))}")
    if coherence or row_errors:
        p.corrupt.update(("sandbox_manifest", "sandbox_container_config", "experiment_ledger"))
        return unmeasured(
            cid, f"sandbox evidence disagrees across artifacts: {(coherence + row_errors)[:8]}. "
                 "The grader cannot choose the more favourable execution record.")

    return ok(
        cid, f"{len(pinned)} pinned dependencies measured inside strict validated Docker image "
             f"{image_id} on daemon {validation.get('daemon_id')!r}; "
             f"all {len(completed)} completed ledger rows agree with the manifest, NVIDIA GPU "
             "allocation and container configuration",
        measured={"pinned": len(pinned), "completed_rows_bound": len(completed),
                  "image_id": image_id, "gpu_devices": gpu.get("device_count")},
        threshold={"pinned": ">0", "strict_docker_contract": "all",
                   "gpu_devices": ">0", "completed_rows_bound": len(completed)})


def dim_reproducibility(p: Project, second: Project | None) -> Dimension:
    d = Dimension("reproducibility", "Reproducibility of the run itself")
    release = p.get("release_manifest")
    if not isinstance(release, dict):
        d.add(unmeasured("E8.release_manifest_present",
                         "release/release_manifest.json is absent, so what was released and "
                         "whether it had lineage cannot be determined"))
    else:
        # release-gate already blocked on any artifact without provenance. The
        # verdict is consumed; what is added is the count, so a manifest that is
        # complete only because it listed nothing cannot pass silently.
        release_status = release.get("release_status")
        released_flag = release.get("released")
        blockers = release.get("blockers")
        top_shape_error = (
            "release_status is not a non-empty string"
            if not isinstance(release_status, str) or not release_status.strip()
            else "run_id is not a non-empty string"
            if not isinstance(release.get("run_id"), str) or not release["run_id"].strip()
            else "released is not a literal boolean"
            if not isinstance(released_flag, bool)
            else "blockers is not a list"
            if not isinstance(blockers, list)
            else None)
        if top_shape_error:
            p.corrupt.add("release_manifest")
            d.add(unmeasured(
                "E8.1_provenance_for_every_released_artifact",
                f"release_manifest is malformed: {top_shape_error}. Truthy strings and other "
                f"coercions are not release-gate verdicts."))
        elif released_flag is False or release_status == "BLOCKED" or blockers:
            d.add(bad("E8.1_provenance_for_every_released_artifact",
                      f"the release gate refused the release (status "
                      f"{release_status!r}, released={released_flag!r}, "
                      f"blockers={len(blockers)}). Its top-level verdict "
                      f"cannot be overridden by stale per-artifact flags.",
                      measured=0, threshold=">0 released by the gate"))
        elif released_flag is not True or release_status != "ASSISTED_DRAFT":
            d.add(unmeasured("E8.1_provenance_for_every_released_artifact",
                             "release_manifest has no recognised permitting top-level status "
                             "(ASSISTED_DRAFT with released=true)"))
        else:
            raw_artifacts = release.get("artifacts")
            malformed_rows = []
            if not isinstance(raw_artifacts, list):
                malformed_rows.append("artifacts is not a list")
                artifacts: list[dict] = []
            else:
                artifacts = []
                seen_artifact_ids: set[str] = set()
                seen_artifact_paths: set[str] = set()
                for index, artifact in enumerate(raw_artifacts):
                    if not isinstance(artifact, dict):
                        malformed_rows.append(f"artifact {index + 1} is not an object")
                        continue
                    if not isinstance(artifact.get("released"), bool):
                        malformed_rows.append(
                            f"artifact {index + 1} released is not a literal boolean")
                    if not isinstance(artifact.get("provenance_complete"), bool):
                        malformed_rows.append(
                            f"artifact {index + 1} provenance_complete is not a literal boolean")
                    if (not isinstance(artifact.get("artifact_id"), str)
                            or not artifact["artifact_id"].strip()):
                        malformed_rows.append(f"artifact {index + 1} artifact_id is absent")
                    elif (artifact.get("released") is True
                          and artifact["artifact_id"] in seen_artifact_ids):
                        malformed_rows.append(
                            f"released artifact {index + 1} duplicates artifact_id "
                            f"{artifact['artifact_id']!r}")
                    elif artifact.get("released") is True:
                        seen_artifact_ids.add(artifact["artifact_id"])
                    if not isinstance(artifact.get("path"), str) or not artifact["path"].strip():
                        malformed_rows.append(f"artifact {index + 1} path is absent")
                    elif (artifact.get("released") is True
                          and artifact["path"] in seen_artifact_paths):
                        malformed_rows.append(
                            f"released artifact {index + 1} duplicates path "
                            f"{artifact['path']!r}")
                    elif artifact.get("released") is True:
                        seen_artifact_paths.add(artifact["path"])
                    if (not isinstance(artifact.get("sha256"), str)
                            or not SHA256_RE.fullmatch(artifact["sha256"])):
                        malformed_rows.append(f"artifact {index + 1} sha256 is malformed")
                    artifacts.append(artifact)
            if not isinstance(release.get("provenance_complete"), bool):
                malformed_rows.append("top-level provenance_complete is not a literal boolean")
            if malformed_rows:
                p.corrupt.update(("release_manifest", "release_bundle"))
                d.add(unmeasured(
                    "E8.1_provenance_for_every_released_artifact",
                    f"release_manifest is malformed: {malformed_rows[:5]}. Boolean strings are "
                    f"data corruption, not release permission."))
            elif not artifacts:
                d.add(unmeasured("E8.1_provenance_for_every_released_artifact",
                                 "the release manifest lists no artifact at all"))
            else:
                incomplete = [a.get("artifact_id") for a in artifacts
                              if a["released"] is True and a["provenance_complete"] is not True]
                released_rows = [a for a in artifacts if a["released"] is True]
                released_n = len(released_rows)
                if released_n == 0:
                    d.add(bad("E8.1_provenance_for_every_released_artifact",
                              f"the release gate released nothing (status {release_status!r}). A "
                              f"refused release is a correct outcome for the run, and it is not an "
                              f"accepted one.", measured=0, threshold=">0"))
                else:
                    unsafe_paths: list[str] = []
                    digest_mismatches: list[str] = []
                    declared_release_paths: set[str] = set()
                    for artifact in released_rows:
                        label = str(artifact["artifact_id"])
                        declared = artifact["path"]
                        relative = Path(declared)
                        if (relative.is_absolute()
                                or len(relative.parts) < 2
                                or relative.parts[0] != "release"
                                or any(part in ("", ".", "..") for part in relative.parts)
                                or relative.as_posix() != declared
                                or declared in _RELEASE_METADATA_PATHS):
                            unsafe_paths.append(
                                f"{label}:released path is not a canonical non-metadata "
                                "release/... bundle path")
                            continue
                        declared_release_paths.add(declared)
                        actual, error = _released_artifact_digest(p.project, declared)
                        if error:
                            unsafe_paths.append(f"{label}:{error}")
                        elif actual != artifact["sha256"]:
                            digest_mismatches.append(label)
                    physical_release_paths, physical_errors = _physical_release_files(p.project)
                    if physical_errors:
                        unsafe_paths.extend(f"bundle:{error}" for error in physical_errors)
                    if physical_release_paths is not None:
                        missing = sorted(declared_release_paths - physical_release_paths)
                        rogue = sorted(physical_release_paths - declared_release_paths)
                        if missing:
                            unsafe_paths.append(
                                f"manifest paths absent from the physical bundle: {missing[:8]}")
                        if rogue:
                            unsafe_paths.append(
                                f"unmanifested physical bundle files: {rogue[:8]}")
                    bundle_errors = _release_bundle_reconciliation_errors(
                        p, release, released_rows, physical_release_paths)
                    if bundle_errors:
                        p.corrupt.update(("release_bundle", "release_manifest"))
                        unsafe_paths.extend(bundle_errors)
                    if unsafe_paths:
                        p.corrupt.add("release_manifest")
                        d.add(unmeasured(
                            "E8.1_provenance_for_every_released_artifact",
                            f"release evidence is missing, unsafe, unreadable or internally "
                            f"inconsistent: {unsafe_paths[:8]}. The grader will not follow "
                            f"symlinks, leave the project root or let either manifest vouch for "
                            f"bytes the other one did not identify."))
                    else:
                        failed = sorted(set(incomplete + digest_mismatches))
                        d.add(gate(
                            "E8.1_provenance_for_every_released_artifact",
                            not failed and release["provenance_complete"] is True,
                            f"all {released_n} released artifacts carry complete provenance and "
                            f"both manifests identify the same exact physical release bundle",
                            f"released artifacts with incomplete provenance or digest drift: "
                            f"{failed}. A changed artifact is not the artifact the release gate "
                            f"audited.",
                            measured=released_n - len(failed), threshold=released_n))

    d.add(_environment_capture_check(p))

    if second is None:
        d.add(unmeasured("E8.3_second_run_reaches_the_same_state",
                         "no second run was supplied (--second-run DIR). Determinism cannot be "
                         "inferred from a single run, and this grader will not assume it: "
                         "run_acceptance.sh performs the second run and passes it here."))
        return d
    if p.project == second.project:
        d.add(unmeasured("E8.3_second_run_reaches_the_same_state",
                         "--second-run resolves to the primary project directory. Comparing a "
                         "project with itself is not a second run."))
        return d
    a, a_error = _state_fingerprint(p)
    b, b_error = _state_fingerprint(second)
    if a is None or b is None:
        d.add(unmeasured("E8.3_second_run_reaches_the_same_state",
                         f"the run identities or final artifacts are not coherent: primary="
                         f"{a_error or 'valid'}; second={b_error or 'valid'}"))
        return d
    if a["run_id"] == b["run_id"]:
        d.add(unmeasured("E8.3_second_run_reaches_the_same_state",
                         f"the projects do not prove independent executions: both coherently "
                         f"identify themselves as run {a['run_id']!r}."))
        return d
    same_state = a["state"] == b["state"]
    same_runs = a["runs"] == b["runs"]
    same_release = (a["release_status"], a["released"], a["release_blocked"]) == \
        (b["release_status"], b["released"], b["release_blocked"])
    differing = [f"{x[0]}:arm={x[1]}:seed={x[2]}"
                 for x, y in zip(a["runs"], b["runs"]) if x != y][:8]
    d.add(gate("E8.3_second_run_reaches_the_same_state",
               same_state and same_runs and same_release,
               f"a second run from the same inputs reached state {a['state']!r} with identical "
               f"metrics for all {len(a['runs'])} runs",
               f"the second run diverged — state {a['state']!r} vs {b['state']!r}, release "
               f"{a['release_status']!r} vs {b['release_status']!r}, "
               f"{'runs differ at ' + str(differing) if not same_runs else 'runs match'}. "
               f"Every interval in the analysis is computed from seed dispersion; if the seeds do "
               f"not reproduce, that dispersion is measuring the machine, not the method.",
               measured={"state_match": same_state, "runs_match": same_runs,
                         "release_match": same_release},
               threshold=True))
    return d


# --------------------------------------------------------------------------
# synthetic refusal
# --------------------------------------------------------------------------
SYNTHETIC_SCAN = ("draft_manifest", "integrity_gate", "review_report", "stats_audit",
                  "claim_audit", "findings", "negative_findings", "artifact_manifest",
                  "comparison_mode", "source_repro_report", "release_manifest",
                  "analysis_results", "manuscript_spine", "finding_memory_graph")


def find_synthetic(p: Project) -> list[str]:
    """Refuse to grade output the runtime already marked as not research.

    `--model offline` marks model-derived artifacts and provenance synthetic.
    Scoring such a project would produce a number that looks like a research
    result and is a test of the machinery, and the number would outlive the caveat.
    """
    hits: list[str] = []
    for aid in SYNTHETIC_SCAN:
        payload = p.get(aid)
        if payload is not None:
            hits += synthetic_hits(aid, payload)
    for event in (p.get("provenance_log", default=[]) or []):
        if isinstance(event, dict) and event.get("kind") == "skill_end" \
                and (event.get("detail") or {}).get("synthetic") is True:
            hits.append(f"provenance:{event.get('skill')}")
    return sorted(set(hits))


# --------------------------------------------------------------------------
# constant drift guard
# --------------------------------------------------------------------------
def assert_constants_agree() -> list[str]:
    """If the runtime is importable, its numbers win.

    A grader holding a stale copy of a threshold grades the project against a rule
    it never agreed to. When the package is not importable — grading a bundle on
    another machine — the copies above stand, and the report says so.
    """
    try:
        from researchforge.skills import analysis as _a
        from researchforge.skills import planning as _pl
    except Exception:
        return []
    drift = []
    for name, mine, theirs in (
            ("MIN_SEEDS_INFERENTIAL/planning.MIN_SEEDS_FOR_COMPARATIVE",
             MIN_SEEDS_INFERENTIAL, _pl.MIN_SEEDS_FOR_COMPARATIVE),
            ("MIN_SEEDS_INFERENTIAL/analysis.MIN_SEEDS_FOR_INFERENCE",
             MIN_SEEDS_INFERENTIAL, _a.MIN_SEEDS_FOR_INFERENCE),
            ("DEFAULT_ALPHA", DEFAULT_ALPHA, _a.DEFAULT_ALPHA)):
        if mine != theirs:
            drift.append(f"{name}: grader has {mine}, runtime has {theirs}")
    return drift


# --------------------------------------------------------------------------
# grading
# --------------------------------------------------------------------------
def grade(project_dir: Path, repo_root: Path,
          second_run: Path | None = None) -> dict[str, Any]:
    p = Project(project_dir, repo_root)
    second = Project(second_run, repo_root) if second_run else None
    drift = assert_constants_agree()
    if drift:
        raise GraderRefusal(
            "the grader's copies of the runtime's thresholds have drifted: " + "; ".join(drift)
            + ". Two thresholds for one question means the lower one governs; fix the copies in "
              "acceptance/grade.py and RUBRIC.md before grading anything.")

    synthetic = find_synthetic(p)
    if second is not None:
        synthetic += [f"second_run:{hit}" for hit in find_synthetic(second)]
        synthetic = sorted(set(synthetic))
    if synthetic:
        return {
            "acceptance_version": RUBRIC_VERSION,
            "graded_at": time.time(),
            "project": str(p.project),
            "verdict": "REFUSED_SYNTHETIC",
            "verdict_reason": (
                f"{len(synthetic)} artifact field(s) are marked synthetic: {synthetic[:10]}. "
                f"Offline-stub output is not research and will not be scored; a score attached to "
                f"it would outlive the caveat attached to it."),
            "synthetic_markers": synthetic,
            "dimensions": [], "failed_dimensions": [], "not_measured_dimensions": [],
        }

    dims = [
        dim_experiments(p),
        dim_baselines(p),
        dim_ablations(p),
        dim_evidence(p),
        dim_statistics(p),
        dim_figures(p),
        dim_writing(p),
        dim_reproducibility(p, second),
    ]
    failed = [d.id for d in dims if d.outcome == FAIL]
    not_measured = [d.id for d in dims if d.outcome == NOT_MEASURED]
    if failed:
        verdict = "REJECTED"
        reason = f"{len(failed)} dimension(s) failed: {failed}"
    elif not_measured:
        # Not a pass with an asterisk. The harness could not see part of the
        # project, so it does not know whether that part is acceptable.
        verdict = "INCOMPLETE"
        reason = (f"no dimension failed, but {len(not_measured)} could not be measured: "
                  f"{not_measured}. An unmeasured dimension is not a passing one.")
    else:
        verdict = "ACCEPTED"
        reason = "every dimension was measured and every dimension passed."

    return {
        "acceptance_version": RUBRIC_VERSION,
        "graded_at": time.time(),
        "project": str(p.project),
        "second_run": str(second.project) if second else None,
        "verdict": verdict,
        "verdict_reason": reason,
        "dimensions": [d.as_dict() for d in dims],
        "failed_dimensions": failed,
        "not_measured_dimensions": not_measured,
        "missing_artifacts": sorted(p.missing),
        "corrupt_artifacts": sorted(p.corrupt),
        "consumed_audits": {
            "integrity_gate": (p.get("integrity_gate") or {}).get("verdict"),
            "stats_audit_evidence_lock_blocked":
                ((p.get("stats_audit") or {}).get("evidence_lock") or {}).get("blocked"),
            "review_report_recommendation": (p.get("review_report") or {}).get("recommendation"),
            "release_manifest_status": (p.get("release_manifest") or {}).get("release_status"),
            "note": "these verdicts are read, never recomputed. Re-deriving them here would "
                    "create a second threshold for a question that already has one.",
        },
        "thresholds_in_force": {
            "min_seeds_inferential": MIN_SEEDS_INFERENTIAL,
            "min_seeds_descriptive": MIN_SEEDS_DESCRIPTIVE,
            "max_failure_rate": MAX_FAILURE_RATE,
            "claim_support_ratio_floor": (
                round(1.0 - valid_alpha(
                    (p.get("stats_audit") or {}).get("alpha", DEFAULT_ALPHA)), 4)
                if valid_alpha((p.get("stats_audit") or {}).get("alpha", DEFAULT_ALPHA))
                is not None else None),
            "runtime_constants_verified": bool(assert_constants_agree() == []),
        },
    }


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------
_SYMBOL = {PASS: "PASS", FAIL: "FAIL", NOT_MEASURED: "NOT_MEASURED",
           NOT_APPLICABLE: "N/A"}


def render_report(result: dict[str, Any]) -> str:
    L = [f"# Acceptance report — {result['verdict']}", "",
         f"- rubric: `RUBRIC.md` v{result['acceptance_version']}",
         f"- project: `{result['project']}`",
         f"- graded: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(result['graded_at']))}", ""]
    if result.get("second_run"):
        L.append(f"- second run: `{result['second_run']}`")
    L += ["", f"**{result['verdict_reason']}**", ""]

    if result["verdict"] == "REFUSED_SYNTHETIC":
        L += ["## Refused", "",
              "This project carries artifacts the runtime itself marked synthetic. The grader does "
              "not score them.", ""]
        L += [f"- `{h}`" for h in result.get("synthetic_markers", [])[:40]]
        return "\n".join(L) + "\n"

    L += ["## Dimensions", "", "| dimension | outcome |", "|---|---|"]
    for d in result["dimensions"]:
        L.append(f"| {d['title']} (`{d['id']}`) | **{_SYMBOL[d['outcome']]}** |")
    L += ["", "A dimension is ACCEPTED-eligible only when it was measured. NOT_MEASURED is not a "
              "pass: it is the grader saying it could not see that part of the project, and it "
              "blocks acceptance exactly as a failure does.", ""]

    for d in result["dimensions"]:
        L += [f"## {d['title']} — {_SYMBOL[d['outcome']]}", ""]
        for c in d["checks"]:
            L += [f"### `{c['id']}` — {_SYMBOL[c['outcome']]}", "",
                  f"{c['detail']}", ""]
            if c["measured"] is not None or c["threshold"] is not None:
                L += [f"- measured: `{json.dumps(c['measured'], default=str)}`",
                      f"- threshold: `{json.dumps(c['threshold'], default=str)}`", ""]

    consumed = result.get("consumed_audits", {})
    L += ["## Audits consumed, not recomputed", "",
          "| audit | verdict as recorded |", "|---|---|"]
    for k, v in consumed.items():
        if k == "note":
            continue
        L.append(f"| `{k}` | `{v}` |")
    L += ["", consumed.get("note", ""), ""]

    if result.get("missing_artifacts"):
        L += ["## Artifacts the grader looked for and did not find", ""]
        L += [f"- `{a}`" for a in result["missing_artifacts"]]
        L += [""]
    if result.get("corrupt_artifacts"):
        L += ["## Artifacts the grader found but could not trust", ""]
        L += [f"- `{a}`" for a in result["corrupt_artifacts"]]
        L += [""]
    return "\n".join(L) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Grade a finished ResearchForge project.")
    ap.add_argument("project", type=Path)
    ap.add_argument("--second-run", type=Path, default=None,
                    help="a second project produced from the same inputs; without it the "
                         "reproducibility dimension reports NOT_MEASURED")
    ap.add_argument("--repo-root", type=Path,
                    default=Path(__file__).resolve().parents[1],
                    help="repository holding manifests/artifact-graph.json")
    ap.add_argument("--out", type=Path, default=None,
                    help="where to write acceptance_report.md and acceptance_result.json "
                         "(default: PROJECT/acceptance)")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)

    try:
        result = grade(a.project, a.repo_root, a.second_run)
    except GraderRefusal as e:
        print(f"acceptance: REFUSED — {e}", file=sys.stderr)
        return 3

    out_dir = a.out or (a.project / "acceptance")
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "acceptance_result.json").write_text(
        json.dumps(result, indent=1, sort_keys=True, default=str), encoding="utf-8")
    report = render_report(result)
    (out_dir / "acceptance_report.md").write_text(report, encoding="utf-8")
    if not a.quiet:
        print(report)
    print(f"acceptance: {result['verdict']} — {result['verdict_reason']}", file=sys.stderr)
    print(f"acceptance: wrote {out_dir}/acceptance_report.md and acceptance_result.json",
          file=sys.stderr)
    return {"ACCEPTED": 0, "REJECTED": 1, "INCOMPLETE": 2}.get(result["verdict"], 3)


if __name__ == "__main__":
    raise SystemExit(main())
