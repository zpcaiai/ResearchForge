#!/usr/bin/env bash
# The acceptance run: one paper, a real model key, real hardware, then a grade.
#
# This script exists for the one thing the development container cannot do. The
# ordinary CLI has an explicit `--offline` machinery path and records planned
# runs as NOT_RUN when its execution backend is unavailable. Missing live keys do
# not trigger an automatic fallback: provider setup fails loudly. All of those
# outcomes are correct outside acceptance and unacceptable as acceptance evidence.
#
# So this script has no fallback. It checks for everything it needs, names each
# missing thing individually, and exits before touching the project directory.
#
# Usage:
#   ./run_acceptance.sh PAPER PROJECT_DIR [options]
#
#   --impl DIR        directory of <EXPERIMENT_ID>.py files supplying the method
#                     under test (see examples/attention-length-generalization)
#   --select IDS      idea ids to select at the human gate (default: I-001)
#   --sets FILE       file of key=value lines, one per --set external
#   --model NAME      model provider (default: anthropic). 'offline' is refused.
#   --set sandbox_image=IMAGE selects an already-local NVIDIA/PyTorch image. Acceptance
#                     automatically requires and validates `sandbox_gpu_required=true`.
#   --no-second-run   skip the determinism run. The reproducibility dimension will
#                     then report NOT_MEASURED and acceptance cannot be reached.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"

PAPER=""; PROJ=""; IMPL=""; SELECT="I-001"; SETS_FILE=""; MODEL="anthropic"
SANDBOX_IMAGE="python:3.11-slim"
SECOND_RUN=1
DIRECT_SETS=()
ARG_ERRORS=()

while [ $# -gt 0 ]; do
  case "$1" in
    --impl|--select|--sets|--model|--set)
      option="$1"
      if [ $# -lt 2 ] || [ -z "$2" ] || [[ "$2" == --* ]]; then
        ARG_ERRORS+=("$option needs a value in the documented '$option VALUE' form")
        shift
        continue
      fi
      value="$2"
      case "$option" in
        --impl) IMPL="$value" ;;
        --select) SELECT="$value" ;;
        --sets) SETS_FILE="$value" ;;
        --model) MODEL="$value" ;;
        --set)
          if [[ "$value" != *=* ]] || [[ "$value" == =* ]]; then
            ARG_ERRORS+=("--set value '$value' is not key=value")
          else
            DIRECT_SETS+=("$value")
          fi ;;
      esac
      shift 2 ;;
    --no-second-run) SECOND_RUN=0; shift ;;
    --)
      shift
      while [ $# -gt 0 ]; do
        ARG_ERRORS+=("unsupported argument after --: '$1'")
        shift
      done ;;
    --set=*)
      ARG_ERRORS+=("'$1' is not supported by the CLI; use the documented '--set key=value' form")
      shift ;;
    --project|--project=*|--offline|--offline=*|--redo|--redo=*|--model=*|--select=*|--sets=*|--impl=*|--no-second-run=*)
      ARG_ERRORS+=("reserved CLI option '$1' is not accepted in that form by the acceptance harness")
      shift ;;
    -*) ARG_ERRORS+=("unsupported acceptance option '$1'"); shift ;;
    *) if [ -z "$PAPER" ]; then PAPER="$1"; elif [ -z "$PROJ" ]; then PROJ="$1";
       else ARG_ERRORS+=("unexpected positional argument '$1'"); fi; shift ;;
  esac
done

# Read the two execution-boundary settings before preflight. The general CLI
# accepts arbitrary externals, but acceptance has one admissible security profile
# and must validate its already-local image before creating evidence directories.
scan_acceptance_set() {
  local setting="$1"
  if [[ "$setting" != *=* ]] || [[ "$setting" == =* ]]; then
    note "acceptance setting '$setting' is not key=value"
    return
  fi
  case "$setting" in
    security_profile=no-network-untrusted-code) ;;
    security_profile=*) note "security_profile must be no-network-untrusted-code for acceptance;
      trusted-host execution is a machinery profile, not acceptance isolation" ;;
    sandbox_image=*) SANDBOX_IMAGE="${setting#sandbox_image=}" ;;
    sandbox_gpu_required=true) ;;
    sandbox_gpu_required=*) note "sandbox_gpu_required is fixed to literal true for acceptance;
      it is not an operator-overridable evidence gate" ;;
  esac
}

# Match execution.py::_module_name exactly for every filename accepted below.
# Keeping this in the harness avoids guessing that E.001 maps to e.001 when the
# generated package is actually code/e_001.
runner_module_name() {
  local name module first
  name="$1"
  module="$(printf '%s' "$name" | sed -E 's/[^0-9A-Za-z_]+/_/g; s/^_+//; s/_+$//' | \
    tr '[:upper:]' '[:lower:]')"
  [ -n "$module" ] || module="unnamed"
  first="${module%"${module#?}"}"
  case "$first" in [A-Za-z_]) ;; *) module="exp_$module" ;; esac
  printf '%s\n' "$module"
}

# --------------------------------------------------------------------------
# Preflight. Every missing precondition is collected and reported together:
# discovering them one exit code at a time wastes an operator's afternoon, and
# the point of this block is that it is cheaper than the run it guards.
# --------------------------------------------------------------------------
MISSING=("${ARG_ERRORS[@]+"${ARG_ERRORS[@]}"}")
note() { MISSING+=("$1"); }

if [ -n "$SETS_FILE" ] && [ -f "$SETS_FILE" ]; then
  while IFS= read -r line; do
    case "$line" in ''|\#*) continue ;; esac
    scan_acceptance_set "$line"
  done < "$SETS_FILE"
fi
for setting in "${DIRECT_SETS[@]+"${DIRECT_SETS[@]}"}"; do
  scan_acceptance_set "$setting"
done

[ -n "$PAPER" ] || note "argument 1 (PAPER): a paper URL, PDF or HTML file to run on"
[ -z "$PAPER" ] || [ -f "$PAPER" ] || [[ "$PAPER" == http://* ]] || \
  [[ "$PAPER" == https://* ]] || \
  note "PAPER '$PAPER' is neither an existing file nor an http(s) URL"
[ -n "$PROJ" ] || note "argument 2 (PROJECT_DIR): where the run will be built"

# -- 1. a real model key ---------------------------------------------------
# Checked by name, because "no key" and "wrong key" produce very different
# failures four hours in, and only the first one is this script's business.
case "$MODEL" in
  anthropic|anthropic:*)
    [ -n "${ANTHROPIC_API_KEY:-}" ] || note "ANTHROPIC_API_KEY: --model '$MODEL' selected the
      Anthropic provider, but its key is unset. An OPENAI_API_KEY cannot authenticate it." ;;
  openai|openai:*)
    [ -n "${OPENAI_API_KEY:-}" ] || note "OPENAI_API_KEY: --model '$MODEL' selected the OpenAI
      provider, but its key is unset. An ANTHROPIC_API_KEY cannot authenticate it." ;;
  offline)
    note "--model offline was requested. Refused: an acceptance run in offline mode grades the
      machinery, not the research." ;;
  *) note "unknown --model '$MODEL'. Supported provider names are anthropic[:MODEL] and
      openai[:MODEL]." ;;
esac
# -- 2. an NVIDIA GPU -------------------------------------------------------
# Deliberately has no override flag. An 'I know what I am doing' escape hatch on
# this check is the door through which an acceptance report gets produced on a
# laptop, and that report is indistinguishable from a real one afterwards.
GPU_DESC=""
if command -v nvidia-smi >/dev/null 2>&1; then
  GPU_DESC="$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null | head -4 || true)"
fi
if [ -z "$GPU_DESC" ]; then
  note "a visible NVIDIA GPU: nvidia-smi reports none. This acceptance protocol requires
      NVIDIA Container Toolkit allocation plus torch.cuda inside the immutable execution image;
      a useful CPU or Apple/ROCm machinery run is still not this protocol's acceptance run."
fi

# -- 3. a sandbox -----------------------------------------------------------
# sandbox-provisioner enables untrusted execution only after it reaches the Docker
# daemon and resolves the configured already-local image to an immutable id.
# experiment-runner otherwise records every planned run as NOT_RUN with no host
# fallback. The daemon check here is necessary but the provisioner remains the
# authority on image validation.
if ! command -v docker >/dev/null 2>&1; then
  note "docker: not on PATH. sandbox-provisioner will set
      untrusted_code_execution_allowed=false and experiment-runner will record every
      planned run as NOT_RUN. The run would finish with an empty ledger."
elif [ -z "$SANDBOX_IMAGE" ] || [[ "$SANDBOX_IMAGE" == -* ]] || \
     [[ "$SANDBOX_IMAGE" =~ [^A-Za-z0-9._/:@-] ]]; then
  note "sandbox_image '$SANDBOX_IMAGE' is not a safe Docker image reference"
else
  DOCKER_BIN="$(command -v docker)"
  if ! DOCKER_REAL="$(PYTHONPATH="$ROOT/python${PYTHONPATH:+:$PYTHONPATH}" python3 - "$DOCKER_BIN" <<'PY'
import sys
try:
    from researchforge.skills.intake import _local_docker_identity
    identity, reason = _local_docker_identity(sys.argv[1])
except Exception as exc:
    print(f"Docker identity probe could not start: {type(exc).__name__}: {exc}", file=sys.stderr)
    raise SystemExit(1)
if reason:
    print(reason, file=sys.stderr)
    raise SystemExit(1)
real = None if identity is None else (identity.get("docker_realpath") or identity.get("binary"))
if not real:
    print("Docker identity probe returned no exact executable", file=sys.stderr)
    raise SystemExit(1)
print(real)
PY
  )"; then
    note "docker: the local-engine identity probe refused this backend: ${DOCKER_REAL:0:800}.
      Acceptance requires an exact local executable, an absolute unix:// endpoint, a reachable
      Linux daemon and no SSH/TCP/npipe/fd Docker context. No daemon command is sent to a
      non-local DOCKER_HOST."
  elif ! GPU_SANDBOX_PROBE="$(PYTHONPATH="$ROOT/python${PYTHONPATH:+:$PYTHONPATH}" \
      python3 - "$SANDBOX_IMAGE" <<'PY' 2>&1
import sys
from researchforge.skills.intake import _validate_local_docker_image
result = _validate_local_docker_image(sys.argv[1], gpu_required=True)
gpu = result.get("gpu") if isinstance(result, dict) else None
if not result.get("validated") or not isinstance(gpu, dict) or gpu.get("validated") is not True:
    print(result.get("reason", "GPU validation returned no usable evidence"))
    raise SystemExit(1)
print(f"{gpu['device_count']} NVIDIA device(s); torch={gpu['torch_version']}; "
      f"cuda={gpu['cuda_runtime']}; image={result['image_id']}")
PY
  )"; then
    note "sandbox_image '$SANDBOX_IMAGE' is not acceptance-ready under the local immutable
        NVIDIA Docker contract: ${GPU_SANDBOX_PROBE:0:800}. Acceptance never pulls an image,
        substitutes the host package set, or treats host-only GPU visibility as container proof."
  fi
fi

# -- 4. the runtime itself --------------------------------------------------
CLI="$ROOT/packages/cli/dist/cli.js"
command -v node >/dev/null 2>&1 || note "node: not on PATH (the orchestrator is TypeScript)"
[ -f "$CLI" ] || note "$CLI: not built. Run 'npm install && npm run build' in $ROOT."
python3 -c "import researchforge" 2>/dev/null || \
  note "the researchforge python package is not importable. Run 'pip install -e $ROOT/python'."
if command -v node >/dev/null 2>&1 && [ -f "$CLI" ]; then
  if ! node "$CLI" doctor >/dev/null 2>&1; then
    note "researchforge doctor failed: the compiled TypeScript/Python contract boundary is not
      healthy. Run 'node $CLI doctor' for the diagnostic."
  fi
fi

# Prove the actual Python choke-point gates without dispatching a skill or
# creating a project. This catches invalid/expired signatures and editions that
# omit any paid stage; grepping the human-facing doctor text cannot do that.
# A literal self-hosted override is accepted because the real invocations record
# it in provenance and release_manifest, while this read-only preflight does not.
if [ -f "$CLI" ]; then
  set +e
  LICENCE_PROBE="$(node "$CLI" license-check 2>&1)"
  LICENCE_RC=$?
  set -e
  if [ "$LICENCE_RC" -ne 0 ]; then
    note "paid Python skill access: the read-only licence probe failed (exit $LICENCE_RC):
      ${LICENCE_PROBE:0:800}
      Use a certified release build with a matching paid licence, or deliberately export
      RESEARCHFORGE_ALLOW_UNLICENSED=1; the latter is recorded by each real invocation."
  fi
fi

# -- 5. inputs the run needs to reach the end -------------------------------
[ -z "$SETS_FILE" ] || [ -f "$SETS_FILE" ] || note "--sets file '$SETS_FILE' does not exist"
[ -z "$IMPL" ] || [ -d "$IMPL" ] || note "--impl directory '$IMPL' does not exist"
IMPL_FILES=()
IMPL_MODULES=()
if [ -z "$IMPL" ]; then
  note "--impl DIR: no implementation directory was given. The scaffolder generates the
      experiment harness but never the method under test; without impl/<id>.py every run
      fails with METHOD_NOT_IMPLEMENTED and the ledger carries no measurement."
elif [ -d "$IMPL" ]; then
  for f in "$IMPL"/*.py; do
    if [ -L "$f" ]; then
      note "implementation '$f' is a symbolic link; acceptance copies only regular files from --impl"
      continue
    fi
    [ -e "$f" ] || continue
    if [ ! -f "$f" ]; then
      note "implementation '$f' is not a regular file"
      continue
    fi
    id="$(basename "$f" .py)"
    if [[ ! "$id" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]*$ ]]; then
      note "implementation filename '$(basename "$f")' is not a safe <EXPERIMENT_ID>.py name"
      continue
    fi
    module="$(runner_module_name "$id")"
    collision=""
    for prior in "${IMPL_MODULES[@]+"${IMPL_MODULES[@]}"}"; do
      if [ "$prior" = "$module" ]; then collision="$module"; break; fi
    done
    if [ -n "$collision" ]; then
      note "implementation '$f' maps to duplicate scaffold module '$module'"
      continue
    fi
    IMPL_FILES+=("$f")
    IMPL_MODULES+=("$module")
  done
  if [ ${#IMPL_FILES[@]} -eq 0 ]; then
    note "--impl directory '$IMPL' contains no safe regular <EXPERIMENT_ID>.py implementation"
  fi
fi

# Project directories are write-once acceptance evidence. Refusing an existing
# path avoids both stale artifacts and a destructive rm -rf on caller input.
if [ -n "$PROJ" ]; then
  PROJ="$(python3 -c 'import os,sys; print(os.path.abspath(sys.argv[1]))' "$PROJ")"
  PROJ2_CHECK="${PROJ%/}-second"
  case "$PROJ" in
    /|"${HOME%/}"|"${ROOT%/}") note "PROJECT_DIR '$PROJ' is a protected root" ;;
  esac
  [ ! -e "$PROJ" ] || note "PROJECT_DIR '$PROJ' already exists. Acceptance evidence must be
      built in a fresh directory; choose a new path rather than mixing or deleting prior data."
  if [ "$SECOND_RUN" -eq 1 ]; then
    [ "$PROJ2_CHECK" != "$PROJ" ] || note "the second-run directory resolves to PROJECT_DIR"
    [ ! -e "$PROJ2_CHECK" ] || note "second-run directory '$PROJ2_CHECK' already exists. Choose
      a fresh PROJECT_DIR so both runs have independent, empty destinations."
  fi
fi

if [ ${#MISSING[@]} -gt 0 ]; then
  echo "" >&2
  echo "acceptance: REFUSING TO START — ${#MISSING[@]} precondition(s) missing." >&2
  echo "" >&2
  for m in "${MISSING[@]}"; do
    echo "  ✖ $m" >&2
    echo "" >&2
  done
  echo "Nothing was written to '${PROJ:-<unset>}'. This script has no degraded mode: its whole" >&2
  echo "purpose is the run that cannot be performed without the things listed above." >&2
  exit 78   # EX_CONFIG
fi

if [ -z "${RESEARCHFORGE_CONTACT_EMAIL:-}" ]; then
  # A warning, not a refusal: the run works without it, but the scholarly APIs
  # throttle an anonymous caller instead of applying polite-pool limits, and the
  # coverage report will name the resulting blind spots.
  echo "acceptance: warning — RESEARCHFORGE_CONTACT_EMAIL is unset; OpenAlex/Crossref requests" >&2
  echo "            will not identify a contact for their polite-pool policies." >&2
fi

# --------------------------------------------------------------------------
# the run
# --------------------------------------------------------------------------
COMMON=(--model "$MODEL" --set sandbox_gpu_required=true)
if [ -n "$SETS_FILE" ]; then
  while IFS= read -r line; do
    case "$line" in ''|\#*) continue ;; esac
    COMMON+=(--set "$line")
  done < "$SETS_FILE"
fi
for setting in "${DIRECT_SETS[@]+"${DIRECT_SETS[@]}"}"; do
  COMMON+=(--set "$setting")
done

echo "acceptance: GPU — ${GPU_DESC//$'\n'/ | }"
echo "acceptance: paper=$PAPER project=$PROJ model=$MODEL select=$SELECT"

drive_run() {
  # One full traversal: to the human gate, through the gate, then again with the
  # method under test in place. The third pass is not a retry — the scaffolder
  # cannot produce impl.py, so the experiments genuinely cannot run before it
  # exists, and --redo experiment-runner is the documented way back into the
  # execution stage.
  local proj="$1"
  mkdir "$proj"

  echo ""; echo "── $proj phase 1: to the human gate ──"
  set +e
  node "$CLI" run "$PAPER" --project "$proj" "${COMMON[@]}"
  local rc=$?
  set -e
  if [ "$rc" -ne 10 ]; then
    echo "acceptance: phase 1 expected the deliberate human-gate exit (10), got $rc" >&2
    # Returning the observed value would turn an unexpected success (rc=0)
    # into success for this function and let the harness continue.
    return 1
  fi

  echo ""; echo "── $proj phase 2: select a direction, compile and scaffold ──"
  set +e
  node "$CLI" run "$PAPER" --project "$proj" "${COMMON[@]}" --select "$SELECT"
  rc=$?
  set -e
  if [ "$rc" -ne 11 ]; then
    echo "acceptance: phase 2 expected a deliberate missing-implementation stop (11), got $rc" >&2
    return 1
  fi
  python3 - "$proj/experiment_ledger.jsonl" <<'PY'
import json, pathlib, sys
p = pathlib.Path(sys.argv[1])
try:
    rows = [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
except Exception as exc:
    raise SystemExit(f"acceptance: phase 2 produced no readable experiment ledger: {exc}")
bad = [r for r in rows if r.get("failure_class") != "METHOD_NOT_IMPLEMENTED"]
if not rows or bad:
    raise SystemExit("acceptance: phase 2 stopped for something other than the expected "
                     "METHOD_NOT_IMPLEMENTED condition")
PY

  if [ -n "$IMPL" ]; then
    echo ""; echo "── $proj phase 3: install the method under test ──"
    local index f id module dir missing generated scaffolds
    missing=0
    for ((index=0; index<${#IMPL_FILES[@]}; index++)); do
      f="${IMPL_FILES[$index]}"
      module="${IMPL_MODULES[$index]}"
      id="$(basename "$f" .py)"
      dir="$proj/code/$module"
      if [ ! -d "$dir" ]; then
        echo "  ! $id: no scaffolded directory at $dir — the blueprint compiled no such experiment" >&2
        missing=1
      fi
    done
    if [ "$missing" -ne 0 ]; then
      echo "acceptance: refusing phase 4 because an implementation does not map to a scaffold" >&2
      return 1
    fi
    for ((index=0; index<${#IMPL_FILES[@]}; index++)); do
      f="${IMPL_FILES[$index]}"
      module="${IMPL_MODULES[$index]}"
      id="$(basename "$f" .py)"
      dir="$proj/code/$module"
      cp "$f" "$dir/impl.py"
      echo "  $id -> $dir/impl.py"
    done
    scaffolds=0
    missing=0
    for generated in "$proj"/code/*/experiment.py; do
      [ -e "$generated" ] || continue
      scaffolds=$((scaffolds + 1))
      dir="$(dirname "$generated")"
      if [ ! -f "$dir/impl.py" ]; then
        echo "  ! $(basename "$dir"): generated experiment has no supplied impl.py" >&2
        missing=1
      fi
    done
    if [ "$scaffolds" -eq 0 ] || [ "$missing" -ne 0 ]; then
      echo "acceptance: refusing phase 4 because implementation coverage is incomplete "\
           "($scaffolds scaffolded experiment(s))" >&2
      return 1
    fi
    echo ""; echo "── $proj phase 4: re-run the experiments and everything downstream ──"
    node "$CLI" run "$PAPER" --project "$proj" "${COMMON[@]}" --select "$SELECT" \
      --redo experiment-runner
  fi

  node "$CLI" status --project "$proj"
}

drive_run "$PROJ"

SECOND_ARG=()
if [ "$SECOND_RUN" -eq 1 ]; then
  PROJ2="${PROJ%/}-second"
  echo ""; echo "══ determinism: a second run from the same inputs into $PROJ2 ══"
  # Same paper, same externals, same impl. If the two disagree on a metric, every
  # confidence interval in the manuscript is measuring the machine.
  drive_run "$PROJ2"
  SECOND_ARG=(--second-run "$PROJ2")
else
  echo ""
  echo "acceptance: --no-second-run given. The reproducibility dimension will report" >&2
  echo "            NOT_MEASURED and the overall verdict cannot be ACCEPTED." >&2
fi

# --------------------------------------------------------------------------
# the grade
# --------------------------------------------------------------------------
echo ""; echo "══ grading ══"
set +e
python3 "$HERE/grade.py" "$PROJ" --repo-root "$ROOT" ${SECOND_ARG[@]+"${SECOND_ARG[@]}"} --quiet
RC=$?
set -e
echo ""
echo "acceptance: report  -> $PROJ/acceptance/acceptance_report.md"
echo "acceptance: machine -> $PROJ/acceptance/acceptance_result.json"
exit $RC
