# Acceptance rubric v1.5.0

The question this rubric answers: **do the recorded artifacts of a finished ResearchForge project
satisfy the project's acceptance requirements?**

This artifact grader does not attest that a real model credential was used or that provider calls
were live. Synthetic markers are a hard refusal when present, but their absence is not a
live-provider attestation. GPU allocation is different: v2.8.4 persists the restrictive NVIDIA
probe, exact device summary, Docker `--gpus all` command and per-row agreement, so E8.2 consumes
that evidence. `run_acceptance.sh` separately preflights the remaining operational envelope; an
`ACCEPTED` result from `grade.py` describes the evidence it can consume, not facts the artifact
contract does not record.

It is written so a human and `grade.py` reach the same verdict on the same project. Every threshold
below is stated as a number, an outcome, and a reason. "80% seems right" is not a reason; a threshold
whose only justification is that it sounds strict is a threshold that will be argued down the first
time it fails.

## How a verdict is reached

Eight dimensions. Each gets exactly one of four outcomes:

| outcome | meaning |
|---|---|
| `PASS` | measured, and it met the threshold |
| `FAIL` | measured, and it did not |
| `NOT_APPLICABLE` | the project legitimately contains nothing of this kind (no figures were planned; the comparison mode requires no disclosure) |
| `NOT_MEASURED` | the grader could not see enough of the project to decide |

> **`NOT_MEASURED` is not a pass.** The overall verdict is `ACCEPTED` only when zero dimensions are
> `FAIL` **and** the `NOT_MEASURED` list is empty. This is the one rule in the rubric that exists to
> constrain the *grader* rather than the project: a harness that scores a missing artifact as a pass
> is the exact failure ResearchForge is built against, reappearing one layer up. The remaining
> verdicts are `REJECTED` (something failed), `INCOMPLETE` (nothing failed, something was invisible)
> and `REFUSED_SYNTHETIC`.

Within a dimension, one failing check fails the dimension. Dimensions are not averaged and there is
no total score. A weighted mean would let a strong result in one dimension pay for a fabricated claim
in another, and nothing in this system is for sale at that price.

## What the grader does not decide

`grade.py` **consumes** these verdicts and never recomputes them:

| verdict | owner |
|---|---|
| is a claim fabricated / unsupported | `claim-citation-auditor` → `integrity_gate`, `claim_audit` |
| do the statistics hold | `integrity-auditor` → `stats_audit.evidence_lock` |
| does the manuscript survive review | `review-simulator` → `review_report` |
| may an artifact ship | `release-gate` → `release_manifest` |
| may a frontier claim in the prose stand | `claim-citation-auditor` → `integrity_gate` (`sota_claims_have_a_measured_sota_arm`, `sota_claims_rest_on_a_same_topic_anchor`) |

Re-deriving any of them would create two thresholds for one question, and the lower of two thresholds
is the one that actually governs — which means the careful one upstream would quietly stop mattering.
What the grader adds is the class of quantity no upstream skill computes, because every upstream check
is per-item and acceptance is per-project: **coverage and ratio**. The gate refuses one fabricated
claim; it has nothing to say about a manuscript in which 40% of claims are merely partially supported.
The figure factory refuses one figure bound to an unknown claim; it has nothing to say about a claim
with no figure at all.

## Refusal: synthetic projects are not graded

If any scanned artifact carries `synthetic: true`, `_synthetic: true` or `is_synthetic: true` — the
same markers `release-gate` refuses on — the grader emits `REFUSED_SYNTHETIC` and no dimension is
scored. `--model offline` exists to exercise the machinery; model-derived artifacts and provenance
are marked synthetic. A score attached to that output would look like a research result, and the
number would outlive the caveat printed next to it.

---

## 1. Experiment engineering

*Do the generated experiments run, is every metric declared, are the seeds enough for the claim, and
do the void conditions get checked while the run is happening rather than after it?*

| check | threshold | rationale |
|---|---|---|
| `E1.1_every_spec_ran` | every `ExperimentSpec` produced ≥1 `COMPLETED` run carrying numeric metrics | A spec that never ran is a plan. The manuscript cannot cite a plan, so a spec with zero measured runs is either dead weight in the blueprint or a missing result — both are defects, and there is no fraction of specs that may be plans. |
| `E1.2_completion_rate` | completed planned identities / all planned identities ≥ **0.66** | The denominator comes from the runner's `experiment_tree` run nodes, with an unambiguous spec arm×seed plan as the legacy fallback; duplicate ledger output is collapsed and an omitted failed row still remains in the denominator. Current tree nodes and ledger rows duplicate identity, status and metrics, so any disagreement is corruption and therefore `NOT_MEASURED`; the grader never chooses whichever copy scores better. A missing or conflicting plan identity is likewise `NOT_MEASURED`, not a smaller denominator. The numeric floor is not chosen here: `integrity-auditor` already prices a failure rate at `max_failure_rate = 0.34` (`analysis.py`). |
| `E1.3_metrics_declared` | **0** metrics recorded that the spec does not declare | A metric that first appears after the run is a metric chosen with the data in view. There is no acceptable fraction of that: one post-hoc metric converts a test into a search. `experiment-runner` already rejects undeclared metrics at the boundary (`INVALID_METRICS`), so a nonzero count here means the ledger was written by something other than the runner. |
| `E1.4_seed_adequacy` | for **each runnable arm**, **≥3** distinct completed seeds for `comparative` and `ablation` specs; **≥2** for `diagnostic` and `evaluation` | 3 is `MIN_SEEDS_FOR_COMPARATIVE` (`planning.py`) and `MIN_SEEDS_FOR_INFERENCE` (`analysis.py`): below it a between-condition difference has no estimable dispersion and the claim is a single draw. 2 is where `analysis._summary` starts reporting an interval at all — at n=1 it refuses, because one observation carries no dispersion information. The unit is the runnable `baseline`, `candidate` or `sota` arm: a full candidate arm cannot hide a thin comparison arm. **Distinct completed seeds**, not rows or declared seeds: a retry is not another sample, and a seed that never ran is not a sample. |
| `E1.5a_invalid_conditions_declared` | every spec declares ≥1 `invalid_conditions` entry | An experiment that cannot come back void is not an experiment, it is a plan to produce numbers. A void run and a negative run are different objects and a system that cannot distinguish them reports its voids as findings. |
| `E1.5b_invalid_conditions_machine_evaluable` | every spec carries ≥1 condition in either legacy inline form `{metric, op, value}` or registered form `{check: {kind: ...}}` | Legacy guards are evaluated by `rf_runtime.check_invalid_conditions`. Registered predicates are evaluated after the arms finish by `researchforge.invalid_conditions`; the current registry is `min_completed_runs_per_condition`, `ledger_arm_completed`, `field_stable_across_runs`, `metric_names_stable`, `configs_match_except`, `artifact_field_present` and `text_present_in_artifact`. Prose-only conditions and unknown kinds remain documentation, not guards. |
| `E1.5c_invalid_conditions_checked_at_runtime` | every `COMPLETED` or `INVALID` legacy row carries the exact clean `provenance.invalid_conditions_runtime = {checked: true, fired: [...], unchecked: [...], error: null}` record, with reported predicates identical to their declarations and status coherent with `fired`; every registered predicate has a corresponding runtime verdict in `experiment_tree.validity` | Source text is not execution evidence: a call may occur in a comment, below `if False`, in an unused function or after an early return. Legacy proof is consumed from the record the runner writes while parsing the actual result payload; missing, malformed, errored or contradictory records are `NOT_MEASURED`, and malformed evidence corrupts the ledger. Registered predicates are verified from the runner's per-experiment validity verdicts (`CLEAR` or `FIRED`); `FIRED` means the experiment is void and it must appear in `void_experiments`, where its rows are excluded from every scientific check. A disagreement among verdict status, per-record `void`, `fired`, and the top-level void list corrupts validity and is `NOT_MEASURED`. A missing verdict or `UNCHECKED` predicate is also `NOT_MEASURED`, never a pass. |

> **Compatibility note.** The compiler's current `invalid_conditions` retain prose for the reader and
> add registered `check.kind` predicates for the runner. Those predicates satisfy `E1.5b`; their
> recorded decisions in `experiment_tree.validity` satisfy `E1.5c`. Legacy generated projects may
> still use inline `{metric, op, value}` guards, but only a persisted per-run decision satisfies
> `E1.5c`; retaining source that appears to call the helper does not. A prose-only condition, an
> unknown kind or an absent runtime decision satisfies neither check.

## 2. Baselines

*Is there something to compare against, is it pinned, and does the comparison mode permit the
comparison that was actually made?*

| check | threshold | rationale |
|---|---|---|
| `E2.1_baseline_condition_exists` | every spec names a `baseline` with a `kind` | Without a referent a number is a measurement of nothing in particular. "Better" has no meaning; only "different" does. |
| `E2.2_baseline_pinned_or_declared_unpinned` | every external baseline is `established: true` **or** carries `BASELINE_NOT_ESTABLISHED` in its `invalid_conditions` | An unpinned baseline is acceptable research practice when it is declared. An unpinned baseline nobody wrote down is not: it can change between conditions, and every difference then belongs to the baseline rather than to the candidate. The disjunction is the point — this rubric does not require a pinned baseline, it requires that the project knows which of the two it has. Internal baselines (`own_full_method`, `metric_under_test`, `internal_reference_condition`) are exempt because there is no external revision to pin. |
| `E2.3_comparison_permitted_by_mode` | **0** specs whose baseline kind is outside the mode's vocabulary; **0** comparative specs under `CM_NONE` | The comparison mode is derived from what was actually reproduced (RL0–RL4), and it is the only thing that licenses a comparison. `CM_MEASURED`→`locally_measured`, `CM_RELATIVE`→`locally_measured_reduced_scale`, `CM_REPORTED`→`reported_by_authors`, `CM_NONE`→internal only. A spec outside that map is comparing against something the project never established, whatever its prose says. |
| `E2.4_sota_anchor_topic_declared` | every spec with `sota.required` records a `topic_match_strength` of `direct`, `asserted` or `weak` | `NOT_APPLICABLE` when no spec declares a frontier arm — not every paper claims the frontier, and whether this one should have is dimension 7's question about what the manuscript says. When one is declared, the field is what separates a candidate that reports on this paper's benchmark (`direct`) or declares itself the frontier of this task (`asserted`) from one admitted on shared task words alone (`weak`). Only the first two make "strongest" mean strongest at *this* measurement. An arm with no recorded strength is unauditable: the reader cannot tell which of the three it was, and the generous reading is the one that gets used. |
| `E2.5_sota_arm_measured_or_declared_unmeasured` | every spec with `sota.required` has ≥1 `COMPLETED` sota-arm run with metrics **or** carries `SOTA_ARM_NOT_MEASURED` with a machine-evaluable `check` (`kind: ledger_arm_completed`) | The same disjunction as `E2.2`, for the same reason: this rubric does not require the frontier to have been run, it requires the project to know which of the two it has. The per-claim gate in `claim-citation-auditor` adjudicates one sentence at a time and only fires on a paper that uses the word — a project can plan a frontier arm, never run it, write around the word, and pass every per-claim check. That is the project-level coverage question no upstream skill asks. A bare code with no `check` does not satisfy it, for the same reason `E1.5b` requires a predicate: `rf_runtime` returns a prose condition as *unchecked*, never as satisfied, so it will not fire on the run it was written for. Requiring the predicate is also what stops this check being vacuous — the compiler emits the code on exactly the specs where `sota.required` is true, so accepting the code alone made the two sets identical by construction. `NOT_MEASURED` if the ledger is absent. |

## 3. Ablations

*Is every claimed mechanism actually isolated, is the compute matched, and is a null result reported
rather than re-run against a different metric?*

| check | threshold | rationale |
|---|---|---|
| `E3.1_isolation_test_per_mechanism` | coverage = **1.0** (every distinct `mechanism_id` in `ablation_plan.mechanisms` maps to exactly one ablation and an ablation spec that produced ≥1 measured run) | The denominator is the mechanism plan, not the ablation rows: omitting an ablation must not omit the mechanism it failed to test. An uncovered mechanism is an unfalsified mechanism. A fractional threshold — 0.8, say — would license claiming exactly the mechanisms nobody tested, since the paper does not distinguish between the covered and uncovered ones when it attributes the effect. Duplicate or conflicting plan identities are `NOT_MEASURED`, because choosing one would manufacture coverage. |
| `E3.2_compute_matched` | every ablation declares a `matched_compute` counterfactual **and**, for every runnable ablation arm, has the same non-empty set of **completed ledger seed identities** as its explicit parent experiment | Matched compute that exists only in declared seed-list lengths is not matched compute. Failed seeds are not compute-matched measurements, duplicate rows are not extra seeds, and a full baseline arm cannot hide a thin candidate arm. The ledger is the part of the seed budget that can witness what actually ran. Without it, "removing the mechanism degrades the metric" is explained equally well by the mechanism simply having cost more. |
| `E3.3a_ablation_shares_a_metric_with_its_primary_experiment` | every ablation spec names one coherent explicit parent via `inherits_metrics_from` / `anchored_to.parent_experiment_id` and shares **≥1** declared metric with that parent | `analysis._group_values` groups the ledger by `(branch, metric)`. Sharing a metric with an unrelated non-ablation experiment cannot construct the intended contrast. An ablation whose metric set is disjoint from its explicit parent's can never isolate the claimed mechanism — no test can be constructed, and the isolation supports nothing. It is also the shape a retried null takes: flat on the metric that mattered, reported on a metric that appeared afterwards. Non-empty intersection, not equality, because an ablation may legitimately record extra diagnostics. |
| `E3.3b_null_results_reported` | every ablation whose test is not significant after correction appears in `findings` or `negative_findings` | A null result that is not written down is indistinguishable from one that was retried until it stopped being null. `finding-memory` already emits negative findings; what is measured here is that none of the ablations went missing between the audit and the findings. `NOT_MEASURED` if `stats_audit` or `negative_findings` is absent. |

## 4. Evidence support

*Does every quantitative claim trace to a run, and how much of the argument is fully backed?*

| check | threshold | rationale |
|---|---|---|
| `E4.0_integrity_gate_permits_submission` | top-level `integrity_gate.verdict` is `PASS` or `PASS_WITH_CONDITIONS` **and** `submission_permitted` is explicitly `true` | Consumed, not recomputed. `BLOCK` or explicit refusal fails even if stale claim rows look clean; an absent, corrupt or unrecognised top-level verdict makes E4.0 `NOT_MEASURED`. It does not hide E4.1–E4.3 when their own claim-audit inputs remain available. Per-claim ratios cannot override the auditor that owns permission to submit. |
| `E4.1_zero_fabricated` | **0** claims with verdict `FABRICATED` | Consumed from well-formed non-negative literal integer `integrity_gate.counts`, with the canonical claim audit as the fallback when the top-level gate/counts are absent. One is disqualifying. There is no rate at which a number with no run behind it is acceptable, because the reader has no way to tell which number it was. |
| `E4.2_support_ratio` | SUPPORTED / graded claims ≥ **1 − α**, where α is `stats_audit.alpha` (default 0.05, so **95%**) | This is the ratio nothing upstream computes, and it exists because the integrity gate permits `PARTIALLY_SUPPORTED`. Audit identity is the atomic manuscript sentence `(locator, text)`: distinct sentences at one paragraph remain distinct, while changing only `claim_id` cannot turn a copied SUPPORTED sentence into extra evidence. Exact copies collapse; different bodies for one sentence are corrupt. A supplied α must be a literal finite number with `0 < α < 1`; otherwise the floor is undefined and this check is `NOT_MEASURED`. The floor is taken from the project's declared error tolerance rather than invented: tightening α tightens this automatically. |
| `E4.3_quantitative_claims_traced` | every claim marked `quantitative` has ≥1 `number_check` and every `matched` is the literal boolean `true` | Consumed from `claim_audit` records, not re-adjudicated. Strings and numbers are malformed audit verdicts and make the check `NOT_MEASURED`, not truthy support. Overlaps with `E4.1` by construction and is kept separate because it is measurable when `integrity_gate` is absent but `claim_audit` is not. `NOT_APPLICABLE` when the manuscript states no quantitative claim. |

## 5. Statistical validity

| check | threshold | rationale |
|---|---|---|
| `E5.alpha_valid` | `stats_audit.alpha` is a literal finite number with **0 < α < 1** (default **0.05** only when absent) | Every significance and support decision depends on this probability. Boolean, string, NaN, infinity, zero and one are not error-rate thresholds; malformed α corrupts the audit and makes the dimension `NOT_MEASURED`. |
| `E5.1_evidence_lock_clear` | `stats_audit.evidence_lock.blocked == false` | Consumed. `BLOCKER` and `HIGH` findings prevent evidence lock for the claims they affect; a claim whose statistics did not survive that audit cannot be written as a result, and the grader does not get a second opinion on it. |
| `E5.2_effect_sizes_with_intervals` | every test with a p-value carries `effect_size.ci95`, or an explicit refusal to compute one | A point estimate with no interval is the format in which noise gets published. `analysis._hedges_g` computes the interval, so a missing one means the field was dropped between the audit and the report. An explicit `refused` counts as satisfied — refusing to compute is a stated position; omitting silently is not. |
| `E5.3_correction_named` | when family size > 1, `multiple_comparison_correction.method` is present and not `"none"` | Named, not merely applied: a correction that is not named cannot be checked, and "we corrected for multiple comparisons" is compatible with anything. At α=0.05 a family of 5 has a ~23% chance of at least one false positive uncorrected. When the family is 1 the audit says so explicitly, which passes — applying a correction to a single test would be theatre. |
| `E5.4_no_claim_on_fewer_than_min_seeds` | **0** tests reporting a result on fewer than `stats_audit.min_seeds_required` (default 3) seeds per arm without a refusal | Below 3 there is no power to be wrong with, and printing a p-value beside it launders that. The audit already refuses these; a nonzero count means something downstream reported one anyway. |

## 6. Figures

| check | threshold | rationale |
|---|---|---|
| `E6.1_vector_not_raster` | every shipped figure parses as `<svg>` and contains no `<image>` element | The `.svg` extension is not the property that matters; what is inside the file is. An embedded raster is how a bitmap ships inside a file everyone reads as a vector, and it is exactly what a reviewer cannot zoom into or a copy-editor correct. |
| `E6.2_figure_claim_binding` | binding coverage = **1.0** against `manuscript_spine` claims | A figure that argues for nothing in the paper is a picture, and the reader will still read it as evidence. `figure-factory` refuses to *draw* an unbound figure; nothing checks the shipped set against the spine afterwards, and coverage over the shipped set is what this grader adds. |
| `E6.3_figure_numbers_match_analysis` | **0** bound elements whose drawn values differ from `analysis_results` beyond 1e-9 + 1e-6·scale | The same tolerance `analysis._close` uses, so the figure check and the statistics check agree on what "equal" means. A figure is believed faster than a sentence and checked later; elements carrying no comparable statistic are counted as neither pass nor fail and are reported as such. |

## 7. Writing and argumentation

| check | threshold | rationale |
|---|---|---|
| `E7.0_review_verdict_present` | `review_report.recommendation == REVISE_THEN_SUBMIT` **and** `submission_permitted_by_integrity_gate == true` | Consumed from `review-simulator`. `DO_NOT_SUBMIT` or explicit integrity refusal fails; an absent, corrupt or unrecognised recommendation is `NOT_MEASURED`. Draft-shape checks cannot override the reviewer that owns this verdict. |
| `E7.1_paragraph_claim_coverage` | **1.0** of paragraphs name a claim id, and `every_paragraph_bound_to_a_claim` is `true` | `manuscript-builder` drops orphan paragraphs before rendering, so a shortfall here means the manifest disagrees with itself — which is worse than an orphan, because it means the invariant is being reported rather than held. |
| `E7.2_spine_claims_are_the_drafts_claims` | the two sets are equal (`MC-DISCLOSURE` excepted; it is a required sentence, not a claim) | A spine claim with no paragraph is an argument the paper promised and did not make. A paragraph claim outside the spine was never audited, because the auditor grades against the spine. Set equality, not overlap. |
| `E7.3_disclosure_present` | when the mode requires it, `draft_manifest.disclosure.missing_sections` is empty | Under a degraded comparison mode the disclosure is not a courtesy; it is the sentence that makes every other number in the section readable. `NOT_APPLICABLE` when the mode requires none. |
| `E7.4_no_forbidden_claim_pattern` | **0** of the mode's `forbidden_claim_patterns` appear in the rendered draft | The builder filters forbidden language out of the paragraphs it was handed; nothing re-reads the rendered file afterwards, and the rendered file is what ships. This is a scan of bytes, not a second judgement about what a claim means, so it does not duplicate the auditor. |

## 8. Reproducibility of the run itself

| check | threshold | rationale |
|---|---|---|
| `E8.1_provenance_for_every_released_artifact` | `release/release_manifest.json` has a permitting top-level verdict (`release_status == ASSISTED_DRAFT`, literal boolean `released == true`, no blockers) and at least one released artifact; `release/_manifest.json` is an object with the same non-empty `run_id`, the same literal permitting verdict and an empty blocker list; artifact ids and paths are unique; every released artifact has literal boolean `provenance_complete == true`; and the two manifests contain exactly the same unique `(artifact_id, path, sha256)` deliverable tuples, which in turn name exactly every non-metadata file physically present under `release/`. Every path is canonical `release/...` and each safely resolved private regular-file copy rehashes to its declared SHA-256. | The gate audit record (`release/release_manifest.json`), shipped inventory (`release/_manifest.json`) and physical bytes are independent evidence and must agree one-to-one; neither manifest may vouch for bytes the other omitted. Missing, malformed, contradictory or duplicate bundle-manifest data marks both release artifacts corrupt and is `NOT_MEASURED`. Boolean strings and numbers are corrupt, not truthy permission. Absolute/outside/non-canonical or metadata paths, duplicate identities, dot traversal, symlinks, hard links, missing/non-regular/unreadable files, malformed digests and unmanifested bundle files are also `NOT_MEASURED`; a safely readable declared file whose digest changed is a measured `FAIL`. A top-level refusal fails even if stale per-artifact rows still say `released`; an absent, malformed or unrecognised top-level verdict is `NOT_MEASURED`. The count matters too: a manifest can otherwise be "complete" because it released nothing. |
| `E8.2_environment_captured` | `environment.lock` contains ≥1 pinned (`==`) line; `sandbox_manifest` names the exact current `no-network-untrusted-code` / container / Docker / network-isolated profile; `container.yaml` records a validated absolute Docker launch entry plus its resolved client target/hash, local Unix endpoint and daemon, immutable `sha256:` image id, no-pull/read-only/no-network/non-root smoke contract and protected mounts; its `environment_lock_measurement` says literal `measured=true`, `source_backend=docker`, `command="python -m pip freeze --all"`, names that same image and daemon, and hashes to the actual lock. Manifest, config and validation must also agree on a literal required+validated NVIDIA allocation with one non-empty provisioner source-run id, positive typed device list, PyTorch/CUDA versions and the fixed restrictive `torch.cuda` probe. **Every completed ledger row** records literal current-invocation GPU authorization, executed Docker provenance, a daemon-issued container id, the same environment digest, image, host, limits, isolation and GPU facts, and its actual command contains exactly one `--gpus all`. | A manifest is permission, a container config is validation, the current runner invocation is device-exposure authorization, the lock/GPU probes are measurements, and ledger provenance plus the executed command are execution evidence; none can vouch for the others. The launch entry is execution semantics for symlinked/multicall clients, while the resolved target/hash is client identity; collapsing the two either breaks a valid client or weakens revalidation. Coherent provisioner evidence may be reused on resume, but preseeded project files alone, host-only GPU discovery, a CUDA image label, legacy sandbox labels, mutable image names, malformed booleans or cross-artifact disagreement are `NOT_MEASURED` and corrupt the implicated evidence. A coherently recorded non-strict or failed-validation environment is a measured failure. This closes the paths where a forged manifest, host `pip freeze`, or host-only `nvidia-smi` could bless numbers produced outside the validated image/device boundary. |
| `E8.3_second_run_reaches_the_same_state` | each distinct project has one non-empty run id that agrees across every ledger row, `experiment_tree`, final state, release manifest and current attempt ids; the two run ids differ; final state, per-(`experiment`, `arm`, `seed`) status and metrics, and release verdict match | Every interval in the analysis is computed from dispersion across seeds. If the seeds do not reproduce, that dispersion is measuring the machine rather than the method. Merely renaming the copied ledger's `run_id` does not prove a rerun: all independently written run artifacts must identify the same execution internally, and the two coherent identities must differ. Equivalence is then compared on a fingerprint because timestamps and absolute paths legitimately differ. **`NOT_MEASURED` unless an independently identifiable second run is supplied** (`--second-run`); `run_acceptance.sh` performs it. |

---

## What a stock synthetic run proves today

The bundled worked example uses the offline model and an explicitly trusted host-code profile. Its
synthetic markers make the grader return `REFUSED_SYNTHETIC` before any dimension is scored, and its
release gate correctly refuses research release. Removing those markers would manufacture evidence,
not create an acceptance fixture. Its v2.8.4 offline rerun completed the machinery and correctly
blocked release, but the only acceptance evidence this rubric recognizes is a fresh strict-profile run with the real
preconditions named by `run_acceptance.sh` and a genuinely independent second run.

## Threshold provenance

Every number above is either taken from the runtime or derived from a stated property. None was
picked for feel.

| threshold | value | source |
|---|---|---|
| minimum seeds, inferential claim | 3 | `planning.MIN_SEEDS_FOR_COMPARATIVE`, `analysis.MIN_SEEDS_FOR_INFERENCE` |
| minimum seeds, descriptive claim | 2 | `analysis._summary` refuses an interval below n=2 |
| run completion floor | 0.66 | `1 − max_failure_rate`, `max_failure_rate = 0.34` in `integrity-auditor` |
| claim support ratio floor | 1 − α (0.95 by default) | `stats_audit.alpha`, defaulting to `analysis.DEFAULT_ALPHA` |
| numeric agreement tolerance | 1e-9 + 1e-6·scale | `analysis.TOL_ABS`, `analysis.TOL_REL` |
| coverage thresholds (ablation, figure, paragraph) | 1.0 | stated per check: a fractional coverage threshold licenses claiming precisely the uncovered items |
| fabrication, undeclared metrics, invented metrics, forbidden patterns | 0 | stated per check: one instance is the whole failure |

`grade.py` re-reads the first and fourth of these from `researchforge` when the package is
importable and **refuses to grade** on any disagreement, rather than scoring against a stale copy.
