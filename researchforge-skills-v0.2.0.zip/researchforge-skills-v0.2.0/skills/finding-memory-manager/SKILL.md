---
name: finding-memory-manager
description: Use when evidence across the run must be distilled into durable findings that later stages and later projects can read. Trigger at every evidence lock point.
version: 0.2.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# finding-memory-manager

## Objective

Persist successful findings, failed hypotheses, reproduction lessons, reviewer concerns and reusable patterns across sessions without polluting current evidence.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `experiment_ledger`
- `decision_log`
- `meta_analysis`
- `meta_analysis_decision`
- `negative_findings`
- `boundary_conditions`
- `experiment_tree`
- `assumption_tests`
- `gap_evidence`
- `closest_prior_work`
- `baseline_metrics`
- `baseline_deviation_log`
- `reproduction_report`
- `source_repro_metrics`
- `repro_failure_taxonomy`
- `fallback_decision_log`
- `citation_gap_candidates`
- `library_hits`
- `library_note_links`
- `landscape_report`
- `system_matrix`
- `benchmark_matrix`
- `source_repro_plan`
- `quota_ledger`
- `literature_retrieval_log`
- `citation_resolution_report`
- `baseline_repo_rankings`
- `baseline_license_risk`
- `visual_notes`
- `layout_warnings`
- `section_map`
- `figure_table_index`
- `paper_assets`
- `source_manifest`
- `claim_registry`
- `contribution_atoms`
- `paper_source_file`
- `locator_map`
- `literature_search_plan`
- `analysis_report`
- `analysis_code`
- `tool_typed_contracts`
- `selected_capabilities`
- `provider_fallback_chain`
- `domain_install_plan`
- `branch_map`
- `checkpoint_metadata`
- `quest_repo`
- `feedback: revision_matrix`
- `feedback: response_to_reviewers`
- `feedback: revision_experiment_plan`
- `feedback: review_triage`
- `feedback: manuscript_pdf`
- `feedback: figure_generation_trace`
- `feedback: speaker_notes`
- `feedback: deck_manifest`

## Outputs

- `finding_memory_graph`
- `findings`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `assumption-weakness-miner`
- `baseline-repo-finder`
- `baseline-reproduction-auditor`
- `citation-neighborhood-miner`
- `citation-resolver`
- `contribution-decomposer`
- `data-analysis-agent`
- `domain-skill-loader`
- `experiment-ledger`
- `experiment-tree-search`
- `literature-provider-manager`
- `literature-search`
- `model-provider-router`
- `negative-result-curator`
- `novelty-gap-miner`
- `novelty-verifier`
- `paper-claim-evidence-graph`
- `paper-html-visual-reader`
- `paper-ingest`
- `paper-library-connector`
- `paper-structure-parser`
- `project-repo-manager`
- `reproduction-fallback-planner`
- `research-landscape-builder`
- `result-meta-analyzer`
- `source-result-reproducer`
- `tool-composition-planner`
- `tool-skill-router`
- `user-feedback-gate`

## Procedure

1. Distill each finding into context, evidence, confidence, scope and source IDs.
2. Link findings to parent idea/experiment and related failures.
3. Tag reusable engineering lessons separately from scientific conclusions.
4. Retrieve only relevant memory for current task and show provenance.
5. Expire or supersede stale findings when new evidence conflicts.

## Hard gates

- Memory is advisory; it cannot substitute for current experiment evidence.
- Conflicting memories remain versioned.

## Verification / tests

- Superseded finding is not returned as current truth.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `EvoScientist/EvoScientist`
- `RUC-NLPIR/Arbor`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
