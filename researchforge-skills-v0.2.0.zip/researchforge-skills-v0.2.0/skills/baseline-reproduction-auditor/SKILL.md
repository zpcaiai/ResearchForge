---
name: baseline-reproduction-auditor
description: Use when a selected direction needs its comparison baseline established locally. Trigger after the blueprint is compiled and before any experiment is allowed to claim an improvement.
version: 0.2.0
stage: 03-baseline
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# baseline-reproduction-auditor

## Objective

Establish a trustworthy baseline before claiming an innovation improvement; records deviations and reproduction quality.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `baseline_assets`
- `paper_model`
- `comparison_mode`
- `source_repro_env`
- `external: resource envelope (compute, time, budget)`

## Outputs

- `baseline_deviation_log`
- `baseline_metrics`
- `reproduction_report`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `baseline-repo-finder`
- `paper-structure-parser`
- `reproduction-fallback-planner`
- `source-result-reproducer`

## Procedure

1. Provision the documented environment in a sandbox and run the smallest valid smoke test.
2. Reproduce the target benchmark under pinned data/config/seeds where feasible.
3. Compare observed metrics to reported values with tolerance bands.
4. Classify differences as reproduced, near-reproduced, non-reproduced or incomparable and explain deviations.
5. Freeze baseline command/config/environment for later differential tests.

## Hard gates

- Novel method comparison is blocked if baseline is non-reproduced unless the blueprint explicitly accepts a new baseline and explains why.
- Do not tune the baseline and candidate asymmetrically.

## Verification / tests

- Metric mismatch fixture blocks downstream comparative claim.
- Re-run from frozen config produces same result within declared tolerance.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `ai4s-research/open-science`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
