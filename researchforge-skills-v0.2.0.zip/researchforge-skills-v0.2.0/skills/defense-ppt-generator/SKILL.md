---
name: defense-ppt-generator
description: Use when the deck must be produced as native editable PowerPoint objects rather than flattened images. Trigger after slide evidence is mapped.
version: 0.2.0
stage: 10-slides
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# defense-ppt-generator

## Objective

Generate a natively editable PPTX from the defense storyline, preserving real text/shapes/charts/tables, source notes and template constraints.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `deck_spec`
- `selected_figure`
- `slide_evidence`
- `editable_svg`
- `svg_element_map`
- `svg_validation_report`
- `external: PPTX template`

## Outputs

- `deck_manifest`
- `defense_deck`
- `speaker_notes`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `defense-ppt-storyline`
- `editable-svg-refiner`
- `paper-to-ppt-evidence-mapper`
- `scientific-figure-generator`

## Procedure

1. Resolve theme/template and typography scale before slide generation.
2. Create each slide from structured spec using native PowerPoint objects where possible.
3. Use data-backed charts/tables and editable vector diagrams rather than flattened screenshots when feasible.
4. Add speaker notes and source/provenance notes.
5. Render/inspect every slide for overflow, alignment, legibility and narrative continuity.

## Hard gates

- Do not produce a deck of full-slide images.
- Slide source references must resolve to project artifacts or citations.

## Verification / tests

- PPTX inspector confirms editable text objects on content slides.
- Rendered slide images pass overflow/legibility checks.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `hugohe3/ppt-master`
- `K-Dense-AI/scientific-agent-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
