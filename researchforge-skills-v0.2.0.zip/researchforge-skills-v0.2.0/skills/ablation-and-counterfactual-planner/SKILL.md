---
name: ablation-and-counterfactual-planner
description: Use when a claimed mechanism needs isolating from incidental complexity. Trigger whenever a headline claim attributes a gain to a specific component.
version: 0.2.0
stage: 05-planning
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# ablation-and-counterfactual-planner

## Objective

Design ablations, counterfactuals and sensitivity analyses that test whether the proposed mechanism—not incidental complexity—causes observed gains.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `baseline_assets`
- `external: candidate method description`
- `external: hypothesis under test`

## Outputs

- `ablation_plan`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `baseline-repo-finder`

## Procedure

1. Map each claimed mechanism to a removable/replaced component.
2. Design equal-budget comparisons where possible.
3. Add sensitivity checks for key hyperparameters/assumptions.
4. Prioritize ablations by claim importance.

## Hard gates

- A component cannot receive causal credit without an isolation test when feasible.

## Verification / tests

- Headline mechanism has at least one discriminating ablation.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `HKUSTDial/Supervisor-Skills`
- `SakanaAI/AI-Scientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
