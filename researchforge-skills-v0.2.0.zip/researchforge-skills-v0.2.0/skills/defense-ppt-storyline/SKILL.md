---
name: defense-ppt-storyline
description: Use when a defense or talk narrative must be planned before slides are built. Trigger with the target audience and talk duration known.
version: 0.2.0
stage: 10-slides
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# defense-ppt-storyline

## Objective

Turn the accepted research narrative into an oral-defense storyline optimized for committee questions, evidence flow and time budget.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `manuscript_spine`
- `meta_analysis`
- `comparison_mode`
- `external: defense audience profile`
- `external: target talk duration`

## Outputs

- `deck_spec`
- `slide_outline`
- `speaker_timing`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `manuscript-spine-builder`
- `reproduction-fallback-planner`
- `result-meta-analyzer`

## Procedure

1. Define defense thesis, audience assumptions and 3–5 takeaways.
2. Allocate time to motivation, gap, method, evidence, limitations, contributions and backup slides.
3. Map each slide to one message and source artifact.
4. Plan likely committee questions and backup evidence slides.
5. Keep slide rhythm and density explicit.

## Hard gates

- No slide without a single primary message.
- All numerical slides reference verified experiment artifacts.

## Verification / tests

- Total planned timing stays within talk duration tolerance.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `hugohe3/ppt-master`
- `Yuan1z0825/nature-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
