---
name: paper-structure-parser
description: Use immediately after ingestion to turn normalized text into a structured PaperModel with anchored sections, claims, methods, datasets and metrics. Trigger before contribution analysis or claim extraction.
version: 0.2.0
stage: 01-intake
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-structure-parser

## Objective

Turn normalized paper content into a machine-readable research object: problem, assumptions, method, data, experiments, metrics, limitations, figures and references.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `normalized_text`
- `locator_map`

## Outputs

- `figure_table_index`
- `paper_model`
- `section_map`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `paper-ingest`

## Procedure

1. Identify rhetorical sections even when headings are non-standard.
2. Extract problem statement, method components, datasets, baselines, metrics, ablations, limitations and future-work claims.
3. Represent method as a component/data-flow graph with explicit dependencies.
4. Link every extracted item back to source locators.
5. Mark inferred fields separately from explicit author statements.

## Hard gates

- Every nontrivial extracted claim must have a source locator.
- Inferences cannot be labeled as author claims.

## Verification / tests

- Parser fixture with renamed sections still maps method/results correctly.
- Schema validation passes with zero orphan locator references.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Yuan1z0825/nature-skills`
- `Imbad0202/academic-research-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
