---
name: figure-storyboard
description: Use when the argument determines which figures must exist and what each must say. Trigger before any figure is drawn; figures follow claims, not the other way round.
version: 0.2.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# figure-storyboard

## Objective

Plan the paper's figures as evidence-bearing narrative objects before generating any artwork.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `manuscript_spine`
- `evidence_graph`
- `figure_plan`
- `analysis_plots`
- `analysis_results`
- `external: target venue`

## Outputs

- `figure_captions`
- `figure_storyboard`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `data-analysis-agent`
- `manuscript-spine-builder`
- `paper-claim-evidence-graph`

## Procedure

1. Assign each figure one communication job: motivation, method overview, main result, ablation, failure case, qualitative example.
2. Define source data/claims and what must remain editable.
3. Choose plot vs schematic vs table and target dimensions.
4. Specify caption claim and accessibility/legibility constraints.
5. Prioritize figures by reviewer decision value.

## Hard gates

- No decorative figure without a defined paper role.
- Data plots must identify exact result artifacts.

## Verification / tests

- Each main manuscript claim has at most appropriate and traceable visual support.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `dwzhu-pku/PaperBanana`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
