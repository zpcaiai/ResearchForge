---
name: model-provider-router
description: Use when a task must be routed to a model or provider under cost, capability and data-policy constraints. Trigger per task role, and on provider failure.
version: 0.2.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# model-provider-router

## Objective

Route roles to model/provider backends by capability, cost, context, privacy and reliability while keeping provider-specific code behind adapters.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `tool_plan`
- `external: budget and cost policy`
- `external: model provider credentials and policy`
- `external: task role descriptor`

## Outputs

- `model_route`
- `provider_fallback_chain`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `tool-skill-router`

## Procedure

1. Classify role as judgment-heavy, coding, extraction, vision, long-context or cheap batch.
2. Filter by privacy/data residency/tool-call/vision/context requirements.
3. Choose primary and fallback providers and set cost ceilings.
4. Use stronger independent models at critical review/novelty gates when configured.
5. Record model/version for reproducibility.

## Hard gates

- Provider substitution must not silently change data-access policy.
- Critical validation should not use the same model output as both generator and sole judge when cross-check is available.

## Verification / tests

- Vision-required task never routes to text-only model fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Jyx0208/claude-science-api-bridge`
- `EvoScientist/EvoScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
