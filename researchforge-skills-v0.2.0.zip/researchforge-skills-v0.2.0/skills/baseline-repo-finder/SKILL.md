---
name: baseline-repo-finder
description: Use when the paper's code, data or checkpoints must be located before anything can be run. Trigger immediately after the paper is modeled and before any reproduction attempt.
version: 0.2.0
stage: 03-baseline
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# baseline-repo-finder

## Objective

Locate official or credible code repositories, datasets, checkpoints and evaluation scripts needed to reproduce the paper or strongest competitor.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `paper_model`
- `external: preferred research direction hint`

## Outputs

- `baseline_assets`
- `baseline_license_risk`
- `baseline_repo_rankings`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `paper-structure-parser`

## Procedure

1. Search paper links, author organizations, GitHub and benchmark pages for official artifacts.
2. Rank repos by author linkage, release tag, paper mention, reproducibility evidence and maintenance state.
3. Identify required datasets/checkpoints and expected licenses/access constraints.
4. Select a baseline asset set and pin commit/tag/checksums.

## Hard gates

- Never assume a similarly named repo is official.
- Pin immutable revisions before experiments.

## Verification / tests

- Fixture with official and unofficial forks ranks the author-linked repo first.
- Selected baseline has immutable commit SHA.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `allenai/codescientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
