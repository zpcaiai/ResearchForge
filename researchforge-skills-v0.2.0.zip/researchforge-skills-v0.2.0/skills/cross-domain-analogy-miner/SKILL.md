---
name: cross-domain-analogy-miner
description: Use when in-domain gaps look exhausted or incremental and a mechanism from another field might transfer. Trigger as the third mining pass, after weakness and gap mining.
version: 0.2.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# cross-domain-analogy-miner

## Objective

Generate grounded cross-domain transfers by mapping mechanisms, not keywords, between the source problem and adjacent fields.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `method_dependency_graph`
- `gap_ledger`
- `external: tool and domain catalog source`

## Outputs

- `analogy_candidates`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `contribution-decomposer`
- `novelty-gap-miner`

## Procedure

1. Represent the source method as abstract operations: estimation, control, retrieval, optimization, compression, causal adjustment, memory, search, etc.
2. Search for structurally similar mechanisms in adjacent domains.
3. For each transfer, state invariant, required adaptation, likely failure and testable hypothesis.
4. Reject analogies based only on surface vocabulary.

## Hard gates

- Every analogy must identify a mechanism-level correspondence and a falsifiable benefit.

## Verification / tests

- Keyword-only analogy fixture is rejected.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `K-Dense-AI/scientific-agent-skills`
- `mims-harvard/ToolUniverse`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
