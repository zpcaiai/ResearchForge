---
name: citation-resolver
description: Use when reference strings, DOIs or arXiv ids must become canonical, deduplicated records with a renderable bibliography. Trigger before any citation is allowed to support a claim.
version: 0.2.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# citation-resolver

## Objective

Resolve bibliography entries to canonical scholarly records and maintain stable BibTeX/CSL identities.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `provider_registry`
- `external: personal library metadata`
- `external: raw reference strings or identifiers`

## Outputs

- `bibliography`
- `citation_resolution_report`
- `resolved_references`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `literature-provider-manager`

## Procedure

1. Normalize titles/authors/years and attempt DOI/arXiv/OpenAlex/Semantic Scholar/Crossref resolution through configured providers.
2. Deduplicate preprint/published versions while preserving version lineage.
3. Store canonical IDs, landing URLs and citation metadata.
4. Flag unresolved, suspicious or title-mismatched records for manual review.

## Hard gates

- Never invent DOI, venue, pages or authors.
- Unresolved citations cannot be promoted to VERIFIED.

## Verification / tests

- Duplicate arXiv+journal fixture collapses to one work with two versions.
- Fabricated DOI fixture is flagged unresolved.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `openags/paper-search-mcp`
- `yilewang/llm-for-zotero`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
