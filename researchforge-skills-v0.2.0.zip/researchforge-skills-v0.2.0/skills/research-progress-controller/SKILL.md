---
name: research-progress-controller
description: Use when a run needs budget, pace or stall supervision, or must resume after interruption. Trigger on every stage transition and whenever cost or wall-clock crosses a threshold.
version: 0.2.0
stage: 00-orchestration
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# research-progress-controller

## Objective

Monitor long-running research DAGs, budgets, stalls, checkpoints and user takeover/resume semantics.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: budget and cost policy`
- `external: live runtime state feed`

## Outputs

- `progress_alerts`
- `progress_state`
- `resume_token`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Track stage/node status, cost, wall-clock, GPU usage and pending human gates.
2. Detect stalled loops and repeated failures.
3. Checkpoint durable state before cancellation/takeover.
4. Resume from last valid artifact rather than restarting everything.

## Hard gates

- Budget overrun blocks new expensive jobs.

## Verification / tests

- Kill-and-resume fixture continues from checkpoint.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `EvoScientist/EvoScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
