---
name: paper-to-ppt-evidence-mapper
description: Use when every quantitative element planned for a slide must be bound to a project artifact. Trigger between storyline and deck generation.
version: 0.2.0
stage: 10-slides
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-to-ppt-evidence-mapper

## Objective

Map paper sections, figures, tables and claims into slide-ready evidence packets before deck rendering.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `manuscript_draft`
- `deck_spec`
- `slide_outline`
- `speaker_timing`
- `draft_manifest`
- `experiment_ledger`

## Outputs

- `slide_evidence`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `defense-ppt-storyline`
- `experiment-ledger`
- `paper-drafter`

## Procedure

1. For each planned slide, choose the minimum evidence needed.
2. Link source figure/table/claim IDs and decide reuse vs redraw.
3. Prepare concise speaker-note provenance.
4. Flag unsupported or too-dense slides before generation.

## Hard gates

- Every evidence slide has source IDs.

## Verification / tests

- Orphan slide fixture is rejected.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `hugohe3/ppt-master`
- `Yuan1z0825/nature-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
