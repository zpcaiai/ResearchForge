---
name: paper-library-connector
description: Use when the user has a personal reference library (Zotero or similar) that should ground retrieval and citation. Trigger when library credentials are configured and the topic overlaps their existing collection.
version: 0.2.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-library-connector

## Objective

Connect personal/reference libraries (for example Zotero-like stores) as a grounded literature source without mixing private notes into public citations.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: library query`
- `external: paper context for library lookup`
- `external: personal library connector configuration`

## Outputs

- `library_hits`
- `library_note_links`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Search library by title/author/topic and reuse existing PDFs/notes when authorized.
2. Separate bibliographic metadata from private annotations.
3. Resolve cited works through citation-resolver before manuscript use.

## Hard gates

- Private annotations are not quoted or exported unless explicitly requested.

## Verification / tests

- Library hit missing canonical citation is routed to resolver.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `yilewang/llm-for-zotero`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
