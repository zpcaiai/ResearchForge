---
name: negative-result-curator
description: Use when experiments fail or return null results that are worth keeping. Trigger before any failed branch is discarded — boundary conditions are findings.
version: 0.2.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# negative-result-curator

## Objective

Preserve and interpret null/negative results so the system learns, narrows claims and avoids rerunning dead ends.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `experiment_ledger`

## Outputs

- `boundary_conditions`
- `negative_findings`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `experiment-ledger`

## Procedure

1. Distinguish implementation failure from scientific null.
2. Summarize conditions under which the idea failed.
3. Update kill criteria, finding memory and manuscript limitations when relevant.
4. Suggest informative pivots rather than hiding the result.

## Hard gates

- Negative evidence cannot be deleted merely because it hurts the narrative.

## Verification / tests

- Repeated dead-end branch is suppressed by memory.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `allenai/codescientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
