---
name: artifact-provenance
description: Use whenever an artifact is created or modified. Trigger continuously; an artifact without lineage cannot support a claim at the release gate.
version: 0.2.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# artifact-provenance

## Objective

Track exactly which code, inputs, environment, model calls and human decisions produced every research artifact.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: artifact creation and edit events`

## Outputs

- `artifact_manifest`
- `provenance_log`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Assign stable artifact IDs and checksums.
2. Record producer skill/tool/model, source artifact IDs, git SHA, run ID and timestamps.
3. Version edits instead of losing history.
4. Expose lineage queries from paper claim → figure/table → analysis → raw experiment.

## Hard gates

- Release-visible artifacts require provenance entries.
- Manual edits are recorded as human-authored events, not hidden.

## Verification / tests

- Lineage query resolves a paper number back to raw result fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ai4s-research/open-science`
- `ResearAI/DeepScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
