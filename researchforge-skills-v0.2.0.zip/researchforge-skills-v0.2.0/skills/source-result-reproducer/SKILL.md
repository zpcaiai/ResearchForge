---
name: source-result-reproducer
description: Use when a source paper has been modeled and BEFORE any idea generation. Reproduces the source paper's own headline results and grades the outcome RL0-RL4. Trigger on state EVIDENCE_EXPANDED; nothing downstream may assume a working code base until this runs.
version: 0.2.0
stage: 03-reproduction
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# source-result-reproducer

## Objective

Reproduce the **source paper's own** results before the system is allowed to propose innovations on top of it.

This is deliberately placed before ideation. An innovation direction whose feasibility, delta and minimum experiment were estimated against a code base that does not actually run is not an estimate — it is fiction. Reproduction is also the cheapest available kill signal: it is far better to spend two hours discovering that the artifact is unusable than to spend two GPU-days discovering it after committing to a direction.

Note the distinction from `baseline-reproduction-auditor`: that skill reproduces the **comparison baseline** for a selected direction, later in the pipeline. This skill reproduces **the paper you are reading**, earlier, and its output constrains what may be proposed at all.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `paper_model`
- `contribution_atoms`
- `baseline_assets`
- `baseline_license_risk`
- `sandbox_manifest`
- `external: reproduction tolerance policy`
- `external: resource envelope (wall-clock cap, compute class, cost cap)`

## Outputs

- `repro_failure_taxonomy`
- `source_repro_env`
- `source_repro_metrics`
- `source_repro_plan`
- `source_repro_report`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `baseline-repo-finder`
- `contribution-decomposer`
- `paper-structure-parser`
- `sandbox-provisioner`

## Procedure

1. Extract from `paper_model` the paper's **headline claims** and the specific table/figure cells that carry them. Reproduce claims, not repositories: a repo whose demo script runs but whose Table 2 cannot be regenerated is RL1, not success.
2. Build the `source_repro_plan`: for each headline cell, record the required dataset, checkpoint, config, hardware class and estimated wall-clock. Rank by (claim importance) / (estimated cost). Declare an explicit time box; the default is 4 hours of agent wall-clock per paper before escalation.
3. Provision a pinned environment via the sandbox and capture `source_repro_env` **before** any dependency is resolved loosely. Record resolved versions, CUDA/driver, and image digest.
4. Execute in escalating tiers, stopping as soon as the time box is exhausted:
   - **RL1 CODE_RUNS** — environment builds and the entry point completes on a reduced sample without error.
   - **RL2 SMOKE_MATCH** — a reduced-scale run produces metrics whose direction and order of magnitude match the paper.
   - **RL3 HEADLINE_MATCH** — at least one headline cell reproduces within tolerance (default: relative deviation ≤5%, or inside the paper's own reported variance where given).
   - **RL4 TABLE_MATCH** — a majority of the cells in the primary results table reproduce within tolerance.
5. Grade honestly and record the achieved level in `source_repro_report`. **RL is assigned by measured comparison against the paper's reported numbers, never by the agent's confidence that the code "looks correct".** Absence of an error is RL1, not RL3.
6. Classify every shortfall into `repro_failure_taxonomy` using a fixed vocabulary: `NO_CODE`, `DEPENDENCY_UNRESOLVABLE`, `HARDWARE_UNAVAILABLE`, `DATA_UNAVAILABLE`, `DATA_ACCESS_GATED`, `CHECKPOINT_MISSING`, `UNDOCUMENTED_PREPROCESSING`, `CONFIG_AMBIGUOUS`, `NONDETERMINISM`, `METRIC_DEFINITION_MISMATCH`, `NUMBERS_DIVERGE`, `TIMEBOX_EXCEEDED`, `LICENSE_BLOCKED`. This vocabulary is the input to fleet-level diagnosis; free-text reasons are not acceptable.
7. Emit `source_repro_metrics` as paired records: `(claim_id, reported_value, measured_value, tolerance, verdict, run_id)`. Unpaired measurements are not evidence.
8. Hand the achieved RL to `reproduction-fallback-planner`. **This skill does not decide whether the project continues** — it only establishes ground truth.

## Hard gates

- No RL above RL1 may be asserted without a numeric comparison to a value extracted from the source paper with a locator.
- Reduced-scale runs may support RL2 but never RL3 or RL4.
- The time box is enforced by the runtime, not by agent judgment; exceeding it yields `TIMEBOX_EXCEEDED` at the highest level actually reached.
- A reproduction attempt that silently changes the metric definition to obtain agreement is a failure, not an RL3.
- Environment capture precedes execution; a run whose environment was not captured cannot support any RL.

## Verification / tests

- Fixture with a deliberately broken dependency yields RL0 with `DEPENDENCY_UNRESOLVABLE`, not a crash.
- Fixture whose code runs but whose metric is 40% off the paper yields RL1 with `NUMBERS_DIVERGE`, never RL3.
- Fixture reproducing Table 1 within 2% yields RL3 with paired metric records.
- Time-box fixture halts and reports the highest level reached rather than running unbounded.
- Re-running the same fixture with the captured `source_repro_env` reproduces the same RL.

## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured failure record and hand control to the fallback planner rather than downgrading the honesty of the report.

## Upstream inspiration (conceptual, not vendored text)

See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their text.
