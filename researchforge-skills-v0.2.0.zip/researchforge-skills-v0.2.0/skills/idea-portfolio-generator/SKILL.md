---
name: idea-portfolio-generator
description: Use when mining is complete and multiple candidate directions must be generated under the constraints the reproduction level imposes. Trigger before any single idea is committed to — never generate one idea and run it.
version: 0.2.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# idea-portfolio-generator

## Objective

Produce a diverse portfolio of concrete research directions instead of one brittle idea.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `gap_ledger`
- `weakness_map`
- `analogy_candidates`
- `comparison_mode`
- `idea_mode_constraints`
- `source_repro_report`
- `external: resource envelope (compute, time, budget)`

## Outputs

- `idea_portfolio`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `assumption-weakness-miner`
- `cross-domain-analogy-miner`
- `novelty-gap-miner`
- `reproduction-fallback-planner`
- `source-result-reproducer`

## Procedure

1. Generate candidates across at least four innovation modes: extend/generalize, replace/simplify, combine/transfer, explain/diagnose, benchmark/evaluate, or systemize.
2. For each idea define hypothesis, exact delta vs baseline, minimum experiment, success metric, novelty rationale, compute/data needs and kill criteria.
3. Deduplicate semantically equivalent ideas.
4. Ensure portfolio includes at least one low-cost high-information probe and one higher-upside direction when resources allow.

## Hard gates

- No vague verbs such as 'improve' without a measurable mechanism and experiment.
- Each idea has explicit kill criteria.

## Verification / tests

- Portfolio fixture contains materially diverse mechanism classes.
- Each candidate validates against IdeaCandidate schema.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `allenai/codescientist`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
