---
name: researchforge-orchestrator
description: Use when the user supplies a paper (URL, PDF, HTML, DOI or arXiv id) and wants the full paper-to-innovation-to-manuscript run. Owns the state machine, enforces the reproduction-before-ideation ordering, and stops at the human selection gate in guided mode.
version: 0.2.0
stage: 00-orchestration
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# researchforge-orchestrator

## Objective

End-to-end paper-to-innovation orchestrator. Converts a paper URL/PDF/HTML into ranked innovation directions, pauses for human selection when required, then coordinates code, experiments, manuscript, citations, figures and defense PPT.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `release_bundle`
- `release_manifest`
- `release_report`
- `progress_state`
- `resume_token`
- `progress_alerts`
- `team_plan`
- `agent_handoffs`
- `model_route`
- `domain_skill_lock`
- `research_blueprint`
- `selected_direction`
- `idea_portfolio`
- `ranked_ideas`
- `paper_model`
- `evidence_graph`
- `comparison_mode`
- `external: paper locator (URL/PDF/HTML/DOI/arXiv/local path)`
- `external: resource envelope (compute, time, budget)`
- `external: run mode (guided|auto|analysis-only)`
- `external: user feedback on ranked ideas`

## Outputs

- `research_state`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `domain-skill-loader`
- `idea-portfolio-generator`
- `idea-ranker`
- `model-provider-router`
- `multi-agent-research-team`
- `paper-claim-evidence-graph`
- `paper-structure-parser`
- `release-gate-exporter`
- `reproduction-fallback-planner`
- `research-blueprint-compiler`
- `research-progress-controller`
- `user-feedback-gate`

## Procedure

1. Normalize the request and create a durable project/quest repository via project-repo-manager.
2. Run paper-ingest → paper-structure-parser → contribution-decomposer → claim-evidence-graph.
3. Expand evidence with literature-search, citation-neighborhood-miner and baseline-repo-finder.
4. Generate a candidate innovation portfolio using assumption-weakness-miner, novelty-gap-miner, cross-domain-analogy-miner and idea-portfolio-generator.
5. Run novelty-verifier, feasibility-estimator and idea-ranker. In guided mode, stop at user-feedback-gate and accept combine/reject/constraint edits without losing prior candidates.
6. Compile the selected direction into a research blueprint; reproduce or establish a baseline before novel experiments are allowed to claim gains.
7. Run experiment-spec-author, sandbox-provisioner, codebase-scaffolder and experiment-tree-search. Persist every attempt in experiment-ledger and finding-memory-manager.
8. Lock validated evidence, then run manuscript-spine-builder → paper-drafter → claim-citation-auditor → journal-fit-reviewer; iterate only on evidence-backed revisions.
9. Generate figures and defense deck; run release-gate-exporter. Never mark the project complete if critical gates remain open.

## Hard gates

- No selected idea may enter experiment execution without novelty + feasibility evidence.
- No experimental claim may enter the manuscript without an experiment_result_id and provenance record.
- No citation may support a claim unless claim-citation-auditor records a resolvable source and support judgment.
- In guided mode, an explicit user selection/merge/approval is required after ranking.

## Verification / tests

- E2E dry run from one paper fixture reaches HUMAN_SELECTION_REQUIRED in guided mode.
- Resume test: killing after any stage preserves state and restarts idempotently.
- Negative test: fabricated experiment metrics are rejected by release gate.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `OpenNSWM-Lab/FAROS`
- `ResearAI/DeepScientist`
- `EvoScientist/EvoScientist`
- `SakanaAI/AI-Scientist-v2`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
