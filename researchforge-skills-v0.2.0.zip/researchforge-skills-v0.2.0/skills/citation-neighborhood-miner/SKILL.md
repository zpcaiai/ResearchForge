---
name: citation-neighborhood-miner
description: Use when the field around a seed paper must be mapped — who cites it, what it cites, and which regions are thin. Trigger after references resolve and before gap mining.
version: 0.2.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# citation-neighborhood-miner

## Objective

Explore backward/forward citation neighborhoods and co-citation clusters to find hidden competitors and adjacent innovation opportunities.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `resolved_references`
- `provider_registry`
- `external: seed paper canonical identifier`

## Outputs

- `citation_clusters`
- `citation_gap_candidates`
- `citation_graph`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `citation-resolver`
- `literature-provider-manager`

## Procedure

1. Collect backward references, forward citations and highly co-cited/co-referenced works.
2. Cluster by problem, method, data and evaluation pattern.
3. Find missing comparisons, convergent ideas, abandoned approaches and recently revived methods.
4. Record why each cluster matters for novelty rather than only listing papers.

## Hard gates

- Do not infer novelty from citation count alone.
- If forward-citation coverage is unavailable, mark coverage limits.

## Verification / tests

- Known competitor fixture appears in method-neighbor cluster.
- Coverage metadata distinguishes unavailable vs zero citations.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `yilewang/llm-for-zotero`
- `FuLab-ZhaoSun/auto-research-landscape-2026`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
