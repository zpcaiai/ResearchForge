---
name: contribution-decomposer
description: Use when the paper's contributions must be separated into independently attackable atoms. Trigger before weakness mining — you cannot mine assumptions out of a contribution you have not isolated.
version: 0.2.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# contribution-decomposer

## Objective

Decompose the source paper into contribution atoms so innovation can target a precise replace/extend/generalize/validate point.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `paper_model`

## Outputs

- `contribution_atoms`
- `method_dependency_graph`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `paper-structure-parser`

## Procedure

1. Separate problem novelty, method novelty, data novelty, system novelty, theory novelty and evaluation novelty.
2. Map each contribution atom to assumptions, dependencies and supporting evidence.
3. Identify which atoms are essential versus packaging/presentation.
4. Expose attack surfaces: bottleneck, missing generality, expensive component, weak evidence, untested regime.

## Hard gates

- Do not call the whole paper one contribution.
- Every targetable atom must cite source evidence.

## Verification / tests

- Fixture produces multiple atomic contributions from one abstract-level contribution list.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `WUBING2023/PaperSpine`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
