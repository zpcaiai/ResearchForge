---
name: manuscript-spine-builder
description: Use when evidence is locked and the paper's central argument must be built before any prose is written. Trigger before drafting; a draft without a spine is unreviewable.
version: 0.2.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# manuscript-spine-builder

## Objective

Design the paper's contribution-first argument spine before drafting prose: claims, evidence order, figures/tables, related-work contrast and reviewer questions.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `selected_direction`
- `evidence_graph`
- `meta_analysis`
- `findings`
- `negative_findings`
- `boundary_conditions`
- `external: target venue`

## Outputs

- `figure_plan`
- `manuscript_spine`
- `section_blueprint`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `finding-memory-manager`
- `negative-result-curator`
- `paper-claim-evidence-graph`
- `result-meta-analyzer`
- `user-feedback-gate`

## Procedure

1. State the paper's one-sentence contribution and why it matters.
2. Define reviewer-facing claim sequence: problem → gap → method → evidence → limits.
3. Assign each major claim to experiments, tables/figures and citations.
4. Plan introduction beats, method modules, result questions, limitations and discussion.
5. Identify any evidence gap that must be filled before prose generation.

## Hard gates

- No major claim without evidence assignment.
- Writing cannot hide negative results needed to delimit the claim.

## Verification / tests

- Spine validator finds orphan major claim fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `WUBING2023/PaperSpine`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
