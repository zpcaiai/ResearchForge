---
name: experiment-tree-search
description: Use when several experimental branches must be explored under a budget, with failures preserved rather than repeated. Trigger after scaffolding, when uncertainty is high enough that one branch is a gamble.
version: 0.2.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# experiment-tree-search

## Objective

Explore multiple implementation/experiment branches with best-first or portfolio search, using evidence-based expansion and pruning.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `research_blueprint`
- `experiment_specs`
- `code_worktree`
- `code_tests`
- `implementation_plan`
- `sandbox_manifest`
- `environment_lock`
- `sandbox_container_config`
- `evaluator_spec`
- `failure_diagnosis`
- `repair_commits`
- `debug_terminal_status`
- `blueprint_dag`
- `acceptance_criteria`
- `mutant_candidates`
- `idea_lineage_graph`

## Outputs

- `best_candidate`
- `experiment_tree`
- `ranked_branches`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `codebase-scaffolder`
- `debug-and-repair`
- `experiment-spec-author`
- `genetic-idea-mutator`
- `metric-and-hidden-evaluator-builder`
- `research-blueprint-compiler`
- `sandbox-provisioner`

## Procedure

1. Initialize several diverse branches/seeds when uncertainty is high.
2. Execute cheap probes first and score nodes using experiment evidence, not model confidence.
3. Expand promising nodes, debug bounded failures and prune dominated/invalid branches.
4. Preserve failed nodes with reasons to prevent repeat waste.
5. Stop on budget, target achievement, statistical futility or exhausted high-value branches.

## Hard gates

- No unlimited self-debug loops.
- Search score must come from declared evaluator/metrics.

## Verification / tests

- Failed branch is not repeatedly retried after terminal classification.
- Budget exhaustion stops new node creation.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `ResearAI/DeepScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
