---
name: vector-figure-reconstructor
description: Use when an existing raster or PDF figure must become editable vector content. Trigger when a needed figure exists only as an image.
version: 0.2.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# vector-figure-reconstructor

## Objective

Reconstruct existing scientific figures into editable vector structures for revision or style normalization.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: source raster figure`

## Outputs

- `reconstructed_svg`
- `svg_reconstruction_map`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Detect text, shapes, icons and connectors.
2. Recreate layout with editable elements.
3. Compare geometry and labels against source.
4. Expose uncertain elements for manual correction.

## Hard gates

- Do not claim pixel-perfect semantic reconstruction when labels are uncertain.

## Verification / tests

- Text remains editable in output fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/AutoFigure-Edit`
- `Rss3208/Visiomaster`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
