---
name: journal-fit-reviewer
description: Use when a draft needs adversarial pre-submission review against a target venue's standards. Trigger after the citation audit passes.
version: 0.2.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# journal-fit-reviewer

## Objective

Simulate multi-perspective peer review focused on venue fit, novelty, correctness, experiments, clarity and reproducibility, with actionable priority.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `manuscript_draft`
- `evidence_graph`
- `citation_audit`
- `external: target venue`
- `feedback: integrity_gate`

## Outputs

- `review_report`
- `revision_backlog`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `claim-citation-auditor`
- `paper-claim-evidence-graph`
- `paper-drafter`

## Procedure

1. Create journal/venue-fit, methods, experiments, novelty and devil's-advocate review perspectives.
2. Score with explicit rubric and confidence; separate fatal issues from presentation issues.
3. Map each concern to a manuscript location and required evidence or edit.
4. Preserve disagreement among reviewers instead of forcing consensus.
5. Recommend accept-like, major revision, or resubmit only with reasons.

## Hard gates

- Reviewer must not request impossible evidence without flagging resource mismatch.
- No review concern can directly rewrite experimental facts.

## Verification / tests

- Known methodological flaw fixture appears as high-priority concern.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `HKUSTDial/Supervisor-Skills`
- `JimLiu/science-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
