---
name: research-blueprint-compiler
description: Use when a direction has been selected and must become an executable plan with stages, budgets, acceptance criteria and human gates. Trigger immediately after selection.
version: 0.2.0
stage: 05-planning
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# research-blueprint-compiler

## Objective

Compile a selected direction into a versioned research blueprint with workflow DAG, artifacts, gates, budgets and stop conditions.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `selected_direction`
- `comparison_mode`
- `source_repro_report`
- `external: resource envelope (compute, time, budget)`

## Outputs

- `acceptance_criteria`
- `blueprint_dag`
- `research_blueprint`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `reproduction-fallback-planner`
- `source-result-reproducer`
- `user-feedback-gate`

## Procedure

1. Define research question, hypothesis, baseline, candidate method, datasets, metrics, statistical plan and expected artifacts.
2. Expand into DAG stages with dependencies and parallelizable experiments.
3. Assign providers/tools/skills to capabilities using tool-skill-router.
4. Define human gates, budget limits, safety constraints and kill/continue rules.
5. Version the blueprint and hash critical configs.

## Hard gates

- Every success claim has a measurable acceptance criterion.
- Every expensive branch has a predeclared budget/stop rule.

## Verification / tests

- Blueprint schema validation.
- Cycle detection rejects invalid DAG.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `OpenNSWM-Lab/FAROS`
- `THU-Team-Eureka/EurekAgent`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
