---
name: experiment-ledger
description: Use whenever any run produces a metric. Trigger on every run start and completion; a number that never entered the ledger cannot enter the manuscript.
version: 0.2.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# experiment-ledger

## Objective

Append-only ledger of every experiment attempt, command, config, environment, code revision, metrics, artifacts and status.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `evaluator_code`
- `hidden_tests`
- `external: runtime execution events`

## Outputs

- `experiment_ledger`
- `run_index`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `metric-and-hidden-evaluator-builder`

## Procedure

1. Assign immutable run_id before execution.
2. Record git SHA, config hash, dataset/version, seed, command, environment and timestamps.
3. Attach stdout/stderr/logs/raw results/artifacts by checksum.
4. Record terminal status and evaluator result.
5. Provide query views by idea, branch, metric, failure class and artifact.

## Hard gates

- Never overwrite historical run records.
- A manuscript-visible metric must resolve to one or more run IDs.

## Verification / tests

- Tampering with artifact triggers checksum mismatch.
- Duplicate retry receives a new run_id but links parent_run_id.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ai4s-research/open-science`
- `ResearAI/DeepScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
