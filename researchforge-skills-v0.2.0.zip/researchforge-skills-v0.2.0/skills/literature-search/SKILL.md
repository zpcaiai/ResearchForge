---
name: literature-search
description: Use when related work must be retrieved for a topic, claim or candidate idea. Trigger after provider registration, never before, so that coverage is measured rather than assumed.
version: 0.2.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# literature-search

## Objective

Run query-expansion and multi-source scholarly search for related work, SOTA, competing methods, replications and negative results.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `paper_model`
- `provider_registry`
- `external: literature search objective`
- `external: recency and time constraints`

## Outputs

- `literature_candidates`
- `literature_retrieval_log`
- `literature_search_plan`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `literature-provider-manager`
- `paper-structure-parser`

## Procedure

1. Generate query families from problem, method components, metrics, datasets and hidden assumptions.
2. Search configured scholarly sources and tool ecosystems; record exact query/provider/time.
3. Prioritize primary papers and authoritative artifacts; retain negative or contradictory evidence.
4. Deduplicate and rank by relevance, recency, methodological proximity and citation-neighborhood importance.
5. Hand selected records to citation-resolver and deep reading.

## Hard gates

- Search coverage must include at least method-neighbor, task-neighbor and benchmark-neighbor queries before claiming novelty coverage.

## Verification / tests

- Fixture returns distinct method/task/benchmark query families.
- Search log is replayable and provider failures are visible.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `K-Dense-AI/scientific-agent-skills`
- `mims-harvard/ToolUniverse`
- `openags/paper-search-mcp`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
