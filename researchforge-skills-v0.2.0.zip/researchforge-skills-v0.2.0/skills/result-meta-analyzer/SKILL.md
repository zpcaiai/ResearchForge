---
name: result-meta-analyzer
description: Use when repeated independent trials must be aggregated into a single honest keep-or-kill decision. Trigger when a direction has enough runs to stop guessing.
version: 0.2.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# result-meta-analyzer

## Objective

Aggregate repeated trials, branches, datasets or independent attempts into a balanced meta-analysis and decision recommendation.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `experiment_ledger`
- `stats_audit`
- `stats_required_fixes`
- `external: keep/kill decision criteria`

## Outputs

- `meta_analysis`
- `meta_analysis_decision`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `experiment-ledger`
- `statistical-integrity-auditor`

## Procedure

1. Group comparable runs by design and identify heterogeneity.
2. Aggregate effect estimates with uncertainty; avoid mixing incompatible metrics.
3. Analyze consistency across seeds/datasets/branches and failure rate.
4. Report positive, null and negative evidence.
5. Recommend continue, pivot, narrow claim or stop.

## Hard gates

- Best-run-only summaries are disallowed when repeated trials exist.

## Verification / tests

- One outlier win among failed trials does not produce GO recommendation.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `allenai/codescientist`
- `ruc-datalab/DeepAnalyze`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
