---
name: skill-evolution-manager
description: Use when accumulated run traces suggest a skill should change. Trigger offline only; a candidate edit is promoted only if it improves held-out performance without regressing any guardrail.
version: 0.2.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# skill-evolution-manager

## Objective

Improve skills offline from validated run feedback using bounded edits and held-out evaluation; never self-modify production prompts without a gate.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `eval_runs`
- `eval_failure_taxonomy`
- `eval_scorecard`
- `skill_audit_machine_report`
- `skill_audit_report`
- `external: held-out evaluation suite`
- `external: skill version under evaluation`

## Outputs

- `skill_eval_comparison`
- `skill_patch`
- `skill_promotion_decision`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `research-eval-harness`
- `skill-package-auditor`

## Procedure

1. Mine recurring failure patterns and useful human corrections.
2. Propose bounded add/delete/replace changes to one skill at a time.
3. Replay training examples and evaluate on held-out tasks.
4. Reject changes that regress any hard guardrail or fail minimum improvement threshold.
5. Promote as a new version with changelog and rollback pointer.

## Hard gates

- No online self-edit of active skill.
- Held-out improvement and guardrail pass are required for promotion.

## Verification / tests

- Overfit skill that improves train but harms held-out is rejected.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `microsoft/SkillOpt`
- `EvoScientist/EvoScientist`
- `RUC-NLPIR/Arbor`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
