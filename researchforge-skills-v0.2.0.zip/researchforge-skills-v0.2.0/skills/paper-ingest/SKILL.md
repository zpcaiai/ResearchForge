---
name: paper-ingest
description: Use as the first action on any new paper locator. Fetches the source, normalizes text and extracts assets. Trigger before any parsing, search or reasoning about the paper's content.
version: 0.2.0
stage: 01-intake
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-ingest

## Objective

Acquire and normalize a paper from URL/PDF/HTML/DOI/arXiv into a source-preserving local bundle without losing page/section anchors.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `external: paper locator (URL/PDF/HTML/DOI/arXiv/local path)`
- `external: supplementary URLs or files`

## Outputs

- `locator_map`
- `normalized_text`
- `paper_assets`
- `paper_source_file`
- `source_manifest`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- None; this skill consumes only external inputs.

## Procedure

1. Resolve the canonical paper identity and version; record title/authors/year/venue/DOI/arXiv when available.
2. Fetch or copy the source while preserving original bytes and checksum.
3. Extract text and structural anchors; for PDFs preserve page numbers and figure/table references; for HTML preserve heading/XPath-like anchors.
4. Download linked supplementary material only when explicitly accessible and relevant.
5. Emit a source manifest with provenance, fetch time, license/access notes and parser warnings.

## Hard gates

- Do not silently substitute a different paper version.
- If text extraction is materially incomplete, mark NEEDS_VISUAL_INSPECTION rather than guessing.

## Verification / tests

- Same DOI ingested twice is deduplicated by canonical ID.
- PDF fixture preserves page anchors for at least abstract/method/results.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ai4s-research/open-science`
- `Yuan1z0825/nature-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
