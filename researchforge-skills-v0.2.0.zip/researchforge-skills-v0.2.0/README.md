# ResearchForge Skills v0.2.0

A 66-skill, Codex/Claude-Code-oriented specification package for building a paper-to-innovation autonomous research system.

## What this package gives you

- 66 concrete `SKILL.md` workflow contracts, grouped from paper intake through final release.
- **A closed artifact contract**: `manifests/artifact-graph.json` defines 164 artifacts, each with exactly one producer. Every skill input resolves to an artifact id, a declared `external:` input, or a declared `feedback:` read. `depends_on` is derived from this graph, never hand-written.
- **Reproduction before ideation**: the source paper's own results are reproduced and graded RL0–RL4 *before* any innovation direction is generated, and the achieved level constrains which comparative claims and which innovation modes remain admissible. RL0 redirects the project rather than halting it.
- **Measured retrieval coverage**: novelty claims are absence claims, so coverage is measured and its blind spots named. `UNKNOWN_COVERAGE` blocks `NOVEL_ENOUGH`.
- **A retrospective self-evaluation benchmark** with a mandatory contamination floor.
- Shared JSON schemas for paper models, idea candidates, experiment specs/results, claim evidence, blueprints and artifact manifests.
- A source map covering the 34 repositories indexed by the Research OS page (33 URLs from the request + PaperSpine from the site).
- An architecture and state machine for **paper URL/PDF/HTML → innovation portfolio → user choice → code/experiments → paper/citations → figures → editable defense PPTX**.
- Validation tooling that enforces the artifact contract — single producer, no dangling inputs, acyclic build graph, entry-point reachability, schema binding — and states what it does not check.

## Important boundary

This package contains **skills/specifications**, schemas and a build plan. It does **not** contain the full ResearchForge application runtime, experiment infrastructure, paper parser, literature connectors, or PPT engine. A coding agent should use these skills to implement those modules in a target repository and must prove implementation with builds/tests/evidence.

## Start here

1. Read `ARCHITECTURE.md`.
2. Install/copy the `skills/` directories into the host agent's supported skill path, or keep this repo open and explicitly point the agent to the relevant `SKILL.md`.
3. Use `researchforge-orchestrator` as the top-level workflow.
4. For implementation, follow `IMPLEMENTATION_PLAN.md` — but do **Batch 04-pre** first: run the 20-paper study in `REPRO_STUDY_PROTOCOL.md` and record it in `repro_study_tracker.xlsx`. Its RL distribution decides whether the rest of the plan is viable, and it costs two weeks against a six-month execution plane.
5. Run `python tests/validate_package.py` before distributing the package. See `CHANGELOG.md` for what changed in v0.2.0 and what is knowingly still unfixed.

## Primary output gate

The top-level workflow is intentionally interrupted after idea ranking in guided mode. It must show the user multiple innovation directions and accept selection/merge/constraint feedback before executing expensive research.

## Upstream usage

This project does not vendor upstream SKILL.md text. It records conceptual inspirations and links in `SOURCE_MAP.md`; see `LICENSE_NOTES.md` before directly importing or redistributing upstream assets.
