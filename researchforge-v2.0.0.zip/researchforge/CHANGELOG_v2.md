# v2.0.0 — commercial build (2026-08-11)

## Licence issuing and enforcement

- `tools/license/{keygen,issue,server}.mjs` — Ed25519 keypair generation, licence signing with a
  self-check that refuses to emit an unverifiable licence, and a minimal issuing service with an
  admin token, rate limiting and an append-only issuance ledger that never records the key.
- **The paywall now actually gates.** It previously computed the restricted feature list correctly
  and then printed it while running every gated stage anyway. Enforcement is now on both sides of
  the language boundary, because `researchforge.runner` is invokable directly.
- A licence cannot be made unbypassable in self-hosted software. The design goal is therefore that
  bypass is a deliberate, *recorded* act: `RESEARCHFORGE_ALLOW_UNLICENSED=1` works, and writes itself
  into provenance and the release manifest.
- Fixed a latent bug that would have broken every real licence: the verifier called
  `crypto.verify("sha256", ...)`, and OpenSSL rejects a named digest for Ed25519 rather than
  ignoring it. Every test passed because they all verified against a null key.

## Measured ingestion quality on real PDFs, and three fixes

18 real paper PDFs from 14 GitHub repos. Measured: 73% of extracted claims carried a wrong section
label, 28% were mined from past the References heading, and 1 in 18 PDFs was un-ingestable.

Fixed:
1. **Lone surrogates no longer crash ingestion.** pypdf emits unpaired U+D835 for math-italic
   glyphs; the artifact store died on `.encode()` and a real paper looked like a runtime bug.
   Now transcoded lossily *and the loss is named*, because a silent recovery would hide that the
   formulae on those pages are junk.
2. **`HEAD_RE` now matches `1. Introduction` and roman numerals.** It previously required whitespace
   after the section number, so ICML/PMLR style was invisible: 7 of 18 papers detected exactly two
   sections, and every body claim was filed under "Abstract".
3. **`layout_warnings.md` can no longer claim a clean bill of health.** It used to print
   "none: text extraction produced anchored, ordered content" whenever the warning list happened to
   be empty — an affirmative all-clear for checks that were never run. In a system whose entire pitch
   is refusing to report work it did not do, this was the worst defect in the codebase. It now
   separates what was checked from what was not.

Everything else found is documented in `docs/PDF_INGEST_QUALITY.md` with its measured cost, and
pinned by tests.

## Acceptance harness

`acceptance/` — `RUBRIC.md` (eight dimensions, every threshold traced to a runtime constant or a
stated property), `grade.py` (consumes the existing audits rather than re-deriving them, because two
thresholds means the lower one wins), `run_acceptance.sh` (fails loudly if no API key or GPU rather
than degrading to the offline path).

`NOT_MEASURED` is a distinct outcome from `PASS`, and it blocks acceptance. Grading a project whose
artifacts carry `synthetic: true` is refused outright.

## Commercial proposal

`docs/COMMERCIAL.md` — what is actually being sold, four buyer segments and what each is buying
instead of, tiers mapped onto the feature gates that exist, price points with the reasoning chain,
what will block a sale, and legal exposure. Every guess is marked as one, with how to replace it.

## Corrected: the A′ arm refuted this project's own recommendation

`docs/study/APRIME_FINDINGS.md`. v1.1.0 recommended a "dependency time machine" — a date-pinned wheel
index and a multi-version interpreter pool — as the highest-value engineering investment. Both were
built and tested on the same 20 papers. The date snapshot helped one paper; the interpreter pool
helped none. The apparent gain from switching resolvers evaporated under a real install, because a
dry-run does not execute `setup.py`.

The real blocker is a CUDA build toolchain: `flash-attn` and its class import torch at build time and
then compile. `result-reproducer`'s remediation table has been corrected to say so, and to say
explicitly that the date-pinned index was tested and did not work.

## Step 0, executed

`docs/study/step0_results.json`. 30 seeds per metric on the worked example: **8 of 12 metrics need a
tolerance wider than the 2% floor, one of them 67× wider.** A fixed ±5% tolerance would classify
those metrics' own noise as a failed reproduction. The floor is now documented as a floor and nothing
more.

## Still not done

- **No acceptance run has been performed.** No API key, no GPU here. The harness exists; the run does not.
- **B arm not executed.** The protocol's human-ceiling comparison needs a human; the agent-vs-human gap is unmeasured.
- The innovation engine has never been scored against a benchmark. `retrospective-benchmark-builder`
  correctly refuses without a corpus, and no corpus exists.
- `pubkey.ts` still holds the substitution sentinel: no shipped build can verify a licence until the
  release process substitutes a real public key.
