#!/usr/bin/env python3
"""Score a system's research directions against the frozen retrospective benchmark.

`retrospective-benchmark-builder` builds and freezes the benchmark. Nothing scored
against it. This is that half.

THE TWO PHASES, AND WHY THERE ARE TWO

Matching a generated direction to a gold one is a judgment, and the benchmark's own
scoring contract forbids the shortcuts: not string overlap, not an embedding
threshold, not a title match. Two directions can share every content word and mean
different things ("scale the teacher" vs "scale the student"), and two can share no
words and mean the same thing.

So scoring is split. `--emit-packet` writes every candidate pair with both texts and
no verdicts. Something else — a human, or a model acting as judge and recorded as
one — fills the verdicts in. `--score` then computes recall@k from the filled
packet. An unfilled pair is `UNADJUDICATED`, which is not a miss: a pair nobody
looked at contributes to neither numerator nor denominator, and the run is reported
as incomplete rather than as a low score.

WHAT THE SCORE IS COMPARED AGAINST

Zero is not the reference point. The benchmark's contamination floor is: the
fraction of gold directions the model names when asked to recite them, with no
reasoning involved. A recall@k at or below the floor is reported as
`AT_OR_BELOW_FLOOR` and carries no capability claim, because the same number is
produced by a system that has merely read the literature.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

VERDICTS = ("MATCH", "NO_MATCH", "UNADJUDICATED")
#: A judge that is a model must be recorded as one. The benchmark exists because
#: a model's memory of the literature is indistinguishable from research judgment
#: in the output; a model adjudicating whether the output matches that same
#: literature has the same problem one level up.
JUDGE_KINDS = ("human", "model", "unspecified")


def _sha(obj) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def load_benchmark(path: Path) -> tuple[dict, list[dict]]:
    records = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    freeze = next((r for r in records if r.get("record_type") == "freeze"), None)
    if freeze is None:
        raise SystemExit("the benchmark carries no freeze record; a score against an unfrozen "
                         "benchmark cannot later be shown to have been measured against the "
                         "same questions")
    pairs = [r for r in records if r.get("record_type") == "pair"]
    if not pairs:
        raise SystemExit("the benchmark has no seed/follow-up pairs to score against")
    return freeze, pairs


def load_directions(path: Path) -> dict[str, list[dict]]:
    """{seed_id: [direction, ...]} from a portfolio file.

    Accepts either an explicit map or an `idea_portfolio`-shaped list, so the
    innovation engine's real output can be scored without being reshaped by hand
    — reshaping by hand is where a direction quietly acquires a better wording.
    """
    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict) and not raw.get("ideas"):
        return {str(k): list(v or []) for k, v in raw.items()}
    ideas = raw.get("ideas") if isinstance(raw, dict) else raw
    out: dict[str, list[dict]] = {}
    for i in ideas or []:
        seed = str(i.get("seed_id") or i.get("for_seed") or "")
        if not seed:
            raise SystemExit(
                "an idea in the portfolio names no seed_id. Scoring needs to know which seed a "
                "direction was generated for; assigning it to all of them would let one lucky "
                "direction score against every seed.")
        out.setdefault(seed, []).append(i)
    return out


def direction_text(d) -> str:
    if isinstance(d, str):
        return d
    fields = ("problem_delta", "method_delta", "mechanism", "demonstrating_experiment")
    parts = [f"{f}: {d[f]}" for f in fields if d.get(f)]
    if parts:
        return " | ".join(parts)
    return str(d.get("statement") or d.get("summary") or d.get("title") or json.dumps(d))[:600]


def emit_packet(freeze: dict, pairs: list[dict], directions: dict[str, list], k: int) -> dict:
    """Every candidate pair, with both texts and no verdict.

    Deliberately the full cross product per seed rather than a shortlist. A
    shortlist would be produced by a similarity function, and the shortlisting
    function would then be the real matcher while the adjudicator believed they
    were doing the matching.
    """
    items, missing = [], []
    for p in pairs:
        seed = p["seed_id"]
        gen = directions.get(seed) or []
        if not gen:
            missing.append(seed)
        topk = gen[:k]
        for gi, g in enumerate(topk):
            for gold in p["gold_directions"]:
                items.append({
                    "pair_id": f"{seed}::gen{gi}::{gold['gold_direction_id']}",
                    "seed_id": seed,
                    "generated_rank": gi + 1,
                    "generated": direction_text(g),
                    "gold_direction_id": gold["gold_direction_id"],
                    "gold_split": gold["split"],
                    "gold": direction_text(gold),
                    "verdict": "UNADJUDICATED",
                    "adjudicator": None,
                    "note": None,
                })
    return {
        "packet_version": "1",
        "benchmark_content_hash": freeze["content_hash"],
        "benchmark_version": freeze["benchmark_version"],
        "k": k,
        "contamination_floor": (freeze.get("contamination_floor") or {}).get("floor_recall"),
        "seeds_with_no_generated_directions": sorted(missing),
        "rubric": [
            "MATCH means the generated direction and the gold direction are the same research "
            "direction: same problem delta AND same mechanism. Same benchmark is not enough; "
            "'improve accuracy on ImageNet' matches nothing.",
            "A generated direction that is strictly more general than the gold one is NO_MATCH. "
            "'use a better teacher' does not match 'update the teacher from the student's "
            "performance on labelled data'.",
            "Wording is irrelevant in both directions. Shared vocabulary is not a match; disjoint "
            "vocabulary is not a miss.",
            "If you cannot decide, leave UNADJUDICATED. An undecided pair is excluded from the "
            "score and reported; a guessed one is not recoverable.",
        ],
        "items": items,
    }


def score(packet: dict, judge_kind: str, judge_id: str | None) -> dict:
    k = int(packet.get("k") or 10)
    floor = packet.get("contamination_floor")
    by_seed: dict[str, dict] = {}
    unadjudicated = 0
    for it in packet["items"]:
        s = by_seed.setdefault(it["seed_id"], {"hit": set(), "gold": set(), "held_out_gold": set(),
                                               "held_out_hit": set(), "pairs": 0})
        s["pairs"] += 1
        s["gold"].add(it["gold_direction_id"])
        if it["gold_split"] == "held_out_post_cutoff":
            s["held_out_gold"].add(it["gold_direction_id"])
        v = str(it.get("verdict") or "UNADJUDICATED").upper()
        if v not in VERDICTS:
            raise SystemExit(f"pair {it['pair_id']} carries verdict {v!r}, which is not one of "
                             f"{VERDICTS}. An unknown verdict is not a miss and will not be "
                             f"treated as one.")
        if v == "UNADJUDICATED":
            unadjudicated += 1
        elif v == "MATCH":
            s["hit"].add(it["gold_direction_id"])
            if it["gold_split"] == "held_out_post_cutoff":
                s["held_out_hit"].add(it["gold_direction_id"])

    per_seed = []
    for seed, s in sorted(by_seed.items()):
        denom = len(s["gold"]) or 1
        per_seed.append({
            "seed_id": seed,
            "recall_at_k": round(len(s["hit"]) / denom, 6),
            "matched": len(s["hit"]), "gold": len(s["gold"]),
            "held_out_recall": (round(len(s["held_out_hit"]) / len(s["held_out_gold"]), 6)
                                if s["held_out_gold"] else None),
            "pairs_adjudicated": s["pairs"],
        })
    recall = (sum(p["recall_at_k"] for p in per_seed) / len(per_seed)) if per_seed else None
    held = [p["held_out_recall"] for p in per_seed if p["held_out_recall"] is not None]

    if unadjudicated:
        verdict, why = "INCOMPLETE", (
            f"{unadjudicated} of {len(packet['items'])} candidate pair(s) were never adjudicated. "
            f"They are excluded from the score rather than counted as misses, so this number is "
            f"a partial measurement and not a low one.")
    elif floor is None:
        verdict, why = "UNINTERPRETABLE", (
            "the benchmark carries no measured contamination floor, so there is nothing to read "
            "this recall against. An unmeasured floor is not a low floor.")
    elif recall is not None and recall <= float(floor):
        verdict, why = "AT_OR_BELOW_FLOOR", (
            f"recall@{k}={recall:.3f} does not exceed the contamination floor of {float(floor):.3f}. "
            f"A system that had merely read the literature would produce this number, so it "
            f"carries no claim about research judgment.")
    else:
        verdict, why = "ABOVE_FLOOR", (
            f"recall@{k}={recall:.3f} exceeds the contamination floor of {float(floor):.3f} by "
            f"{recall - float(floor):.3f}. That margin is the only part of this score that is "
            f"evidence of anything, and it is not a significance test.")

    return {
        "scorecard_version": "1",
        "benchmark_content_hash": packet["benchmark_content_hash"],
        "benchmark_version": packet["benchmark_version"],
        "packet_hash": _sha(packet["items"])[:32],
        "k": k,
        "recall_at_k": None if recall is None else round(recall, 6),
        "held_out_recall_at_k": (round(sum(held) / len(held), 6) if held else None),
        "held_out_note": ("no gold direction postdates the declared model cutoff, so there is no "
                          "uncontaminated subset in this benchmark at all"
                          if not held else "held-out subset is reported, never used to tune"),
        "contamination_floor": floor,
        "verdict": verdict,
        "why": why,
        "unadjudicated_pairs": unadjudicated,
        "total_pairs": len(packet["items"]),
        "seeds_with_no_generated_directions": packet.get("seeds_with_no_generated_directions", []),
        "adjudication": {
            "judge_kind": judge_kind,
            "judge_id": judge_id,
            "caveat": ("a model judge has the same contamination problem one level up: it is "
                       "deciding whether an output matches literature it has also read"
                       if judge_kind == "model" else None),
        },
        "per_seed": per_seed,
        "is_a_quality_measure": False,
        "what_it_is": ("a comparative signal between system versions against one frozen "
                       "benchmark. Research quality needs the blind rubric; the two do not "
                       "substitute for each other."),
    }


def to_harness_inputs(packet: dict) -> dict:
    """Convert a filled packet into what `research-eval-harness` expects.

    Two representations exist because the packet is built for a human to fill in
    and the harness input is built to be stamped with the system's identity. They
    are kept in one file so that a change to either format breaks a test rather
    than silently producing two different recall numbers from one adjudication.
    """
    directions, seen = [], set()
    adjudications = []
    for it in packet["items"]:
        did = f"{it['seed_id']}::gen{it['generated_rank']}"
        if did not in seen:
            seen.add(did)
            directions.append({"direction_id": did, "rank": it["generated_rank"],
                               "seed_id": it["seed_id"], "text": it["generated"]})
        if str(it.get("verdict") or "").upper() == "MATCH":
            adjudications.append({"system_direction_id": did,
                                  "gold_direction_id": it["gold_direction_id"],
                                  "match": True,
                                  "adjudicator": it.get("adjudicator")})
    return {"system_directions": directions, "match_adjudications": adjudications}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--benchmark", help="evals/retro_benchmark.jsonl")
    ap.add_argument("--directions", help="portfolio of generated directions")
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--emit-packet", help="write the adjudication packet here")
    ap.add_argument("--packet", help="a filled adjudication packet to score")
    ap.add_argument("--judge-kind", choices=JUDGE_KINDS, default="unspecified")
    ap.add_argument("--judge-id")
    ap.add_argument("--out")
    ap.add_argument("--emit-harness-inputs",
                    help="write {system_directions, match_adjudications} for research-eval-harness")
    a = ap.parse_args(argv)

    if a.emit_packet:
        if not (a.benchmark and a.directions):
            raise SystemExit("--emit-packet needs --benchmark and --directions")
        freeze, pairs = load_benchmark(Path(a.benchmark))
        packet = emit_packet(freeze, pairs, load_directions(Path(a.directions)), a.k)
        Path(a.emit_packet).write_text(json.dumps(packet, indent=1), encoding="utf-8")
        print(f"wrote {a.emit_packet}: {len(packet['items'])} pair(s) to adjudicate across "
              f"{len({i['seed_id'] for i in packet['items']})} seed(s); floor="
              f"{packet['contamination_floor']}")
        for s in packet["seeds_with_no_generated_directions"]:
            print(f"  no generated direction for seed {s}: it scores 0 by absence, not by error")
        return 0

    if not a.packet:
        raise SystemExit("pass --emit-packet to prepare adjudication, or --packet to score one")
    packet = json.loads(Path(a.packet).read_text(encoding="utf-8"))
    if a.emit_harness_inputs:
        payload = to_harness_inputs(packet)
        Path(a.emit_harness_inputs).write_text(json.dumps(payload, indent=1), encoding="utf-8")
        print(f"wrote {a.emit_harness_inputs}: {len(payload['system_directions'])} direction(s), "
              f"{len(payload['match_adjudications'])} adjudicated match(es)")
    card = score(packet, a.judge_kind, a.judge_id)
    out = Path(a.out) if a.out else None
    text = json.dumps(card, indent=1)
    if out:
        out.write_text(text, encoding="utf-8")
        print(f"wrote {out}")
    else:
        print(text)
    print(f"{card['verdict']}: {card['why']}", file=sys.stderr)
    return 0



if __name__ == "__main__":
    raise SystemExit(main())
