# v2.0.0 — commercial build (2026-08-11)

## Licence issuing and enforcement

- `tools/license/{keygen,issue,server}.mjs` — Ed25519 keypair generation, licence signing with a
  self-check that refuses to emit an unverifiable licence, and a minimal issuing service with an
  admin token, rate limiting and an append-only issuance ledger that never records the key.
- **The paywall now actually gates.** It previously computed the restricted feature list correctly
  and then printed it while running every gated stage anyway. Enforcement is now on both sides of
  the language boundary, because `researchforge.runner` is invokable directly.
- A licence cannot be made unbypassable in self-hosted software. The design goal is therefore that
  bypass is a deliberate, *recorded* act: `RESEARCHFORGE_ALLOW_UNLICENSED=1` works, and writes itself
  into provenance and the release manifest.
- Fixed a latent bug that would have broken every real licence: the verifier called
  `crypto.verify("sha256", ...)`, and OpenSSL rejects a named digest for Ed25519 rather than
  ignoring it. Every test passed because they all verified against a null key.

## Measured ingestion quality on real PDFs, and three fixes

18 real paper PDFs from 14 GitHub repos. Measured: 73% of extracted claims carried a wrong section
label, 28% were mined from past the References heading, and 1 in 18 PDFs was un-ingestable.

Fixed:
1. **Lone surrogates no longer crash ingestion.** pypdf emits unpaired U+D835 for math-italic
   glyphs; the artifact store died on `.encode()` and a real paper looked like a runtime bug.
   Now transcoded lossily *and the loss is named*, because a silent recovery would hide that the
   formulae on those pages are junk.
2. **`HEAD_RE` now matches `1. Introduction` and roman numerals.** It previously required whitespace
   after the section number, so ICML/PMLR style was invisible: 7 of 18 papers detected exactly two
   sections, and every body claim was filed under "Abstract".
3. **`layout_warnings.md` can no longer claim a clean bill of health.** It used to print
   "none: text extraction produced anchored, ordered content" whenever the warning list happened to
   be empty — an affirmative all-clear for checks that were never run. In a system whose entire pitch
   is refusing to report work it did not do, this was the worst defect in the codebase. It now
   separates what was checked from what was not.

Everything else found is documented in `docs/PDF_INGEST_QUALITY.md` with its measured cost, and
pinned by tests.

## Acceptance harness

`acceptance/` — `RUBRIC.md` (eight dimensions, every threshold traced to a runtime constant or a
stated property), `grade.py` (consumes the existing audits rather than re-deriving them, because two
thresholds means the lower one wins), `run_acceptance.sh` (fails loudly if no API key or GPU rather
than degrading to the offline path).

`NOT_MEASURED` is a distinct outcome from `PASS`, and it blocks acceptance. Grading a project whose
artifacts carry `synthetic: true` is refused outright.

## Commercial proposal

`docs/COMMERCIAL.md` — what is actually being sold, four buyer segments and what each is buying
instead of, tiers mapped onto the feature gates that exist, price points with the reasoning chain,
what will block a sale, and legal exposure. Every guess is marked as one, with how to replace it.

## Corrected: the A′ arm refuted this project's own recommendation

`docs/study/APRIME_FINDINGS.md`. v1.1.0 recommended a "dependency time machine" — a date-pinned wheel
index and a multi-version interpreter pool — as the highest-value engineering investment. Both were
built and tested on the same 20 papers. The date snapshot helped one paper; the interpreter pool
helped none. The apparent gain from switching resolvers evaporated under a real install, because a
dry-run does not execute `setup.py`.

The real blocker is a CUDA build toolchain: `flash-attn` and its class import torch at build time and
then compile. `result-reproducer`'s remediation table has been corrected to say so, and to say
explicitly that the date-pinned index was tested and did not work.

## Step 0, executed

`docs/study/step0_results.json`. 30 seeds per metric on the worked example: **8 of 12 metrics need a
tolerance wider than the 2% floor, one of them 67× wider.** A fixed ±5% tolerance would classify
those metrics' own noise as a failed reproduction. The floor is now documented as a floor and nothing
more.

## Still not done

- **No acceptance run has been performed.** No API key, no GPU here. The harness exists; the run does not.
- **B arm not executed.** The protocol's human-ceiling comparison needs a human; the agent-vs-human gap is unmeasured.
- The innovation engine has never been scored against a benchmark. `retrospective-benchmark-builder`
  correctly refuses without a corpus, and no corpus exists.
- `pubkey.ts` still holds the substitution sentinel: no shipped build can verify a licence until the
  release process substitutes a real public key.

---

# v2.1.0 — the falsifiability mechanism, made real (2026-08-12)

The acceptance grader built in v2.0.0 immediately failed the stock run on two structural
defects. Both were real, both reproduced on any run, and both are now fixed. A grader that
finds nothing on its first outing is a grader nobody should trust.

## 1. Void conditions were prose, so nothing was ever checked

Every `invalid_condition` the blueprint compiler emitted carried a `detect` field written for a
human — "count completed runs per condition in the experiment ledger". No runtime can evaluate
that. Not one condition had ever fired or cleared on any run, which made every experiment the
system produced formally **unfalsifiable** while its spec said otherwise in good English.

`researchforge/invalid_conditions.py` gives each condition a machine-evaluable `check`:
`min_completed_runs_per_condition`, `field_stable_across_runs`, `metric_names_stable`,
`configs_match_except`, `artifact_field_present`, `text_present_in_artifact`. The prose stays
for the reader; the predicate is what binds.

`experiment-runner` evaluates them after the runs and **excludes a void experiment's runs before
ranking**, rather than annotating the ranking afterwards. A void run is not a negative result —
it is nothing, and nothing may be concluded from it.

A condition whose kind is unknown reports `UNCHECKED`, never satisfied. An experiment none of
whose conditions could be evaluated is reported as not falsifiable, which is a distinct and
worse state than void.

Each ledger entry now stamps the evaluator digest, because `EVALUATOR_CHANGED_MID_RUN` was
otherwise permanently `UNCHECKED` — which reads like "fine" and means "we never looked".

## 2. Ablations measured something other than the claim they tested

Ablation specs declared `primary` and `seed_dispersion` while the experiments they ablate
declared domain metrics. Disjoint sets: the contrast an ablation exists to make could never be
constructed from the ledger. The ablation was structurally incapable of answering the only
question it was created to answer.

Ablations now inherit the parent experiment's metrics and add dispersion on top. The worked
example's ablation was rewritten accordingly — and the corrected contract immediately rejected
the old implementation for returning undeclared metrics, which is the gate working.

## 3. A number extractor that silently dropped exponents

Found while diagnosing why a slide number would not bind. `5.3462760410685855e-16` — a
dispersion of essentially zero — was parsed as `5.34628` and rendered on a defense slide as five
and a third. **Wrong by sixteen orders of magnitude.** The binder caught it as "unbound", so the
gate held, but the diagnosis pointed at the wrong thing.

`NUMBER_RE` now matches scientific notation as one quantity, exponent included, while still
keeping digits inside identifiers (`E-001`, `v1.2`) out.

## 4. Two false positives in the claim auditor

Sample sizes (`n=7 runs`) and recorded run scalars (wall-clock, seed) were marked FABRICATED
because the indexes exposed only metric values. Both are recorded facts traceable to a run id.
An auditor that cries wolf on sample sizes is one nobody reads. The worked example now audits
11 of 11 claims as SUPPORTED, and the release is still refused — for the synthetic draft, which
is correct.

## 5. A scoping error I made and then reverted

I first limited `BASELINE_NOT_ESTABLISHED` to comparative specs, reasoning that a diagnostic
experiment at CM_NONE compares against our own implementation and needs no external pin. A test
disagreed and the test was right: an internal reference has to hold still too, or a change in
our own code is credited to the mechanism. The condition applies to every spec; only the *check*
differs — external revision pin for comparative specs, entry-point digest stability for internal ones.

## Verified

300 tests (276 Python + 24 TypeScript). The worked example traverses all 16 states, all three
experiments are non-void and falsifiable with zero unchecked conditions on the two primaries,
11 of 11 claims SUPPORTED, and the release gate still refuses the synthetic draft.

# v2.2.0 — the comparison has a third arm (2026-08-12)

Ablations and baselines now measure against the current strongest method, not only against the
paper the project started from.

## 1. Nothing ever asked who is currently best

`result-reproducer` located the *source paper's* repository and stopped there. Every downstream
comparison was therefore "did we beat what they beat", and every ablation isolated a mechanism
inside a method whose competitiveness nobody had established. Both are real measurements. Neither
answers the question a reviewer asks, and an ablation anchored to a non-competitive full method is
a strawman with extra steps.

- `result-reproducer` now consumes `benchmark_matrix` and `literature_candidates` and writes
  `baseline_assets.sota`: candidates drawn from `--set sota_methods='[...]'`, from the benchmark
  table, and from titles that assert the frontier. `established` stays **False** until a candidate
  has been run here and graded RL3+. A number scraped from a benchmark table is a *reported*
  number; placing our measured result beside someone else's best-case reported one, under their
  hardware and their tuning budget, is the most common way a comparison becomes fiction.
- `research-blueprint-compiler` adds a third condition to every comparative spec when a candidate
  exists, states in the success metric whether that arm is measured or reported, budgets for it
  (`conditions: 3`), and emits `SOTA_NOT_ESTABLISHED` as a machine-checkable invalid condition.
- Ablation specs carry `anchored_to`, including a `strawman_risk` naming which of the two weaknesses
  applies: no sota arm at all, or one declared and never run.
- When no candidate is found the compiler says so and says what it costs: no claim of
  competitiveness can come out of that plan however the runs turn out.
- `claim-citation-auditor` blocks "state-of-the-art" / "outperforms all prior" claims about *this
  work* unless a `sota` arm completed with metrics in the ledger. Reported numbers do not satisfy
  it. Sentences describing the literature are not graded, because a check that misfires in related
  work is a check that gets turned off.

## 2. The runner only ever ran one arm

Found while wiring the above. `experiment-runner` invoked the generated entry point with no
`--arm` at all, so it always executed the default — the candidate. A spec could declare a baseline
and report `conditions: 2`, and the ledger would contain two runs of the same condition.

Every comparison built on such a ledger was the candidate against itself. It could not fail: the
means matched because they were the same runs.

- The runner now executes every arm the spec declares, the generated entry point derives its
  `--arm` choices from the spec rather than a hard-coded pair, and ledger rows carry `arm`.
- A spec that designs more conditions than it names runnable arms now says which ones will never be
  measured, instead of leaving "small effect" and "never ran" indistinguishable downstream.
- `research-blueprint-compiler`'s diagnostic spec said `conditions: 1` while declaring a baseline
  the runner would be asked to execute. The budget was short by half.

## 3. Four places that pooled a method with its own control

Once the arms actually ran, every consumer that grouped by experiment id started averaging the
candidate together with the baseline it was being compared against. The result is arithmetically
valid, describes no condition that was ever run, and passes every integrity check downstream
because it is a real mean of real runs.

- `experiment-runner._rank` scores a branch by its **candidate** arm and reports the others beside
  it, with `contrasts` giving candidate-minus-control per metric. No significance is claimed there;
  `integrity-auditor` owns that question.
- `data-analyst` groups by `(experiment, arm, metric)`. Grouping by arm alone — the first fix, and
  wrong — would have merged E-001's baseline with E-ABL-001's baseline into one group called
  "baseline".
- `integrity-auditor` identifies one control **per experiment**, refuses to pair arms across
  experiments, and no longer fills the multiple-comparison family with contrasts nobody designed.
- `claim-evidence-graph` emits one own-work claim per (experiment, arm, metric). It previously
  emitted "In E-001, failure_mode_incidence measured 0.2131 (n=14 runs)" — 7 seeds of the method
  and 7 of its control, averaged. `figure-factory` caught it: the number matched nothing in the
  analysis. That refusal is the one that made this whole class visible.

# v2.3.0 — the innovation engine has a benchmark, and the benchmark has a floor (2026-08-12)

`retrospective-benchmark-builder` had been correctly refusing to run since v1: no corpus existed,
and it will not invent one. The corpus now exists. Its most important output is not the benchmark.

## The floor is 0.75

Asked to name — from memory, with no corpus, no retrieval and no tools — the papers that beat each
seed on its own benchmark between 2020 and 2022, `claude-opus-5` named **3 of 3** ImageNet gold
directions and **1 of 2** CoNLL 2003 directions. The probe ran in a separate context from the one
that built the corpus, so the answers could not leak from the session that knew them.

**Any recall@10 at or below 0.75 on this benchmark measures the model's reading, not its judgment.**
Without that number the same score would have been reported as a capability, which is the failure
this skill was written to prevent. The floor is a lower bound: it is scored by title containment,
which misses paraphrase and misses recognition that never surfaces as a title.

## Leaderboards, not citations

Forward-citation traversal is the obvious source and the wrong one. A citation edge says one paper
mentioned another; deciding which mentions are *material* is a judgment, and a judgment made by the
model that is about to be scored is not evidence.

`tools/benchmark/build_retro_corpus.py` uses the archived Papers With Code evaluation tables
instead. Per benchmark it takes the record holder as of a cut date as the seed, and the
**record-holder chain** after it as the gold directions: each paper that set a new best, in date
order, deduplicated by arXiv id. The relation `replaces` is then a recorded fact — a published
number on the same benchmark exceeding the previous record — and no text was read to decide it.

What it costs, stated in the shipped report rather than discovered later: the chain contains only
work that improved a headline number. It excludes work that diagnosed the seed, refuted it, changed
the problem, or was tried and lost. A system scoring 0 here has not been shown to be bad at
research; it has been shown not to predict leaderboard succession.

## The skips are findings

Five benchmarks were queried; three were dropped by the rule. Nothing in the Papers With Code
record beat the 2019 leader on **SQuAD1.1 dev** or **MultiNLI** during 2020–2022, and WMT2014 En-De
produced exactly one record-setting successor. Those benchmarks were saturated. A suite that
dropped them quietly would have hidden that, so `benchmarks_skipped` carries each one with its
reason and the builder prints them.

That leaves **2 seeds and 5 gold directions** — small, and labelled as such. The one non-mechanical
step is the benchmark list itself, a convenience enumeration of five widely used benchmarks; it is
recorded in `selection_rule`, and it biases toward heavily-worked benchmarks whose successors are
famous, which *raises* contamination rather than lowering it.

Shipped in `benchmarks/retro-v1/`: the corpus, the raw leaderboard rows as retrieved, the paper
metadata, the frozen benchmark, the run config and the report. A test rebuilds the shipped corpus
from the shipped inputs and asserts byte equality, so the corpus is provably derived rather than
written.

## Still not done

- **Scoring the engine against it** needs a real model provider. The offline stub emits structural
  placeholders and scoring placeholders yields a number, not a measurement. The bar, when someone
  runs it, is not zero — it is 0.75.
- **No blind human rubric.** recall@k is a regression signal between versions. It is not evidence
  that the output is worth anything, and the two do not substitute for each other.
- **No acceptance run** (no API key, no GPU here) and **no B arm** (needs a human).

# v2.4.0 — the benchmark can now be scored against (2026-08-12)

v2.3.0 shipped a frozen benchmark and a contamination floor. Nothing could score a system against
it: `research-eval-harness` computed recall@k only if handed adjudicated matches, and nothing
produced adjudicated matches. That is the missing half.

## 1. `tools/benchmark/score_directions.py`

Two phases, because matching a generated direction to a gold one is a judgment and the benchmark's
own scoring contract forbids every shortcut — not string overlap, not an embedding threshold, not a
title match. Two directions can share every content word and mean different things ("scale the
teacher" vs "scale the student"); two can share none and mean the same.

- `--emit-packet` writes the **full cross product** of the top-k generated directions against every
  gold direction, with both texts and no verdicts. Deliberately not a shortlist: a shortlisting
  function would be the real matcher while the adjudicator believed they were doing the matching.
- The rubric ships inside the packet, including the rule that does most of the work — a generated
  direction *strictly more general* than the gold one is `NO_MATCH`.
- An unfilled pair is `UNADJUDICATED`. It is excluded from numerator and denominator, and the run
  is reported `INCOMPLETE` rather than as a low score. Counting undecided as wrong is how an
  unreviewed run comes to look measured.
- `--score` reports one of four verdicts. `AT_OR_BELOW_FLOOR` names the only thing that matters
  about a number on this benchmark: **the reference point is 0.75, not zero.** A system at or below
  the floor produces the same number a system that had merely read the literature produces.
- A model judge is allowed and is *recorded as one*, with the caveat attached: a model adjudicating
  whether an output matches literature it has also read has the contamination problem one level up.
- `--emit-harness-inputs` converts the filled packet into what `research-eval-harness` consumes. A
  test asserts both paths compute the same recall from one adjudication — two formats for one fact
  is how a project ends up with two numbers and no way to say which is right.

## 2. `tools/benchmark/blind_rubric.py`

recall@k answers one question: does the system name the directions the field took? It cannot say
whether they are any good, and the gap is not academic — the gold set is leaderboard succession, so
a system that only ever proposes "scale it up" scores well while proposing nothing worth reading.

The blind rubric is the other half, and the instrument is the whole thing:

- Five criteria, each defined by what a **1 and a 5** look like. "Rate novelty" collects the rater's
  mood.
- Arms must be **balanced** — a rater who notices the imbalance can guess the majority arm and beat
  chance without reading — and above a minimum size, below which the comparison is a coin flip
  dressed as a rubric.
- **Tells are stripped and reported**: model-voice phrasing, citation markers, numbered-plan
  formatting, emoji, markdown leads. One "as an AI" and the rater is no longer blind for the rest
  of the session.
- The order is shuffled by a **recorded seed**, so a disputed packet can be rebuilt and shown to
  have had the order it claims. The key is a separate file that raters never see.
- Analysis **refuses** in three cases: the packet no longer hashes to its key (edited after the
  fact, so the arm labels attach to text nobody rated); raters guessed the arm above chance (the
  ratings are then ratings of the arm); or the blind check was never run at all — which is not the
  same as it having held.
- A blank score is `not rated`, never a 1.

## What is still missing, and what is no longer missing

Scoring the innovation engine needed a real model provider **and** a scorer. It now needs only the
provider. The blind rubric needed an instrument **and** a panel. It now needs only the panel.

Still absent for the same reasons as before: the acceptance run (no API key, no GPU here) and the
B arm of the reproduction study (needs a human).
