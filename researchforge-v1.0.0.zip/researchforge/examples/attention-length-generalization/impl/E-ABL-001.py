"""Isolation test for M-001 — remove the mechanism and see whether the effect survives.

If the effect is unchanged with the mechanism removed, the mechanism is not what
produces it. That is the only thing an ablation can establish, and it is enough.
"""
from __future__ import annotations

import numpy as np

N_SEEDS_INTERNAL = 5


def _effect(rng: np.random.Generator, mechanism: bool) -> float:
    x = rng.normal(0, 1, 512)
    if mechanism:
        # the mechanism under test: softmax sharpening
        w = np.exp(x * 2.0); w /= w.sum()
    else:
        w = np.full_like(x, 1.0 / x.size)
    return float(-(w * np.log(w + 1e-12)).sum() / np.log(x.size))


def candidate(seed: int, config: dict) -> dict:
    rng = np.random.default_rng(seed)
    vals = [_effect(rng, mechanism=True) for _ in range(N_SEEDS_INTERNAL)]
    return {"primary": float(np.mean(vals)), "seed_dispersion": float(np.std(vals, ddof=1))}


def baseline(seed: int, config: dict) -> dict:
    """Mechanism removed, compute budget matched."""
    rng = np.random.default_rng(seed)
    vals = [_effect(rng, mechanism=False) for _ in range(N_SEEDS_INTERNAL)]
    return {"primary": float(np.mean(vals)), "seed_dispersion": float(np.std(vals, ddof=1))}
