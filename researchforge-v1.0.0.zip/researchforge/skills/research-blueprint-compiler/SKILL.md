---
name: research-blueprint-compiler
description: Use when a direction has been selected and must become an executable plan: stages, budgets, acceptance criteria, falsifiable experiment specifications and the ablations that isolate the claimed mechanism. Trigger immediately after selection.
version: 0.3.0
stage: 05-planning
artifact_kind: workflow-skill
implementation_status: specification-ready
consolidates: [research-blueprint-compiler, experiment-spec-author, ablation-and-counterfactual-planner]
---

# research-blueprint-compiler

## Objective

Compile a selected direction into experiments that can actually be run and that can actually fail.

**Consolidates v0.2.0 skills** `research-blueprint-compiler`, `experiment-spec-author`, `ablation-and-counterfactual-planner`.

The blueprint, the experiment specs and the ablation plan were one act of planning split three ways. An experiment spec without its ablations cannot support a causal claim, so the two were never separable in practice.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- `baseline_assets`
- `comparison_mode`
- `selected_direction`
- `source_repro_report`
- `external: candidate method description`
- `external: hypothesis under test`
- `external: resource envelope (compute, time, budget)`

## Outputs

- `acceptance_criteria`
- `blueprint_dag`
- `experiment_specs`
- `research_blueprint`

## Depends on

*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*

- `reproduction-fallback-planner`
- `result-reproducer`
- `user-feedback-gate`

## Procedure

### A. Blueprint and acceptance criteria

1. Define research question, hypothesis, baseline, candidate method, datasets, metrics, statistical plan and expected artifacts.
2. Expand into DAG stages with dependencies and parallelizable experiments.
3. Assign providers/tools/skills to capabilities using tool-skill-router.
4. Define human gates, budget limits, safety constraints and kill/continue rules.
5. Version the blueprint and hash critical configs.

### B. Falsifiable experiment specifications

1. Define hypothesis and decision rule first.
2. Specify control/baseline, treatment variants, fixed factors and nuisance variables.
3. Pin dataset splits, preprocessing, seeds and metric code.
4. Declare required outputs: raw metrics, logs, plots, environment capture and result JSON.
5. Define invalid-run conditions and rerun policy.

### C. Ablations and counterfactual controls

1. Map each claimed mechanism to a removable/replaced component.
2. Design equal-budget comparisons where possible.
3. Add sensitivity checks for key hyperparameters/assumptions.
4. Prioritize ablations by claim importance.


## Hard gates

- Every success claim has a measurable acceptance criterion.
- Every expensive branch has a predeclared budget/stop rule.
- No experiment without a control or an explicit reason control is impossible.
- Metric implementation is shared between baseline and candidate when comparing them.
- A component cannot receive causal credit without an isolation test when feasible.

## Verification / tests

- Blueprint schema validation.
- Cycle detection rejects invalid DAG.
- Experiment schema rejects missing seed/split for stochastic benchmark fixture.
- Headline mechanism has at least one discriminating ablation.

## Internal artifacts

Produced and consumed entirely inside this skill. They no longer cross a skill boundary, so they are not part of the public artifact contract — but they are still written to disk and still carry provenance.

- `ablation_plan` — Ablations and counterfactual controls (`experiments/ablation_plan.yaml`)

## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured failure record rather than degrading the honesty of the report.

## Upstream inspiration (conceptual, not vendored text)

See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their text.
