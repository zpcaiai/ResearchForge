"""Reproduction before ideation, and the degradation path when it falls short.

This is the highest-risk stage in the system and the one whose real-world success
rate the project's viability depends on. Under BYOK-without-GPU the reproducer can
honestly reach RL0 and RL1 — it can clone, resolve dependencies and run an entry
point on CPU — and must refuse to claim RL2 or above, because those require
matching numbers the available compute cannot produce.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from .evidence import _in_family


def _as_list(v) -> list:
    """A list, from something that may be a scalar or None.

    A bare string is the failure this exists for: `for d in "Mamba-2"` iterates
    characters, and every one of them became a state-of-the-art candidate.
    """
    if v is None:
        return []
    if isinstance(v, (str, bytes)):
        t = v.strip()
        return [t] if t else []
    if isinstance(v, (list, tuple, set)):
        return list(v)
    return [v]


def _metric_name(m) -> str:
    return str(m.get("name") or "") if isinstance(m, dict) else str(m)


def _reported_direction(model) -> str | None:
    """`maximize` / `minimize` for the paper's own metrics, or None.

    None is load-bearing, exactly as in `execution._metric_direction`: without a
    direction there is no defensible way to call 44.0 better than 8.9, and the
    ranking that assumed higher-is-better put the worst perplexity first and then
    dropped the best method with a `[:5]`. Where the declared metrics disagree,
    the answer is also None — a mixed set has no single ordering.
    """
    dirs = set()
    for m in _as_list(model.get("metrics")):
        if isinstance(m, dict):
            d = str(m.get("direction") or m.get("goal") or "").lower()
            if d in ("maximize", "max", "higher_is_better", "higher"):
                dirs.add("maximize")
            elif d in ("minimize", "min", "lower_is_better", "lower"):
                dirs.add("minimize")
    return dirs.pop() if len(dirs) == 1 else None


def _cand_key(c: dict) -> str:
    """Identity of a candidate for dedup.

    The old key was `name.lower()[:80]`, which collapsed two distinct papers
    sharing an 80-character title prefix — common, because the prefix of a title
    is where the shared jargon lives. Normalising whitespace and punctuation and
    keeping the whole name is both stricter and less arbitrary.
    """
    name = re.sub(r"[^a-z0-9]+", " ", str(c.get("name", "")).lower()).strip()
    return name or str(c.get("citation") or id(c))

from ..skill import Context, Skill, SkillResult, register

GITHUB_RE = re.compile(r"https?://github\.com/([\w.-]+)/([\w.-]+?)(?:\.git)?(?:[/#?]|$)", re.I)
FAILURE_CODES = ("NO_CODE", "DEPENDENCY_UNRESOLVABLE", "HARDWARE_UNAVAILABLE", "DATA_UNAVAILABLE",
                 "DATA_ACCESS_GATED", "CHECKPOINT_MISSING", "UNDOCUMENTED_PREPROCESSING",
                 "CONFIG_AMBIGUOUS", "NONDETERMINISM", "METRIC_DEFINITION_MISMATCH",
                 "NUMBERS_DIVERGE", "TIMEBOX_EXCEEDED", "LICENSE_BLOCKED")


@register
class ResultReproducer(Skill):
    name = "result-reproducer"
    # comparison-baseline outputs only exist once a direction has been selected
    optional_outputs = ("reproduction_report", "baseline_metrics", "baseline_deviation_log")

    def execute(self, ctx: Context) -> SkillResult:
        model = ctx.store.read(self.name, "paper_model")
        atoms = ctx.store.read(self.name, "contribution_atoms")
        sandbox = ctx.store.read(self.name, "sandbox_manifest")
        timebox = float(ctx.external("repro_timebox_seconds", 4 * 3600))
        # A 30-seed probe of the worked example (docs/study/step0_results.json)
        # found 8 of 12 metrics need a WIDER tolerance than this floor, one of them
        # 67x wider. The floor is therefore a floor and nothing more: step 0 must
        # measure the metric's own dispersion before any RL3 verdict, or the run
        # will classify its own noise as a failed reproduction.
        tol_floor = float(ctx.external("tolerance_relative_floor", 0.02))
        repos = ctx.external("code_urls", []) or self._discover(model)
        started = time.time()
        codes: list[str] = []
        warnings: list[str] = []

        # ---- A. artifact discovery -----------------------------------
        rankings = []
        for i, url in enumerate(repos):
            m = GITHUB_RE.search(url)
            rankings.append({"rank": i + 1, "url": url,
                             "owner": m.group(1) if m else None,
                             "repo": m.group(2) if m else None,
                             "kind": "official" if i == 0 else "candidate",
                             "prior_features": {}})
        ctx.store.write(self.name, "baseline_repo_rankings", {"candidates": rankings})

        if not repos:
            codes.append("NO_CODE")
            warnings.append("no code repository found for this paper. RL0 by definition; the "
                            "degradation path decides what remains possible.")
        assets = {"repos": rankings, "checkpoints": [], "datasets": [],
                  "resolved_at": time.time(), "pinned_revision": None}

        # ---- B. plan --------------------------------------------------
        headline = [a for a in atoms.get("atoms", []) if a.get("kind") == "empirical"][:5]
        plan = {"target_kind": "source_paper", "timebox_seconds": timebox,
                "tolerance_policy": {"kind": "max(reported_variance, 2x measured_std, relative floor)",
                                     "relative_floor": tol_floor,
                                     "measured_std": None,
                                     "note": "seed-variance probe required before any RL3 verdict"},
                "targets": [{"atom_id": a["atom_id"], "claim_ids": a["claim_ids"],
                             "summary": a["summary"][:160]} for a in headline]}
        ctx.store.write(self.name, "source_repro_plan", json.dumps(plan, indent=1))

        # ---- C. tiered attempt ---------------------------------------
        level = "RL0"
        env_digest = None
        detail: dict[str, Any] = {}
        if repos and not ctx.offline:
            level, codes2, detail = self._attempt(repos[0], timebox, ctx)
            codes += codes2
            env_digest = detail.get("env_digest")
        elif repos and ctx.offline:
            codes.append("TIMEBOX_EXCEEDED")
            warnings.append("offline mode: repository clone and dependency resolution were not "
                            "attempted. RL0 here means 'not attempted', not 'not reproducible'.")

        if not sandbox.get("untrusted_code_execution_allowed"):
            codes.append("HARDWARE_UNAVAILABLE")
            warnings.append(
                "no container isolation available, so the paper's entry point was not executed. "
                "RL1 requires running untrusted code and this host is not a security boundary.")
        if level in ("RL3", "RL4"):
            warnings.append("RL3+ requires matched numbers on full-scale runs; downgrading because "
                            "no compute budget was configured")
            level = "RL2"

        ctx.store.write(self.name, "source_repro_env", env_digest or
                        f"# environment not captured\n# python={sys.version.split()[0]}\n")
        ctx.store.write(self.name, "source_repro_metrics",
                        {"comparisons": [],
                         "note": "no paired reported-vs-measured record was produced. Any level "
                                 "above RL1 requires at least one, so none was claimed."})
        ctx.store.append_jsonl(self.name, "repro_failure_taxonomy",
                               [{"code": c, "target": "source_paper", "ts": time.time()}
                                for c in dict.fromkeys(codes)])
        report = {
            "target_paper_id": model.get("paper_id", "unknown"),
            "target_kind": "source_paper",
            "level": level,
            "level_rationale": detail.get("rationale",
                "No execution was attempted or no paired numeric comparison exists."),
            "assessed_at_run_id": ctx.run_id,
            "reduced_scale": True,
            "claim_comparisons": [],
            "failure_codes": sorted(dict.fromkeys(codes)),
            "remediation_candidates": self._remediation(codes),
            "environment_digest": env_digest or "not-captured",
            "timebox_seconds": timebox,
            "timebox_exhausted": (time.time() - started) >= timebox,
            "human_reviewed": False,
        }
        ctx.store.write(self.name, "source_repro_report", report)
        # --- D. who is currently strongest on this task ------------------
        # A comparison against the source paper's own baseline answers "did we beat
        # what they beat". That is not the question a reviewer asks. An ablation
        # anchored to a non-competitive full method is a strawman with extra steps,
        # so the SOTA candidates are discovered HERE, graded by the same RL ladder,
        # and carried in baseline_assets where the blueprint compiler will require them.
        bench = ctx.store.read(self.name, "benchmark_matrix", default="")
        lit = ctx.store.read(self.name, "literature_candidates", default=[])
        declared = ctx.external("sota_methods", []) or []
        # Coverage, so an empty candidate list can be reported as a fact about the
        # search rather than about the field.
        cov = ctx.store.read(self.name, "coverage_report", default={})
        # The retrieval log, so `searched_for` reports the benchmarks that were
        # actually queried rather than the ones the paper happens to name. The
        # manuscript gate quotes this field back to the author as evidence of what
        # the search covered; a list assembled from the paper's own metadata is
        # not evidence of anything.
        rlog = ctx.store.read(self.name, "literature_retrieval_log", default=[])
        sota = self._sota(model, bench, lit, declared, cov, rlog)
        assets["sota"] = sota
        # Flat mirror of sota.established. The invalid-condition checker reads one
        # level of an artifact and has no path syntax, deliberately — a check that
        # can address arbitrary nesting is a check nobody can audit by reading it.
        # Keeping the flat key here is cheaper than teaching every checker to walk.
        assets["sota_established"] = bool(sota["established"])
        if not sota["candidates"]:
            warnings.append(
                "no state-of-the-art candidate could be identified for this task. Retrieval "
                "coverage is the usual cause, and the consequence is concrete: any later "
                "comparative claim would be against the source paper's baseline only, which "
                "answers 'did we beat what they beat' rather than 'is this competitive'. "
                "Supply them with --set sota_methods='[...]' if you know them.")
        elif not sota["established"]:
            warnings.append(
                f"{len(sota['candidates'])} SOTA candidate(s) identified but none established "
                f"(none reproduced locally). Comparative claims against them may only be made "
                f"under the disclosure the comparison mode requires.")

        ctx.store.write(self.name, "baseline_assets", assets)
        ctx.store.write(self.name, "baseline_license_risk", self._license(rankings))
        return SkillResult(self.name,
                           produced=["baseline_repo_rankings", "source_repro_plan", "source_repro_env",
                                     "source_repro_metrics", "repro_failure_taxonomy",
                                     "source_repro_report", "baseline_assets", "baseline_license_risk"],
                           warnings=warnings, next_state="REPRO_LEVEL_ESTABLISHED",
                           detail={"level": level, "failure_codes": report["failure_codes"]})

    # ------------------------------------------------------------------
    def _discover(self, model) -> list[str]:
        return []

    #: A candidate is on-topic only if it shares a benchmark or the task with the
    #: source paper. Without this the filter was "the title contains the phrase
    #: state-of-the-art", which is satisfied by any field on earth.
    _STOP = frozenset({"the", "a", "an", "of", "for", "on", "in", "and", "with", "to", "via",
                       "using", "based", "new", "novel", "towards", "toward", "dataset",
                       "benchmark", "task", "test", "dev", "validation", "set"})

    @staticmethod
    def _toks(text) -> set[str]:
        return {t for t in re.findall(r"[a-z0-9]+", str(text).lower())
                if len(t) > 2 and t not in ResultReproducer._STOP}

    @staticmethod
    def _bench_pattern(name: str) -> str:
        """A benchmark name matched as a name, not as a substring.

        Benchmark names are written inconsistently (`WikiText-103`, `wikitext 103`,
        `WikiText103`), so the separators inside the name are made flexible while
        the two ends are pinned to word boundaries. Names shorter than two
        characters get no pattern at all — a one-character "benchmark" matches
        every paper ever written, which is how `datasets` arriving as a bare
        string instead of a list produced a protein-folding paper that "names the
        benchmark 'W'".
        """
        parts = [re.escape(p) for p in re.split(r"[^A-Za-z0-9]+", str(name).lower()) if p]
        if not parts or len("".join(parts)) < 2:
            return r"(?!)"                       # matches nothing, deliberately
        return r"(?<![a-z0-9])" + r"[^a-z0-9]?".join(parts) + r"(?![a-z0-9])"

    def _topic_match(self, text: str, datasets: list[str], task: str) -> dict | None:
        """Why this candidate is on the same research topic, or None.

        Two ways to qualify, in order of strength. Naming one of the paper's own
        benchmarks is direct evidence: a leaderboard is a shared measuring stick.
        Overlapping the task's content words is weaker and is recorded as weaker —
        an ablation anchored to a task-match-only candidate is anchored to
        something that may not be measured the same way at all.
        """
        low = str(text).lower()
        for d in datasets:
            # Word boundaries, not substring. `"pile" in "compiler"` graded a
            # tensor-compiler paper as sharing this paper's benchmark, and
            # `direct` is the class that sorts first and licenses the manuscript
            # claim — a false `direct` is worse than no candidate at all.
            if d and re.search(self._bench_pattern(d), low):
                return {"kind": "shared_benchmark", "matched": d, "strength": "direct",
                        "why": f"names the benchmark {d!r}, which this paper also reports on"}
        t_toks = self._toks(task)
        if t_toks:
            overlap = t_toks & self._toks(text)
            # Two content words is the floor. One word matches "learning".
            if len(overlap) >= 2:
                return {"kind": "shared_task_terms", "matched": sorted(overlap),
                        "strength": "weak",
                        "why": (f"shares {len(overlap)} task term(s) with {task!r} but names none "
                                f"of this paper's benchmarks, so it may not be measured the same "
                                f"way")}
        return None

    def _sota(self, model, bench, lit, declared, coverage=None, retrieval_log=None) -> dict:
        """Current strongest methods on THIS paper's task and benchmarks.

        Two things this refuses to do. It does not accept a candidate that merely
        asserts the frontier somewhere in its title — every candidate has to name
        one of the paper's benchmarks or overlap its task, and the matched evidence
        is recorded per candidate. And it does not read an empty result as "there
        is no state of the art": when retrieval coverage is unknown, absence is a
        fact about this search.

        Deliberately conservative about what counts as evidence. A number scraped
        from a benchmark table is a REPORTED number, not a measured one, and this
        records it as such — `established` stays False until something in the
        reproduction ladder actually ran it. The alternative, treating a table cell
        as a baseline, is how a project ends up comparing its measured result
        against someone else's best-case reported one.
        """
        # A bare string here used to be iterated character by character, so
        # `datasets="WikiText-103"` searched for the benchmark "W" and
        # `--set sota_methods=Mamba-2` produced five one-character candidates that
        # neutralised the topic gate for the whole project.
        datasets = [str(d) for d in _as_list(model.get("datasets")) if str(d).strip()]
        declared = _as_list(declared)
        task = str(model.get("task") or model.get("problem") or model.get("title") or "")
        metrics = {str(_metric_name(m)).lower() for m in _as_list(model.get("metrics"))}
        cands: list[dict] = []
        rejected: list[dict] = []

        def consider(rec: dict, text: str, *, gate: bool = True):
            if not gate:
                cands.append(rec)
                return
            match = self._topic_match(text, datasets, task)
            if match is None:
                rejected.append({"name": rec.get("name"), "source": rec.get("source"),
                                 "why": ("names none of this paper's benchmarks and overlaps its "
                                         "task in fewer than two content words, so it is not "
                                         "evidence about this research topic")})
                return
            cands.append({**rec, "topic_match": match})

        # Declared by the operator: they said it is the relevant SOTA, and that is a
        # human decision this skill does not overrule. It is still recorded as
        # ungated so a reader can see which candidates were asserted rather than found.
        for d in declared:
            rec = ({**d, "source": "declared_by_user"} if isinstance(d, dict)
                   else {"name": str(d), "source": "declared_by_user"})
            consider({**rec, "reported_only": True,
                      "topic_match": {"kind": "declared", "strength": "asserted",
                                      "why": "named by the operator; not gated on topic match"}},
                     "", gate=False)

        # benchmark_matrix is CSV: benchmark,reported_by,value,source. Parsed with
        # the csv module, because the writer quotes every field and a naive
        # `split(",")` shifted every column on any title containing a comma — the
        # reported number landed in the citation column, the paper's own row
        # stopped being recognised as its own, and the paper was anchored to a
        # fragment of its own metric name.
        for cols in csv.reader(io.StringIO(str(bench or ""))):
            cols = [str(c).strip() for c in cols]
            if len(cols) < 4 or not cols[0] or cols[0].lower() == "benchmark":
                continue
            if cols[1].lower() == "source paper":
                continue            # the paper's own row is not a competing method
            consider({"name": cols[1] or "unknown", "benchmark": cols[0],
                      "reported_value": cols[2], "source": "benchmark_matrix",
                      "citation": cols[3], "reported_only": True},
                     f"{cols[1]} {cols[0]}")

        # Literature hits from the SOTA query family only. The related-work family
        # is not a frontier search, and treating its titles as one is how a paper
        # from another field became a comparison target.
        for w in (lit or []):
            if not _in_family(w, "sota"):
                continue
            title = str(w.get("title") or "")
            body = f"{title} {w.get('abstract') or w.get('summary') or ''}"
            asserts_frontier = any(k in body.lower() for k in
                                   ("state-of-the-art", "state of the art", "sota",
                                    "outperform", "best performing", "new record"))
            if not asserts_frontier:
                continue
            consider({"name": title[:120], "source": "literature_sota_query",
                      "provider": w.get("_provider"), "query": w.get("_query"),
                      "reported_only": True}, body)

        # Strongest evidence first: a shared benchmark beats a task-term overlap.
        # Ordering matters because the blueprint takes the top five, so the order
        # IS the selection.
        rank = {"direct": 0, "asserted": 1, "weak": 2}
        direction = _reported_direction(model)

        def sort_key(item):
            i, c = item
            v = 0.0
            if direction:
                try:
                    v = float(str(c.get("reported_value", "")).replace("%", ""))
                    v = -v if direction == "maximize" else v
                except (TypeError, ValueError):
                    v = 0.0
            return (rank.get((c.get("topic_match") or {}).get("strength"), 3), v, i)

        # Sort BEFORE dedup. First-wins dedup ran in source order — declared,
        # then benchmark_matrix, then literature — so the operator's bare name
        # displaced the same method's shared-benchmark evidence and its reported
        # number, and neither loss appeared anywhere in the output.
        ordered = [c for _, c in sorted(enumerate(cands), key=sort_key)]
        seen: dict[str, dict] = {}
        uniq: list[dict] = []
        for c in ordered:
            k = _cand_key(c)
            kept = seen.get(k)
            if kept is None:
                seen[k] = c
                uniq.append(c)
                continue
            # Same method reached us twice. Keep the stronger record and absorb
            # what the weaker one knew, rather than discarding it silently.
            for field in ("reported_value", "benchmark", "citation", "provider", "query"):
                if not kept.get(field) and c.get(field):
                    kept[field] = c[field]
            srcs = kept.setdefault("also_found_by", [])
            if c.get("source") and c["source"] != kept.get("source") and c["source"] not in srcs:
                srcs.append(c["source"])
        cov = coverage.get("status") if isinstance(coverage, dict) else None
        # What the search actually asked. None means no log was available, which
        # is reported as None rather than as the paper's own dataset list —
        # "unknown" and "all of them" are not the same statement.
        sota_queries = [str(r.get("query") or "") for r in _as_list(retrieval_log)
                        if isinstance(r, dict) and r.get("query_family") == "sota"]
        queried = None
        if retrieval_log is not None:
            blob = " ".join(sota_queries).lower()
            queried = [d for d in datasets if re.search(self._bench_pattern(d), blob)]
        return {
            "candidates": uniq[:20],
            "established": False,
            "established_ids": [],
            "relevant_metrics": sorted(metrics)[:12],
            "searched_for": {"task": task[:200],
                             "datasets": queried if queried is not None else datasets[:10],
                             "datasets_named_by_the_paper": datasets[:10],
                             "datasets_never_queried": (
                                 [d for d in datasets if d not in (queried or [])]
                                 if queried is not None else None),
                             "queries": sota_queries[:20] if queried is not None else None,
                             "query_family": "sota",
                             "gate": ("a candidate must name one of this paper's benchmarks, or "
                                      "overlap the task in at least two content words"),
                             "ordering": ("evidence strength, then reported value "
                                          f"({direction})" if direction else
                                          "evidence strength, then retrieval order — no metric "
                                          "direction was declared, so a reported number could not "
                                          "be read as better or worse and was not used to rank")},
            "rejected_off_topic": rejected[:20],
            "retrieval_coverage": cov or "UNDECLARED",
            "absence_means": (
                "nothing: retrieval coverage is " + str(cov or "UNDECLARED") + ", so an empty "
                "candidate list is a fact about this search and not about the field"
                if not uniq else None),
            "note": ("Reported numbers only. A candidate becomes `established` when it has been "
                     "run here and graded RL3+, which is the only state in which our measured "
                     "number and its number are comparable."),
        }

    def _attempt(self, url: str, timebox: float, ctx: Context):
        codes: list[str] = []
        tmp = Path(tempfile.mkdtemp(prefix="rf-repro-"))
        try:
            r = subprocess.run(["git", "clone", "--depth", "1", url, str(tmp / "repo")],
                               capture_output=True, text=True, timeout=min(600, timebox))
            if r.returncode != 0:
                codes.append("NO_CODE")
                return "RL0", codes, {"rationale": f"clone failed: {r.stderr[-200:]}"}
            repo = tmp / "repo"
            rev = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                                 capture_output=True, text=True).stdout.strip()
            reqs = [p for p in ("requirements.txt", "pyproject.toml", "environment.yml", "setup.py")
                    if (repo / p).exists()]
            if not reqs:
                codes.append("CONFIG_AMBIGUOUS")
            readme = next((p for p in repo.iterdir()
                           if p.name.lower().startswith("readme")), None)
            has_repro_section = bool(readme and re.search(
                r"^#+.*(reproduc|replicat|results)", readme.read_text(errors="replace"), re.I | re.M))
            codes.append("HARDWARE_UNAVAILABLE")
            return "RL0", codes, {
                "rationale": ("repository cloned and inspected; execution not attempted because no "
                              "isolated runtime was available. RL0 = not reproduced, not "
                              "'not reproducible'."),
                "env_digest": f"# repo={url}\n# revision={rev}\n# dep_files={reqs}\n",
                "revision": rev, "dependency_files": reqs,
                "readme_has_reproduction_section": has_repro_section}
        except subprocess.TimeoutExpired:
            codes.append("TIMEBOX_EXCEEDED")
            return "RL0", codes, {"rationale": "clone exceeded the time box"}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _remediation(self, codes):
        # Priorities here are not guesses. A 20-paper probe (docs/study/FINDINGS.md,
        # 2026-08-11, seed 20260811) found DEPENDENCY_UNRESOLVABLE to be the single
        # largest addressable failure class, and within it pinned torch/CUDA wheels
        # absent from PyPI dominated. That is why the dependency remediations below
        # are specific about *which* index to reach for rather than saying "fix the
        # dependencies". NO_CODE and CONFIG_AMBIGUOUS together accounted for 40% of
        # that sample and have no engineering remedy at all — they are what the
        # degradation path exists for.
        table = {
            "CHECKPOINT_MISSING": ("locate a weight mirror or contact the authors", 0.0, 2.0),
            "HARDWARE_UNAVAILABLE": ("rent a GPU instance, or run the paper's reduced setting", 20.0, 1.0),
            "DATA_ACCESS_GATED": ("submit the dataset access application", 0.0, 72.0),
            # Corrected 2026-08-11. The A' arm (docs/study/APRIME_FINDINGS.md) built
            # and tested the "dependency time machine" this table used to recommend:
            # a date-pinned index snapshot and a multi-version interpreter pool. On the
            # same 20 papers it produced ZERO real lift. The date snapshot helped one
            # paper; the interpreter pool helped none; the apparent gain from switching
            # resolvers evaporated under a real install, because a dry-run does not run
            # setup.py. What actually blocks these repos is a CUDA build toolchain —
            # flash-attn and its class import torch at build time and then compile.
            "DEPENDENCY_UNRESOLVABLE": (
                "the blocker is almost always a CUDA extension package (flash-attn, "
                "xformers, deepspeed) that compiles at install time: install torch first, "
                "retry with --no-build-isolation, and above all supply a prebuilt wheel "
                "matched to the torch/CUDA/Python triple. A date-pinned index does NOT "
                "fix this — that was tested and it did not work", 0.0, 2.0),
            "CONFIG_AMBIGUOUS": (
                "no environment specification exists anywhere in the tree; this is not "
                "fixable by tooling. Contact the authors or accept the degraded mode",
                0.0, 4.0),
            "NO_CODE": ("search for a credible third-party reimplementation", 0.0, 2.0),
        }
        out = []
        for c in dict.fromkeys(codes):
            if c in table:
                a, usd, hrs = table[c]
                out.append({"failure_code": c, "action": a, "est_cost_usd": usd, "est_hours": hrs})
        return out

    def _license(self, rankings):
        lines = ["# License and reuse risk", ""]
        if not rankings:
            lines.append("- no repository located; nothing to assess")
        for r in rankings:
            lines.append(f"- {r['url']}: license NOT inspected. Inspect LICENSE at the exact commit "
                         f"before vendoring, and record commit + license in a dependency lock.")
        lines += ["", "Permissive, non-commercial, share-alike and custom responsible-use terms are "
                      "materially different. Treat every upstream asset as reference-only until a "
                      "project-specific review is complete."]
        return "\n".join(lines)


@register
class ReproductionFallbackPlanner(Skill):
    name = "reproduction-fallback-planner"

    MODE = {"RL4": "CM_MEASURED", "RL3": "CM_MEASURED", "RL2": "CM_RELATIVE",
            "RL1": "CM_REPORTED", "RL0": "CM_NONE"}
    MODES = {
        "RL4": ["extend_generalize", "replace_simplify", "combine_transfer", "explain_diagnose",
                "benchmark_evaluate", "systemize"],
        "RL3": ["extend_generalize", "replace_simplify", "combine_transfer", "explain_diagnose",
                "benchmark_evaluate", "systemize"],
        "RL2": ["extend_generalize", "replace_simplify", "combine_transfer", "explain_diagnose",
                "benchmark_evaluate", "systemize"],
        "RL1": ["explain_diagnose", "benchmark_evaluate", "systemize", "combine_transfer"],
        "RL0": ["explain_diagnose", "benchmark_evaluate"],
    }
    DISCLOSURE = {
        "CM_REPORTED": ("The comparison baseline was not reproduced locally (level {lvl}). All "
                        "comparisons are against numbers as reported by the original authors, under "
                        "a different environment. Observed shortfalls: {codes}."),
        "CM_RELATIVE": ("Only reduced-scale reproduction was achieved (level {lvl}). Comparisons are "
                        "relative, under identical environment and seeds; published absolute values "
                        "are not comparable to these runs."),
        "CM_NONE": ("The source artifact could not be reproduced (level {lvl}; {codes}). No "
                    "comparative performance claim is made in this work."),
    }

    def execute(self, ctx: Context) -> SkillResult:
        report = ctx.store.read(self.name, "source_repro_report")
        codes = ctx.store.read(self.name, "repro_failure_taxonomy", default=[])
        lvl = report.get("level", "RL0")
        mode = self.MODE[lvl]
        modes = self.MODES[lvl]
        code_list = ", ".join(sorted({c["code"] for c in codes})) or "none recorded"

        remediations = report.get("remediation_candidates", [])
        warnings = []
        if remediations:
            warnings.append(
                "recoverable causes were identified before accepting the degraded mode: "
                + "; ".join(f"{r['failure_code']} -> {r['action']} (~{r['est_hours']}h, "
                            f"${r['est_cost_usd']:.0f})" for r in remediations)
                + ". Accepting a lower comparison mode while a cheap remediation exists is a choice, "
                  "and it is recorded as one.")
        if mode == "CM_NONE":
            warnings.append(
                "RL0 is not a terminal state. Comparative performance claims are closed off, but "
                "diagnostic and evaluation-methodology directions remain open — and the failure "
                "taxonomy just produced is itself evidence for them.")

        disclosure = self.DISCLOSURE.get(mode)
        cm = {
            "mode": mode,
            "derived_from_level": lvl,
            "derived_from_report_id": report.get("assessed_at_run_id"),
            "admissible_idea_modes": modes,
            "forbidden_claim_patterns": self._forbidden(mode),
            "disclosure_required": {
                "required": mode != "CM_MEASURED",
                "text_template": (disclosure.format(lvl=lvl, codes=code_list) if disclosure else ""),
                "must_appear_in": ["experimental setup", "limitations"] if disclosure else [],
            },
            "substitute_baseline": None,
            "approved_by": None,
            "autonomous_decision_id": f"auto-{ctx.run_id}" if ctx.mode == "auto" else None,
        }
        ctx.store.write(self.name, "comparison_mode", cm)
        ctx.store.write(self.name, "idea_mode_constraints", {
            "level": lvl, "admissible": modes,
            "closed_off": [m for m in self.MODES["RL4"] if m not in modes],
            "rationale": f"derived from reproduction level {lvl}",
        })
        ctx.store.append_jsonl(self.name, "fallback_decision_log", [{
            "ts": time.time(), "run_id": ctx.run_id, "level": lvl, "mode": mode,
            "closed_modes": [m for m in self.MODES["RL4"] if m not in modes],
            "failure_codes": sorted({c["code"] for c in codes}),
            "remediations_offered": remediations,
            "decided_by": "auto" if ctx.mode == "auto" else "pending_human_ack",
        }])
        return SkillResult(self.name,
                           produced=["comparison_mode", "idea_mode_constraints", "fallback_decision_log"],
                           warnings=warnings, next_state="REPRO_LEVEL_ESTABLISHED",
                           detail={"level": lvl, "comparison_mode": mode, "admissible_modes": modes})

    def _forbidden(self, mode):
        if mode == "CM_NONE":
            return ["outperforms", "improves over", "achieves higher", "state-of-the-art",
                    "beats the baseline", "reduces error by"]
        if mode == "CM_REPORTED":
            return ["we reproduce", "our measured baseline", "under identical conditions"]
        if mode == "CM_RELATIVE":
            return ["absolute comparison with published values", "state-of-the-art"]
        return []
