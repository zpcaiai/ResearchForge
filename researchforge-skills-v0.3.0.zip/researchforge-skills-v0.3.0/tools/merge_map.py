# -*- coding: utf-8 -*-
"""v0.3.0 consolidation: 66 -> 32.

Merge rule: two skills are one skill if they always run in the same call and the
artifact between them has no other consumer. Splitting a single action across two
skills does not make the system more modular; it makes the contract wider and the
failure surface larger.

Each entry: new_name -> dict(
  stage, desc (with trigger), objective, why (rationale for the merge),
  parts = [(old_skill, sub_phase_title), ...])
"""
DELETED = {
 "multi-agent-research-team":
   "69 words, orphan, unreachable in v0.1.0. Role decomposition across agents is a runtime "
   "implementation detail of the orchestrator, not a research capability with its own contract.",
 "tool-composition-planner":
   "62 words, orphan. Overlapped tool-skill-router while saying less.",
 "tool-skill-router":
   "Premature abstraction: selecting from a large tool catalog only becomes a real problem "
   "once there is a large tool catalog. Fold back in when one exists.",
 "model-provider-router":
   "Premature abstraction: routing across providers is worth a skill when there are two "
   "providers with different data policies. Until then it is a config file.",
 "domain-skill-loader":
   "Premature abstraction: pinning domain skill versions matters once domain skills exist.",
}

MERGE = {
"paper-ingest": dict(stage="01-intake",
 desc="Use as the first action on any new paper locator. Fetches the source, normalizes text, extracts assets and falls back to visual reading when layout defeats text extraction. Trigger before any parsing or reasoning about the paper's content.",
 objective="Turn a paper locator into a normalized, anchored, machine-readable source bundle — including when the PDF fights back.",
 why="Visual reading is the fallback branch of ingestion, not a separate capability. It fires on the same input, produces artifacts only ingestion's consumers read, and choosing between the two paths is a decision inside one act of reading the paper.",
 parts=[("paper-ingest","Fetch and normalize"),("paper-html-visual-reader","Visual fallback when text extraction is unreliable")]),

"paper-model-builder": dict(stage="01-intake",
 desc="Use immediately after ingestion to turn normalized text into a structured PaperModel and to isolate the paper's contributions into independently attackable atoms. Trigger before literature expansion or weakness mining.",
 objective="Build the structured representation of the source paper, down to the level at which its individual contributions can be attacked separately.",
 why="Parsing structure and decomposing contributions were never independently useful. The section map exists so contributions can be located; the contribution atoms exist so weaknesses can be mined. Nothing consumed one without the other.",
 parts=[("paper-structure-parser","Structural parse"),("contribution-decomposer","Contribution decomposition")]),

"claim-evidence-graph": dict(stage="02-evidence",
 desc="Use when claims must be bound to the evidence supporting them — first for the source paper, later for your own manuscript. Trigger after parsing, and again whenever new experimental evidence lands.",
 objective="Maintain the evidence backbone: every claim, in the source paper and in your own writing, connected to what actually supports it.",
 why="Kept whole. This is the truth backbone of the architecture and the store outlives every stage that writes to it.",
 parts=[("paper-claim-evidence-graph","Claim extraction and evidence binding")]),

"literature-provider-manager": dict(stage="02-evidence",
 desc="Use before any literature search, novelty check or citation resolution. Manages providers, quota and credentials, and measures how much of the relevant literature was actually reachable. Trigger whenever a skill is about to assert that no prior work exists.",
 objective="Make retrieval coverage an explicit, measured quantity rather than a silent assumption.",
 why="Kept whole and deliberately separate from search. Coverage is the guarantee behind every novelty claim; folding it into the searcher would let the searcher grade its own homework.",
 parts=[("literature-provider-manager","Provider registry, quota and coverage measurement")]),

"literature-search": dict(stage="02-evidence",
 desc="Use when related work must be retrieved for a topic, claim or candidate idea, or when the user needs a comparative view of competing systems rather than a list of papers. Trigger after provider registration, never before.",
 objective="Retrieve the relevant literature, ground it in the user's own library where one exists, and render it as a comparative landscape rather than a pile of citations.",
 why="Personal-library lookup is one more retrieval provider. Landscape building is a rendering of a completed search, not a separate investigation — it consumed search output and produced only documents.",
 parts=[("literature-search","Query planning and retrieval"),("paper-library-connector","Personal library grounding"),("research-landscape-builder","Comparative landscape rendering")]),

"citation-resolver": dict(stage="02-evidence",
 desc="Use when reference strings, DOIs or arXiv ids must become canonical records with a renderable bibliography, and when the citation neighbourhood around a seed paper must be mapped. Trigger before any citation is allowed to support a claim.",
 objective="Turn reference strings into resolvable, deduplicated records, and expand outward through the citation graph to find where the field is thin.",
 why="Neighbourhood mining is what you do with resolved references, using the same provider clients and the same identity resolution. Separating them duplicated the hardest part — deciding when two references are the same work.",
 parts=[("citation-resolver","Reference resolution and bibliography"),("citation-neighborhood-miner","Citation graph expansion and thin regions")]),

"result-reproducer": dict(stage="03-reproduction",
 desc="Use when any published result must be reproduced and graded — the source paper's own results before ideation, a comparison baseline after a direction is selected, or a substitute baseline. Trigger on state EVIDENCE_EXPANDED for the source paper; nothing downstream may assume a working code base until this runs.",
 objective="Locate the artifacts behind a published result, attempt reproduction inside a time box, and grade the outcome RL0-RL4 against numbers actually read from the paper.",
 why="v0.2.0 had three skills doing one thing at three points in the pipeline: find the repo, reproduce the source paper, reproduce the comparison baseline. The mechanism is identical — the only difference is which paper you point it at, which the ReproductionLevel schema already carries as `target_kind`. Three copies of the hardest procedure in the system was three places for it to drift.",
 parts=[("baseline-repo-finder","Artifact discovery"),("source-result-reproducer","Time-boxed tiered reproduction and RL grading"),("baseline-reproduction-auditor","Comparison-baseline mode")]),

"reproduction-fallback-planner": dict(stage="03-reproduction",
 desc="Use immediately after result-reproducer, before ideation. Converts the achieved reproduction level into the comparative claims and innovation modes that remain admissible. Trigger whenever RL is established or re-established.",
 objective="Turn 'we could not fully reproduce the paper' from a terminal state into a constraint.",
 why="Kept deliberately separate from the reproducer. Measurement and policy must not live in the same skill, or the thing that decides what counts as success is also the thing that reports it.",
 parts=[("reproduction-fallback-planner","RL to comparison mode and admissible idea modes")]),

"idea-seed-miner": dict(stage="04-innovation",
 desc="Use when contributions are decomposed, the literature is mapped and coverage is measured, and you need innovation seeds grounded in evidence rather than in guessing. Runs three mining modes — weakness, gap and analogy. Trigger as the first stage of the innovation engine.",
 objective="Produce evidenced innovation seeds from three complementary angles: what the paper assumes, what the field has not covered, and what transfers from elsewhere.",
 why="Three mining passes emitting the same kind of object into the same consumer. Keeping them apart made the portfolio generator depend on three skills to get one list, and let a run silently skip a mode without anything noticing. As modes of one skill, mode coverage becomes checkable.",
 parts=[("assumption-weakness-miner","Mode A — assumptions, failure modes and blind spots"),
        ("novelty-gap-miner","Mode B — evidenced gaps in the literature"),
        ("cross-domain-analogy-miner","Mode C — cross-domain mechanism transfer")]),

"idea-portfolio-generator": dict(stage="04-innovation",
 desc="Use when seed mining is complete and multiple candidate directions must be generated under the constraints the reproduction level imposes, including variants recombined from existing candidates and prior findings. Trigger before any single idea is committed to.",
 objective="Generate a materially diverse portfolio of candidate directions, each with a falsifiable hypothesis, an exact delta, a minimum experiment and explicit kill criteria.",
 why="Mutation is a generation strategy, not a separate stage. It read the same seeds, wrote the same candidate objects, and existed mainly to be run again after the first batch clustered too tightly.",
 parts=[("idea-portfolio-generator","Candidate generation across innovation modes"),
        ("genetic-idea-mutator","Recombination and mutation of existing candidates")]),

"idea-evaluator": dict(stage="04-innovation",
 desc="Use when candidate ideas need evidenced novelty verdicts with their closest prior work named, and honest cost, dependency-risk and data-availability scores with uncertainty kept separate. Trigger for every candidate before ranking.",
 objective="Establish, per candidate, whether it is actually new and whether it can actually be done — as two separately reported judgments.",
 why="Novelty and feasibility were always computed together and consumed together by exactly one skill. Merging keeps them adjacent while preserving the thing that matters: they remain two scores, never collapsed into one.",
 parts=[("novelty-verifier","Novelty verification and closest prior work"),
        ("feasibility-estimator","Feasibility, uncertainty and resource planning")]),

"idea-ranker": dict(stage="04-innovation",
 desc="Use when candidates have novelty and feasibility evidence and must be ordered for human decision. Trigger before the selection gate; hard user constraints are filters here, not preferences.",
 objective="Order candidate directions across multiple criteria and name the tradeoff that decided the ordering.",
 why="Kept whole. Ranking is a pure function over evaluations, independently testable, and the one place where a subtle scoring error changes the entire project's direction.",
 parts=[("idea-ranker","Multi-criteria ranking and Pareto front")]),

"user-feedback-gate": dict(stage="04-innovation",
 desc="Use when ranked directions are ready and the human must choose, merge, constrain or reject before expensive work begins. Trigger in guided mode always; in auto mode, record an autonomous decision artifact instead.",
 objective="Stop the machine at the one decision a human should make, and accept merges and constraints without losing the candidates not chosen.",
 why="Kept whole. This is the highest-value skill in the package and the reason the system is not just another autonomous idea generator.",
 parts=[("user-feedback-gate","Human selection, merge and constraint")]),

"research-blueprint-compiler": dict(stage="05-planning",
 desc="Use when a direction has been selected and must become an executable plan: stages, budgets, acceptance criteria, falsifiable experiment specifications and the ablations that isolate the claimed mechanism. Trigger immediately after selection.",
 objective="Compile a selected direction into experiments that can actually be run and that can actually fail.",
 why="The blueprint, the experiment specs and the ablation plan were one act of planning split three ways. An experiment spec without its ablations cannot support a causal claim, so the two were never separable in practice.",
 parts=[("research-blueprint-compiler","Blueprint and acceptance criteria"),
        ("experiment-spec-author","Falsifiable experiment specifications"),
        ("ablation-and-counterfactual-planner","Ablations and counterfactual controls")]),

"evaluator-builder": dict(stage="05-planning",
 desc="Use when scoring must be defined and decisive tests kept outside the agent's reach. Trigger before experiments run, and re-trigger whenever the metric definition changes.",
 objective="Define what the score means and keep the tests that decide it isolated from whatever is being scored.",
 why="Kept whole and separate on purpose. This is a security boundary, not a planning step; merging it into the blueprint would put the grader inside the thing it grades.",
 parts=[("metric-and-hidden-evaluator-builder","Metric semantics and hidden evaluator isolation")]),

"sandbox-provisioner": dict(stage="00-runtime",
 desc="Use before any generated or untrusted code executes, and whenever an evaluator must stay invisible to the agent being evaluated. Trigger at run setup, not at first execution.",
 objective="Provide a pinned, least-privilege execution environment, and keep the grader context out of the agent's reach.",
 why="Kept whole. It is provisioned in phase 0 — reproduction needs it long before any experiment spec exists — which is precisely why v0.2.0's edge from experiment specs into the sandbox was a genuine design error.",
 parts=[("sandbox-provisioner","Environment provisioning and evaluator isolation")]),

"codebase-scaffolder": dict(stage="06-execution",
 desc="Use when experiment specs must become an actual code branch with tests, and when the resulting runs fail and need bounded diagnosis rather than blind retry. Trigger after specs exist and the sandbox is provisioned.",
 objective="Turn experiment specifications into running code, and keep it running without unbounded self-debugging.",
 why="Scaffolding and repair are one loop. The debugger only ever read code the scaffolder wrote, and separating them made 'stop trying' a decision with no owner.",
 parts=[("codebase-scaffolder","Scaffolding from specs"),
        ("debug-and-repair","Bounded diagnosis and repair")]),

"experiment-runner": dict(stage="06-execution",
 desc="Use when experimental branches must be explored under a budget, every run recorded, and every artifact given lineage. Trigger after scaffolding; a number that never entered the ledger cannot enter the manuscript.",
 objective="Execute the search over experimental branches, and make every resulting number traceable to the code, config, data, seed and environment that produced it.",
 why="The ledger and the provenance log were two views of one append-only event stream, and the tree search was the only thing writing to them. Three skills, one write path — which is exactly how a metric ends up in a paper without a matching ledger entry.",
 parts=[("experiment-tree-search","Branch search and pruning"),
        ("experiment-ledger","Run ledger"),
        ("artifact-provenance","Artifact lineage")]),

"data-analyst": dict(stage="07-analysis",
 desc="Use when raw data must be profiled, cleaned, split and leakage-checked, and when experiment results must become computed answers, diagnostic plots and an analyst-grade narrative. Trigger before any result is interpreted.",
 objective="Prepare the data honestly, then analyse it, keeping every transformation on the record.",
 why="Preparation and analysis shared the leakage question, which is the only question either of them gets seriously wrong. Splitting them let a leak be introduced in one skill and go unnoticed in the other.",
 parts=[("data-prep-agent","Profiling, cleaning, splitting, leakage checks"),
        ("data-analysis-agent","Analysis, plots and narrative")]),

"integrity-auditor": dict(stage="07-analysis",
 desc="Use before any result is allowed to become a claim, and when repeated trials must be aggregated into an honest keep-or-kill decision. Trigger on every analysis output.",
 objective="Check that the statistics support what is about to be claimed, and aggregate repeated runs without letting the best one speak for the rest.",
 why="Meta-analysis is where selective reporting actually happens, so the skill that aggregates repeated trials and the skill that detects cherry-picking belong in the same place with the same view of the raw runs.",
 parts=[("statistical-integrity-auditor","Statistical validity audit"),
        ("result-meta-analyzer","Aggregation across repeated trials")]),

"finding-memory": dict(stage="07-analysis",
 desc="Use when evidence across the run must be distilled into durable findings that later stages and later projects can read, including the failures and null results worth keeping. Trigger at every evidence lock point, and before any failed branch is discarded.",
 objective="Keep what was learned, including — especially — what did not work and where the method stops working.",
 why="Negative results are findings with a tag, not a separate store. Separating them was how negative results got curated into a file nobody read.",
 parts=[("finding-memory-manager","Finding distillation and memory graph"),
        ("negative-result-curator","Negative results and boundary conditions")]),

"manuscript-builder": dict(stage="08-writing",
 desc="Use when evidence is locked and the paper must be built — first its central argument, then prose written against that argument and the evidence behind it. Trigger only after evidence lock.",
 objective="Build the paper's argument first and write to it, so that no sentence exists without a claim behind it and no claim without evidence.",
 why="The spine exists solely to constrain the draft. Two skills meant the draft could be regenerated without regenerating the spine it was supposed to obey, which is precisely how evidence-free prose gets in.",
 parts=[("manuscript-spine-builder","Argument spine and section blueprint"),
        ("paper-drafter","Evidence-bound drafting")]),

"claim-citation-auditor": dict(stage="08-writing",
 desc="Use when a draft exists and every claim must be checked against its cited source or experiment record, and as the final pre-submission verdict on whether anything unsupported survived. Trigger before any submission or release; citation existence is not citation support.",
 objective="Verify that each claim is supported by what it points at, and refuse to pass a manuscript in which any high-severity finding is unresolved.",
 why="The integrity gate was reading the citation auditor's output and re-deciding the same question. One skill, one verdict, with the gate as its final step — because two skills meant two thresholds and the lower one wins.",
 parts=[("claim-citation-auditor","Claim extraction and support verification"),
        ("paper-quality-integrity-gate","Pre-submission verdict")]),

"review-simulator": dict(stage="08-writing",
 desc="Use when a draft needs adversarial pre-submission review against a target venue, and when reviews — simulated or real — must be triaged into a prioritized revision and response plan. Trigger after the citation audit passes.",
 objective="Attack the manuscript the way a reviewer will, then turn what survives into a plan rather than a list of complaints.",
 why="Generating a review and acting on one are the same competence pointed in two directions, and they were the only consumers of each other's output.",
 parts=[("journal-fit-reviewer","Adversarial review against the venue"),
        ("rebuttal-and-revision-planner","Concern triage, revision matrix and response")]),

"figure-factory": dict(stage="09-visuals",
 desc="Use when the argument determines which figures must exist, and each must become a publication-quality, semantically editable vector figure — whether drawn from data, reconstructed from an existing raster, or both. Trigger after the data behind each figure is audited.",
 objective="Produce the figures the argument requires, as editable vector artifacts bound to the claims they support.",
 why="Four skills for one pipeline: decide what the figure must say, draw it, and make it editable — where two of the four ('refine to editable SVG' and 'reconstruct a raster into vectors') were the same job reached from different inputs.",
 parts=[("figure-storyboard","What each figure must say"),
        ("scientific-figure-generator","Figure generation"),
        ("vector-figure-reconstructor","Raster to vector reconstruction"),
        ("editable-svg-refiner","Semantic labelling and editability validation")]),

"deck-factory": dict(stage="10-slides",
 desc="Use when a defense or talk must be produced as native editable PowerPoint objects, with every quantitative element on every slide bound to a project artifact. Trigger once the manuscript's evidence is locked.",
 objective="Turn the locked evidence into a defense narrative and then into a real, editable deck in which every number can be traced back.",
 why="Evidence mapping was a step between storyline and generation with no other consumer. Three skills made it possible to generate a deck that skipped the mapping entirely — which is the exact failure the mapping exists to prevent.",
 parts=[("defense-ppt-storyline","Narrative, slide spec and timing"),
        ("paper-to-ppt-evidence-mapper","Slide element to artifact binding"),
        ("defense-ppt-generator","Native PPTX generation and render QA")]),

"project-repo-manager": dict(stage="00-runtime",
 desc="Use at project start and at every milestone. Trigger to create the quest repository, pin sources, route ideas to branches and preserve failed paths.",
 objective="One research quest, one Git repository — with competing directions on branches and failed paths kept until their findings are distilled.",
 why="Kept whole. Long-horizon projects live or die on their ability to resume, and the repository is where that lives.",
 parts=[("project-repo-manager","Repository, branches and checkpoints")]),

"release-gate": dict(stage="11-release",
 desc="Use when the project claims to be finished. Trigger to verify every gate, package the deliverables, and refuse release while any critical gate remains open.",
 objective="Refuse to ship a project whose claims outrun its evidence, and package what does ship with the provenance to check it.",
 why="Kept whole. This is the last place a fabricated number can be caught.",
 parts=[("release-gate-exporter","Gate verification, packaging and export")]),

"researchforge-orchestrator": dict(stage="00-runtime",
 desc="Use when the user supplies a paper and wants the full paper-to-innovation-to-manuscript run. Owns the state machine, enforces reproduction before ideation, supervises budget and pace, and stops at the human selection gate in guided mode.",
 objective="Drive the research lifecycle as a gated state machine that can be killed and resumed without losing or inventing evidence.",
 why="Budget supervision, stall detection and resume semantics are the state machine's own mechanics. As a separate skill they described a controller with no authority over the thing it was controlling.",
 parts=[("researchforge-orchestrator","State machine and stage gating"),
        ("research-progress-controller","Budget, pace, alerts and resume")]),

"retrospective-benchmark-builder": dict(stage="12-meta",
 desc="Use when you need to measure whether ResearchForge produces good research directions. Builds a benchmark from older seed papers paired with the follow-up work actually published afterwards. Trigger before tuning the innovation engine.",
 objective="Give the system a way to be wrong measurably.",
 why="Kept whole, on the offline maintenance entry point.",
 parts=[("retrospective-benchmark-builder","Benchmark construction and contamination control")]),

"research-eval-harness": dict(stage="12-meta",
 desc="Use when the ResearchForge system itself must be measured against a task suite. Trigger before and after any change to the innovation engine or to a skill.",
 objective="Run the system against a frozen task suite and produce comparable scores across versions.",
 why="Kept whole, on the offline maintenance entry point.",
 parts=[("research-eval-harness","System-level evaluation runs")]),

"skill-evolution-manager": dict(stage="12-meta",
 desc="Use when accumulated run traces suggest a skill should change, or when the package's own structure and contracts need auditing. Trigger offline only; a candidate edit is promoted only if it improves held-out performance without regressing any guardrail.",
 objective="Change the system's own skills only when a held-out evaluation says the change is an improvement.",
 why="Auditing the package and proposing edits to it are the same loop; the audit existed to feed the evolution manager and had no other consumer.",
 parts=[("skill-package-auditor","Package and contract audit"),
        ("skill-evolution-manager","Bounded edit, held-out evaluation, promotion")]),
}
