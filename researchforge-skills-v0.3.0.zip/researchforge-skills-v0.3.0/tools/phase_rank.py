# -*- coding: utf-8 -*-
"""Phase rank = position in the research run's build order.

An edge consumer<-producer with rank(producer) < rank(consumer) is a BUILD
dependency. An edge in the other direction is a runtime FEEDBACK edge: a real
read that happens on a later iteration of a loop. Feedback edges are declared
explicitly with the `feedback:` prefix and are excluded from depends_on, so the
build graph stays an acyclic, orderable DAG while the design stays honest about
its loops.
"""
RANK = {
 # phase 0 — run scaffolding, provisioned before any paper work
 "project-repo-manager":0, "research-progress-controller":0, "artifact-provenance":0,
 "tool-composition-planner":0, "tool-skill-router":1, "model-provider-router":2,
 "domain-skill-loader":0, "multi-agent-research-team":0, "sandbox-provisioner":0,
 # intake
 "paper-ingest":3, "paper-html-visual-reader":4,
 "paper-structure-parser":5, "contribution-decomposer":6,
 # evidence
 "literature-provider-manager":7,
 "literature-search":8, "paper-library-connector":8,
 "citation-resolver":9, "citation-neighborhood-miner":10,
 "research-landscape-builder":11, "paper-claim-evidence-graph":11,
 # reproduction FIRST — before any ideation
 "baseline-repo-finder":12,
 "source-result-reproducer":13,
 "reproduction-fallback-planner":14,
 # innovation
 "assumption-weakness-miner":15, "novelty-gap-miner":16, "cross-domain-analogy-miner":17,
 "idea-portfolio-generator":18, "genetic-idea-mutator":19,
 "novelty-verifier":20, "feasibility-estimator":20,
 "idea-ranker":21, "user-feedback-gate":22,
 # planning
 "research-blueprint-compiler":23,
 "ablation-and-counterfactual-planner":24, "metric-and-hidden-evaluator-builder":24,
 "experiment-spec-author":25,
 # execution
 "experiment-ledger":26, "baseline-reproduction-auditor":27,
 "codebase-scaffolder":28, "debug-and-repair":29, "experiment-tree-search":30,
 # analysis
 "data-prep-agent":31, "data-analysis-agent":32,
 "statistical-integrity-auditor":33, "result-meta-analyzer":34,
 "negative-result-curator":35, "finding-memory-manager":36,
 # writing
 "manuscript-spine-builder":37,
 "figure-storyboard":38, "scientific-figure-generator":39,
 "vector-figure-reconstructor":40, "editable-svg-refiner":41,
 "paper-drafter":42, "claim-citation-auditor":43, "journal-fit-reviewer":44,
 "rebuttal-and-revision-planner":45, "paper-quality-integrity-gate":46,
 # slides + release
 "defense-ppt-storyline":47, "paper-to-ppt-evidence-mapper":48, "defense-ppt-generator":49,
 "release-gate-exporter":50, "researchforge-orchestrator":51,
 # offline maintenance entry point — operates on the system, not on a paper
 "retrospective-benchmark-builder":90, "research-eval-harness":91,
 "skill-package-auditor":92, "skill-evolution-manager":93,
}
