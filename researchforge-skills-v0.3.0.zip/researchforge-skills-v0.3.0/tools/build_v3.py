# -*- coding: utf-8 -*-
"""Build v0.3.0 (32 skills) from the v0.2.0 package + merge_map."""
import sys, re, json, pathlib, shutil, collections
HERE = pathlib.Path(__file__).parent; sys.path.insert(0, str(HERE))
ROOT = HERE.parent
from merge_map import MERGE, DELETED
from artifact_map import ARTIFACTS

OWNER = {p: new for new, v in MERGE.items() for p, _ in v['parts']}
RANK = {n: i for i, n in enumerate([
 "project-repo-manager","sandbox-provisioner","paper-ingest","paper-model-builder",
 "literature-provider-manager","literature-search","citation-resolver","claim-evidence-graph",
 "result-reproducer","reproduction-fallback-planner","idea-seed-miner","idea-portfolio-generator",
 "idea-evaluator","idea-ranker","user-feedback-gate","research-blueprint-compiler",
 "evaluator-builder","codebase-scaffolder","experiment-runner","data-analyst",
 "integrity-auditor","finding-memory","manuscript-builder","figure-factory",
 "claim-citation-auditor","review-simulator","deck-factory","release-gate",
 "researchforge-orchestrator"])}
RANK.update({"retrospective-benchmark-builder":90,"research-eval-harness":91,"skill-evolution-manager":92})

ART = {}
for aid, (prod, path, schema, desc) in ARTIFACTS.items():
    if prod in DELETED: continue
    ART[aid] = dict(producer=OWNER[prod], path=path, schema=schema, description=desc)

g = json.loads((ROOT/'manifests/artifact-graph.json').read_text())
raw_in, raw_ext = collections.defaultdict(set), collections.defaultdict(set)
for old, v in g['consumers'].items():
    if old in DELETED: continue
    new = OWNER[old]
    for a in v['artifacts'] + v['feedback']:
        if a in ART: raw_in[new].add(a)
    for e in v['external']: raw_ext[new].add(e)

consumers = collections.defaultdict(set)
for n, s in raw_in.items():
    for a in s: consumers[a].add(n)
TERMINAL = {"release_bundle","release_manifest","release_report","defense_deck","deck_manifest",
            "speaker_notes","manuscript_draft","manuscript_pdf","bibliography","research_state",
            "quest_repo","findings","evidence_graph","experiment_ledger","artifact_manifest",
            "provenance_log","idea_portfolio","ranked_ideas","selected_direction","research_blueprint",
            "paper_model","comparison_mode","source_repro_report","coverage_report","decision_log"}
internal = {}
for aid, v in list(ART.items()):
    cs = consumers.get(aid, set())
    if aid in TERMINAL: continue
    if (cs and cs == {v['producer']}) or not cs:
        internal.setdefault(v['producer'], []).append(aid); del ART[aid]
for n in raw_in: raw_in[n] = {a for a in raw_in[n] if a in ART and ART[a]['producer'] != n}

build, feed = {}, {}
for n in MERGE:
    ins = sorted(raw_in.get(n, []))
    build[n] = [a for a in ins if RANK[ART[a]['producer']] < RANK[n]]
    feed[n]  = [a for a in ins if RANK[ART[a]['producer']] >= RANK[n]]
deps = {n: sorted({ART[a]['producer'] for a in build[n]}) for n in MERGE}

def sec(t, h, nx):
    m = re.search(rf'## {re.escape(h)}\n(.*?)\n## {re.escape(nx)}', t, re.S)
    return m.group(1).strip() if m else ''
def bullets(s):
    return [re.sub(r'^[-*]\s*','',l).strip() for l in s.split('\n') if l.strip().startswith(('-','*'))]
def steps(s):
    out, cur = [], None
    for l in s.split('\n'):
        if re.match(r'^\s*\d+\.\s', l):
            if cur: out.append(cur)
            cur = re.sub(r'^\s*\d+\.\s*','',l).rstrip()
        elif cur is not None and l.strip(): cur += "\n   " + l.strip()
        elif cur is not None and not l.strip(): out.append(cur); cur = None
    if cur: out.append(cur)
    return out

BOILER_EXEC = ("This skill is an **execution contract for an agent/coding runtime**, not proof that "
 "the corresponding application code already exists. When used to build the ResearchForge system, the "
 "agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.")
BOILER_EV = ("When this skill executes in a real project, persist an evidence record containing: skill "
 "version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test "
 "results, warnings, model/provider identity when relevant, git SHA when code changed, and human "
 "approvals when a gate required them.")
BOILER_FAIL = ("Fail closed for integrity, provenance, evaluator isolation, citation support, or "
 "baseline-comparability problems. For recoverable execution errors, create a structured failure record "
 "rather than degrading the honesty of the report.")

old_bodies = {}
for p in (ROOT/'skills').glob('*/SKILL.md'):
    t = p.read_text(); old_bodies[re.search(r'^name: (.+)$', t, re.M).group(1)] = t

outdir = ROOT/'skills_v3'
if outdir.exists(): shutil.rmtree(outdir)
for n, v in MERGE.items():
    (outdir/n).mkdir(parents=True)
    outs = sorted([a for a in ART if ART[a]['producer'] == n])
    gates, tests, proc = [], [], []
    for old, title in v['parts']:
        t = old_bodies[old]
        st = steps(sec(t,'Procedure','Hard gates'))
        if st: proc.append((title, st))
        gates += bullets(sec(t,'Hard gates','Verification / tests'))
        tests += bullets(sec(t,'Verification / tests','Evidence contract'))
    def dedup(xs):
        seen, out = set(), []
        for x in xs:
            k = re.sub(r'\W+','',x.lower())[:70]
            if k in seen: continue
            seen.add(k); out.append(x)
        return out
    gates, tests = dedup(gates), dedup(tests)

    L = ["---", f"name: {n}", f"description: {v['desc']}", "version: 0.3.0",
         f"stage: {v['stage']}", "artifact_kind: workflow-skill",
         "implementation_status: specification-ready",
         "consolidates: [" + ", ".join(p for p,_ in v['parts']) + "]", "---\n",
         f"# {n}\n", "## Objective\n", v['objective'] + "\n"]
    L.append(("**Consolidates v0.2.0 skills** " + ", ".join(f"`{p}`" for p,_ in v['parts']) + ".\n")
             if len(v['parts'])>1 else f"**Unchanged from v0.2.0** (`{v['parts'][0][0]}`).\n")
    L += [v['why'] + "\n", BOILER_EXEC + "\n", "## Inputs\n"]
    body = ([f"- `{a}`" for a in build[n]] + [f"- `{e}`" for e in sorted(raw_ext.get(n,[]))]
            + [f"- `feedback: {a}`" for a in feed[n]])
    L.append("\n".join(body) if body else "- `external: none`")
    L += ["\n## Outputs\n", "\n".join(f"- `{a}`" for a in outs) if outs else "- none",
          "\n## Depends on\n",
          "*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*\n",
          "\n".join(f"- `{d}`" for d in deps[n]) if deps[n] else "- None; this skill consumes only external inputs.",
          "\n## Procedure\n"]
    if len(proc) == 1:
        L.append("\n".join(f"{i}. {s}" for i, s in enumerate(proc[0][1], 1)))
    else:
        for k, (title, st) in enumerate(proc):
            L.append(f"### {chr(65+k)}. {title}\n")
            L.append("\n".join(f"{i}. {s}" for i, s in enumerate(st, 1)) + "\n")
    L += ["\n## Hard gates\n", "\n".join(f"- {x}" for x in gates),
          "\n## Verification / tests\n", "\n".join(f"- {x}" for x in tests)]
    if internal.get(n):
        L += ["\n## Internal artifacts\n",
              "Produced and consumed entirely inside this skill. They no longer cross a skill boundary, "
              "so they are not part of the public artifact contract — but they are still written to disk "
              "and still carry provenance.\n",
              "\n".join(f"- `{a}` — {ARTIFACTS[a][3]} (`{ARTIFACTS[a][1]}`)" for a in sorted(internal[n]))]
    L += ["\n## Evidence contract\n", BOILER_EV, "\n## Failure behavior\n", BOILER_FAIL,
          "\n## Upstream inspiration (conceptual, not vendored text)\n",
          "See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow "
          "wording and references upstream projects by URL/role instead of copying their text.\n"]
    (outdir/n/'SKILL.md').write_text("\n".join(L))

json.dump({"artifacts":ART,"internal_artifacts":{k:sorted(x) for k,x in internal.items()},
  "consumers":{n:{"artifacts":build[n],"external":sorted(raw_ext.get(n,[])),"feedback":feed[n]} for n in MERGE},
  "depends_on":deps}, open(ROOT/'manifests/artifact-graph.json','w'), ensure_ascii=False, indent=1)
json.dump({"version":"0.3.0","from_version":"0.2.0",
  "merged":{n:{"parts":[p for p,_ in v['parts']],"rationale":v['why']} for n,v in MERGE.items()},
  "deleted":DELETED}, open(ROOT/'manifests/merge-map.json','w'), ensure_ascii=False, indent=2)
print(f"{len(MERGE)} skills | {len(ART)} public artifacts "
      f"({sum(len(x) for x in internal.values())} internalized) | "
      f"{sum(len(v) for v in feed.values())} feedback edges")
