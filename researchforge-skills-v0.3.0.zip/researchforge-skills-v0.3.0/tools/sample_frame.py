#!/usr/bin/env python3
"""Draw a frozen, stratified random sample from a reproduction-study frame.

The frame is a CSV you build once from a single venue+year (OpenReview's API
enumerates accepted papers completely, which is the point — it stops you from
sampling the papers you happen to remember).

Required frame columns:
  paper_id,title,url,code_url,code_availability,compute_class
    code_availability : official | third_party | none
    compute_class     : lt10min | 10to60min

Usage:
  python tools/sample_frame.py --frame frame.csv --n 20 --seed 20260811 --out sample.csv
"""
import argparse, csv, random, collections, sys

QUOTA = {("official","lt10min"):7, ("official","10to60min"):7,
         ("third_party","lt10min"):2, ("third_party","10to60min"):1,
         ("none","lt10min"):2,        ("none","10to60min"):1}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frame", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--n", type=int, default=20); ap.add_argument("--seed", type=int, required=True)
    a = ap.parse_args()

    rows = list(csv.DictReader(open(a.frame, encoding="utf-8")))
    if not rows: sys.exit("empty frame")
    strata = collections.defaultdict(list)
    for r in rows: strata[(r["code_availability"], r["compute_class"])].append(r)

    rng = random.Random(a.seed)
    picked, shortfall = [], []
    for k, want in QUOTA.items():
        pool = strata.get(k, [])
        if len(pool) < want:
            shortfall.append((k, want, len(pool)))
            picked += pool
        else:
            picked += rng.sample(pool, want)
    # backfill only from strata that still have unused rows, at random
    if len(picked) < a.n:
        rest = [r for r in rows if r not in picked]
        picked += rng.sample(rest, min(a.n - len(picked), len(rest)))

    for i, r in enumerate(picked, 1):
        r["sample_index"] = i; r["draw_seed"] = a.seed
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(picked[0].keys())); w.writeheader(); w.writerows(picked)

    print(f"drew {len(picked)} papers from a frame of {len(rows)}, seed={a.seed}")
    for k, want, have in shortfall:
        print(f"  WARNING stratum {k}: wanted {want}, frame only had {have} — record this, it is data")
    print("\nThe sample is now FROZEN. Do not substitute a paper because it looks hard;")
    print("if you must substitute, log the reason and report substitutions as a separate count.")

if __name__ == "__main__": main()
