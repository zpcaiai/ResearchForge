# -*- coding: utf-8 -*-
"""Rewrite v0.1.0 SKILL.md I/O sections into the canonical artifact contract,
then DERIVE depends_on from the artifact graph."""
import sys, re, json, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from artifact_map import ARTIFACTS
from input_map import M
from phase_rank import RANK

ROOT = pathlib.Path(__file__).resolve().parents[1]

# same string means different things in different skills
DROP_INPUT = {                       # edges removed as genuine design errors
 ("sandbox-provisioner","experiment_specs"),      # a sandbox must exist before any spec does
 ("literature-provider-manager","literature_search_plan"),  # provider mgmt is upstream of search
}
PER_SKILL = {
 ("release-gate-exporter","project state"): "progress_state",
 ("statistical-integrity-auditor","analysis artifacts"): "analysis_code",
 ("figure-storyboard","evidence/analysis artifacts"): "evidence_graph",
 ("scientific-figure-generator","source data/method text"): "analysis_results",
 ("debug-and-repair","logs"): "experiment_ledger",
}

# cross-cutting wiring added in v0.2.0 (reproduction-first, coverage, self-eval)
ADD = {
 "literature-search":            ["provider_registry"],
 "citation-resolver":            ["provider_registry"],
 "citation-neighborhood-miner":  ["provider_registry"],
 "research-landscape-builder":   ["provider_registry","coverage_report"],
 "novelty-verifier":             ["coverage_report"],
 "novelty-gap-miner":            ["coverage_report"],
 "idea-portfolio-generator":     ["comparison_mode","idea_mode_constraints","source_repro_report"],
 "feasibility-estimator":        ["source_repro_report","comparison_mode"],
 "idea-ranker":                  ["coverage_report","comparison_mode"],
 "genetic-idea-mutator":         ["idea_mode_constraints"],
 "user-feedback-gate":           ["comparison_mode","ranking_rationale","idea_pareto_front"],
 "research-blueprint-compiler":  ["comparison_mode","source_repro_report"],
 "experiment-spec-author":       ["comparison_mode","ablation_plan"],
 "baseline-reproduction-auditor":["comparison_mode","source_repro_env"],
 "paper-drafter":                ["comparison_mode","bibliography","figure_plan","selected_figure","section_blueprint"],
 "claim-citation-auditor":       ["comparison_mode","draft_manifest"],
 "paper-quality-integrity-gate": ["comparison_mode","stats_audit","citation_audit","claim_audit","source_repro_report","review_triage","revision_matrix","response_to_reviewers","revision_experiment_plan"],
 "manuscript-spine-builder":     ["meta_analysis","findings","negative_findings","boundary_conditions"],
 "journal-fit-reviewer":         ["citation_audit","integrity_gate"],
 "rebuttal-and-revision-planner":["revision_backlog","manuscript_spine"],
 "figure-storyboard":            ["figure_plan","analysis_plots","analysis_results"],
 "scientific-figure-generator":  ["figure_storyboard","figure_captions"],
 "editable-svg-refiner":         ["figure_candidates","svg_reconstruction_map","reconstructed_svg"],
 "defense-ppt-storyline":        ["manuscript_spine","meta_analysis","comparison_mode"],
 "paper-to-ppt-evidence-mapper": ["slide_outline","speaker_timing","draft_manifest","experiment_ledger"],
 "defense-ppt-generator":        ["slide_evidence","editable_svg","svg_element_map","svg_validation_report"],
 "experiment-tree-search":       ["code_worktree","code_tests","implementation_plan","sandbox_manifest",
                                  "environment_lock","sandbox_container_config","evaluator_spec",
                                  "failure_diagnosis","repair_commits","debug_terminal_status",
                                  "blueprint_dag","acceptance_criteria","mutant_candidates","idea_lineage_graph"],
 "experiment-ledger":            ["evaluator_code","hidden_tests","run_index_seed" ],
 "data-analysis-agent":          ["prepared_data","data_profile","data_transform_log","experiment_tree",
                                  "ranked_branches","best_candidate"],
 "result-meta-analyzer":         ["stats_audit","stats_required_fixes"],
 "finding-memory-manager":       ["meta_analysis","meta_analysis_decision","negative_findings","boundary_conditions",
                                  "experiment_tree","assumption_tests","gap_evidence","closest_prior_work",
                                  "baseline_metrics","baseline_deviation_log","reproduction_report",
                                  "source_repro_metrics","repro_failure_taxonomy","fallback_decision_log",
                                  "citation_gap_candidates","library_hits","library_note_links",
                                  "landscape_report","system_matrix","benchmark_matrix","source_repro_plan",
                                  "quota_ledger","literature_retrieval_log","citation_resolution_report",
                                  "baseline_repo_rankings","baseline_license_risk","visual_notes","layout_warnings",
                                  "section_map","figure_table_index","paper_assets","source_manifest",
                                  "claim_registry","contribution_atoms","paper_source_file","locator_map",
                                  "literature_search_plan","analysis_report","analysis_code","tool_typed_contracts",
                                  "selected_capabilities","provider_fallback_chain","domain_install_plan",
                                  "revision_matrix","response_to_reviewers","revision_experiment_plan",
                                  "review_triage","manuscript_pdf","figure_generation_trace","speaker_notes",
                                  "deck_manifest","decision_log","branch_map","checkpoint_metadata","quest_repo"],
 "release-gate-exporter":        ["artifact_manifest","provenance_log","integrity_gate","submission_blockers",
                                  "stats_audit","citation_audit","review_report","comparison_mode",
                                  "source_repro_report","defense_deck","manuscript_draft","bibliography",
                                  "findings","finding_memory_graph","release_readiness_seed"],
 "research-eval-harness":        ["retro_benchmark","retro_benchmark_report"],
 "skill-evolution-manager":      ["eval_scorecard","eval_failure_taxonomy","skill_audit_machine_report","skill_audit_report"],
 "tool-skill-router":            ["tool_dag","tool_typed_contracts"],
 "model-provider-router":        ["tool_plan"],
 "multi-agent-research-team":    ["team_plan_seed"],
 "researchforge-orchestrator":   ["release_bundle","release_manifest","release_report","progress_state",
                                  "resume_token","progress_alerts","team_plan","agent_handoffs","model_route",
                                  "domain_skill_lock","research_blueprint","selected_direction","idea_portfolio",
                                  "ranked_ideas","paper_model","evidence_graph","comparison_mode"],
}
DROP = {"run_index_seed","release_readiness_seed","team_plan_seed"}  # placeholders, removed below

# v0.1.0 sometimes referred to an artifact by its filename; resolve those too
FILE2ID = {}
for _aid, (_p, _path, _s, _d) in ARTIFACTS.items():
    FILE2ID.setdefault(_path.split('/')[-1], _aid)
    FILE2ID.setdefault(_path, _aid)

def canon(skill, s):
    if (skill, s) in PER_SKILL: return PER_SKILL[(skill, s)]
    if s in ARTIFACTS: return s
    if s in M: return M[s]
    if s in FILE2ID: return FILE2ID[s]
    return None

def block(items):
    return "\n".join(f"- `{i}`" if not i.startswith("external:") else f"- `{i}`" for i in items)

def main():
    prod_by_skill = {}
    for aid,(p,_,_,_) in ARTIFACTS.items(): prod_by_skill.setdefault(p, []).append(aid)
    producer = {aid: v[0] for aid, v in ARTIFACTS.items()}

    inputs_by_skill = {}
    for f in sorted(ROOT.glob('skills/*/SKILL.md')):
        t = f.read_text(); n = re.search(r'^name: (.+)$', t, re.M).group(1)
        m = re.search(r'## Inputs\n(.*?)\n## Outputs', t, re.S)
        raw = [re.sub(r'^[-*]\s*','',l).strip().strip('`') for l in m.group(1).split('\n') if l.strip().startswith(('-','*'))] if m else []
        got, ext, unres = [], [], []
        for s in raw:
            if s.startswith('external:'): ext.append(s); continue
            c = canon(n, s)
            if c is None: unres.append(s)
            elif c.startswith('external:'): ext.append(c)
            else: got.append(c)
        for a in ADD.get(n, []):
            if a in DROP: continue
            if a in ARTIFACTS and a not in got and producer[a] != n: got.append(a)
        if unres: print(f"  !! {n}: unresolved {unres}")
        got = [a for a in dict.fromkeys(got)
               if producer[a] != n and (n, a) not in DROP_INPUT]
        # split build dependencies from runtime feedback edges by phase rank
        build = [a for a in got if RANK[producer[a]] < RANK[n]]
        feed  = [a for a in got if RANK[producer[a]] >= RANK[n]]
        inputs_by_skill[n] = (build, sorted(dict.fromkeys(ext)), feed)

    deps = {n: sorted({producer[a] for a in b}) for n,(b,_,_) in inputs_by_skill.items()}

    for f in sorted(ROOT.glob('skills/*/SKILL.md')):
        t = f.read_text(); n = re.search(r'^name: (.+)$', t, re.M).group(1)
        got, ext, feed = inputs_by_skill[n]
        outs = sorted(prod_by_skill.get(n, []))
        inb = block(got + ext + [f"feedback: {a}" for a in feed]) or "- `external: none`"
        outb = block(outs) or "- none"
        depb = "\n".join(f"- `{d}`" for d in deps[n]) or "- None; this skill consumes only external inputs."
        t = re.sub(r'## Inputs\n.*?\n## Outputs', f'## Inputs\n\n{inb}\n\n## Outputs', t, flags=re.S)
        t = re.sub(r'## Outputs\n.*?\n## Depends on', f'## Outputs\n\n{outb}\n\n## Depends on', t, flags=re.S)
        t = re.sub(r'## Depends on\n.*?\n## Procedure',
                   f'## Depends on\n\n*Derived from the artifact graph (`manifests/artifact-graph.json`); do not hand-edit.*\n\n{depb}\n\n## Procedure', t, flags=re.S)
        f.write_text(t)

    json.dump({"artifacts":{k:{"producer":v[0],"path":v[1],"schema":v[2],"description":v[3]} for k,v in ARTIFACTS.items()},
               "consumers":{n:{"artifacts":g,"external":e,"feedback":fb} for n,(g,e,fb) in inputs_by_skill.items()},
               "depends_on":deps},
              open(ROOT/'manifests/artifact-graph.json','w'), ensure_ascii=False, indent=1)
    print(f"rewrote {len(inputs_by_skill)} skills; {len(ARTIFACTS)} artifacts")
    return deps, inputs_by_skill

if __name__ == "__main__": main()
