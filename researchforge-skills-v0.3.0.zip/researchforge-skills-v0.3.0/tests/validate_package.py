#!/usr/bin/env python3
"""ResearchForge package validator (v0.2.0).

Checks the artifact contract, not just file structure. Replaces the v0.1.0
validator, whose "procedures sufficiently specific" message asserted more than
it verified. This one ends by stating what it did NOT check.

Exit 0 = structural checks pass. WARN items are printed but do not fail.
"""
from pathlib import Path
import json, re, sys, collections

ROOT = Path(__file__).resolve().parents[1]
SECTIONS = ['## Objective','## Inputs','## Outputs','## Procedure',
            '## Hard gates','## Verification / tests','## Evidence contract']
errors, warns = [], []

cat = json.loads((ROOT/'manifests/skill-catalog.json').read_text(encoding='utf-8'))
skills = cat['skills']
names = {s['name'] for s in skills}
entries = cat.get('entry_points') or ['researchforge-orchestrator']

# ---------- 1. structure ----------
bodies = {}
for item in skills:
    n = item['name']; p = ROOT/'skills'/n/'SKILL.md'
    if not p.exists(): errors.append(f"missing {p}"); continue
    t = p.read_text(encoding='utf-8'); bodies[n] = t
    for s in SECTIONS:
        if s not in t: errors.append(f"{n}: missing section {s}")
if cat['skill_count'] != len(skills):
    errors.append(f"skill_count {cat['skill_count']} != {len(skills)} entries")
for e in entries:
    if e not in names: errors.append(f"entry point '{e}' not in catalog")

# ---------- 2. parse the artifact contract out of the skill bodies ----------
def listed(t, head, nxt):
    m = re.search(rf'## {re.escape(head)}\n(.*?)\n## {re.escape(nxt)}', t, re.S)
    if not m: return []
    out = []
    for l in m.group(1).split('\n'):
        l = l.strip()
        if l.startswith(('-','*')):
            v = re.sub(r'^[-*]\s*','',l).strip().strip('`').strip()
            if v and not v.startswith('*'): out.append(v)
    return out

produced, consumed, feedback, external = {}, collections.defaultdict(list), collections.defaultdict(list), set()
for n, t in bodies.items():
    for a in listed(t, 'Outputs', 'Depends on'):
        if a == 'none': continue
        if a in produced: errors.append(f"artifact '{a}' has two producers: {produced[a]} and {n}")
        else: produced[a] = n
    for a in listed(t, 'Inputs', 'Outputs'):
        if a.startswith('external:'): external.add(a); continue
        if a.startswith('feedback:'): feedback[a[9:].strip()].append(n); continue
        consumed[a].append(n)

dangling = {a: c for a, c in consumed.items() if a not in produced}
if dangling:
    errors.append(f"{len(dangling)}/{len(consumed)} consumed artifacts have no producer "
                  f"and are not marked 'external:' — the artifact contract is not closed.")
    for a in sorted(dangling)[:15]:
        errors.append(f"    dangling '{a}' (needed by {', '.join(dangling[a])})")
bad_fb = {a: c for a, c in feedback.items() if a not in produced}
if bad_fb:
    errors.append(f"{len(bad_fb)} feedback edges name a non-existent artifact: {sorted(bad_fb)}")

# ---------- 3. dependency graph ----------
G = {s['name']: s.get('depends_on', []) for s in skills}
for n, ds in G.items():
    for d in ds:
        if d not in names: errors.append(f"{n}: unknown dependency {d}")
# depends_on must equal the producers of the build inputs
for n in names:
    want = sorted({produced[a] for a in listed(bodies[n],'Inputs','Outputs')
                   if not a.startswith(('external:','feedback:')) and a in produced})
    if sorted(G.get(n, [])) != want:
        errors.append(f"{n}: depends_on out of sync with Inputs (declared {G.get(n)}, derived {want})")

color, cycles = {}, []
def dfs(u, path):
    color[u] = 1; path.append(u)
    for v in G.get(u, []):
        if color.get(v) == 1: cycles.append(" -> ".join(path[path.index(v):]+[v]))
        elif color.get(v, 0) == 0: dfs(v, path)
    path.pop(); color[u] = 2
for n in G:
    if color.get(n, 0) == 0: dfs(n, [])
for c in cycles[:10]: errors.append(f"build-graph cycle: {c}")

seen, stack = set(), list(entries)
while stack:
    x = stack.pop()
    if x in seen: continue
    seen.add(x); stack += G.get(x, [])
unreach = sorted(names - seen)
if unreach:
    errors.append(f"{len(unreach)}/{len(names)} skills unreachable from entry points "
                  f"{entries}: " + ", ".join(unreach))

# ---------- 4. schemas ----------
schema_files = sorted(p.name.replace('.schema.json','') for p in (ROOT/'schemas').glob('*.json'))
for p in (ROOT/'schemas').glob('*.json'):
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
        if '$schema' not in d: warns.append(f"schema {p.name}: no $schema declaration")
    except Exception as e: errors.append(f"bad schema {p.name}: {e}")
graph = json.loads((ROOT/'manifests/artifact-graph.json').read_text(encoding='utf-8'))
bound = {v['schema'] for v in graph['artifacts'].values() if v.get('schema')}
unused = [s for s in schema_files if s not in bound]
if unused:
    errors.append(f"{len(unused)}/{len(schema_files)} schemas bound to no artifact: " + ", ".join(unused))
for aid, v in graph['artifacts'].items():
    if v.get('schema') and v['schema'] not in schema_files:
        errors.append(f"artifact '{aid}' references missing schema {v['schema']}")

# ---------- 5. quality warnings ----------
TRIG = re.compile(r'\b(use when|use this when|use before|use immediately|when the user|trigger|invoke when|call this when)\b', re.I)
notrig = [s['name'] for s in skills if not TRIG.search(s.get('description',''))]
if notrig:
    warns.append(f"{len(notrig)}/{len(skills)} descriptions contain no when-to-use/trigger "
                 f"language; an agent cannot reliably route to them.")
def sec(t,h,nx):
    m = re.search(rf'## {re.escape(h)}\n(.*?)\n## {re.escape(nx)}', t, re.S); return m.group(1) if m else ''
thin = []
for n, t in bodies.items():
    d = next((s.get('description','') for s in skills if s['name']==n), '')
    u = len((d+' '+sec(t,'Procedure','Hard gates')+' '+sec(t,'Hard gates','Verification / tests')
             +' '+sec(t,'Verification / tests','Evidence contract')).split())
    if u < 120: thin.append((n,u))
if thin:
    t0 = min(thin, key=lambda x: x[1])
    warns.append(f"{len(thin)}/{len(bodies)} skills carry <120 words of non-boilerplate "
                 f"specification (thinnest: {t0[0]} @ {t0[1]}). Spec density this low is "
                 f"design intent, not an implementable contract.")

# ---------- report ----------
print("="*74)
print("FAILED\n" if errors else f"PASS — {len(skills)} skills, {len(produced)} artifacts, "
      f"{len(external)} external inputs, {sum(len(v) for v in feedback.values())} declared feedback edges\n")
for e in errors: print("  ERROR  " + e)
if warns:
    print()
    for w in warns: print("  WARN   " + w)
print()
print("-"*74)
print("CHECKED : sections present; every consumed artifact has exactly one producer;")
print("          no dangling inputs (external inputs must say so); depends_on is")
print("          in sync with Inputs; build graph is acyclic; every skill reachable")
print("          from a declared entry point; feedback edges name real artifacts;")
print("          schemas parse and are bound to artifacts.")
print("NOT CHECKED : whether any procedure is correct, implementable or sufficient;")
print("          whether the runtime exists; whether outputs are scientifically valid;")
print("          whether the reproduction/coverage thresholds are the right ones.")
print("          This validator says nothing about any of that.")
print("="*74)
sys.exit(1 if errors else 0)
