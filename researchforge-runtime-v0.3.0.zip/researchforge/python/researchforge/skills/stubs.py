"""Skills that are specified but not built.

Every one of these raises. None of them returns a plausible result.

This file is the whole reason the package exists. The failure mode it guards
against is a system that produces sixty markdown files and then reports the
feature as implemented — so an unbuilt stage here does not degrade gracefully, it
stops the run and names the batch that would build it and what that batch needs.
"""
from __future__ import annotations

from ..errors import NotImplementedYet
from ..skill import Context, Skill, SkillResult, register

# skill -> (IMPLEMENTATION_PLAN batch, what it actually requires)
UNBUILT = {
    "research-blueprint-compiler": (
        "Batch 07 — Blueprint and evaluation environment",
        "a selected direction plus an experiment schema compiler; blocked behind the human gate"),
    "evaluator-builder": (
        "Batch 07 — Blueprint and evaluation environment",
        "grader-side isolation: hidden tests must live outside any context the agent can read, "
        "which requires the container sandbox that is unavailable in this deployment"),
    "codebase-scaffolder": (
        "Batch 08 — Code/worktree experiment engine",
        "git worktrees plus an isolated runtime; refuses to generate code it cannot run safely"),
    "experiment-runner": (
        "Batch 08 — Code/worktree experiment engine",
        "a sandbox that is a real security boundary, plus a compute budget. Neither exists under "
        "the current BYOK-without-GPU configuration"),
    "data-analyst": (
        "Batch 09 — Data analysis and integrity",
        "experiment results in the ledger; there are none until the experiment engine runs"),
    "integrity-auditor": (
        "Batch 09 — Data analysis and integrity",
        "analysis artifacts and raw run results to audit"),
    "finding-memory": (
        "Batch 09 — Data analysis and integrity",
        "experiment outcomes to distil; premature use would record findings from no evidence"),
    "manuscript-builder": (
        "Batch 10 — Manuscript and citation integrity",
        "a LOCKED evidence graph. Drafting before evidence lock is how unsupported claims enter a "
        "paper, so this refuses rather than drafting early"),
    "claim-citation-auditor": (
        "Batch 10 — Manuscript and citation integrity",
        "a draft to audit and a resolved reference corpus to audit it against"),
    "review-simulator": (
        "Batch 10 — Manuscript and citation integrity",
        "a manuscript draft that has already passed the citation audit"),
    "figure-factory": (
        "Batch 11 — Figure and defense PPT factory",
        "audited analysis results; figures drawn from unaudited numbers are how a plot ends up "
        "disagreeing with its own table"),
    "deck-factory": (
        "Batch 11 — Figure and defense PPT factory",
        "locked evidence and figures, so every quantitative slide element can be bound to an artifact"),
    "release-gate": (
        "Batch 13 — Release gate and E2E certification",
        "all upstream audits. It is the last place a fabricated number can be caught, so it must "
        "not be stubbed permissively"),
    "retrospective-benchmark-builder": (
        "Batch 12 — Tool/model routing, evals and skill evolution",
        "a seed/follow-up corpus and a contamination probe; see REPRO_STUDY_PROTOCOL.md"),
    "research-eval-harness": (
        "Batch 12 — Tool/model routing, evals and skill evolution",
        "a frozen task suite; without one, a 'score' would be a number with no referent"),
    "skill-evolution-manager": (
        "Batch 12 — Tool/model routing, evals and skill evolution",
        "held-out evaluation data from real runs. Editing skills before that exists is optimising "
        "a system that has not yet been measured"),
}


def _make(skill_name: str, batch: str, missing: str) -> type[Skill]:
    class _Stub(Skill):
        name = skill_name

        def execute(self, ctx: Context) -> SkillResult:
            raise NotImplementedYet(skill_name, batch, missing)

    _Stub.__name__ = "Stub_" + skill_name.replace("-", "_")
    _Stub.__qualname__ = _Stub.__name__
    return _Stub


for _name, (_batch, _missing) in UNBUILT.items():
    register(_make(_name, _batch, _missing))


@register
class Orchestrator(Skill):
    """The Python half of the orchestrator: it persists state, it does not decide it.

    Transition decisions live in the TypeScript layer. This exists so that
    `research_state` is written through the same contract-enforcing store as every
    other artifact rather than being poked at directly from the other language.
    """

    name = "researchforge-orchestrator"

    def execute(self, ctx: Context) -> SkillResult:
        import time
        state = ctx.external("state", required=True)
        history = ctx.external("history", []) or []
        ctx.store.write(self.name, "research_state", {
            "run_id": ctx.run_id, "mode": ctx.mode, "state": state,
            "history": history, "updated_at": time.time(),
            "contract_digest": __import__("researchforge.generated", fromlist=["x"]).CONTRACT_DIGEST,
        })
        return SkillResult(self.name, produced=["research_state"], next_state=state)
