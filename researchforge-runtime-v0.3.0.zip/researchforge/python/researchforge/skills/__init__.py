"""Skill implementations.

Importing this package registers every implementation and every stub. A skill
that is specified but not built is present here as a stub that raises — never as
a missing entry that would let the orchestrator skip a stage silently.
"""
from . import intake, evidence, reproduction, innovation, stubs  # noqa: F401
