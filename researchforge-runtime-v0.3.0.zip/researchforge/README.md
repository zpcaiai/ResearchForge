# ResearchForge

Self-hosted research runtime. One paper in; a ranked portfolio of research directions, a human
decision, and — as the remaining batches land — code, experiments, a manuscript and a defense deck out.

```bash
researchforge run paper.pdf --project ./my-project
researchforge select --project ./my-project
researchforge status --project ./my-project
researchforge doctor
```

## What is actually built

This repository is honest about its own completeness, because the failure it is designed against is
a system that reports work it did not do.

| stage | status |
|---|---|
| project repo, sandbox provisioning, paper ingestion | **built** |
| paper model, contribution decomposition, claim/evidence graph | **built** |
| provider registry, quota ledger, measured coverage | **built** |
| literature search, citation resolution | **built** |
| reproduction (RL0/RL1 grading, failure taxonomy) | **built** — RL2+ needs compute |
| reproduction fallback (comparison mode, admissible idea modes) | **built** |
| idea seed mining, portfolio, evaluation, ranking | **built** |
| human selection gate | **built** |
| blueprint, experiments, analysis, manuscript, figures, deck, release | **stubs that raise** |

Sixteen skills are implemented. Sixteen are stubs, and every stub raises with the batch that would
build it and what that batch needs. None of them returns a plausible result.

## The three things this design is actually about

**Reproduction runs before ideation.** `IDEAS_READY` is unreachable except through
`REPRO_LEVEL_ESTABLISHED`. An idea whose feasibility and delta were estimated against a code base
nobody tried to run is not an estimate.

**A failed reproduction narrows the project instead of ending it.** The achieved level (RL0–RL4)
sets the comparison mode, and the comparison mode sets which innovation modes remain open:

| RL | comparison mode | admissible innovation modes |
|---|---|---|
| RL3–RL4 | `CM_MEASURED` | all six |
| RL2 | `CM_RELATIVE` | all six, deltas stated relatively |
| RL1 | `CM_REPORTED` | diagnose, evaluate, systemize, guarded transfer |
| RL0 | `CM_NONE` | explain/diagnose and benchmark/evaluate |

At RL0 the run keeps going and produces a non-empty portfolio — of reproducibility studies,
negative-result reports and evaluation-methodology work. The failure taxonomy it just generated is
the evidence for them.

**Coverage is measured, so "we did not find prior work" cannot be confused with "we could not
look."** Under `UNKNOWN_COVERAGE` no candidate may be certified `NOVEL_ENOUGH` — by rule, not by
judgment.

## Architecture

```
manifests/artifact-graph.json     the contract: 128 artifacts, one producer each
        │
        ├─ tools/codegen ──► packages/contracts/src/generated.ts   (TypeScript)
        └─ tools/codegen ──► python/researchforge/generated.py     (Python)

packages/cli        TypeScript: state machine, gating, human interface, licensing
python/researchforge  Python: skills, artifact store, providers, provenance
```

The TypeScript layer exists to own orchestration and the human gate. Its cross-language boundary is
the one place a contract violation would otherwise go unnoticed, so the boundary is *generated from
the contract* rather than described by it. Both sides fail on the same violation for the same reason.

Each skill runs as its own subprocess. Skills execute untrusted generated code and can hang or die;
process isolation makes that a normal observable outcome rather than a corrupted shared runtime, and
makes every invocation reproducible from its request JSON alone.

## The artifact store is where the contract stops being a document

A skill physically cannot write an artifact it does not own, or read one it did not declare.

```
ContractViolation: skill 'idea-ranker' tried to write 'paper_model',
which is produced by 'paper-model-builder'. Every artifact has exactly one
producer; two writers means no one owns whether it is correct.
```

Schemas are enforced on write, not on read, so a malformed artifact never reaches a consumer.

## BYOK

No key ships with this. Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY`; set
`RESEARCHFORGE_CONTACT_EMAIL` so scholarly APIs apply polite-pool limits rather than throttling you.

`--model offline` runs the whole pipeline without a model. Every artifact it touches is stamped
`synthetic: true`, every result reports `[SYNTHETIC]`, and the release gate treats it as a blocker.
It exists to exercise the machinery. It is not a demo mode and it is not research.

## Install

```bash
npm install && npm run build          # TypeScript
pip install -e python                 # Python core
node packages/cli/dist/cli.js doctor  # check the wiring
```

## Test

```bash
npm test        # 13 contract, ordering and licensing tests
npm run test:py # 19 behavioural tests, including the ones that assert refusal
```

The Python suite is mostly tests that something is correctly *refused*: that an abstract page is
reported as insufficient, that zero search results do not become evidence of novelty, that an
unbuilt skill raises instead of returning, that guided mode stops for a human, and that RL0 still
produces a non-empty portfolio.

## Licensing

Self-hosted with an offline-verified license key. No phone-home: in the environments this is built
for, egress is a compliance question, and a six-hour run should not die because a license server was
unreachable. Without a key you get the community edition — ingestion, literature, reproduction, the
innovation engine and the human gate.

## Where to go next

`IMPLEMENTATION_PLAN.md` in the skills package. Do **Batch 04-pre** first: the 20-paper reproduction
study in `REPRO_STUDY_PROTOCOL.md`. Its RL distribution decides whether the rest of the plan is
viable, and it costs two weeks against a six-month execution plane.
