# ResearchForge Skills v0.1.0

A 62-skill, Codex/Claude-Code-oriented specification package for building a paper-to-innovation autonomous research system.

## What this package gives you

- 62 concrete `SKILL.md` workflow contracts, grouped from paper intake through final release.
- Shared JSON schemas for paper models, idea candidates, experiment specs/results, claim evidence, blueprints and artifact manifests.
- A source map covering the 34 repositories indexed by the Research OS page (33 URLs from the request + PaperSpine from the site).
- An architecture and state machine for **paper URL/PDF/HTML → innovation portfolio → user choice → code/experiments → paper/citations → figures → editable defense PPTX**.
- Validation tooling that checks the package structure and avoids claiming runtime code is already implemented.

## Important boundary

This package contains **skills/specifications**, schemas and a build plan. It does **not** contain the full ResearchForge application runtime, experiment infrastructure, paper parser, literature connectors, or PPT engine. A coding agent should use these skills to implement those modules in a target repository and must prove implementation with builds/tests/evidence.

## Start here

1. Read `ARCHITECTURE.md`.
2. Install/copy the `skills/` directories into the host agent's supported skill path, or keep this repo open and explicitly point the agent to the relevant `SKILL.md`.
3. Use `researchforge-orchestrator` as the top-level workflow.
4. For implementation, follow `IMPLEMENTATION_PLAN.md`.
5. Run `python tests/validate_package.py` before distributing the package.

## Primary output gate

The top-level workflow is intentionally interrupted after idea ranking in guided mode. It must show the user multiple innovation directions and accept selection/merge/constraint feedback before executing expensive research.

## Upstream usage

This project does not vendor upstream SKILL.md text. It records conceptual inspirations and links in `SOURCE_MAP.md`; see `LICENSE_NOTES.md` before directly importing or redistributing upstream assets.
