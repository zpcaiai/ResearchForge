---
name: rebuttal-and-revision-planner
description: Triage review concerns, decide rebuttal-vs-resubmission value, plan P0–P3 evidence work and draft responses only after results exist.
version: 0.1.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# rebuttal-and-revision-planner

## Objective

Triage review concerns, decide rebuttal-vs-resubmission value, plan P0–P3 evidence work and draft responses only after results exist.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- reviews/scores
- paper
- deadline/resources
- new experiment results optional


## Outputs

- review_triage.json
- experiment_plan.md
- response_to_reviewers.md
- revision_matrix.csv


## Depends on

- None; may be invoked independently.

## Procedure

1. Atomize comments and infer underlying concern with uncertainty flag.
2. Classify severity and decide PROMISING/BORDERLINE/LOW_RETURN for rebuttal.
3. Plan P0–P3 experiments/analyses before drafting persuasive text.
4. When results arrive, validate them and draft Direct Answer → Evidence → Revision responses.
5. Track every promised manuscript change to a concrete location.

## Hard gates

- Never claim planned work as completed.
- Negative new results are disclosed when material.

## Verification / tests

- Low-return fixture produces resubmission plan rather than aggressive rebuttal.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `TobiasLee/Rebuttal-Skill`
- `Boom5426/Nature-Paper-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
