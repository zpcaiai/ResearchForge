---
name: statistical-integrity-auditor
description: Audit statistical validity, leakage, multiple comparisons, uncertainty, effect sizes and reporting consistency before results can support claims.
version: 0.1.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# statistical-integrity-auditor

## Objective

Audit statistical validity, leakage, multiple comparisons, uncertainty, effect sizes and reporting consistency before results can support claims.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- experiment specs
- raw/aggregated results
- analysis artifacts


## Outputs

- stats_audit.json
- required_fixes.md


## Depends on

- `data-analysis-agent`

## Procedure

1. Verify test assumptions and independence structure.
2. Check sample sizes/seeds, uncertainty intervals, effect sizes and multiple testing where relevant.
3. Compare metric code and reported values to raw results.
4. Detect selective reporting, leakage, p-hacking-like post-hoc promotion and mismatch between plots/tables/text.
5. Classify findings as BLOCKER/HIGH/MEDIUM/LOW.

## Hard gates

- BLOCKER/HIGH unresolved findings prevent evidence lock for affected claims.

## Verification / tests

- Mismatched table vs raw metric fixture is caught.
- Multiple-comparison fixture triggers correction requirement.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ai4s-research/open-science`
- `Imbad0202/academic-research-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
