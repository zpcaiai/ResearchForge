---
name: idea-portfolio-generator
description: Produce a diverse portfolio of concrete research directions instead of one brittle idea.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# idea-portfolio-generator

## Objective

Produce a diverse portfolio of concrete research directions instead of one brittle idea.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- gap ledger
- weakness map
- analogies
- resource envelope


## Outputs

- idea_portfolio.json


## Depends on

- `novelty-gap-miner`
- `cross-domain-analogy-miner`

## Procedure

1. Generate candidates across at least four innovation modes: extend/generalize, replace/simplify, combine/transfer, explain/diagnose, benchmark/evaluate, or systemize.
2. For each idea define hypothesis, exact delta vs baseline, minimum experiment, success metric, novelty rationale, compute/data needs and kill criteria.
3. Deduplicate semantically equivalent ideas.
4. Ensure portfolio includes at least one low-cost high-information probe and one higher-upside direction when resources allow.

## Hard gates

- No vague verbs such as 'improve' without a measurable mechanism and experiment.
- Each idea has explicit kill criteria.

## Verification / tests

- Portfolio fixture contains materially diverse mechanism classes.
- Each candidate validates against IdeaCandidate schema.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `allenai/codescientist`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
