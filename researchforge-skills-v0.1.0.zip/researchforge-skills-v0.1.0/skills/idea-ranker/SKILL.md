---
name: idea-ranker
description: Rank candidate innovations using transparent multi-objective expected value rather than a single LLM preference.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# idea-ranker

## Objective

Rank candidate innovations using transparent multi-objective expected value rather than a single LLM preference.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- idea portfolio
- novelty reports
- feasibility reports
- user/venue priorities


## Outputs

- ranked_ideas.json
- pareto_front.json
- ranking_rationale.md


## Depends on

- `novelty-verifier`
- `feasibility-estimator`

## Procedure

1. Score novelty, scientific value, falsifiability, feasibility, compute cost, expected effect size, venue fit, differentiation and reproducibility.
2. Calibrate uncertainty and penalize unknown novelty coverage or fragile baselines.
3. Compute a Pareto front and top-N recommendations.
4. Explain decisive tradeoffs and identify which evidence would most change the ranking.

## Hard gates

- Do not collapse all criteria into an unexplained 1–10 score.
- User-specified hard constraints are filters, not soft preferences.

## Verification / tests

- Changing compute budget changes ranking for compute-heavy idea fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `THU-Team-Eureka/EurekAgent`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
