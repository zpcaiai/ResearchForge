---
name: domain-skill-loader
description: Install/load only the domain-specific scientific skills needed for the selected project, with version pins and compatibility checks.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# domain-skill-loader

## Objective

Install/load only the domain-specific scientific skills needed for the selected project, with version pins and compatibility checks.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- domain profile
- skill catalogs


## Outputs

- domain_skill_lock.json
- install_plan.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Infer domain/subdomain and required operations.
2. Search installed/upstream skill catalogs.
3. Pin compatible skill versions or commit SHAs.
4. Run smoke tests before enabling them in production runs.

## Hard gates

- Do not vendor unknown-license skill text into this package.
- Pinned dependency required for reproducible run.

## Verification / tests

- Broken skill dependency is caught before experiment start.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `K-Dense-AI/scientific-agent-skills`
- `mims-harvard/ToolUniverse`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
