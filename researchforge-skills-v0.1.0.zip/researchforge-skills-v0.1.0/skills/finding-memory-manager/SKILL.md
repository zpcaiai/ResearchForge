---
name: finding-memory-manager
description: Persist successful findings, failed hypotheses, reproduction lessons, reviewer concerns and reusable patterns across sessions without polluting current evidence.
version: 0.1.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# finding-memory-manager

## Objective

Persist successful findings, failed hypotheses, reproduction lessons, reviewer concerns and reusable patterns across sessions without polluting current evidence.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- run results
- reviews
- decisions


## Outputs

- findings.jsonl
- memory_graph.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Distill each finding into context, evidence, confidence, scope and source IDs.
2. Link findings to parent idea/experiment and related failures.
3. Tag reusable engineering lessons separately from scientific conclusions.
4. Retrieve only relevant memory for current task and show provenance.
5. Expire or supersede stale findings when new evidence conflicts.

## Hard gates

- Memory is advisory; it cannot substitute for current experiment evidence.
- Conflicting memories remain versioned.

## Verification / tests

- Superseded finding is not returned as current truth.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `EvoScientist/EvoScientist`
- `RUC-NLPIR/Arbor`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
