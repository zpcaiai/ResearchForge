---
name: research-progress-controller
description: Monitor long-running research DAGs, budgets, stalls, checkpoints and user takeover/resume semantics.
version: 0.1.0
stage: 00-orchestration
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# research-progress-controller

## Objective

Monitor long-running research DAGs, budgets, stalls, checkpoints and user takeover/resume semantics.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- active run state
- budget policy


## Outputs

- progress.json
- alerts.jsonl
- resume_token


## Depends on

- None; may be invoked independently.

## Procedure

1. Track stage/node status, cost, wall-clock, GPU usage and pending human gates.
2. Detect stalled loops and repeated failures.
3. Checkpoint durable state before cancellation/takeover.
4. Resume from last valid artifact rather than restarting everything.

## Hard gates

- Budget overrun blocks new expensive jobs.

## Verification / tests

- Kill-and-resume fixture continues from checkpoint.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `EvoScientist/EvoScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
