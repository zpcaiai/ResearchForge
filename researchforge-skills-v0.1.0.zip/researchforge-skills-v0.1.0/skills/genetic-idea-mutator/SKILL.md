---
name: genetic-idea-mutator
description: Mutate ideas/method components/code exemplars to discover non-obvious variants while preserving explicit parent lineage and evaluation comparability.
version: 0.1.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# genetic-idea-mutator

## Objective

Mutate ideas/method components/code exemplars to discover non-obvious variants while preserving explicit parent lineage and evaluation comparability.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- parent idea/method
- code exemplars
- finding memory


## Outputs

- mutant_candidates.jsonl
- lineage_graph.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Choose mutation operators: replace component, recombine mechanisms, simplify, scale, alter objective, alter representation, or transfer code pattern.
2. Generate bounded mutants with stated delta from parents.
3. Reject mutants that violate blueprint hard constraints or duplicate prior failures.
4. Send survivors through feasibility + experiment spec generation before execution.

## Hard gates

- Mutation does not bypass novelty verification for a paper-level claim.
- Lineage is mandatory.

## Verification / tests

- Duplicate mutant is filtered via semantic fingerprint.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `allenai/codescientist`
- `RUC-NLPIR/Arbor`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
