---
name: multi-agent-research-team
description: Create a temporary research team (plan/research/code/debug/analyze/write/review) with clear ownership and shared artifacts, not duplicated free-form conversations.
version: 0.1.0
stage: 00-orchestration
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# multi-agent-research-team

## Objective

Create a temporary research team (plan/research/code/debug/analyze/write/review) with clear ownership and shared artifacts, not duplicated free-form conversations.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- blueprint
- task slice


## Outputs

- team_plan.json
- agent_handoffs.jsonl


## Depends on

- None; may be invoked independently.

## Procedure

1. Instantiate only roles needed for current stage.
2. Give each role scoped inputs/outputs and write permissions.
3. Use artifact handoffs with schemas.
4. Aggregate disagreements through explicit judge/human gates.

## Hard gates

- Agents cannot overwrite another role's evidence without provenance.

## Verification / tests

- Two agents editing same artifact fixture triggers ownership conflict.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SamuelSchmidgall/AgentLaboratory`
- `Future-House/robin`
- `EvoScientist/EvoScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
