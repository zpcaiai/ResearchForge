---
name: codebase-scaffolder
description: Generate the implementation project for the selected innovation while preserving baseline interfaces and testability.
version: 0.1.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# codebase-scaffolder

## Objective

Generate the implementation project for the selected innovation while preserving baseline interfaces and testability.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- research blueprint
- baseline repo
- experiment specs


## Outputs

- code branch/worktree
- implementation_plan.md
- tests/


## Depends on

- `research-blueprint-compiler`
- `baseline-reproduction-auditor`

## Procedure

1. Create a dedicated branch/worktree from the pinned baseline.
2. Map proposed method changes to concrete modules/functions/configs.
3. Add feature flags so baseline and candidate can be executed from the same harness.
4. Implement unit/smoke tests for new components before large experiments.
5. Keep generated code, configs and docs aligned with experiment contracts.

## Hard gates

- Do not rewrite unrelated baseline code.
- Candidate path must be disable-able for baseline parity.

## Verification / tests

- Baseline tests still pass.
- Candidate feature flag changes only intended execution path.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `allenai/codescientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
