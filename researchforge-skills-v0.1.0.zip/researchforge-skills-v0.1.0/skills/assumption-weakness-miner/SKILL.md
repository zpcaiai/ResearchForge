---
name: assumption-weakness-miner
description: Systematically mine explicit/implicit assumptions, failure modes, evaluation blind spots and implementation bottlenecks as innovation seeds.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# assumption-weakness-miner

## Objective

Systematically mine explicit/implicit assumptions, failure modes, evaluation blind spots and implementation bottlenecks as innovation seeds.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- paper_model.json
- contribution_atoms.json
- reproduction report optional


## Outputs

- weakness_map.json
- assumption_tests.jsonl


## Depends on

- `contribution-decomposer`

## Procedure

1. Enumerate assumptions about data distribution, compute, labels, sensors, stationarity, supervision, architecture, optimization and evaluation.
2. Separate author-admitted limitations from independently inferred risks.
3. For each assumption, propose a falsifiable stress test and likely scientific value if broken.
4. Prioritize weaknesses that can produce a new contribution rather than cosmetic fixes.

## Hard gates

- Weaknesses must be falsifiable or explicitly marked speculative.
- Do not convert mere implementation inconvenience into a scientific gap without evidence.

## Verification / tests

- At least one stress-test spec is generated per high-priority assumption.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `HKUSTDial/Supervisor-Skills`
- `Imbad0202/academic-research-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
