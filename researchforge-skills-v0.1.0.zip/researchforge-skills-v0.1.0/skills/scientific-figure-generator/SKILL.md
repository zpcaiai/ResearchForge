---
name: scientific-figure-generator
description: Generate publication-oriented plots and scientific schematics using reference-aware planning, iterative critique and source-bound data.
version: 0.1.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# scientific-figure-generator

## Objective

Generate publication-oriented plots and scientific schematics using reference-aware planning, iterative critique and source-bound data.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- figure storyboard item
- source data/method text
- reference style optional


## Outputs

- figure candidates
- generation_trace.json
- selected figure


## Depends on

- `figure-storyboard`

## Procedure

1. Retrieve relevant style/reference examples when allowed.
2. Plan semantics/layout before rendering.
3. For plots, generate code from exact data; for schematics, generate a structured visual spec.
4. Produce multiple candidates when ambiguity is high.
5. Run critic loop for semantic accuracy, legibility, venue size and consistency.

## Hard gates

- Plots cannot invent or smooth away data without explicit transformation.
- Visual critic must check labels/units/legend against source.

## Verification / tests

- Mismatched axis-unit fixture is rejected.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `dwzhu-pku/PaperBanana`
- `K-Dense-AI/scientific-agent-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
