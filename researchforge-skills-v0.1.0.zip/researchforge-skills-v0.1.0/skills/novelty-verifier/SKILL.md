---
name: novelty-verifier
description: Adversarially test whether an idea is actually new, including synonym/terminology search, independent rediscovery and closest-prior-work comparison.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# novelty-verifier

## Objective

Adversarially test whether an idea is actually new, including synonym/terminology search, independent rediscovery and closest-prior-work comparison.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- idea candidate
- literature search tools
- citation graph


## Outputs

- novelty_report.json
- closest_prior_work.jsonl


## Depends on

- `literature-search`
- `idea-portfolio-generator`

## Procedure

1. Translate the idea into multiple terminology families and mechanism descriptions.
2. Search title/abstract/full-text/code when available for near-duplicates.
3. Identify the closest prior work and write a delta table: same/different problem, mechanism, data, evaluation, outcome.
4. Assign novelty status: NOVEL_ENOUGH, INCREMENTAL, DUPLICATE_RISK, UNKNOWN_COVERAGE.
5. Recommend reframing or merger when overlap is high.

## Hard gates

- NOVEL_ENOUGH requires at least one closest-prior-work comparison, not just zero search hits.
- Coverage limits must propagate to idea-ranker.

## Verification / tests

- Paraphrased duplicate fixture is detected by mechanism search.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `Imbad0202/academic-research-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
