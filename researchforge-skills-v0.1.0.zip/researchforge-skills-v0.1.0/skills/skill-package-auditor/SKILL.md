---
name: skill-package-auditor
description: Validate the skills package itself: schema, references, dependency graph, duplicate descriptions, unsafe commands and evidence of real implementation vs specification-only artifacts.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# skill-package-auditor

## Objective

Validate the skills package itself: schema, references, dependency graph, duplicate descriptions, unsafe commands and evidence of real implementation vs specification-only artifacts.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- skills directory
- catalog


## Outputs

- skill_audit_report.md
- machine_report.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Validate frontmatter and required sections.
2. Check dependency names and cycles.
3. Detect suspiciously identical placeholder skills.
4. Classify each artifact as workflow spec, executable script, adapter or implementation code.
5. Fail if documentation claims runtime implementation that package does not contain.

## Hard gates

- Specification-only package must say so explicitly.

## Verification / tests

- Template-clone fixture is flagged as low-specificity.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `microsoft/SkillOpt`
- `JimLiu/science-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
