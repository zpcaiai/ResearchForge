---
name: release-gate-exporter
description: Final gate that packages code, full paper, verified references, figures, PPT and provenance only when reproducibility/integrity requirements are satisfied.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# release-gate-exporter

## Objective

Final gate that packages code, full paper, verified references, figures, PPT and provenance only when reproducibility/integrity requirements are satisfied.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- project state
- all audits
- artifact manifest


## Outputs

- release/
- release_manifest.json
- release_report.md


## Depends on

- `paper-quality-integrity-gate`
- `artifact-provenance`
- `defense-ppt-generator`

## Procedure

1. Verify required artifacts and their checksums/provenance.
2. Run baseline/candidate smoke tests and deterministic package validation.
3. Check unresolved novelty/citation/statistical/review blockers.
4. Build export bundle: code, configs, paper source/PDF, references, figures/SVG, PPTX, review and evidence reports.
5. Record limitations, unresolved risks and exact commands for reproduction.

## Hard gates

- No 'complete' status with unresolved BLOCKER/HIGH integrity findings.
- Release report must distinguish generated skill package validation from scientific result validation.

## Verification / tests

- Missing provenance for a headline result blocks release.
- Bundle validation script verifies all declared files/checksums.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `ai4s-research/open-science`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
