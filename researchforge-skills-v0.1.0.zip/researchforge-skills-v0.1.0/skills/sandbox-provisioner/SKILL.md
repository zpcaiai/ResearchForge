---
name: sandbox-provisioner
description: Create isolated, reproducible execution environments for LLM-written code with restricted secrets/network/filesystem and separate grading when needed.
version: 0.1.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# sandbox-provisioner

## Objective

Create isolated, reproducible execution environments for LLM-written code with restricted secrets/network/filesystem and separate grading when needed.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- experiment spec
- dependency lock
- security profile


## Outputs

- sandbox_manifest.json
- container config
- environment lock


## Depends on

- None; may be invoked independently.

## Procedure

1. Build or select a pinned container/venv image.
2. Mount only required project/data paths and provide least-privilege secrets.
3. Apply CPU/GPU/memory/time/process/network limits.
4. When evaluation could be gamed, put evaluator in a separate grader context invisible to the agent.
5. Capture package versions, system info and image digest.

## Hard gates

- Untrusted generated code cannot run on the host by default.
- Private evaluator and hidden tests are never mounted into the agent context.

## Verification / tests

- Sandbox escape fixture cannot read host secret path.
- Agent cannot read hidden evaluator fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `THU-Team-Eureka/EurekAgent`
- `SakanaAI/AI-Scientist`
- `allenai/codescientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
