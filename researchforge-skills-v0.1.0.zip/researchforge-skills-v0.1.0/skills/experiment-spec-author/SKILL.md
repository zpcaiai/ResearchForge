---
name: experiment-spec-author
description: Write executable experiment contracts with independent variables, controls, metrics, seeds, datasets, resource budgets and expected evidence outputs.
version: 0.1.0
stage: 05-planning
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# experiment-spec-author

## Objective

Write executable experiment contracts with independent variables, controls, metrics, seeds, datasets, resource budgets and expected evidence outputs.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- research blueprint
- baseline config


## Outputs

- experiments/*.yaml


## Depends on

- `research-blueprint-compiler`

## Procedure

1. Define hypothesis and decision rule first.
2. Specify control/baseline, treatment variants, fixed factors and nuisance variables.
3. Pin dataset splits, preprocessing, seeds and metric code.
4. Declare required outputs: raw metrics, logs, plots, environment capture and result JSON.
5. Define invalid-run conditions and rerun policy.

## Hard gates

- No experiment without a control or an explicit reason control is impossible.
- Metric implementation is shared between baseline and candidate when comparing them.

## Verification / tests

- Experiment schema rejects missing seed/split for stochastic benchmark fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `THU-Team-Eureka/EurekAgent`
- `CMarsRover/SciAgentGYM`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
