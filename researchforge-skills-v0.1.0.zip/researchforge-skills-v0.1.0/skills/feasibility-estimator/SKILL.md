---
name: feasibility-estimator
description: Estimate implementation, data, compute, evaluation and dependency feasibility before user selection or autonomous execution.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# feasibility-estimator

## Objective

Estimate implementation, data, compute, evaluation and dependency feasibility before user selection or autonomous execution.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- idea candidate
- baseline assets
- resource envelope


## Outputs

- feasibility_report.json
- resource_plan.yaml


## Depends on

- `idea-portfolio-generator`
- `baseline-repo-finder`

## Procedure

1. Estimate required code changes, dependency risk, dataset access, GPU/CPU/memory/storage and wall-clock classes.
2. Identify unknowns that need a cheap probe.
3. Score feasibility and uncertainty separately.
4. Propose a minimal viable experiment and a full validation experiment.

## Hard gates

- High uncertainty cannot be hidden inside a high feasibility score.
- Ideas requiring unavailable proprietary data must be flagged before selection.

## Verification / tests

- Unavailable dataset fixture lowers feasibility and emits blocker.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `SamuelSchmidgall/AgentLaboratory`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
