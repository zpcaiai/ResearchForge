---
name: tool-composition-planner
description: Compose deterministic scientific tools into sequential/parallel plans with typed intermediate artifacts and failure handling.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# tool-composition-planner

## Objective

Compose deterministic scientific tools into sequential/parallel plans with typed intermediate artifacts and failure handling.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- task
- tool registry


## Outputs

- tool_dag.json
- typed_contracts.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Break task into deterministic vs judgment steps.
2. Select tools and typed IO contracts.
3. Parallelize independent calls and cache stable results.
4. Validate each intermediate before continuation.

## Hard gates

- No untyped blob handoffs for critical metrics.

## Verification / tests

- Invalid tool output stops downstream execution.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `mims-harvard/ToolUniverse`
- `CMarsRover/SciAgentGYM`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
