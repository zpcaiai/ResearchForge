---
name: editable-svg-refiner
description: Convert or refine scientific diagrams into editable SVG while preserving semantics, text, connectors and element identity.
version: 0.1.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# editable-svg-refiner

## Objective

Convert or refine scientific diagrams into editable SVG while preserving semantics, text, connectors and element identity.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- raster/generated figure or structured visual spec
- optional style reference


## Outputs

- editable SVG
- element_map.json
- validation_report.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Segment or identify meaningful visual elements.
2. Construct a vector layout with stable IDs and real text whenever possible.
3. Reassemble icons/shapes/connectors in a common coordinate system.
4. Iteratively compare against semantic/layout constraints.
5. Export SVG plus a manifest mapping visual elements to manuscript concepts.

## Hard gates

- Do not rasterize the whole diagram into a single embedded image and call it editable.
- Text must remain selectable/editable unless technically impossible and disclosed.

## Verification / tests

- SVG fixture contains separate editable text and connector elements.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/AutoFigure-Edit`
- `Rss3208/Visiomaster`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
