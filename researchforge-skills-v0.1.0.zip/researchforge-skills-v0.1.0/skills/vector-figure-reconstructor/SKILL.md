---
name: vector-figure-reconstructor
description: Reconstruct existing scientific figures into editable vector structures for revision or style normalization.
version: 0.1.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# vector-figure-reconstructor

## Objective

Reconstruct existing scientific figures into editable vector structures for revision or style normalization.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- source image/PDF figure


## Outputs

- reconstructed.svg
- reconstruction_map.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Detect text, shapes, icons and connectors.
2. Recreate layout with editable elements.
3. Compare geometry and labels against source.
4. Expose uncertain elements for manual correction.

## Hard gates

- Do not claim pixel-perfect semantic reconstruction when labels are uncertain.

## Verification / tests

- Text remains editable in output fixture.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/AutoFigure-Edit`
- `Rss3208/Visiomaster`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
