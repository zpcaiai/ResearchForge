---
name: novelty-gap-miner
description: Mine publishable gaps by comparing source contributions against related work, recent SOTA, benchmark expectations and unresolved contradictions.
version: 0.1.0
stage: 04-innovation
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# novelty-gap-miner

## Objective

Mine publishable gaps by comparing source contributions against related work, recent SOTA, benchmark expectations and unresolved contradictions.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- weakness_map.json
- literature corpus
- citation clusters
- target venue optional


## Outputs

- gap_ledger.jsonl
- gap_evidence.md


## Depends on

- `assumption-weakness-miner`
- `literature-search`
- `citation-neighborhood-miner`

## Procedure

1. Build a comparison matrix of capabilities/assumptions/metrics/compute/data across source and competitors.
2. Detect uncovered cells, contradictory results, missing ablations, cost-quality frontiers and domain-transfer gaps.
3. Estimate whether each gap is already solved in another terminology or adjacent field.
4. Attach positive and negative evidence and a novelty-risk level.

## Hard gates

- A gap cannot be labeled novel until novelty-verifier runs.
- No 'nobody has done X' statement from search absence alone.

## Verification / tests

- Synthetic literature matrix yields expected uncovered cell and contradiction.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `HKUSTDial/Supervisor-Skills`
- `SakanaAI/AI-Scientist-v2`
- `FuLab-ZhaoSun/auto-research-landscape-2026`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
