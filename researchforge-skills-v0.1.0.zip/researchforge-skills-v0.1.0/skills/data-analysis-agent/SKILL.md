---
name: data-analysis-agent
description: Perform exploratory and confirmatory analysis from structured experiment outputs, producing reusable code and analyst-grade evidence artifacts.
version: 0.1.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# data-analysis-agent

## Objective

Perform exploratory and confirmatory analysis from structured experiment outputs, producing reusable code and analyst-grade evidence artifacts.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- experiment ledger/results
- analysis question


## Outputs

- analysis notebook/script
- analysis_results.json
- plots/
- analysis_report.md


## Depends on

- `experiment-ledger`

## Procedure

1. Read experiment design before touching metrics.
2. Separate exploratory from confirmatory analyses.
3. Compute declared metrics and appropriate uncertainty summaries.
4. Inspect subgroup/seed/ablation behavior and potential failure cases.
5. Generate figures from code with traceable inputs.

## Hard gates

- Post-hoc metrics are labeled exploratory.
- No cherry-picking of best seeds without full distribution.

## Verification / tests

- Analysis fixture reports all seeds and flags selective subset attempt.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ruc-datalab/DeepAnalyze`
- `K-Dense-AI/scientific-agent-skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
