---
name: tool-skill-router
description: Dynamically select the smallest relevant subset of installed skills/tools/MCPs for a task, keeping large catalogs out of model context until needed.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# tool-skill-router

## Objective

Dynamically select the smallest relevant subset of installed skills/tools/MCPs for a task, keeping large catalogs out of model context until needed.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- task
- skill/tool registry
- constraints


## Outputs

- tool_plan.json
- selected capabilities


## Depends on

- None; may be invoked independently.

## Procedure

1. Classify the task by research stage/domain/action/risk.
2. Search registry metadata rather than loading all tool descriptions.
3. Select minimal capability set and resolve dependencies.
4. Prefer deterministic tools for retrieval/calculation/execution and use LLM judgment where needed.
5. Record routing rationale and fallback providers.

## Hard gates

- Do not expose 1000+ tools directly when discovery/compact mode is available.
- High-risk execution tools require sandbox profile.

## Verification / tests

- Biomed query selects domain tools while unrelated physics tools remain unloaded.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `mims-harvard/ToolUniverse`
- `K-Dense-AI/scientific-agent-skills`
- `EvoScientist/EvoScientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
