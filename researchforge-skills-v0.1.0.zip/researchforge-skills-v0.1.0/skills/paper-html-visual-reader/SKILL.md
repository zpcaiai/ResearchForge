---
name: paper-html-visual-reader
description: Read figure-heavy or layout-sensitive paper HTML/PDF visually and reconcile text extraction with charts, equations and multi-column layout.
version: 0.1.0
stage: 01-intake
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-html-visual-reader

## Objective

Read figure-heavy or layout-sensitive paper HTML/PDF visually and reconcile text extraction with charts, equations and multi-column layout.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- paper pages/screenshots
- text extraction


## Outputs

- visual_notes.jsonl
- layout_warnings.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Inspect pages containing key figures/tables/equations when parser confidence is low.
2. Capture semantic content, not OCR-only strings.
3. Reconcile visual findings with locator map and flag discrepancies.

## Hard gates

- Do not infer unreadable labels; mark uncertain.

## Verification / tests

- Known figure-caption mismatch fixture is detected.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Yuan1z0825/nature-skills`
- `ai4s-research/open-science`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
