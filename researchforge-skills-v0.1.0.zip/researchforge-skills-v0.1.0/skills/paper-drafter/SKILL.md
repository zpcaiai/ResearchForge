---
name: paper-drafter
description: Generate the full manuscript from a locked manuscript spine and evidence graph, with claim-bounded language and venue-aware structure.
version: 0.1.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-drafter

## Objective

Generate the full manuscript from a locked manuscript spine and evidence graph, with claim-bounded language and venue-aware structure.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- manuscript spine
- evidence graph
- references.bib
- target venue template


## Outputs

- paper/*.tex or .md
- paper.pdf optional
- draft_manifest.json


## Depends on

- `manuscript-spine-builder`
- `citation-resolver`

## Procedure

1. Draft section-by-section from the spine, never from model memory alone for factual claims.
2. Use stable claim IDs and citation IDs during generation, then render bibliography syntax.
3. Report methods and experimental settings from provenance records.
4. Use calibrated language matching evidence strength.
5. Include limitations, negative findings and AI-use disclosure when required by venue/license/workflow.

## Hard gates

- No invented experiment or citation.
- Numbers must be pulled from verified result artifacts by ID.

## Verification / tests

- Draft with injected unsupported number is rejected by post-draft audit.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `WUBING2023/PaperSpine`
- `Boom5426/Nature-Paper-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
