---
name: claim-citation-auditor
description: Audit every citation-bearing and quantitative manuscript claim for existence, locator support, experiment provenance and scope fidelity.
version: 0.1.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# claim-citation-auditor

## Objective

Audit every citation-bearing and quantitative manuscript claim for existence, locator support, experiment provenance and scope fidelity.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- draft
- evidence graph
- reference corpus
- experiment ledger


## Outputs

- claim_audit.jsonl
- citation_audit.md


## Depends on

- `paper-drafter`
- `experiment-ledger`

## Procedure

1. Extract atomic claims from the draft.
2. Resolve citations and verify each cited source supports the intended proposition, not merely the topic.
3. Verify quantitative claims against experiment ledger and raw artifacts.
4. Flag unsupported, overstated, anchorless, fabricated or scope-mismatched claims.
5. Block finalization until high-severity findings are fixed or claims removed/narrowed.

## Hard gates

- Citation existence is necessary but not sufficient; support must be checked.
- Planned experiments cannot be written as completed.

## Verification / tests

- Real-but-irrelevant citation fixture is marked NOT_SUPPORTED.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `ai4s-research/open-science`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
