---
name: paper-library-connector
description: Connect personal/reference libraries (for example Zotero-like stores) as a grounded literature source without mixing private notes into public citations.
version: 0.1.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-library-connector

## Objective

Connect personal/reference libraries (for example Zotero-like stores) as a grounded literature source without mixing private notes into public citations.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- library connector
- query
- paper context


## Outputs

- library_hits.jsonl
- note_links.json


## Depends on

- None; may be invoked independently.

## Procedure

1. Search library by title/author/topic and reuse existing PDFs/notes when authorized.
2. Separate bibliographic metadata from private annotations.
3. Resolve cited works through citation-resolver before manuscript use.

## Hard gates

- Private annotations are not quoted or exported unless explicitly requested.

## Verification / tests

- Library hit missing canonical citation is routed to resolver.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `yilewang/llm-for-zotero`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
