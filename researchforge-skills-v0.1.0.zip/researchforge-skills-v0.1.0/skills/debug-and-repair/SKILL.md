---
name: debug-and-repair
description: Diagnose experiment/code failures using logs, minimal reproduction and bounded repair attempts without silently changing the scientific question.
version: 0.1.0
stage: 06-execution
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# debug-and-repair

## Objective

Diagnose experiment/code failures using logs, minimal reproduction and bounded repair attempts without silently changing the scientific question.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- failed run
- logs
- code diff
- experiment spec


## Outputs

- failure_diagnosis.json
- repair_commits
- terminal_status


## Depends on

- None; may be invoked independently.

## Procedure

1. Classify failure: environment, dependency, data, code bug, numerical issue, OOM, evaluator mismatch, invalid hypothesis.
2. Create minimal reproduction and inspect recent diffs.
3. Attempt bounded repairs that preserve experimental contract.
4. If repair requires changing metric/data/hypothesis, open a blueprint amendment instead of silently proceeding.
5. Record root cause and prevention note in finding memory.

## Hard gates

- Maximum repair attempts is explicit.
- Scientific-contract changes require new version and rerun of affected baseline.

## Verification / tests

- Metric-changing repair triggers amendment-required status.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `SakanaAI/AI-Scientist-v2`
- `allenai/codescientist`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
