---
name: figure-storyboard
description: Plan the paper's figures as evidence-bearing narrative objects before generating any artwork.
version: 0.1.0
stage: 09-visuals
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# figure-storyboard

## Objective

Plan the paper's figures as evidence-bearing narrative objects before generating any artwork.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- manuscript spine
- evidence/analysis artifacts
- target venue


## Outputs

- figure_storyboard.json
- captions_draft.md


## Depends on

- `manuscript-spine-builder`

## Procedure

1. Assign each figure one communication job: motivation, method overview, main result, ablation, failure case, qualitative example.
2. Define source data/claims and what must remain editable.
3. Choose plot vs schematic vs table and target dimensions.
4. Specify caption claim and accessibility/legibility constraints.
5. Prioritize figures by reviewer decision value.

## Hard gates

- No decorative figure without a defined paper role.
- Data plots must identify exact result artifacts.

## Verification / tests

- Each main manuscript claim has at most appropriate and traceable visual support.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `dwzhu-pku/PaperBanana`
- `HKUSTDial/Supervisor-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
