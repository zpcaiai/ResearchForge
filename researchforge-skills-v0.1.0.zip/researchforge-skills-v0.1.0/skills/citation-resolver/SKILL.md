---
name: citation-resolver
description: Resolve bibliography entries to canonical scholarly records and maintain stable BibTeX/CSL identities.
version: 0.1.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# citation-resolver

## Objective

Resolve bibliography entries to canonical scholarly records and maintain stable BibTeX/CSL identities.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- reference strings/DOIs/arXiv IDs
- optional Zotero/library metadata


## Outputs

- references.jsonl
- references.bib
- resolution_report.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Normalize titles/authors/years and attempt DOI/arXiv/OpenAlex/Semantic Scholar/Crossref resolution through configured providers.
2. Deduplicate preprint/published versions while preserving version lineage.
3. Store canonical IDs, landing URLs and citation metadata.
4. Flag unresolved, suspicious or title-mismatched records for manual review.

## Hard gates

- Never invent DOI, venue, pages or authors.
- Unresolved citations cannot be promoted to VERIFIED.

## Verification / tests

- Duplicate arXiv+journal fixture collapses to one work with two versions.
- Fabricated DOI fixture is flagged unresolved.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `openags/paper-search-mcp`
- `yilewang/llm-for-zotero`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
