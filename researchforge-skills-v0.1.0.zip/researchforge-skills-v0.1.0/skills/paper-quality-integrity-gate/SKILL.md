---
name: paper-quality-integrity-gate
description: Run a final multi-layer paper audit across logic, evidence, citations, figures, statistics, formatting and reproducibility before submission artifacts are frozen.
version: 0.1.0
stage: 08-writing
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# paper-quality-integrity-gate

## Objective

Run a final multi-layer paper audit across logic, evidence, citations, figures, statistics, formatting and reproducibility before submission artifacts are frozen.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- paper bundle
- audits


## Outputs

- integrity_gate.json
- submission_blockers.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Check argument continuity from spine to manuscript.
2. Run citation and statistical audits.
3. Verify figure/table/text consistency and LaTeX/package health.
4. Verify reproducibility commands and AI-use disclosures where required.

## Hard gates

- Critical audit failures block submission packaging.

## Verification / tests

- Broken figure reference and unsupported claim fixture both block.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `Imbad0202/academic-research-skills`
- `ai4s-research/open-science`
- `Boom5426/Nature-Paper-Skills`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
