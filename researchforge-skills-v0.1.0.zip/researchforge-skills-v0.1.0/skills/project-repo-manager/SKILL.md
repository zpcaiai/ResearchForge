---
name: project-repo-manager
description: Manage one durable Git repository per research quest, with branches/worktrees for competing ideas and persistent checkpoints/artifacts.
version: 0.1.0
stage: 11-governance
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# project-repo-manager

## Objective

Manage one durable Git repository per research quest, with branches/worktrees for competing ideas and persistent checkpoints/artifacts.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- project intent
- paper source
- workspace policy


## Outputs

- quest repo
- branch map
- checkpoint metadata


## Depends on

- None; may be invoked independently.

## Procedure

1. Create/adopt a Git repo and initialize research metadata directories.
2. Pin the source paper and baseline revision.
3. Create branches/worktrees for selected idea and major experimental variants.
4. Commit meaningful milestones: baseline reproduced, experiment evidence locked, draft reviewed, deck finalized.
5. Never delete failed branches until findings are distilled and retention policy allows cleanup.

## Hard gates

- Generated agents do not force-push protected project history.
- Secrets/data artifacts follow .gitignore/data policy.

## Verification / tests

- Resume from checkpoint fixture restores correct branch and blueprint version.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ResearAI/DeepScientist`
- `ai4s-research/open-science`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
