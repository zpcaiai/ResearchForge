---
name: metric-and-hidden-evaluator-builder
description: Build defensive evaluation code and hidden tests for metric-driven discovery, including reward-hacking defenses.
version: 0.1.0
stage: 05-planning
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# metric-and-hidden-evaluator-builder

## Objective

Build defensive evaluation code and hidden tests for metric-driven discovery, including reward-hacking defenses.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- research objective
- submission schema
- known failure modes


## Outputs

- evaluate.py
- hidden_tests/
- evaluator_spec.md


## Depends on

- None; may be invoked independently.

## Procedure

1. Define raw score semantics and validity rules.
2. Create public examples but keep decisive hidden tests isolated.
3. Probe obvious leakage/tampering/tolerance hacks.
4. Version evaluator independently of agent code.

## Hard gates

- Agent context cannot access hidden tests.
- Evaluator change invalidates comparability unless results are rerun.

## Verification / tests

- Score-tampering fixture is invalid.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `THU-Team-Eureka/EurekAgent`
- `CMarsRover/SciAgentGYM`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
