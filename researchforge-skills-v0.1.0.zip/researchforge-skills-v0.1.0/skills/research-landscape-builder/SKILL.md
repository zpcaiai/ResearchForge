---
name: research-landscape-builder
description: Build a current landscape of adjacent systems, datasets, benchmarks and methods to avoid local-optimum ideation.
version: 0.1.0
stage: 02-evidence
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# research-landscape-builder

## Objective

Build a current landscape of adjacent systems, datasets, benchmarks and methods to avoid local-optimum ideation.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- topic
- literature/tool catalogs


## Outputs

- landscape.md
- system_matrix.csv
- benchmark_matrix.csv


## Depends on

- None; may be invoked independently.

## Procedure

1. Collect representative systems and surveys.
2. Normalize capabilities and evaluation axes.
3. Identify capability gaps and crowded directions.
4. Feed landscape deltas into novelty-gap-miner.

## Hard gates

- Landscape is descriptive evidence, not proof of novelty.

## Verification / tests

- Matrix includes source paper plus nearest competitors.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `yenanjing/awesome-ai-for-science`
- `FuLab-ZhaoSun/auto-research-landscape-2026`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
