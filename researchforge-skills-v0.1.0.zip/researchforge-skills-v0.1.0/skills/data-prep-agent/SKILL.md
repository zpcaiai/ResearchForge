---
name: data-prep-agent
description: Discover, clean, transform and validate experiment data with execution-grounded intermediate state and reversible transformations.
version: 0.1.0
stage: 07-analysis
artifact_kind: workflow-skill
implementation_status: specification-ready
---

# data-prep-agent

## Objective

Discover, clean, transform and validate experiment data with execution-grounded intermediate state and reversible transformations.

This skill is an **execution contract for an agent/coding runtime**, not proof that the corresponding application code already exists. When used to build the ResearchForge system, the agent must create/modify real files, run tests, capture evidence, and report incomplete items explicitly.

## Inputs

- raw data
- experiment spec


## Outputs

- prepared data
- data_profile.json
- transform_log.jsonl


## Depends on

- None; may be invoked independently.

## Procedure

1. Profile schema, missingness, duplicates, outliers, units and split leakage.
2. Propose transformations with reason and reversibility.
3. Execute transformations and validate postconditions after each step.
4. Freeze train/val/test semantics and checksum outputs.
5. Emit warnings for potentially outcome-leaking operations.

## Hard gates

- No target leakage.
- Raw data is never destructively overwritten.

## Verification / tests

- Leakage fixture is detected.
- Transformation pipeline reproduces same checksum.


## Evidence contract

When this skill executes in a real project, persist an evidence record containing: skill version, input artifact IDs, output artifact IDs, commands/tool calls executed, exit status, test results, warnings, model/provider identity when relevant, git SHA when code changed, and human approvals when a gate required them.

## Failure behavior

Fail closed for integrity, provenance, evaluator isolation, citation support, or baseline-comparability problems. For recoverable execution errors, create a structured blocker/failure record and route to `debug-and-repair` or a human gate; never fabricate a successful artifact.

## Upstream inspiration (conceptual, not vendored text)

- `ruc-datalab/DeepAnalyze`


See `SOURCE_MAP.md` and `LICENSE_NOTES.md`. This package intentionally uses original workflow wording and references upstream projects by URL/role instead of copying their SKILL.md bodies.
