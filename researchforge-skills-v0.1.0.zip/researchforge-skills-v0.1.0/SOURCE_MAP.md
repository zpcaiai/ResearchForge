# Upstream Source Map

The Research OS page lists 34 projects. The user message contained 33 explicit repository URLs; `WUBING2023/PaperSpine` is the additional repository shown on the site, so it is included here.

This package uses these projects as **conceptual/architectural inspiration** and does not vendor their SKILL.md bodies.

| # | Repository | Role absorbed into ResearchForge |
|---:|---|---|
| 1 | [hugohe3/ppt-master](https://github.com/hugohe3/ppt-master) | Native editable PowerPoint generation; narrative-first deck planning; charts/tables/notes/template preservation. |
| 2 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | Human-in-the-loop research/writing/review pipeline; citation/claim integrity gates; multi-agent peer review. |
| 3 | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | Large scientific skill/tool library; database/tool adapters; hypothesis, critical thinking, slides and domain workflows. |
| 4 | [Yuan1z0825/nature-skills](https://github.com/Yuan1z0825/nature-skills) | Paper reading, Nature-style writing, review, figures and paper-to-PPT skill patterns. |
| 5 | [SakanaAI/AI-Scientist](https://github.com/SakanaAI/AI-Scientist) | Template-driven autonomous ideation, code experiments, plotting, paper writing and review. |
| 6 | [microsoft/SkillOpt](https://github.com/microsoft/SkillOpt) | Validated self-evolution of skill documents using rollout/reflection/update/evaluate loops and held-out gates. |
| 7 | [SakanaAI/AI-Scientist-v2](https://github.com/SakanaAI/AI-Scientist-v2) | Open-ended ideation plus experiment-manager-guided agentic tree search; template-free exploration. |
| 8 | [dwzhu-pku/PaperBanana](https://github.com/dwzhu-pku/PaperBanana) | Reference-driven multi-agent academic illustration: retrieve, plan, style, visualize, critique. |
| 9 | [SamuelSchmidgall/AgentLaboratory](https://github.com/SamuelSchmidgall/AgentLaboratory) | Literature-review → experiment → report multi-agent workflow; checkpoints and copilot mode. |
| 10 | [ruc-datalab/DeepAnalyze](https://github.com/ruc-datalab/DeepAnalyze) | Autonomous data preparation, analysis, modeling, visualization and analyst-grade reporting. |
| 11 | [EvoScientist/EvoScientist](https://github.com/EvoScientist/EvoScientist) | Long-running multi-agent research, self-evolving memory, AutoSkills, tool selection and human-on-the-loop control. |
| 12 | [WUBING2023/PaperSpine](https://github.com/WUBING2023/PaperSpine) | Contribution-first manuscript spine, target-example learning, reviewer-oriented paper reconstruction and LaTeX-safe audits. |
| 13 | [ResearAI/AutoFigure-Edit](https://github.com/ResearAI/AutoFigure-Edit) | Method-text-to-editable-SVG workflow with segmentation, structured template reconstruction and iterative refinement. |
| 14 | [HKUSTDial/Supervisor-Skills](https://github.com/HKUSTDial/Supervisor-Skills) | Supervisor-style idea evaluation, deep research, paper writing, plotting and pre-submission review heuristics. |
| 15 | [ResearAI/DeepScientist](https://github.com/ResearAI/DeepScientist) | Local-first long-horizon research studio; one repo per quest; branch/worktree experiment routes; findings memory and human takeover. |
| 16 | [yilewang/llm-for-zotero](https://github.com/yilewang/llm-for-zotero) | Personal-library grounded literature assistance and citation-aware interaction patterns. |
| 17 | [openags/paper-search-mcp](https://github.com/openags/paper-search-mcp) | Paper retrieval as MCP/tool surface for agentic literature search. |
| 18 | [OpenNSWM-Lab/FAROS](https://github.com/OpenNSWM-Lab/FAROS) | Blueprint/capability/profile/provider research runtime abstraction with persistent runs, artifacts, memory and verification. |
| 19 | [mims-harvard/ToolUniverse](https://github.com/mims-harvard/ToolUniverse) | Large scientific tool ecosystem, compact tool discovery, composition, MCP, async tools and prebuilt research skills. |
| 20 | [OpenRaiser/NanoResearch](https://github.com/OpenRaiser/NanoResearch) | Autonomous research-assistant patterns for compact end-to-end research workflows. |
| 21 | [RUC-NLPIR/Arbor](https://github.com/RUC-NLPIR/Arbor) | Autonomous optimization / insight propagation patterns for improving research systems. |
| 22 | [ai4s-research/open-science](https://github.com/ai4s-research/open-science) | Local-first auditable research workbench; provenance, reproducible runs, persistent projects, first-party integrity skills. |
| 23 | [Rss3208/Visiomaster](https://github.com/Rss3208/Visiomaster) | Image-to-editable-vector / visual reconstruction patterns for scientific artifacts. |
| 24 | [Future-House/robin](https://github.com/Future-House/robin) | Multi-agent scientific discovery patterns and division of research roles. |
| 25 | [Boom5426/Nature-Paper-Skills](https://github.com/Boom5426/Nature-Paper-Skills) | Nature-oriented manuscript revision, audit and publication-quality writing workflows. |
| 26 | [allenai/codescientist](https://github.com/allenai/codescientist) | Paper+code mutation for idea generation; sandboxed experiment builder; repeated independent trials and meta-analysis. |
| 27 | [allenai/discoveryworld](https://github.com/allenai/discoveryworld) | Interactive scientific-discovery environment and benchmark with observations/actions/scorecards and detailed logs. |
| 28 | [JimLiu/science-skills](https://github.com/JimLiu/science-skills) | Research skill/system-prompt asset collection and reviewer-style audit patterns. |
| 29 | [TobiasLee/Rebuttal-Skill](https://github.com/TobiasLee/Rebuttal-Skill) | Rebuttal-vs-resubmission gate; atomic concern triage; P0–P3 experiment planning; evidence-grounded response drafting. |
| 30 | [THU-Team-Eureka/EurekAgent](https://github.com/THU-Team-Eureka/EurekAgent) | Environment engineering, isolated agent/grader containers, private evaluator, resumable metric-driven discovery loops. |
| 31 | [CMarsRover/SciAgentGYM](https://github.com/CMarsRover/SciAgentGYM) | Isolated scientific tool-use benchmark, typed tool contracts, structured traces and automated scoring. |
| 32 | [Jyx0208/claude-science-api-bridge](https://github.com/Jyx0208/claude-science-api-bridge) | Provider-bridge pattern for swapping model backends behind a research workbench. |
| 33 | [yenanjing/awesome-ai-for-science](https://github.com/yenanjing/awesome-ai-for-science) | Discovery/index source for AI-for-science tools and ecosystem coverage. |
| 34 | [FuLab-ZhaoSun/auto-research-landscape-2026](https://github.com/FuLab-ZhaoSun/auto-research-landscape-2026) | Landscape/survey source for autonomous-research systems and capability gaps. |
