# License and upstream reuse notes

ResearchForge Skills v0.1.0 is an original specification package. It intentionally does not copy upstream SKILL.md bodies or source code.

Before vendoring, redistributing, modifying, or commercially using an upstream skill/code asset:

1. inspect the repository's current LICENSE at the exact commit you plan to use;
2. record that commit SHA and license in a dependency lock;
3. distinguish permissive code licenses from non-commercial/share-alike/custom responsible-use terms;
4. preserve required attribution/notices;
5. prefer adapters or runtime installation for license-incompatible assets rather than copying them into one combined distribution.

Some upstream projects have materially different licensing and responsible-use conditions; therefore this package treats all upstream integration as **reference/adaptation by default** until a project-specific license review is complete.

The `SOURCE_MAP.md` descriptions are short functional summaries for architecture routing, not copied documentation.
