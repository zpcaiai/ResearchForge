from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
cat=json.loads((ROOT/'manifests/skill-catalog.json').read_text(encoding='utf-8'))
skills=cat['skills']
if cat['skill_count'] != 62: errors.append(f"expected 62 skills, got {cat['skill_count']}")
seen=set()
texts=[]
for item in skills:
    name=item['name']
    if name in seen: errors.append(f"duplicate skill {name}")
    seen.add(name)
    p=ROOT/'skills'/name/'SKILL.md'
    if not p.exists(): errors.append(f"missing {p}"); continue
    t=p.read_text(encoding='utf-8')
    texts.append((name,t))
    for section in ['## Objective','## Inputs','## Outputs','## Procedure','## Hard gates','## Verification / tests','## Evidence contract']:
        if section not in t: errors.append(f"{name}: missing {section}")
    if 'implementation_status: specification-ready' not in t: errors.append(f"{name}: missing specification status")
# dependency validity
for item in skills:
    for dep in item.get('depends_on',[]):
        if dep not in seen: errors.append(f"{item['name']}: unknown dependency {dep}")
# Check schemas parse
for p in (ROOT/'schemas').glob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f"bad schema {p.name}: {e}")
# crude duplicate-body guard: procedure blocks should not all be identical
procedures=[]
for name,t in texts:
    m=re.search(r'## Procedure\n\n(.*?)\n## Hard gates',t,re.S)
    if m: procedures.append(m.group(1).strip())
if len(set(procedures)) < int(0.9*len(procedures)):
    errors.append('too many duplicate procedure bodies')
if errors:
    print('FAILED')
    print('\n'.join('- '+e for e in errors))
    sys.exit(1)
print(f"OK: {len(skills)} skills, {len(list((ROOT/'schemas').glob('*.json')))} schemas, dependency references valid, procedures sufficiently specific.")
