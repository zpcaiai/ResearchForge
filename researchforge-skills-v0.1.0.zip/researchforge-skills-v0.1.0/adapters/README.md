# Upstream adapter strategy

Do not merge 34 codebases into one monolith. Wrap them behind capability adapters.

Recommended adapter groups:

- `literature`: paper-search-mcp, ToolUniverse, Zotero-like library adapters.
- `domain_tools`: Scientific Agent Skills / ToolUniverse skills loaded on demand.
- `autonomous_research`: AI-Scientist v1/v2, AgentLaboratory, CodeScientist, DeepScientist, EvoScientist invoked as optional execution backends or mined for patterns.
- `figures`: PaperBanana, AutoFigure-Edit, Visiomaster.
- `writing_review`: ARS, PaperSpine, Supervisor-Skills, Nature/Nature-Paper/Rebuttal skills.
- `slides`: ppt-master and scientific-slides/paper-to-PPT skills.
- `evaluation`: EurekAgent, SciAgentGym, DiscoveryWorld patterns.
- `skill_evolution`: SkillOpt/Arbor/EvoScientist patterns.

Every adapter should expose: `capability_id`, version, license metadata, required secrets, data access level, deterministic vs LLM-mediated behavior, input/output schema, resource class, sandbox requirement, timeout, retries, and provenance hooks.
