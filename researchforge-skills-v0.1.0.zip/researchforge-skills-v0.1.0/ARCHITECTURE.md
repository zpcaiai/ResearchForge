# ResearchForge — Paper → Innovation → Code → Paper → Defense PPT

## Goal

Given a paper URL, PDF or HTML, ResearchForge should automatically understand the paper, expand and verify the literature, discover several high-value innovation directions, allow a user to choose/merge/constrain them (or run auto mode), then execute a reproducible research project that outputs code, experiment evidence, a full paper with verified citations, publication figures, and a natively editable defense PPTX.

## Non-negotiable design choices

1. **Portfolio before commitment.** Generate and rank multiple directions; do not run the first plausible idea.
2. **Baseline before improvement.** Reproduce or explicitly replace the comparison baseline before claiming gains.
3. **Evidence graph as truth backbone.** Manuscript claims, figures and slides point to source citations or experiment result IDs.
4. **One research quest = one Git repo.** Branch/worktree routes preserve competing ideas and failed paths.
5. **Sandboxed code execution.** Generated code runs isolated; private evaluator/hidden tests stay outside agent view.
6. **Durable run ledger.** Every metric is traceable to code SHA, config, data, seed and environment.
7. **Human gate at innovation selection.** Guided mode requires explicit selection; auto mode still records an autonomous decision artifact.
8. **Claim-bounded writing.** Paper generation starts only after evidence is locked; citations are checked for support, not only existence.
9. **Editable artifacts.** Scientific diagrams prefer SVG; defense deck prefers native PPT objects.
10. **Offline skill evolution.** Skill changes use held-out evaluation and version promotion; no live self-rewriting in production.

## Runtime layers

- **Control plane:** orchestrator, research-progress-controller, project-repo-manager, budgets, human gates.
- **Knowledge/evidence plane:** paper model, citation resolver, literature/citation graph, claim-evidence graph, finding memory.
- **Innovation plane:** weakness/gap/analogy mining, portfolio generation, novelty/feasibility/ranking, user feedback.
- **Execution plane:** blueprint, experiment specs, sandbox, code/worktrees, tree search/mutation, debugger, ledger.
- **Evaluation plane:** hidden evaluator, research-eval-harness, data/statistical audits, meta-analysis.
- **Publication plane:** manuscript spine, drafting, citation audit, review/rebuttal, figures, PPT, release gate.
- **Provider/tool plane:** model-provider-router, tool-skill-router, domain-skill-loader, tool composition.

## State machine

```text
INGESTED
  -> MODELED
  -> EVIDENCE_EXPANDED
  -> IDEAS_READY
  -> HUMAN_SELECTION_REQUIRED (guided)
  -> DIRECTION_SELECTED
  -> BLUEPRINT_READY
  -> BASELINE_REPRODUCED
  -> EXPERIMENTING
  -> EVIDENCE_LOCKED
  -> WRITING
  -> REVIEWING
  -> DEFENSE_READY
  -> RELEASED
```

Transitions are gated; a later stage must not synthesize missing evidence to bypass an earlier failure.

## Suggested project layout produced by the future runtime

```text
research-project/
  .researchforge/
    research_state.json
    research_blueprint.yaml
    decisions.jsonl
    provenance.jsonl
    experiment_ledger.jsonl
    findings.jsonl
  source/
  literature/
  baseline/
  code/
  experiments/
  analysis/
  evidence/
  paper/
  figures/
  slides/
  review/
  release/
```

## Guided interaction

At the idea gate, present 3–5 directions with: novelty status, closest prior work, mechanism delta, minimum experiment, expected value, feasibility, compute cost, kill criteria, and biggest uncertainty. The user can choose one, merge several, change constraints or request more candidates; only the affected downstream artifacts should be recomputed.

## One-click UX target

A future CLI/API can expose:

```bash
researchforge run <paper-url-or-file> --mode guided
researchforge run <paper-url-or-file> --mode auto --budget-usd 100 --gpu-hours 20
researchforge resume <project-dir>
researchforge export <project-dir>
```

This ZIP is a **skills/specification package**, not that runtime implementation. `IMPLEMENTATION_PLAN.md` defines the recommended coding order.
